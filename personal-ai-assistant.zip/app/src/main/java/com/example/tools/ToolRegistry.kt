package com.example.tools

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import com.example.ai.AiToolDefinition
import com.example.ai.AiToolParameter
import com.example.apps.AppIndexer
import com.example.data.settings.SettingsRepository
import com.example.files.FileIndexWorker
import com.example.files.FileIndexer
import com.example.files.NaturalLanguageFileSearch
import com.example.memory.MemoryRepository
import com.example.patterns.PatternExecutor
import com.example.patterns.PatternRepository
import com.example.permissions.PermissionChecker
import com.example.permissions.PermissionId
import com.example.screen.ScreenUnderstandingRepository
import com.example.security.SecurityScanner
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

/**
 * Controlled Action/Tool Layer.
 * All AI tool calls pass through schema lookup, permission validation, safety checks,
 * and optional user confirmation before touching Android APIs.
 */
class ToolRegistry(
    private val context: Context,
    private val appIndexer: AppIndexer,
    private val fileIndexer: FileIndexer,
    private val fileSearch: NaturalLanguageFileSearch,
    private val screenRepo: ScreenUnderstandingRepository,
    private val permissionChecker: PermissionChecker,
    private val memoryRepository: MemoryRepository,
    private val settingsRepository: SettingsRepository,
    private val securityScanner: SecurityScanner,
    private val patternRepository: PatternRepository,
    private val patternExecutor: PatternExecutor
) {
    val descriptors: List<ToolDescriptor> = listOf(
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "open_app",
                description = "Launch an installed Android application by package name or app name.",
                parameters = listOf(
                    AiToolParameter("package_name", "string", "Exact Android package name if known (e.g. com.android.chrome)", required = false),
                    AiToolParameter("app_name", "string", "Human-readable app name to search and launch if package_name is unknown", required = false)
                )
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "search_apps",
                description = "Search indexed launchable Android applications by name, package, or category (e.g. browser, music, photo editing).",
                parameters = listOf(
                    AiToolParameter("query", "string", "App name or category query", required = true)
                )
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "get_app_info",
                description = "Get version, launchability, category, and permission summary for an installed app.",
                parameters = listOf(
                    AiToolParameter("package_or_name", "string", "Package name or app display name", required = true)
                )
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "search_files",
                description = "Search the local indexed files using natural language (filename, type, date like 'this week', or extracted text).",
                parameters = listOf(
                    AiToolParameter("query", "string", "Natural language file search query", required = true)
                )
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "search_index",
                description = "Query the local file index directly with optional category or extension filter.",
                parameters = listOf(
                    AiToolParameter("query", "string", "Search keywords", required = true),
                    AiToolParameter("category", "string", "Optional category: IMAGE, VIDEO, DOCUMENT, AUDIO, ARCHIVE, CODE", required = false)
                )
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "open_file",
                description = "Open a specific file from the local index using its URI string.",
                parameters = listOf(
                    AiToolParameter("uri", "string", "Content URI string returned by search_files or search_index", required = true),
                    AiToolParameter("mime_type", "string", "Optional MIME type", required = false)
                )
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "create_file_index",
                description = "Trigger an asynchronous local file index scan on authorized folders and accessible downloads.",
                parameters = listOf(
                    AiToolParameter("incremental", "boolean", "Whether to do a fast incremental scan (default true)", required = false)
                )
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "inspect_screen",
                description = "Inspect the active Android screen's package name, visible text, and clickable UI elements using Accessibility or Assist context.",
                parameters = emptyList()
            ),
            requiredPermission = PermissionId.ACCESSIBILITY
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "read_screen_text",
                description = "Read all visible text currently captured from the active Android screen.",
                parameters = emptyList()
            ),
            requiredPermission = PermissionId.ACCESSIBILITY
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "summarize_screen",
                description = "Retrieve structured screen context so the assistant can summarize or explain what is on the user's screen.",
                parameters = emptyList()
            ),
            requiredPermission = PermissionId.ACCESSIBILITY
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "click_screen_element",
                description = "Perform an official Accessibility ACTION_CLICK on a visible UI element matching the label or view id.",
                parameters = listOf(
                    AiToolParameter("element_label", "string", "Visible text, content description, or view id of the element to click", required = true)
                )
            ),
            requiredPermission = PermissionId.ACCESSIBILITY,
            isSensitive = true
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "open_settings",
                description = "Open an official Android Settings page.",
                parameters = listOf(
                    AiToolParameter(
                        "section",
                        "string",
                        "Settings section to open",
                        required = true,
                        enumValues = listOf("general", "wifi", "bluetooth", "display", "sound", "storage", "accessibility", "voice_input", "overlay", "apps", "battery", "security", "location", "language")
                    )
                )
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "find_games",
                description = "List installed Android games on the device and optionally launch one.",
                parameters = listOf(
                    AiToolParameter("query", "string", "Optional game name to filter or launch directly", required = false),
                    AiToolParameter("launch_if_single_match", "boolean", "Whether to launch immediately if one matching game is found", required = false)
                )
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "type_in_element",
                description = "Type text into a visible input box inside the currently open app or game using Accessibility.",
                parameters = listOf(
                    AiToolParameter("element_label", "string", "Hint, label, or view id of the input field (leave empty for focused box)", required = false),
                    AiToolParameter("text", "string", "Text to type into the field", required = true)
                )
            ),
            requiredPermission = PermissionId.ACCESSIBILITY,
            isSensitive = true
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "scroll_screen",
                description = "Scroll the active app, feed, or game menu via Accessibility.",
                parameters = listOf(
                    AiToolParameter(
                        "direction",
                        "string",
                        "Scroll direction: down, up, left, right, forward, backward",
                        required = true,
                        enumValues = listOf("down", "up", "left", "right", "forward", "backward")
                    )
                )
            ),
            requiredPermission = PermissionId.ACCESSIBILITY
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "tap_screen_coordinates",
                description = "Tap specific (x, y) pixel coordinates via official Accessibility gesture dispatch. Ideal for games and custom canvas buttons.",
                parameters = listOf(
                    AiToolParameter("x", "number", "Horizontal screen X coordinate in pixels", required = true),
                    AiToolParameter("y", "number", "Vertical screen Y coordinate in pixels", required = true),
                    AiToolParameter("reason", "string", "Short description of what UI or game button is at (x, y)", required = false)
                )
            ),
            requiredPermission = PermissionId.ACCESSIBILITY,
            isSensitive = true
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "swipe_screen",
                description = "Perform an Accessibility swipe gesture between (start_x, start_y) and (end_x, end_y) for games, sliders, or app navigation.",
                parameters = listOf(
                    AiToolParameter("start_x", "number", "Start X coordinate in pixels", required = true),
                    AiToolParameter("start_y", "number", "Start Y coordinate in pixels", required = true),
                    AiToolParameter("end_x", "number", "End X coordinate in pixels", required = true),
                    AiToolParameter("end_y", "number", "End Y coordinate in pixels", required = true),
                    AiToolParameter("duration_ms", "integer", "Swipe duration in milliseconds (default 320)", required = false)
                )
            ),
            requiredPermission = PermissionId.ACCESSIBILITY,
            isSensitive = true
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "get_device_status",
                description = "Read battery percentage, charging state, network online/offline status, free storage, and active foreground app.",
                parameters = emptyList()
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "clipboard_action",
                description = "Read or copy text to the Android clipboard.",
                parameters = listOf(
                    AiToolParameter("mode", "string", "Action: read or write", required = true, enumValues = listOf("read", "write")),
                    AiToolParameter("text", "string", "Text to copy when mode is write", required = false)
                )
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "open_url",
                description = "Open an https:// or http:// link in the user's browser.",
                parameters = listOf(
                    AiToolParameter("url", "string", "Valid https:// or http:// URL", required = true)
                )
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "scan_for_viruses",
                description = "Scan installed apps and local indexed files/APKs for malware indicators, high-risk permissions, sideloaded APKs, and disguised executables.",
                parameters = emptyList()
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "save_user_pattern",
                description = "Learn and save a repeatable multi-step user pattern/routine so the assistant can run it whenever the user asks.",
                parameters = listOf(
                    AiToolParameter("name", "string", "Short pattern name (e.g. Game Night)", required = true),
                    AiToolParameter("trigger_phrase", "string", "Trigger phrase user will say/type (e.g. game night)", required = true),
                    AiToolParameter("description", "string", "Summary of what the pattern does", required = false),
                    AiToolParameter("steps_json", "string", "JSON array of steps: [{\"action\":\"open_app|click_element|type_text|tap_coordinates|swipe|scroll|open_settings|scan_viruses|open_url|wait\",\"target\":\"...\",\"value\":\"...\"}]", required = true)
                )
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "list_user_patterns",
                description = "List all learned user patterns and routines saved on this device.",
                parameters = emptyList()
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "run_user_pattern",
                description = "Execute a previously learned user pattern/routine by its name or trigger phrase.",
                parameters = listOf(
                    AiToolParameter("trigger_or_name", "string", "Name or trigger phrase of the saved pattern", required = true)
                )
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "ask_user",
                description = "Ask the user a clarification or disambiguation question with selectable options (for example when multiple files or apps match).",
                parameters = listOf(
                    AiToolParameter("question", "string", "Clear question for the user", required = true),
                    AiToolParameter("options", "array", "Array of selectable option objects or strings with label and optional subtitle/value", required = true)
                )
            )
        ),
        ToolDescriptor(
            definition = AiToolDefinition(
                name = "perform_safe_action",
                description = "Perform a safe standard Android action such as web_search, set_timer, share_text, navigate_back, navigate_home, or save_memory.",
                parameters = listOf(
                    AiToolParameter(
                        "action_type",
                        "string",
                        "Safe action identifier",
                        required = true,
                        enumValues = listOf("web_search", "set_timer", "share_text", "navigate_back", "navigate_home", "save_memory")
                    ),
                    AiToolParameter("value", "string", "Search query, text to share, timer seconds, or memory fact", required = true),
                    AiToolParameter("label", "string", "Optional timer label or memory category", required = false)
                )
            )
        )
    )

    val aiDefinitions: List<AiToolDefinition> = descriptors.map { it.definition }

    suspend fun execute(
        toolName: String,
        argumentsJson: String,
        bypassConfirmation: Boolean = false
    ): ToolExecutionOutcome {
        val descriptor = descriptors.firstOrNull { it.definition.name == toolName }
            ?: return ToolExecutionOutcome.Executed(
                success = false,
                resultJson = errorJson("Unknown or disallowed tool '$toolName'."),
                summaryForUser = "Blocked unsupported tool '$toolName'."
            )

        val args = parseJsonObject(argumentsJson)
            ?: return ToolExecutionOutcome.Executed(
                success = false,
                resultJson = errorJson("Invalid JSON parameters passed to '$toolName'."),
                summaryForUser = "Invalid tool arguments received."
            )

        // Safety gate: reject any suspicious/blocked arguments
        if (containsUnsafePayload(args.toString())) {
            return ToolExecutionOutcome.Executed(
                success = false,
                resultJson = errorJson("Action blocked by security policy."),
                summaryForUser = "Blocked unsafe action parameters."
            )
        }

        // Permission check
        if (descriptor.requiredPermission == PermissionId.ACCESSIBILITY) {
            val hasAccessibility = permissionChecker.isAccessibilityEnabled()
            val hasAssistSnapshot = screenRepo.latestSnapshot.value != null
            val isActionTool = toolName in setOf(
                "click_screen_element",
                "type_in_element",
                "scroll_screen",
                "tap_screen_coordinates",
                "swipe_screen"
            )
            if (!hasAccessibility && !(!isActionTool && hasAssistSnapshot)) {
                val msg = if (isActionTool) {
                    "Accessibility Screen Reader is not enabled. Enable it in Permissions to interact with apps and games."
                } else {
                    "I can't inspect your screen yet. Please enable the Accessibility Screen Reader in Permissions."
                }
                return ToolExecutionOutcome.Executed(
                    success = false,
                    resultJson = errorJson(msg),
                    summaryForUser = msg
                )
            }
        }

        // Sensitive confirmation gate
        val confirmEnabled = settingsRepository.assistantSettingsFlow.first().confirmSensitiveActions
        if (descriptor.isSensitive && confirmEnabled && !bypassConfirmation) {
            val summary = when (toolName) {
                "type_in_element" -> "Type \"${args.optString("text").take(30)}\" into active screen input?"
                "tap_screen_coordinates" -> "Tap screen at (${args.optDouble("x").toInt()}, ${args.optDouble("y").toInt()})?"
                "swipe_screen" -> "Swipe on screen from (${args.optDouble("start_x").toInt()},${args.optDouble("start_y").toInt()}) to (${args.optDouble("end_x").toInt()},${args.optDouble("end_y").toInt()})?"
                else -> "Tap \"${args.optString("element_label").ifBlank { "UI element" }}\" on the active screen via Accessibility?"
            }
            return ToolExecutionOutcome.NeedsConfirmation(
                PendingConfirmation(
                    toolName = toolName,
                    argumentsJson = argumentsJson,
                    humanReadableSummary = summary
                )
            )
        }

        return when (toolName) {
            "open_app" -> handleOpenApp(args)
            "search_apps" -> handleSearchApps(args)
            "get_app_info" -> handleGetAppInfo(args)
            "find_games" -> handleFindGames(args)
            "search_files" -> handleSearchFiles(args)
            "search_index" -> handleSearchIndex(args)
            "open_file" -> handleOpenFile(args)
            "create_file_index" -> handleCreateFileIndex(args)
            "inspect_screen", "read_screen_text", "summarize_screen" -> handleInspectScreen(toolName)
            "click_screen_element" -> handleClickElement(args)
            "type_in_element" -> handleTypeInElement(args)
            "scroll_screen" -> handleScrollScreen(args)
            "tap_screen_coordinates" -> handleTapCoordinates(args)
            "swipe_screen" -> handleSwipeScreen(args)
            "open_settings" -> handleOpenSettings(args)
            "get_device_status" -> handleDeviceStatus()
            "clipboard_action" -> DeviceToolsHelper.handleClipboard(
                context = context,
                mode = args.optString("mode", "read"),
                text = args.optString("text", "")
            )
            "open_url" -> DeviceToolsHelper.openSafeUrl(context, args.optString("url", ""))
            "scan_for_viruses" -> handleScanForViruses()
            "save_user_pattern" -> handleSavePattern(args)
            "list_user_patterns" -> handleListPatterns()
            "run_user_pattern" -> handleRunPattern(args)
            "ask_user" -> handleAskUser(args)
            "perform_safe_action" -> handleSafeAction(args)
            else -> ToolExecutionOutcome.Executed(
                success = false,
                resultJson = errorJson("Tool '$toolName' is not implemented."),
                summaryForUser = "Unsupported tool."
            )
        }
    }

    private suspend fun handleOpenApp(args: JSONObject): ToolExecutionOutcome {
        val pkg = args.optString("package_name").trim()
        val appName = args.optString("app_name").trim()

        if (pkg.isBlank() && appName.isBlank()) {
            return ToolExecutionOutcome.Executed(
                success = false,
                resultJson = errorJson("Provide either package_name or app_name."),
                summaryForUser = "Missing app name or package."
            )
        }

        if (pkg.isNotBlank()) {
            val res = appIndexer.launchApp(pkg)
            return if (res.isSuccess) {
                ToolExecutionOutcome.Executed(
                    success = true,
                    resultJson = JSONObject().put("launched_package", pkg).toString(),
                    summaryForUser = "Opened $pkg"
                )
            } else {
                // Fallback: try searching by pkg as keyword
                val fallbackMatches = appIndexer.searchApps(appName.ifBlank { pkg })
                buildAppLookupOutcome(fallbackMatches, appName.ifBlank { pkg })
            }
        }

        val matches = appIndexer.searchApps(appName)
        return buildAppLookupOutcome(matches, appName)
    }

    private fun buildAppLookupOutcome(
        matches: List<com.example.data.db.InstalledAppEntity>,
        query: String
    ): ToolExecutionOutcome {
        if (matches.isEmpty()) {
            val msg = "No launchable app matching \"$query\" was found."
            return ToolExecutionOutcome.Executed(false, errorJson(msg), msg)
        }
        val exact = matches.firstOrNull { it.appName.equals(query, ignoreCase = true) }
        if (exact != null || matches.size == 1) {
            val target = exact ?: matches.first()
            val launch = appIndexer.launchApp(target.packageName)
            return if (launch.isSuccess) {
                ToolExecutionOutcome.Executed(
                    success = true,
                    resultJson = JSONObject()
                        .put("launched_app", target.appName)
                        .put("package_name", target.packageName)
                        .toString(),
                    summaryForUser = "Opened ${target.appName}"
                )
            } else {
                val err = launch.exceptionOrNull()?.localizedMessage ?: "Failed to launch ${target.appName}."
                ToolExecutionOutcome.Executed(false, errorJson(err), err)
            }
        }

        val arr = JSONArray()
        matches.take(8).forEach { app ->
            arr.put(
                JSONObject()
                    .put("app_name", app.appName)
                    .put("package_name", app.packageName)
                    .put("category", app.category)
            )
        }
        return ToolExecutionOutcome.Executed(
            success = true,
            resultJson = JSONObject().put("multiple_matches", arr).toString(),
            summaryForUser = "Found ${matches.size} matching apps for \"$query\"."
        )
    }

    private suspend fun handleSearchApps(args: JSONObject): ToolExecutionOutcome {
        val query = args.optString("query").trim()
        val matches = appIndexer.searchApps(query)
        val arr = JSONArray()
        matches.take(15).forEach { app ->
            arr.put(
                JSONObject()
                    .put("app_name", app.appName)
                    .put("package_name", app.packageName)
                    .put("version", app.versionName)
                    .put("category", app.category)
                    .put("launchable", app.isLaunchable)
            )
        }
        return ToolExecutionOutcome.Executed(
            success = true,
            resultJson = JSONObject().put("count", matches.size).put("apps", arr).toString(),
            summaryForUser = "Found ${matches.size} installed app(s) for \"$query\"."
        )
    }

    private suspend fun handleGetAppInfo(args: JSONObject): ToolExecutionOutcome {
        val query = args.optString("package_or_name").trim()
        if (query.isBlank()) {
            return ToolExecutionOutcome.Executed(false, errorJson("Missing package_or_name."), "Missing app query.")
        }
        val info = appIndexer.getAppInfo(query)
            ?: return ToolExecutionOutcome.Executed(
                false,
                errorJson("App \"$query\" was not found in the indexed launcher apps."),
                "App \"$query\" not found."
            )
        val obj = JSONObject()
            .put("app_name", info.appName)
            .put("package_name", info.packageName)
            .put("version_name", info.versionName)
            .put("version_code", info.versionCode)
            .put("category", info.category)
            .put("launchable", info.isLaunchable)
            .put("permissions_summary", info.permissionsSummary)
        return ToolExecutionOutcome.Executed(
            success = true,
            resultJson = obj.toString(),
            summaryForUser = "Loaded details for ${info.appName} (${info.versionName})."
        )
    }

    private suspend fun handleSearchFiles(args: JSONObject): ToolExecutionOutcome {
        val query = args.optString("query").trim()
        if (query.isBlank()) {
            return ToolExecutionOutcome.Executed(false, errorJson("Search query cannot be empty."), "Empty file query.")
        }
        val totalIndexed = fileIndexer.totalCountFlow.first()
        if (totalIndexed == 0 && !permissionChecker.hasFileAccess()) {
            val msg = "I can't access your files yet. Please grant folder access in Permissions or File Index."
            return ToolExecutionOutcome.Executed(false, errorJson(msg), msg)
        }
        val result = fileSearch.search(query, limit = 15)
        val arr = JSONArray()
        result.files.forEach { file ->
            arr.put(
                JSONObject()
                    .put("name", file.name)
                    .put("uri", file.uriString)
                    .put("path", file.displayPath)
                    .put("mime_type", file.mimeType)
                    .put("category", file.category)
                    .put("size_bytes", file.sizeBytes)
                    .put("modified_at", file.modifiedAt)
                    .put("snippet", file.extractedText.take(160))
            )
        }
        return ToolExecutionOutcome.Executed(
            success = true,
            resultJson = JSONObject()
                .put("count", result.files.size)
                .put("confidence", result.confidence.toDouble())
                .put("files", arr)
                .toString(),
            summaryForUser = "Found ${result.files.size} indexed file(s) matching \"$query\"."
        )
    }

    private suspend fun handleSearchIndex(args: JSONObject): ToolExecutionOutcome {
        val query = args.optString("query").trim()
        val category = args.optString("category").trim().uppercase().takeIf { it.isNotBlank() }
        val result = fileSearch.search(
            if (category != null) "$query $category" else query,
            limit = 20
        )
        val filtered = if (category != null) {
            result.files.filter { it.category == category }.ifEmpty { result.files }
        } else {
            result.files
        }
        val arr = JSONArray()
        filtered.forEach { file ->
            arr.put(
                JSONObject()
                    .put("name", file.name)
                    .put("uri", file.uriString)
                    .put("path", file.displayPath)
                    .put("mime_type", file.mimeType)
                    .put("category", file.category)
                    .put("size_bytes", file.sizeBytes)
            )
        }
        return ToolExecutionOutcome.Executed(
            success = true,
            resultJson = JSONObject().put("count", filtered.size).put("files", arr).toString(),
            summaryForUser = "Index returned ${filtered.size} item(s)."
        )
    }

    private fun handleOpenFile(args: JSONObject): ToolExecutionOutcome {
        val uri = args.optString("uri").trim()
        val mime = args.optString("mime_type").trim().ifBlank { "*/*" }
        if (uri.isBlank() || (!uri.startsWith("content://") && !uri.startsWith("file://"))) {
            return ToolExecutionOutcome.Executed(
                false,
                errorJson("Invalid file URI. Use a URI returned by search_files."),
                "Could not open invalid file reference."
            )
        }
        val res = fileIndexer.openFile(uri, mime)
        return if (res.isSuccess) {
            ToolExecutionOutcome.Executed(
                success = true,
                resultJson = JSONObject().put("opened_uri", uri).toString(),
                summaryForUser = "Opened file in Android viewer."
            )
        } else {
            val err = res.exceptionOrNull()?.localizedMessage
                ?: "Unable to open this file. Access may have been revoked."
            ToolExecutionOutcome.Executed(false, errorJson(err), err)
        }
    }

    private fun handleCreateFileIndex(args: JSONObject): ToolExecutionOutcome {
        val incremental = args.optBoolean("incremental", true)
        FileIndexWorker.enqueue(context, incremental = incremental)
        return ToolExecutionOutcome.Executed(
            success = true,
            resultJson = JSONObject()
                .put("started", true)
                .put("incremental", incremental)
                .toString(),
            summaryForUser = "Started background file index scan."
        )
    }

    private fun handleInspectScreen(toolName: String): ToolExecutionOutcome {
        val snap = screenRepo.refreshFromAccessibility()
            ?: return ToolExecutionOutcome.Executed(
                success = false,
                resultJson = errorJson("No screen snapshot is currently available. Make sure Accessibility Screen Reader is enabled."),
                summaryForUser = "No screen content captured yet."
            )
        val obj = JSONObject()
            .put("package_name", snap.packageName)
            .put("window_title", snap.windowTitle)
            .put("source", snap.source)
            .put("visible_text", snap.fullText.take(3500))

        if (toolName != "read_screen_text") {
            val elArr = JSONArray()
            snap.interactiveElements.take(35).forEach { el ->
                elArr.put(
                    JSONObject()
                        .put("label", el.displayLabel)
                        .put("type", if (el.isEditable) "input" else "button")
                        .put("view_id", el.viewId)
                )
            }
            obj.put("interactive_elements", elArr)
        }
        return ToolExecutionOutcome.Executed(
            success = true,
            resultJson = obj.toString(),
            summaryForUser = "Captured screen context from ${snap.packageName}."
        )
    }

    private fun handleClickElement(args: JSONObject): ToolExecutionOutcome {
        val label = args.optString("element_label").trim()
        val res = screenRepo.clickElementByQuery(label)
        return if (res.isSuccess) {
            val msg = res.getOrNull() ?: "Clicked \"$label\"."
            ToolExecutionOutcome.Executed(
                success = true,
                resultJson = JSONObject().put("clicked", label).put("message", msg).toString(),
                summaryForUser = msg
            )
        } else {
            val err = res.exceptionOrNull()?.localizedMessage ?: "Failed to click \"$label\"."
            ToolExecutionOutcome.Executed(false, errorJson(err), err)
        }
    }

    private fun handleOpenSettings(args: JSONObject): ToolExecutionOutcome {
        val section = args.optString("section").trim().lowercase()
        val intent = DeviceToolsHelper.resolveSettingsIntent(section, permissionChecker)

        return try {
            context.startActivity(intent)
            ToolExecutionOutcome.Executed(
                success = true,
                resultJson = JSONObject().put("opened_settings", section).toString(),
                summaryForUser = "Opened Android $section settings."
            )
        } catch (e: Exception) {
            val err = "Android could not open '$section' settings on this device."
            ToolExecutionOutcome.Executed(false, errorJson(err), err)
        }
    }

    private suspend fun handleFindGames(args: JSONObject): ToolExecutionOutcome {
        val query = args.optString("query").trim()
        val launchIfSingle = args.optBoolean("launch_if_single_match", false)
        val games = appIndexer.getInstalledGames()
        val matches = if (query.isBlank()) games else games.filter {
            it.appName.contains(query, ignoreCase = true) || it.packageName.contains(query, ignoreCase = true)
        }
        if (launchIfSingle && matches.size == 1) {
            val game = matches.first()
            val launch = appIndexer.launchApp(game.packageName)
            return if (launch.isSuccess) {
                ToolExecutionOutcome.Executed(
                    true,
                    JSONObject().put("launched_game", game.appName).put("package_name", game.packageName).toString(),
                    "Launched game ${game.appName}"
                )
            } else {
                val err = launch.exceptionOrNull()?.localizedMessage ?: "Failed to launch ${game.appName}."
                ToolExecutionOutcome.Executed(false, errorJson(err), err)
            }
        }
        val arr = JSONArray()
        matches.take(20).forEach { game ->
            arr.put(
                JSONObject()
                    .put("app_name", game.appName)
                    .put("package_name", game.packageName)
                    .put("version", game.versionName)
            )
        }
        return ToolExecutionOutcome.Executed(
            success = true,
            resultJson = JSONObject().put("count", matches.size).put("games", arr).toString(),
            summaryForUser = "Found ${matches.size} installed game(s)."
        )
    }

    private fun handleTypeInElement(args: JSONObject): ToolExecutionOutcome {
        val label = args.optString("element_label").trim()
        val text = args.optString("text")
        val res = screenRepo.typeInElement(label, text)
        return res.fold(
            onSuccess = { msg ->
                ToolExecutionOutcome.Executed(true, JSONObject().put("typed", true).put("message", msg).toString(), msg)
            },
            onFailure = { err ->
                val msg = err.localizedMessage ?: "Failed to type text."
                ToolExecutionOutcome.Executed(false, errorJson(msg), msg)
            }
        )
    }

    private fun handleScrollScreen(args: JSONObject): ToolExecutionOutcome {
        val direction = args.optString("direction", "down").trim()
        val res = screenRepo.scrollScreen(direction)
        return res.fold(
            onSuccess = { msg ->
                ToolExecutionOutcome.Executed(true, JSONObject().put("scrolled", direction).toString(), msg)
            },
            onFailure = { err ->
                val msg = err.localizedMessage ?: "Failed to scroll screen."
                ToolExecutionOutcome.Executed(false, errorJson(msg), msg)
            }
        )
    }

    private fun handleTapCoordinates(args: JSONObject): ToolExecutionOutcome {
        val x = args.optDouble("x", -1.0).toFloat()
        val y = args.optDouble("y", -1.0).toFloat()
        if (x < 0f || y < 0f) {
            return ToolExecutionOutcome.Executed(false, errorJson("Provide valid x and y coordinates."), "Invalid tap coordinates.")
        }
        val res = screenRepo.tapCoordinates(x, y)
        return res.fold(
            onSuccess = { msg ->
                ToolExecutionOutcome.Executed(true, JSONObject().put("tapped_x", x).put("tapped_y", y).toString(), msg)
            },
            onFailure = { err ->
                val msg = err.localizedMessage ?: "Tap gesture failed."
                ToolExecutionOutcome.Executed(false, errorJson(msg), msg)
            }
        )
    }

    private fun handleSwipeScreen(args: JSONObject): ToolExecutionOutcome {
        val sx = args.optDouble("start_x", -1.0).toFloat()
        val sy = args.optDouble("start_y", -1.0).toFloat()
        val ex = args.optDouble("end_x", -1.0).toFloat()
        val ey = args.optDouble("end_y", -1.0).toFloat()
        val duration = args.optLong("duration_ms", 320L)
        if (sx < 0f || sy < 0f || ex < 0f || ey < 0f) {
            return ToolExecutionOutcome.Executed(false, errorJson("Provide valid start and end coordinates."), "Invalid swipe coordinates.")
        }
        val res = screenRepo.swipeCoordinates(sx, sy, ex, ey, duration)
        return res.fold(
            onSuccess = { msg ->
                ToolExecutionOutcome.Executed(true, JSONObject().put("swiped", true).toString(), msg)
            },
            onFailure = { err ->
                val msg = err.localizedMessage ?: "Swipe gesture failed."
                ToolExecutionOutcome.Executed(false, errorJson(msg), msg)
            }
        )
    }

    private fun handleDeviceStatus(): ToolExecutionOutcome {
        val obj = DeviceToolsHelper.collectDeviceStatus(context, permissionChecker, screenRepo)
        return ToolExecutionOutcome.Executed(
            success = true,
            resultJson = obj.toString(),
            summaryForUser = "Battery ${obj.optInt("battery_percent")}%, Online=${obj.optBoolean("is_online")}, Free storage ${obj.optString("free_storage_gb")} GB."
        )
    }

    private suspend fun handleScanForViruses(): ToolExecutionOutcome {
        val report = securityScanner.runFullScan()
        val arr = JSONArray()
        report.findings.take(15).forEach { f ->
            arr.put(
                JSONObject()
                    .put("severity", f.severity.label)
                    .put("type", f.targetType.name)
                    .put("title", f.title)
                    .put("target", f.targetName)
                    .put("detail", f.detail)
                    .put("recommendation", f.recommendation)
            )
        }
        val obj = JSONObject()
            .put("status", report.overallStatusLabel)
            .put("apps_scanned", report.scannedAppsCount)
            .put("files_scanned", report.scannedFilesCount)
            .put("high_risk_count", report.highRiskCount)
            .put("suspicious_count", report.mediumRiskCount)
            .put("advisories_count", report.lowRiskCount)
            .put("findings", arr)
        return ToolExecutionOutcome.Executed(
            success = true,
            resultJson = obj.toString(),
            summaryForUser = "${report.overallStatusLabel} (${report.scannedAppsCount} apps, ${report.scannedFilesCount} files scanned)."
        )
    }

    private suspend fun handleSavePattern(args: JSONObject): ToolExecutionOutcome {
        val name = args.optString("name").trim()
        val trigger = args.optString("trigger_phrase").trim().ifBlank { name }
        val desc = args.optString("description").trim()
        val stepsJson = args.optString("steps_json").trim()
        if (name.isBlank() || stepsJson.isBlank()) {
            return ToolExecutionOutcome.Executed(
                false,
                errorJson("Provide both pattern name/trigger and steps_json array."),
                "Could not save incomplete pattern."
            )
        }
        val steps = PatternRepository.decodeSteps(stepsJson)
        if (steps.isEmpty()) {
            return ToolExecutionOutcome.Executed(
                false,
                errorJson("steps_json must contain at least one valid step object."),
                "Invalid pattern steps."
            )
        }
        val id = patternRepository.savePattern(name, trigger, desc, steps)
        return ToolExecutionOutcome.Executed(
            success = true,
            resultJson = JSONObject()
                .put("pattern_id", id)
                .put("name", name)
                .put("trigger_phrase", trigger)
                .put("steps_count", steps.size)
                .toString(),
            summaryForUser = "Learned pattern \"$name\" (${steps.size} steps) — trigger: \"$trigger\"."
        )
    }

    private suspend fun handleListPatterns(): ToolExecutionOutcome {
        val patterns = patternRepository.getAllPatterns()
        val arr = JSONArray()
        patterns.forEach { p ->
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("name", p.name)
                    .put("trigger_phrase", p.triggerPhrase)
                    .put("description", p.description)
                    .put("use_count", p.useCount)
                    .put("steps_count", PatternRepository.decodeSteps(p.stepsJson).size)
            )
        }
        return ToolExecutionOutcome.Executed(
            success = true,
            resultJson = JSONObject().put("count", patterns.size).put("patterns", arr).toString(),
            summaryForUser = "Found ${patterns.size} learned pattern(s)."
        )
    }

    private suspend fun handleRunPattern(args: JSONObject): ToolExecutionOutcome {
        val query = args.optString("trigger_or_name").trim()
        val pattern = patternRepository.findMatchingPattern(query)
            ?: return ToolExecutionOutcome.Executed(
                false,
                errorJson("No saved pattern matches \"$query\"."),
                "Pattern \"$query\" not found."
            )
        val report = patternExecutor.execute(pattern)
        val obj = JSONObject()
            .put("pattern_name", report.patternName)
            .put("succeeded_steps", report.succeededSteps)
            .put("total_steps", report.totalSteps)
            .put("logs", JSONArray(report.logs))
        return ToolExecutionOutcome.Executed(
            success = report.allSucceeded || report.succeededSteps > 0,
            resultJson = obj.toString(),
            summaryForUser = "Ran pattern \"${report.patternName}\": ${report.succeededSteps}/${report.totalSteps} steps succeeded."
        )
    }

    private fun handleAskUser(args: JSONObject): ToolExecutionOutcome {
        val question = args.optString("question").trim().ifBlank { "Which option would you like?" }
        val rawOptions = args.optJSONArray("options")
        val options = mutableListOf<AskUserOption>()
        if (rawOptions != null) {
            for (i in 0 until rawOptions.length()) {
                val item = rawOptions.opt(i)
                when (item) {
                    is JSONObject -> {
                        val label = item.optString("label").ifBlank { item.optString("name") }
                        val subtitle = item.optString("subtitle").ifBlank { item.optString("path") }
                        val value = item.optString("value").ifBlank { label }
                        if (label.isNotBlank()) {
                            options.add(AskUserOption("opt_$i", label, subtitle, value))
                        }
                    }
                    is String -> {
                        if (item.isNotBlank()) {
                            options.add(AskUserOption("opt_$i", item, "", item))
                        }
                    }
                }
            }
        }
        return ToolExecutionOutcome.Executed(
            success = true,
            resultJson = JSONObject().put("awaiting_user_choice", true).toString(),
            summaryForUser = "Waiting for your selection.",
            askUserQuestion = question,
            askUserOptions = options
        )
    }

    private suspend fun handleSafeAction(args: JSONObject): ToolExecutionOutcome {
        val actionType = args.optString("action_type").trim().lowercase()
        val value = args.optString("value").trim()
        val label = args.optString("label").trim()

        return when (actionType) {
            "web_search" -> {
                try {
                    val intent = Intent(Intent.ACTION_WEB_SEARCH).apply {
                        putExtra(SearchManager.QUERY, value)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    ToolExecutionOutcome.Executed(
                        true,
                        JSONObject().put("web_search", value).toString(),
                        "Searched web for \"$value\"."
                    )
                } catch (_: Exception) {
                    val urlIntent = Intent(
                        Intent.ACTION_VIEW,
                        android.net.Uri.parse("https://www.google.com/search?q=${android.net.Uri.encode(value)}")
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(urlIntent)
                    ToolExecutionOutcome.Executed(
                        true,
                        JSONObject().put("web_search", value).toString(),
                        "Opened browser search for \"$value\"."
                    )
                }
            }
            "set_timer" -> {
                val seconds = value.toIntOrNull()?.coerceIn(1, 86400)
                    ?: return ToolExecutionOutcome.Executed(
                        false,
                        errorJson("Timer duration must be a valid number of seconds."),
                        "Invalid timer duration."
                    )
                return try {
                    val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                        putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                        if (label.isNotBlank()) putExtra(AlarmClock.EXTRA_MESSAGE, label)
                        putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    ToolExecutionOutcome.Executed(
                        true,
                        JSONObject().put("timer_seconds", seconds).toString(),
                        "Opened clock to set a ${seconds}s timer."
                    )
                } catch (_: Exception) {
                    val err = "No clock app on this device handled timer creation."
                    ToolExecutionOutcome.Executed(false, errorJson(err), err)
                }
            }
            "share_text" -> {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, value)
                }
                val chooser = Intent.createChooser(intent, "Share via")
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(chooser)
                ToolExecutionOutcome.Executed(
                    true,
                    JSONObject().put("shared", true).toString(),
                    "Opened Android share sheet."
                )
            }
            "navigate_back" -> {
                val res = screenRepo.performGlobalNavigation("back")
                if (res.isSuccess) {
                    ToolExecutionOutcome.Executed(true, JSONObject().put("navigated", "back").toString(), "Navigated back.")
                } else {
                    val err = res.exceptionOrNull()?.localizedMessage ?: "Back navigation unavailable."
                    ToolExecutionOutcome.Executed(false, errorJson(err), err)
                }
            }
            "navigate_home" -> {
                val res = screenRepo.performGlobalNavigation("home")
                if (res.isSuccess) {
                    ToolExecutionOutcome.Executed(true, JSONObject().put("navigated", "home").toString(), "Returned to Home screen.")
                } else {
                    val err = res.exceptionOrNull()?.localizedMessage ?: "Home navigation unavailable."
                    ToolExecutionOutcome.Executed(false, errorJson(err), err)
                }
            }
            "save_memory" -> {
                val saved = memoryRepository.saveMemory(value, label.ifBlank { "User Note" })
                if (saved) {
                    ToolExecutionOutcome.Executed(
                        true,
                        JSONObject().put("memory_saved", value).toString(),
                        "Saved memory: \"$value\""
                    )
                } else {
                    val msg = "Memory is disabled or text contained sensitive credentials."
                    ToolExecutionOutcome.Executed(false, errorJson(msg), msg)
                }
            }
            else -> ToolExecutionOutcome.Executed(
                false,
                errorJson("Unsupported safe action '$actionType'."),
                "Unsupported action."
            )
        }
    }

    private fun parseJsonObject(raw: String): JSONObject? =
        try {
            if (raw.isBlank()) JSONObject() else JSONObject(raw)
        } catch (_: Exception) {
            null
        }

    private fun containsUnsafePayload(payload: String): Boolean {
        val lower = payload.lowercase()
        val blocked = listOf("/system/bin/sh", "su -c", "chmod ", "rm -rf", "pm install", "pm uninstall")
        return blocked.any { lower.contains(it) }
    }

    private fun errorJson(message: String): String =
        JSONObject().put("error", message).toString()
}
