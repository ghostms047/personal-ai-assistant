package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.ui.navigation.AboutRoute
import com.example.ui.navigation.ApiKeySettingsRoute
import com.example.ui.navigation.AppsRoute
import com.example.ui.navigation.AssistantSettingsRoute
import com.example.ui.navigation.ChatRoute
import com.example.ui.navigation.FileIndexRoute
import com.example.ui.navigation.FileSearchRoute
import com.example.ui.navigation.FloatingConfigRoute
import com.example.ui.navigation.HomeRoute
import com.example.ui.navigation.MemoryRoute
import com.example.ui.navigation.ModelsAndSpeechRoute
import com.example.ui.navigation.PatternsRoute
import com.example.ui.navigation.PermissionsRoute
import com.example.ui.navigation.ScreenUnderstandingRoute
import com.example.ui.navigation.SecurityScanRoute
import com.example.ui.navigation.SetupRoute
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.ApiKeySettingsScreen
import com.example.ui.screens.AppsScreen
import com.example.ui.screens.AssistantSettingsScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.FileIndexScreen
import com.example.ui.screens.FileSearchScreen
import com.example.ui.screens.FloatingConfigScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MemoryScreen
import com.example.ui.screens.ModelsAndSpeechScreen
import com.example.ui.screens.PatternsScreen
import com.example.ui.screens.PermissionsScreen
import com.example.ui.screens.ScreenUnderstandingScreen
import com.example.ui.screens.SecurityScanScreen
import com.example.ui.screens.SetupScreen
import com.example.ui.theme.PersonalAiTheme
import com.example.ui.theme.isDarkAppearance
import com.example.ui.viewmodel.PersonalAiViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: PersonalAiViewModel by viewModels {
        PersonalAiViewModel.Factory(application)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val initialDeepRoute = intent?.getStringExtra(EXTRA_TARGET_ROUTE)

        setContent {
            val assistantSettings by viewModel.assistantSettings.collectAsStateWithLifecycle()
            val uiNotice by viewModel.uiNotice.collectAsStateWithLifecycle()
            val snackbarHostState = remember { SnackbarHostState() }

            LaunchedEffect(uiNotice) {
                val msg = uiNotice
                if (!msg.isNullOrBlank()) {
                    snackbarHostState.showSnackbar(msg)
                    viewModel.clearUiNotice()
                }
            }

            val darkTheme = assistantSettings.themeMode.isDarkAppearance(isSystemInDarkTheme())
            LaunchedEffect(darkTheme) {
                val barStyle = if (darkTheme) {
                    SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
                } else {
                    SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
                }
                enableEdgeToEdge(statusBarStyle = barStyle, navigationBarStyle = barStyle)
            }

            PersonalAiTheme(
                themeMode = assistantSettings.themeMode,
                darkTheme = darkTheme,
                dynamicColor = assistantSettings.dynamicColor
            ) {
                Scaffold(
                    snackbarHost = { SnackbarHost(snackbarHostState) },
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(bottom = innerPadding.calculateBottomPadding())
                    ) {
                        PersonalAiNavHost(
                            viewModel = viewModel,
                            onboardingCompleted = assistantSettings.onboardingCompleted,
                            initialDeepRoute = initialDeepRoute
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshSystemState()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
    }

    companion object {
        const val EXTRA_TARGET_ROUTE = "target_route"
        const val EXTRA_ROUTE_CHAT = "chat"
        const val EXTRA_ROUTE_API_KEYS = "api_keys"
        const val EXTRA_ROUTE_PERMISSIONS = "permissions"
    }
}

@Composable
private fun PersonalAiNavHost(
    viewModel: PersonalAiViewModel,
    onboardingCompleted: Boolean,
    initialDeepRoute: String?
) {
    val navController = rememberNavController()
    val startDestination: Any = when {
        initialDeepRoute == MainActivity.EXTRA_ROUTE_CHAT -> ChatRoute
        initialDeepRoute == MainActivity.EXTRA_ROUTE_API_KEYS -> ApiKeySettingsRoute
        initialDeepRoute == MainActivity.EXTRA_ROUTE_PERMISSIONS -> PermissionsRoute
        !onboardingCompleted -> SetupRoute
        else -> HomeRoute
    }

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable<SetupRoute> {
            SetupScreen(
                viewModel = viewModel,
                onSetupFinished = {
                    navController.navigate(HomeRoute) {
                        popUpTo<SetupRoute> { inclusive = true }
                    }
                }
            )
        }
        composable<HomeRoute> {
            HomeScreen(
                viewModel = viewModel,
                onNavigateToChat = { navController.navigate(ChatRoute) },
                onNavigateToAssistantSettings = { navController.navigate(AssistantSettingsRoute) },
                onNavigateToApiKeys = { navController.navigate(ApiKeySettingsRoute) },
                onNavigateToPermissions = { navController.navigate(PermissionsRoute) },
                onNavigateToFileIndex = { navController.navigate(FileIndexRoute) },
                onNavigateToFileSearch = { navController.navigate(FileSearchRoute) },
                onNavigateToApps = { navController.navigate(AppsRoute) },
                onNavigateToScreenUnderstanding = { navController.navigate(ScreenUnderstandingRoute) },
                onNavigateToFloatingConfig = { navController.navigate(FloatingConfigRoute) },
                onNavigateToModelsAndSpeech = { navController.navigate(ModelsAndSpeechRoute) },
                onNavigateToSecurityScan = { navController.navigate(SecurityScanRoute) },
                onNavigateToPatterns = { navController.navigate(PatternsRoute) },
                onNavigateToMemory = { navController.navigate(MemoryRoute) },
                onNavigateToAbout = { navController.navigate(AboutRoute) }
            )
        }
        composable<ChatRoute> {
            ChatScreen(
                viewModel = viewModel,
                onBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(HomeRoute)
                    }
                },
                onOpenApiKeySettings = { navController.navigate(ApiKeySettingsRoute) },
                onOpenModelsAndSpeech = { navController.navigate(ModelsAndSpeechRoute) },
                onOpenAssistantSettings = { navController.navigate(AssistantSettingsRoute) },
                onOpenSecurityScan = { navController.navigate(SecurityScanRoute) },
                onOpenPatterns = { navController.navigate(PatternsRoute) }
            )
        }
        composable<AssistantSettingsRoute> {
            AssistantSettingsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenMemory = { navController.navigate(MemoryRoute) },
                onOpenSetup = { navController.navigate(SetupRoute) }
            )
        }
        composable<ApiKeySettingsRoute> {
            ApiKeySettingsScreen(
                viewModel = viewModel,
                onBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(HomeRoute)
                    }
                },
                onOpenModelsAndSpeech = { navController.navigate(ModelsAndSpeechRoute) }
            )
        }
        composable<ModelsAndSpeechRoute> {
            ModelsAndSpeechScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenApiKeySettings = { navController.navigate(ApiKeySettingsRoute) }
            )
        }
        composable<PermissionsRoute> {
            PermissionsScreen(
                viewModel = viewModel,
                onBack = {
                    if (!navController.popBackStack()) {
                        navController.navigate(HomeRoute)
                    }
                }
            )
        }
        composable<FileIndexRoute> {
            FileIndexScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenFileSearch = { navController.navigate(FileSearchRoute) }
            )
        }
        composable<FileSearchRoute> {
            FileSearchScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onOpenFileIndex = { navController.navigate(FileIndexRoute) }
            )
        }
        composable<AppsRoute> {
            AppsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable<ScreenUnderstandingRoute> {
            ScreenUnderstandingScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() },
                onAskAboutScreen = { prompt ->
                    viewModel.sendMessage(prompt, attachScreen = true)
                    navController.navigate(ChatRoute)
                }
            )
        }
        composable<FloatingConfigRoute> {
            FloatingConfigScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable<MemoryRoute> {
            MemoryScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable<SecurityScanRoute> {
            SecurityScanScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable<PatternsRoute> {
            PatternsScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable<AboutRoute> {
            AboutScreen(
                onBack = { navController.popBackStack() },
                onOpenPermissions = { navController.navigate(PermissionsRoute) },
                onOpenMemory = { navController.navigate(MemoryRoute) }
            )
        }
    }
}
