package com.example.floating

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.WindowManager
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.PersonalAiApp
import com.example.R
import com.example.assistant.AssistantOrchestrator
import com.example.data.settings.FloatingSettings
import com.example.data.settings.ThemeMode
import com.example.ui.theme.PersonalAiTheme
import com.example.ui.theme.isDarkAppearance
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class FloatingAssistantService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var windowManager: WindowManager? = null
    private var overlayView: ComposeView? = null
    private var layoutParams: WindowManager.LayoutParams? = null
    private var lifecycleOwner: FloatingOverlayLifecycleOwner? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private val expandedState = mutableStateOf(false)
    private val listeningState = mutableStateOf(false)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunningFlow.value = true
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        startForegroundNotification()
        attachOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_EXPAND) {
            setExpanded(true)
        }
        return START_STICKY
    }

    override fun onDestroy() {
        isRunningFlow.value = false
        speechRecognizer?.destroy()
        speechRecognizer = null
        overlayView?.let { view ->
            try {
                windowManager?.removeView(view)
            } catch (_: Exception) {
            }
        }
        overlayView = null
        lifecycleOwner?.onDestroy()
        lifecycleOwner = null
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun startForegroundNotification() {
        val initialTheme = ThemeMode.SYSTEM
        startForegroundNotificationWithTheme(initialTheme)
    }

    private fun buildFloatingNotification(themeMode: ThemeMode): Notification {
        val nm = NotificationManagerCompat.from(this)
        val channel = NotificationChannelCompat.Builder(
            CHANNEL_ID,
            NotificationManagerCompat.IMPORTANCE_LOW
        )
            .setName(getString(R.string.floating_notification_channel_name))
            .build()
        nm.createNotificationChannel(channel)

        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, FloatingAssistantService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val accentArgb = when (themeMode) {
            ThemeMode.PERSIAN -> 0xFF007A78.toInt()
            ThemeMode.NEON -> 0xFF00F5D4.toInt()
            else -> 0xFF1D4ED8.toInt()
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.floating_notification_title))
            .setContentText(getString(R.string.floating_notification_text))
            .setSmallIcon(R.mipmap.ic_launcher)
            .setColor(accentArgb)
            .setContentIntent(openIntent)
            .addAction(0, "Close Overlay", stopIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun startForegroundNotificationWithTheme(themeMode: ThemeMode) {
        val notification = buildFloatingNotification(themeMode)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun attachOverlay() {
        val app = applicationContext as PersonalAiApp
        val container = app.container
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 260
        }
        layoutParams = params

        serviceScope.launch {
            val floatCfg = container.settingsRepository.floatingSettingsFlow.first()
            if (floatCfg.startOnRightEdge) {
                val width = resources.displayMetrics.widthPixels
                params.x = (width - 200).coerceAtLeast(24)
                overlayView?.let { windowManager?.updateViewLayout(it, params) }
            }
        }

        serviceScope.launch {
            container.settingsRepository.assistantSettingsFlow.collect { cfg ->
                runCatching {
                    NotificationManagerCompat.from(this@FloatingAssistantService)
                        .notify(NOTIFICATION_ID, buildFloatingNotification(cfg.themeMode))
                }
            }
        }

        val owner = FloatingOverlayLifecycleOwner().also { it.onCreate() }
        lifecycleOwner = owner

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(owner)
            setViewTreeSavedStateRegistryOwner(owner)
            setViewTreeViewModelStoreOwner(owner)

            setContent {
                val aiSettings by container.settingsRepository.aiSettingsFlow.collectAsState(
                    initial = com.example.data.settings.AiSettings()
                )
                val assistantSettings by container.settingsRepository.assistantSettingsFlow.collectAsState(
                    initial = com.example.data.settings.AssistantSettings()
                )
                val floatingSettings by container.settingsRepository.floatingSettingsFlow.collectAsState(
                    initial = FloatingSettings()
                )
                val messages by container.orchestrator
                    .observeMessages(AssistantOrchestrator.FLOATING_SESSION_ID)
                    .collectAsState(initial = emptyList())
                val isProcessing by container.orchestrator.isProcessing.collectAsState()
                val activeStatus by container.orchestrator.activeToolStatus.collectAsState()

                val systemDark = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                    android.content.res.Configuration.UI_MODE_NIGHT_YES
                val isDark = assistantSettings.themeMode.isDarkAppearance(systemDark)

                PersonalAiTheme(
                    themeMode = assistantSettings.themeMode,
                    darkTheme = isDark,
                    dynamicColor = assistantSettings.dynamicColor
                ) {
                    if (!expandedState.value) {
                        FloatingBubbleView(
                            settings = floatingSettings,
                            isProcessing = isProcessing,
                            onTapExpand = { setExpanded(true) },
                            onDragDelta = { dx, dy -> moveOverlayBy(dx, dy) }
                        )
                    } else {
                        FloatingPanelView(
                            messages = messages,
                            isProcessing = isProcessing,
                            activeToolStatus = activeStatus,
                            hasApiKey = aiSettings.hasApiKey,
                            hasMicPermission = container.permissionChecker.hasMicrophonePermission(),
                            isListening = listeningState.value,
                            onSendMessage = { text, attachScreen ->
                                serviceScope.launch {
                                    container.orchestrator.submitUserMessage(
                                        userText = text,
                                        sessionId = AssistantOrchestrator.FLOATING_SESSION_ID,
                                        attachScreenSnapshot = attachScreen
                                    )
                                    if (floatingSettings.autoMinimizeAfterAction) {
                                        setExpanded(false)
                                    }
                                }
                            },
                            onSelectOption = { msgId, option ->
                                serviceScope.launch {
                                    container.orchestrator.selectDisambiguationOption(
                                        messageId = msgId,
                                        option = option,
                                        sessionId = AssistantOrchestrator.FLOATING_SESSION_ID
                                    )
                                }
                            },
                            onConfirmAction = { msgId, conf, ok ->
                                serviceScope.launch {
                                    container.orchestrator.resolveConfirmation(
                                        messageId = msgId,
                                        confirmation = conf,
                                        approved = ok,
                                        sessionId = AssistantOrchestrator.FLOATING_SESSION_ID
                                    )
                                }
                            },
                            onToggleListening = {
                                if (!container.permissionChecker.hasMicrophonePermission()) {
                                    openAppToRoute(MainActivity.EXTRA_ROUTE_PERMISSIONS)
                                } else {
                                    toggleSpeechInput()
                                }
                            },
                            onOpenFullApp = {
                                setExpanded(false)
                                openAppToRoute(MainActivity.EXTRA_ROUTE_CHAT)
                            },
                            onOpenApiKeySettings = {
                                setExpanded(false)
                                openAppToRoute(MainActivity.EXTRA_ROUTE_API_KEYS)
                            },
                            onMinimize = { setExpanded(false) },
                            onClose = {
                                serviceScope.launch {
                                    container.settingsRepository.updateFloatingSettings {
                                        it.copy(enabled = false)
                                    }
                                }
                                stopSelf()
                            },
                            onDragHeaderDelta = { dx, dy -> moveOverlayBy(dx, dy) }
                        )
                    }
                }
            }
        }

        overlayView = composeView
        windowManager?.addView(composeView, params)
    }

    private fun setExpanded(expanded: Boolean) {
        expandedState.value = expanded
        val params = layoutParams ?: return
        val view = overlayView ?: return
        params.flags = if (expanded) {
            // Allow IME keyboard input when panel is expanded
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
        try {
            windowManager?.updateViewLayout(view, params)
        } catch (_: Exception) {
        }
    }

    private fun moveOverlayBy(dx: Float, dy: Float) {
        val params = layoutParams ?: return
        val view = overlayView ?: return
        params.x += dx.roundToInt()
        params.y += dy.roundToInt()
        try {
            windowManager?.updateViewLayout(view, params)
        } catch (_: Exception) {
        }
    }

    private fun toggleSpeechInput() {
        if (listeningState.value) {
            speechRecognizer?.stopListening()
            listeningState.value = false
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        val recognizer = speechRecognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
            speechRecognizer = it
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                listeningState.value = true
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                listeningState.value = false
            }

            override fun onError(error: Int) {
                listeningState.value = false
            }

            override fun onResults(results: Bundle?) {
                listeningState.value = false
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?.trim()
                    .orEmpty()
                if (spoken.isNotBlank()) {
                    val container = (applicationContext as PersonalAiApp).container
                    serviceScope.launch {
                        container.orchestrator.submitUserMessage(
                            userText = spoken,
                            sessionId = AssistantOrchestrator.FLOATING_SESSION_ID
                        )
                    }
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer.startListening(intent)
    }

    private fun openAppToRoute(routeExtra: String) {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(MainActivity.EXTRA_TARGET_ROUTE, routeExtra)
        }
        startActivity(intent)
    }

    companion object {
        private const val CHANNEL_ID = "personal_ai_floating_channel"
        private const val NOTIFICATION_ID = 4101
        const val ACTION_STOP = "com.example.floating.ACTION_STOP"
        const val ACTION_EXPAND = "com.example.floating.ACTION_EXPAND"

        val isRunningFlow = MutableStateFlow(false)

        fun start(context: Context, expandImmediately: Boolean = false) {
            if (!Settings.canDrawOverlays(context)) return
            val intent = Intent(context, FloatingAssistantService::class.java).apply {
                if (expandImmediately) action = ACTION_EXPAND
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FloatingAssistantService::class.java))
        }
    }
}
