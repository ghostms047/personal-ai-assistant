package com.example.data.db

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "indexed_files",
    indices = [
        Index(value = ["uriString"], unique = true),
        Index(value = ["name"]),
        Index(value = ["category"]),
        Index(value = ["modifiedAt"]),
        Index(value = ["extension"])
    ]
)
data class IndexedFileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val uriString: String,
    val name: String,
    val displayPath: String,
    val folderName: String,
    val extension: String,
    val mimeType: String,
    val sizeBytes: Long,
    val createdAt: Long,
    val modifiedAt: Long,
    val category: String,
    val extractedText: String,
    val sourceType: String,
    val lastIndexedAt: Long
)

@Entity(tableName = "index_progress")
data class IndexProgressEntity(
    @PrimaryKey val id: Int = 1,
    val status: String = "IDLE",
    val totalIndexed: Int = 0,
    val imagesCount: Int = 0,
    val videosCount: Int = 0,
    val documentsCount: Int = 0,
    val audioCount: Int = 0,
    val otherCount: Int = 0,
    val currentFolder: String = "",
    val lastScanTimestamp: Long = 0L,
    val errorMessage: String? = null
)

@Entity(
    tableName = "installed_apps",
    indices = [Index(value = ["appName"])]
)
data class InstalledAppEntity(
    @PrimaryKey val packageName: String,
    val appName: String,
    val versionName: String,
    val versionCode: Long,
    val isLaunchable: Boolean,
    val category: String,
    val permissionsSummary: String,
    val lastUpdatedAt: Long
)

@Entity(
    tableName = "chat_messages",
    indices = [Index(value = ["sessionId", "timestamp"])]
)
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val sessionId: String,
    val role: String,
    val content: String,
    val toolName: String? = null,
    val toolArgsJson: String? = null,
    val toolResultJson: String? = null,
    val toolSuccess: Boolean? = null,
    val optionsJson: String? = null,
    val pendingConfirmationJson: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val fact: String,
    val category: String = "Preference",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "cached_provider_models",
    indices = [Index(value = ["providerId", "modelId"], unique = true)]
)
data class CachedProviderModelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val providerId: String,
    val modelId: String,
    val displayName: String,
    val capability: String,
    val fetchedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "downloaded_models",
    indices = [Index(value = ["downloadUrl"], unique = true)]
)
data class DownloadedModelEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val fileName: String,
    val downloadUrl: String,
    val localPath: String = "",
    val category: String = "Open-Weight",
    val totalBytes: Long = 0L,
    val downloadedBytes: Long = 0L,
    val status: String = "QUEUED",
    val sha256: String = "",
    val errorMessage: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "chat_sessions",
    indices = [Index(value = ["updatedAt"])]
)
data class ChatSessionEntity(
    @PrimaryKey val sessionId: String,
    val title: String,
    val lastMessagePreview: String = "",
    val messageCount: Int = 0,
    val isPinned: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "user_patterns",
    indices = [Index(value = ["triggerPhrase"]), Index(value = ["updatedAt"])]
)
data class UserPatternEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0L,
    val name: String,
    val triggerPhrase: String,
    val description: String = "",
    val stepsJson: String,
    val useCount: Int = 0,
    val lastUsedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

