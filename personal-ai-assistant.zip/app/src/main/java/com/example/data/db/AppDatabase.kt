package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        IndexedFileEntity::class,
        IndexProgressEntity::class,
        InstalledAppEntity::class,
        ChatMessageEntity::class,
        MemoryEntity::class,
        CachedProviderModelEntity::class,
        DownloadedModelEntity::class,
        ChatSessionEntity::class,
        UserPatternEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun indexedFileDao(): IndexedFileDao
    abstract fun indexProgressDao(): IndexProgressDao
    abstract fun installedAppDao(): InstalledAppDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun memoryDao(): MemoryDao
    abstract fun cachedProviderModelDao(): CachedProviderModelDao
    abstract fun downloadedModelDao(): DownloadedModelDao
    abstract fun chatSessionDao(): ChatSessionDao
    abstract fun userPatternDao(): UserPatternDao

    companion object {
        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "personal_ai_local.db"
            )
                .fallbackToDestructiveMigration(dropAllTables = true)
                .build()
    }
}
