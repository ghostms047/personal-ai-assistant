package com.example.assistant

import android.Manifest
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.PersonalAiApp
import com.example.R
import com.example.data.settings.ThemeMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/**
 * Foreground microphone service that continuously listens for the user's chosen AI name
 * (e.g. "Hey Nova" or "سارا") using official Android SpeechRecognizer and wakes
 * the Google Assistant / Gemini-style bottom overlay (AssistActivity).
 */
class WakeWordService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null

    private var currentAssistantName: String = "Personal AI"
    private var currentThemeMode: ThemeMode = ThemeMode.SYSTEM
    private var isDestroyed = false
    private var isListeningCycleActive = false
    private var lastWakeTimestampMs = 0L

    private val restartRunnable = Runnable {
        if (!isDestroyed && !isAssistantOverlayActive.value) {
            beginListeningCycle()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!hasMicPermission(this)) {
            stopSelf()
            return
        }
        isRunningFlow.value = true
        startForegroundNotification()

        val container = (applicationContext as PersonalAiApp).container
        serviceScope.launch {
            container.settingsRepository.assistantSettingsFlow.collect { settings ->
                currentAssistantName = settings.assistantName.ifBlank { "Personal AI" }
                currentThemeMode = settings.themeMode
                if (!settings.wakeWordEnabled) {
                    stopSelf()
                    return@collect
                }
                updateNotification()
            }
        }

        serviceScope.launch {
            isAssistantOverlayActive.collect { active ->
                if (active) {
                    pauseRecognizer()
                } else if (!isDestroyed) {
                    scheduleRestart(delayMs = 700L)
                }
            }
        }

        beginListeningCycle()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        isDestroyed = true
        isRunningFlow.value = false
        isListeningFlow.value = false
        mainHandler.removeCallbacks(restartRunnable)
        destroyRecognizer()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun beginListeningCycle() {
        if (isDestroyed || isAssistantOverlayActive.value) return
        if (!hasMicPermission(this) || !SpeechRecognizer.isRecognitionAvailable(this)) {
            isListeningFlow.value = false
            return
        }
        if (isListeningCycleActive) return

        val recognizer = speechRecognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
            speechRecognizer = it
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                isListeningCycleActive = true
                isListeningFlow.value = true
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                isListeningCycleActive = false
            }

            override fun onError(error: Int) {
                isListeningCycleActive = false
                isListeningFlow.value = false
                if (!isDestroyed && !isAssistantOverlayActive.value) {
                    val delay = when (error) {
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 900L
                        SpeechRecognizer.ERROR_AUDIO -> 1500L
                        else -> 450L
                    }
                    if (error == SpeechRecognizer.ERROR_CLIENT || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                        destroyRecognizer()
                    }
                    scheduleRestart(delay)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val spoken = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (spoken.isNotBlank()) {
                    lastHeardTextFlow.value = spoken
                    // Wake immediately on partial hit if user only said the wake name
                    val match = WakeWordMatcher.matchWakePhrase(spoken, currentAssistantName)
                    if (match != null && match.remainingCommand.isBlank()) {
                        triggerWakeOverlay(match)
                    }
                }
            }

            override fun onResults(results: Bundle?) {
                isListeningCycleActive = false
                val spoken = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (spoken.isNotBlank()) {
                    lastHeardTextFlow.value = spoken
                    val match = WakeWordMatcher.matchWakePhrase(spoken, currentAssistantName)
                    if (match != null) {
                        triggerWakeOverlay(match)
                        return
                    }
                }
                if (!isDestroyed && !isAssistantOverlayActive.value) {
                    scheduleRestart(350L)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        runCatching {
            recognizer.startListening(intent)
        }.onFailure {
            isListeningCycleActive = false
            isListeningFlow.value = false
            scheduleRestart(1500L)
        }
    }

    private fun triggerWakeOverlay(match: WakeMatchResult) {
        val now = System.currentTimeMillis()
        if (now - lastWakeTimestampMs < WAKE_COOLDOWN_MS) return
        lastWakeTimestampMs = now

        pauseRecognizer()

        val wakeIntent = Intent(this, AssistActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
            )
            putExtra(AssistActivity.EXTRA_WAKE_TRIGGERED, true)
            if (match.remainingCommand.isNotBlank()) {
                putExtra(AssistActivity.EXTRA_INITIAL_COMMAND, match.remainingCommand)
            }
        }
        runCatching {
            startActivity(wakeIntent)
        }
    }

    private fun pauseRecognizer() {
        mainHandler.removeCallbacks(restartRunnable)
        isListeningCycleActive = false
        isListeningFlow.value = false
        runCatching { speechRecognizer?.cancel() }
    }

    private fun destroyRecognizer() {
        isListeningCycleActive = false
        runCatching { speechRecognizer?.destroy() }
        speechRecognizer = null
    }

    private fun scheduleRestart(delayMs: Long) {
        mainHandler.removeCallbacks(restartRunnable)
        mainHandler.postDelayed(restartRunnable, delayMs)
    }

    private fun buildNotification(): Notification {
        val nm = NotificationManagerCompat.from(this)
        val channel = NotificationChannelCompat.Builder(
            CHANNEL_ID,
            NotificationManagerCompat.IMPORTANCE_LOW
        )
            .setName(getString(R.string.wake_notification_channel_name))
            .build()
        nm.createNotificationChannel(channel)

        val openIntent = PendingIntent.getActivity(
            this,
            10,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val wakeNowIntent = PendingIntent.getActivity(
            this,
            11,
            Intent(this, AssistActivity::class.java).putExtra(AssistActivity.EXTRA_WAKE_TRIGGERED, true),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            12,
            Intent(this, WakeWordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val accentArgb = when (currentThemeMode) {
            ThemeMode.PERSIAN -> 0xFF007A78.toInt()
            ThemeMode.NEON -> 0xFF00F5D4.toInt()
            else -> 0xFF1D4ED8.toInt()
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Listening for \"$currentAssistantName\"")
            .setContentText("Say \"$currentAssistantName\" anytime to open the bottom assistant")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setColor(accentArgb)
            .setContentIntent(openIntent)
            .addAction(0, "Wake Now", wakeNowIntent)
            .addAction(0, "Stop Listening", stopIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun startForegroundNotification() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification() {
        runCatching {
            NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, buildNotification())
        }
    }

    companion object {
        private const val CHANNEL_ID = "personal_ai_wake_channel"
        private const val NOTIFICATION_ID = 4102
        private const val WAKE_COOLDOWN_MS = 2500L
        const val ACTION_STOP = "com.example.assistant.ACTION_STOP_WAKE"

        val isRunningFlow = MutableStateFlow(false)
        val isListeningFlow = MutableStateFlow(false)
        val isAssistantOverlayActive = MutableStateFlow(false)
        val lastHeardTextFlow = MutableStateFlow<String?>(null)

        fun hasMicPermission(context: Context): Boolean =
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED

        fun start(context: Context) {
            if (!hasMicPermission(context)) return
            val intent = Intent(context, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, WakeWordService::class.java))
        }
    }
}
