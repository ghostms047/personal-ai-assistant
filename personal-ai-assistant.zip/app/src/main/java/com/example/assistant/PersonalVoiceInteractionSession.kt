package com.example.assistant

import android.app.assist.AssistStructure
import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.service.voice.VoiceInteractionSession
import com.example.PersonalAiApp
import com.example.screen.ScreenElement
import com.example.screen.ScreenSnapshot

class PersonalVoiceInteractionSession(context: Context) : VoiceInteractionSession(context) {

    override fun onHandleAssist(state: AssistState) {
        super.onHandleAssist(state)
        val structure = state.assistStructure
        if (structure != null) {
            val snapshot = extractSnapshotFromAssistStructure(structure)
            (context.applicationContext as? PersonalAiApp)?.container
                ?.screenUnderstandingRepository
                ?.updateSnapshot(snapshot)
        }
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val intent = Intent(context, AssistActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(AssistActivity.EXTRA_FROM_VOICE_SESSION, true)
        }
        context.startActivity(intent)
        hide()
    }

    private fun extractSnapshotFromAssistStructure(structure: AssistStructure): ScreenSnapshot {
        val textParts = LinkedHashSet<String>()
        val elements = mutableListOf<ScreenElement>()
        var pkg = ""
        var title = ""

        fun walkNode(node: AssistStructure.ViewNode?, depth: Int) {
            if (node == null || depth > 28 || elements.size >= 150) return
            val text = node.text?.toString()?.trim().orEmpty()
            val desc = node.contentDescription?.toString()?.trim().orEmpty()
            val hint = node.hint?.trim().orEmpty()
            val idEntry = node.idEntry.orEmpty()

            if (text.isNotBlank()) textParts.add(text)
            if (desc.isNotBlank() && desc != text) textParts.add(desc)
            if (hint.isNotBlank() && hint != text) textParts.add(hint)

            if (text.isNotBlank() || desc.isNotBlank() || node.isClickable) {
                elements.add(
                    ScreenElement(
                        index = elements.size,
                        text = text,
                        contentDescription = desc,
                        viewId = idEntry,
                        className = node.className?.substringAfterLast('.').orEmpty(),
                        isClickable = node.isClickable,
                        isEditable = false,
                        isScrollable = false,
                        bounds = Rect(node.left, node.top, node.left + node.width, node.top + node.height)
                    )
                )
            }
            for (i in 0 until node.childCount) {
                walkNode(node.getChildAt(i), depth + 1)
            }
        }

        for (w in 0 until structure.windowNodeCount) {
            val win = structure.getWindowNodeAt(w)
            if (title.isBlank()) title = win.title?.toString().orEmpty()
            val root = win.rootViewNode
            if (pkg.isBlank() && !root?.idPackage.isNullOrBlank()) {
                pkg = root?.idPackage.orEmpty()
            }
            walkNode(root, 0)
        }
        if (pkg.isBlank()) pkg = structure.activityComponent?.packageName.orEmpty().ifBlank { "active_app" }

        return ScreenSnapshot(
            packageName = pkg,
            windowTitle = title,
            source = "Android Assist API",
            capturedAt = System.currentTimeMillis(),
            fullText = textParts.joinToString("\n"),
            elements = elements
        )
    }
}
