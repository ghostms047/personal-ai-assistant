package com.example.screen

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference

class ScreenUnderstandingRepository {

    private val _latestSnapshot = MutableStateFlow<ScreenSnapshot?>(null)
    val latestSnapshot: StateFlow<ScreenSnapshot?> = _latestSnapshot.asStateFlow()

    private val _serviceConnected = MutableStateFlow(false)
    val serviceConnected: StateFlow<Boolean> = _serviceConnected.asStateFlow()

    private var activeServiceRef: WeakReference<PersonalAiAccessibilityService>? = null

    fun attachService(service: PersonalAiAccessibilityService) {
        activeServiceRef = WeakReference(service)
        _serviceConnected.value = true
    }

    fun detachService() {
        activeServiceRef = null
        _serviceConnected.value = false
    }

    fun updateSnapshot(snapshot: ScreenSnapshot) {
        _latestSnapshot.value = snapshot
    }

    fun refreshFromAccessibility(): ScreenSnapshot? {
        val service = activeServiceRef?.get() ?: return _latestSnapshot.value
        val snap = service.captureCurrentWindowSnapshot()
        if (snap != null) {
            _latestSnapshot.value = snap
        }
        return snap ?: _latestSnapshot.value
    }

    fun clickElementByQuery(query: String): Result<String> {
        val service = activeServiceRef?.get()
            ?: return Result.failure(
                IllegalStateException(
                    "Accessibility Screen Reader is not enabled. Enable it in Permissions to interact with UI elements."
                )
            )
        return service.clickElementMatching(query)
    }

    fun performGlobalNavigation(action: String): Result<String> {
        val service = activeServiceRef?.get()
            ?: return Result.failure(
                IllegalStateException(
                    "Accessibility Screen Reader is not enabled. Enable it in Permissions to perform global navigation."
                )
            )
        return service.performGlobalNavigationAction(action)
    }

    fun typeInElement(query: String, text: String): Result<String> {
        val service = activeServiceRef?.get()
            ?: return Result.failure(
                IllegalStateException(
                    "Accessibility Screen Reader is not enabled. Enable it in Permissions to type inside apps."
                )
            )
        return service.typeTextInElement(query, text)
    }

    fun scrollScreen(direction: String): Result<String> {
        val service = activeServiceRef?.get()
            ?: return Result.failure(
                IllegalStateException(
                    "Accessibility Screen Reader is not enabled. Enable it in Permissions to scroll apps or games."
                )
            )
        return service.scrollScreen(direction)
    }

    fun tapCoordinates(x: Float, y: Float): Result<String> {
        val service = activeServiceRef?.get()
            ?: return Result.failure(
                IllegalStateException(
                    "Accessibility Screen Reader is not enabled. Enable it in Permissions to tap coordinates in apps or games."
                )
            )
        return service.tapAtCoordinates(x, y)
    }

    fun swipeCoordinates(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long = 320L
    ): Result<String> {
        val service = activeServiceRef?.get()
            ?: return Result.failure(
                IllegalStateException(
                    "Accessibility Screen Reader is not enabled. Enable it in Permissions to swipe in apps or games."
                )
            )
        return service.swipeCoordinates(startX, startY, endX, endY, durationMs)
    }
}
