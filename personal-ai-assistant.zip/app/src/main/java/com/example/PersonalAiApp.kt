package com.example

import android.app.Application
import com.example.ai.AiEngine
import com.example.ai.ModelCatalogService
import com.example.ai.ModelDownloadManager
import com.example.apps.AppIndexer
import com.example.assistant.AssistantOrchestrator
import com.example.data.db.AppDatabase
import com.example.data.security.KeystoreCryptoManager
import com.example.data.settings.SettingsRepository
import com.example.files.FileIndexer
import com.example.files.NaturalLanguageFileSearch
import com.example.memory.MemoryRepository
import com.example.patterns.PatternExecutor
import com.example.patterns.PatternRepository
import com.example.permissions.PermissionChecker
import com.example.screen.ScreenUnderstandingRepository
import com.example.security.SecurityScanner
import com.example.speech.SpeechAiManager
import com.example.tools.ToolRegistry

class AppContainer(application: Application) {
    val database: AppDatabase = AppDatabase.build(application)
    val cryptoManager: KeystoreCryptoManager = KeystoreCryptoManager()
    val settingsRepository: SettingsRepository = SettingsRepository(application, cryptoManager)
    val permissionChecker: PermissionChecker = PermissionChecker(application)
    val memoryRepository: MemoryRepository = MemoryRepository(database.memoryDao(), settingsRepository)
    val appIndexer: AppIndexer = AppIndexer(application, database.installedAppDao())
    val fileIndexer: FileIndexer = FileIndexer(
        context = application,
        indexedFileDao = database.indexedFileDao(),
        indexProgressDao = database.indexProgressDao(),
        settingsRepository = settingsRepository
    )
    val fileSearch: NaturalLanguageFileSearch = NaturalLanguageFileSearch(database.indexedFileDao())
    val screenUnderstandingRepository: ScreenUnderstandingRepository = ScreenUnderstandingRepository()
    val securityScanner: SecurityScanner = SecurityScanner(application, database.indexedFileDao())
    val patternRepository: PatternRepository = PatternRepository(database.userPatternDao())
    val patternExecutor: PatternExecutor = PatternExecutor(
        context = application,
        appIndexer = appIndexer,
        screenRepo = screenUnderstandingRepository,
        securityScanner = securityScanner,
        patternRepository = patternRepository
    )
    val aiEngine: AiEngine = AiEngine(settingsRepository, permissionChecker)
    val modelCatalogService: ModelCatalogService = ModelCatalogService(database.cachedProviderModelDao())
    val modelDownloadManager: ModelDownloadManager = ModelDownloadManager(application, database.downloadedModelDao())
    val speechAiManager: SpeechAiManager = SpeechAiManager(application)
    val toolRegistry: ToolRegistry = ToolRegistry(
        context = application,
        appIndexer = appIndexer,
        fileIndexer = fileIndexer,
        fileSearch = fileSearch,
        screenRepo = screenUnderstandingRepository,
        permissionChecker = permissionChecker,
        memoryRepository = memoryRepository,
        settingsRepository = settingsRepository,
        securityScanner = securityScanner,
        patternRepository = patternRepository,
        patternExecutor = patternExecutor
    )
    val orchestrator: AssistantOrchestrator = AssistantOrchestrator(
        aiEngine = aiEngine,
        toolRegistry = toolRegistry,
        chatMessageDao = database.chatMessageDao(),
        chatSessionDao = database.chatSessionDao(),
        memoryRepository = memoryRepository,
        patternRepository = patternRepository,
        screenRepo = screenUnderstandingRepository,
        permissionChecker = permissionChecker,
        settingsRepository = settingsRepository
    )
}

class PersonalAiApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}
