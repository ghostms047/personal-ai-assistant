package com.example.ai

import com.example.data.settings.AiApiProtocol
import com.example.data.settings.AiSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class OpenAiProvider(
    private val httpClient: OkHttpClient
) : AiProvider {

    override val protocol: AiApiProtocol = AiApiProtocol.OPENAI_COMPATIBLE

    override suspend fun complete(
        settings: AiSettings,
        systemPrompt: String,
        messages: List<AiMessage>,
        tools: List<AiToolDefinition>
    ): AiResult = withContext(Dispatchers.IO) {
        val baseUrl = settings.customBaseUrl.trim().trimEnd('/')
        val model = settings.model.ifBlank { settings.provider.defaultModel }
        val url = if (baseUrl.contains("/chat/completions")) {
            baseUrl
        } else {
            "$baseUrl/chat/completions"
        }

        val payload = JSONObject().apply {
            put("model", model)
            put("temperature", settings.temperature.toDouble())
            put("messages", buildMessages(systemPrompt, messages))
            if (tools.isNotEmpty() && settings.enableNativeTools) {
                put("tools", buildTools(tools))
                put("tool_choice", "auto")
            }
        }

        val builder = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")

        val authValue = settings.buildAuthHeaderValue()
        if (authValue.isNotBlank()) {
            builder.addHeader(settings.effectiveAuthHeaderName, authValue)
        }

        val request = builder
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        try {
            httpClient.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext mapHttpError(response.code, rawBody, settings)
                }
                parseResponse(rawBody, model, settings)
            }
        } catch (io: IOException) {
            AiResult.Error(
                userMessage = "Could not connect to ${settings.effectiveDisplayName}. Check network or base URL.",
                details = io.localizedMessage
            )
        } catch (e: Exception) {
            AiResult.Error(
                userMessage = "Unexpected response from ${settings.effectiveDisplayName}.",
                details = e.localizedMessage
            )
        }
    }

    override suspend fun testConnection(settings: AiSettings): Result<String> {
        val result = complete(
            settings = settings,
            systemPrompt = "Reply with OK.",
            messages = listOf(AiMessage(role = AiRole.USER, text = "Say OK")),
            tools = emptyList()
        )
        return when (result) {
            is AiResult.Success -> Result.success("Connected to ${settings.effectiveDisplayName} (${result.completion.model})")
            is AiResult.Error -> Result.failure(IllegalStateException(result.userMessage))
            is AiResult.MissingApiKey -> Result.failure(IllegalStateException("API key is empty."))
            AiResult.Offline -> Result.failure(IllegalStateException("Device is offline."))
        }
    }

    private fun buildMessages(systemPrompt: String, messages: List<AiMessage>): JSONArray {
        val arr = JSONArray()
        if (systemPrompt.isNotBlank()) {
            arr.put(JSONObject().put("role", "system").put("content", systemPrompt))
        }
        for (msg in messages) {
            when (msg.role) {
                AiRole.USER -> {
                    arr.put(JSONObject().put("role", "user").put("content", msg.text))
                }
                AiRole.ASSISTANT -> {
                    val obj = JSONObject().put("role", "assistant")
                    obj.put("content", if (msg.text.isNotBlank()) msg.text else JSONObject.NULL)
                    if (msg.toolCalls.isNotEmpty()) {
                        val calls = JSONArray()
                        for (call in msg.toolCalls) {
                            calls.put(
                                JSONObject()
                                    .put("id", call.id)
                                    .put("type", "function")
                                    .put(
                                        "function",
                                        JSONObject()
                                            .put("name", call.name)
                                            .put("arguments", call.argumentsJson.ifBlank { "{}" })
                                    )
                            )
                        }
                        obj.put("tool_calls", calls)
                    }
                    arr.put(obj)
                }
                AiRole.TOOL -> {
                    arr.put(
                        JSONObject()
                            .put("role", "tool")
                            .put("tool_call_id", msg.toolCallId ?: "tool_0")
                            .put("content", msg.text)
                    )
                }
            }
        }
        return arr
    }

    private fun buildTools(tools: List<AiToolDefinition>): JSONArray {
        val arr = JSONArray()
        for (tool in tools) {
            val props = JSONObject()
            val req = JSONArray()
            for (p in tool.parameters) {
                val pObj = JSONObject()
                    .put("type", p.type.lowercase())
                    .put("description", p.description)
                if (!p.enumValues.isNullOrEmpty()) {
                    pObj.put("enum", JSONArray(p.enumValues))
                }
                props.put(p.name, pObj)
                if (p.required) req.put(p.name)
            }
            val paramsSchema = JSONObject()
                .put("type", "object")
                .put("properties", props)
            if (req.length() > 0) paramsSchema.put("required", req)

            arr.put(
                JSONObject()
                    .put("type", "function")
                    .put(
                        "function",
                        JSONObject()
                            .put("name", tool.name)
                            .put("description", tool.description)
                            .put("parameters", paramsSchema)
                    )
            )
        }
        return arr
    }

    private fun parseResponse(rawBody: String, model: String, settings: AiSettings): AiResult {
        val root = JSONObject(rawBody)
        val choices = root.optJSONArray("choices")
        if (choices == null || choices.length() == 0) {
            return AiResult.Error("${settings.effectiveDisplayName} returned no response choices.")
        }
        val message = choices.getJSONObject(0).optJSONObject("message")
            ?: return AiResult.Error("Invalid message structure from ${settings.effectiveDisplayName}.")

        val text = if (message.isNull("content")) "" else message.optString("content", "")
        val toolCalls = mutableListOf<AiToolCall>()
        val rawCalls = message.optJSONArray("tool_calls")
        if (rawCalls != null) {
            for (i in 0 until rawCalls.length()) {
                val callObj = rawCalls.optJSONObject(i) ?: continue
                val id = callObj.optString("id", "call_$i")
                val fn = callObj.optJSONObject("function") ?: continue
                val name = fn.optString("name")
                val args = fn.optString("arguments", "{}")
                if (name.isNotBlank()) {
                    toolCalls.add(AiToolCall(id = id, name = name, argumentsJson = args))
                }
            }
        }
        return AiResult.Success(
            AiCompletion(
                text = text.trim(),
                toolCalls = toolCalls,
                provider = settings.provider,
                model = model
            )
        )
    }

    private fun mapHttpError(code: Int, rawBody: String, settings: AiSettings): AiResult {
        val apiMsg = try {
            val obj = JSONObject(rawBody)
            obj.optJSONObject("error")?.optString("message").orEmpty()
                .ifBlank { obj.optString("message").orEmpty() }
        } catch (_: Exception) {
            ""
        }
        val name = settings.effectiveDisplayName
        val friendly = when (code) {
            401, 403 -> "Invalid or unauthorized API key for $name. Check API Key Settings."
            404 -> "Endpoint or model not found for $name. Verify the Base URL and Model ID."
            429 -> "Rate limit or billing quota reached on $name."
            in 500..599 -> "$name server error ($code). Try again shortly."
            else -> "$name returned HTTP $code. ${apiMsg.take(140)}"
        }
        return AiResult.Error(userMessage = friendly, statusCode = code, details = apiMsg)
    }

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }
}
