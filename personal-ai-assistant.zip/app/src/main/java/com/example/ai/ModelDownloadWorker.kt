package com.example.ai

import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.PersonalAiApp
import com.example.R
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class ModelDownloadWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val modelId = inputData.getLong(KEY_MODEL_ID, -1L)
        if (modelId <= 0L) return Result.failure()

        val container = (applicationContext as? PersonalAiApp)?.container ?: return Result.failure()
        val dao = container.database.downloadedModelDao()
        val entity = dao.getById(modelId) ?: return Result.failure()

        try {
            setForeground(createForegroundInfo(entity.name))
        } catch (_: Exception) {
            // Notification permission may be denied; continue background download safely
        }

        val modelsDir = File(applicationContext.filesDir, "models").apply { mkdirs() }
        val safeName = ModelDownloadManager.sanitizeFileName(entity.fileName)
        val partFile = File(modelsDir, "$safeName.part")
        val finalFile = File(modelsDir, safeName)

        dao.upsert(
            entity.copy(
                status = ModelDownloadManager.STATUS_DOWNLOADING,
                downloadedBytes = 0L,
                errorMessage = null,
                updatedAt = System.currentTimeMillis()
            )
        )

        val client = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()

        return try {
            val request = Request.Builder()
                .url(entity.downloadUrl)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    dao.upsert(
                        entity.copy(
                            status = ModelDownloadManager.STATUS_FAILED,
                            errorMessage = "Server returned HTTP ${response.code}",
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    return Result.failure()
                }

                val body = response.body ?: run {
                    dao.upsert(
                        entity.copy(
                            status = ModelDownloadManager.STATUS_FAILED,
                            errorMessage = "Empty response body",
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    return Result.failure()
                }

                val totalBytes = body.contentLength().coerceAtLeast(0L)
                val digest = MessageDigest.getInstance("SHA-256")
                var downloaded = 0L
                var lastEmit = 0L
                val buffer = ByteArray(16 * 1024)

                body.byteStream().use { input ->
                    FileOutputStream(partFile).use { output ->
                        while (true) {
                            if (isStopped) {
                                partFile.delete()
                                dao.upsert(
                                    entity.copy(
                                        status = ModelDownloadManager.STATUS_CANCELLED,
                                        errorMessage = "Cancelled",
                                        updatedAt = System.currentTimeMillis()
                                    )
                                )
                                return Result.failure()
                            }
                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            digest.update(buffer, 0, read)
                            downloaded += read

                            val now = System.currentTimeMillis()
                            if (now - lastEmit >= 350L) {
                                lastEmit = now
                                dao.upsert(
                                    entity.copy(
                                        status = ModelDownloadManager.STATUS_DOWNLOADING,
                                        totalBytes = totalBytes,
                                        downloadedBytes = downloaded,
                                        updatedAt = now
                                    )
                                )
                            }
                        }
                        output.flush()
                    }
                }

                if (finalFile.exists()) finalFile.delete()
                if (!partFile.renameTo(finalFile)) {
                    partFile.copyTo(finalFile, overwrite = true)
                    partFile.delete()
                }

                val shaHex = digest.digest().joinToString("") { "%02x".format(it) }
                dao.upsert(
                    entity.copy(
                        localPath = finalFile.absolutePath,
                        totalBytes = if (totalBytes > 0L) totalBytes else downloaded,
                        downloadedBytes = downloaded,
                        status = ModelDownloadManager.STATUS_COMPLETED,
                        sha256 = shaHex,
                        errorMessage = null,
                        updatedAt = System.currentTimeMillis()
                    )
                )
                Result.success()
            }
        } catch (e: Exception) {
            partFile.delete()
            dao.upsert(
                entity.copy(
                    status = ModelDownloadManager.STATUS_FAILED,
                    errorMessage = e.localizedMessage ?: "Download failed",
                    updatedAt = System.currentTimeMillis()
                )
            )
            Result.failure()
        }
    }

    private fun createForegroundInfo(modelName: String): ForegroundInfo {
        val nm = NotificationManagerCompat.from(applicationContext)
        val channel = NotificationChannelCompat.Builder(
            CHANNEL_ID,
            NotificationManagerCompat.IMPORTANCE_LOW
        )
            .setName("Model Downloads")
            .build()
        nm.createNotificationChannel(channel)

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setContentTitle("Downloading AI Model")
            .setContentText(modelName)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setSilent(true)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    companion object {
        private const val KEY_MODEL_ID = "model_id"
        private const val CHANNEL_ID = "personal_ai_model_downloads"
        private const val NOTIFICATION_ID = 4103

        fun workNameFor(id: Long): String = "personal_ai_model_dl_$id"

        fun enqueue(context: Context, modelId: Long) {
            val request = OneTimeWorkRequestBuilder<ModelDownloadWorker>()
                .setInputData(workDataOf(KEY_MODEL_ID to modelId))
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                workNameFor(modelId),
                ExistingWorkPolicy.REPLACE,
                request
            )
        }

        fun cancel(context: Context, modelId: Long) {
            WorkManager.getInstance(context).cancelUniqueWork(workNameFor(modelId))
        }
    }
}
