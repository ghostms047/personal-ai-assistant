package com.example.ai

import com.example.data.settings.AiApiProtocol
import com.example.data.settings.AiRouteIssue
import com.example.data.settings.AiSettings
import com.example.data.settings.SettingsRepository
import com.example.permissions.PermissionChecker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import okhttp3.OkHttpClient
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AiEngine(
    private val settingsRepository: SettingsRepository,
    private val permissionChecker: PermissionChecker
) {
    private val _lastUsedRouteLabel = MutableStateFlow<String?>(null)
    val lastUsedRouteLabel: StateFlow<String?> = _lastUsedRouteLabel.asStateFlow()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val providers: Map<AiApiProtocol, AiProvider> = mapOf(
        AiApiProtocol.GEMINI to GeminiProvider(httpClient),
        AiApiProtocol.OPENAI_COMPATIBLE to OpenAiProvider(httpClient),
        AiApiProtocol.ANTHROPIC to AnthropicProvider(httpClient)
    )

    suspend fun complete(
        systemPrompt: String,
        messages: List<AiMessage>,
        tools: List<AiToolDefinition>
    ): AiResult {
        val rawSettings = settingsRepository.aiSettingsFlow.first()
        val isOnline = permissionChecker.isNetworkConnected()
        val route = rawSettings.resolveEffectiveRoute(isOnline = isOnline)
        _lastUsedRouteLabel.value = route.routeBadge

        when (route.issue) {
            AiRouteIssue.MISSING_API_KEY -> return AiResult.MissingApiKey(rawSettings.provider)
            AiRouteIssue.OFFLINE_API_ONLY -> return AiResult.Offline
            AiRouteIssue.MISSING_LOCAL_CONFIG -> {
                return AiResult.Error(
                    "Local AI is selected (${route.routeBadge}), but no local endpoint/model is configured. Open Models & Local AI to configure your local runtime."
                )
            }
            null -> {}
        }

        val settings = route.effectiveSettings
        val isLoopback = AiSettings.isLoopbackEndpoint(settings.customBaseUrl)
        if (!route.isUsingLocal && !isLoopback && !isOnline) {
            return AiResult.Offline
        }

        val provider = providers[settings.protocol]
            ?: return AiResult.Error("Unsupported API protocol configured.")

        if (!settings.enableNativeTools && tools.isNotEmpty()) {
            return completeWithPromptToolFallback(provider, settings, systemPrompt, messages, tools)
        }

        val result = provider.complete(settings, systemPrompt, messages, tools)
        if (result is AiResult.Error &&
            tools.isNotEmpty() &&
            (result.statusCode == 400 || result.statusCode == 422) &&
            isToolsUnsupportedError(result.details.orEmpty() + " " + result.userMessage)
        ) {
            return completeWithPromptToolFallback(provider, settings, systemPrompt, messages, tools)
        }
        if (result is AiResult.Error && route.isUsingLocal && result.statusCode == null) {
            return result.copy(
                userMessage = "Local AI (${settings.model}) at ${settings.customBaseUrl} did not respond. Make sure your on-device LLM server is running, or switch to Auto / API Key Only."
            )
        }
        return result
    }

    suspend fun testConnection(settings: AiSettings): Result<String> {
        if (!settings.hasApiKey) {
            return Result.failure(IllegalStateException("Enter an API key or enable keyless local mode first."))
        }
        if (!AiSettings.isLoopbackEndpoint(settings.customBaseUrl) && !permissionChecker.isNetworkConnected()) {
            return Result.failure(IllegalStateException("Device appears offline."))
        }
        val provider = providers[settings.protocol]
            ?: return Result.failure(IllegalStateException("Unsupported API protocol."))
        return provider.testConnection(settings)
    }

    private suspend fun completeWithPromptToolFallback(
        provider: AiProvider,
        settings: AiSettings,
        systemPrompt: String,
        messages: List<AiMessage>,
        tools: List<AiToolDefinition>
    ): AiResult {
        val toolCatalog = buildString {
            appendLine(systemPrompt)
            appendLine()
            appendLine("Available tools (when you need a device action, reply ONLY with JSON {\"tool_call\": {\"name\": \"<tool_name>\", \"arguments\": {...}}}):")
            tools.forEach { t ->
                val params = t.parameters.joinToString(", ") { "${it.name}:${it.type}" }
                appendLine("- ${t.name}($params): ${t.description}")
            }
        }
        val fallbackSettings = settings.copy(enableNativeTools = false)
        val rawResult = provider.complete(fallbackSettings, toolCatalog, messages, emptyList())
        if (rawResult !is AiResult.Success) return rawResult

        val parsedCall = tryExtractJsonToolCall(rawResult.completion.text)
        return if (parsedCall != null) {
            AiResult.Success(
                rawResult.completion.copy(
                    text = "",
                    toolCalls = listOf(parsedCall)
                )
            )
        } else {
            rawResult
        }
    }

    private fun isToolsUnsupportedError(text: String): Boolean {
        val lower = text.lowercase()
        return lower.contains("tool") || lower.contains("function") || lower.contains("unsupported")
    }

    private fun tryExtractJsonToolCall(text: String): AiToolCall? {
        val trimmed = text.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
        if (!trimmed.startsWith("{") || !trimmed.contains("tool_call")) return null
        return try {
            val root = JSONObject(trimmed)
            val call = root.optJSONObject("tool_call") ?: return null
            val name = call.optString("name")
            if (name.isBlank()) return null
            val args = call.optJSONObject("arguments")?.toString() ?: "{}"
            AiToolCall(
                id = "prompt_tool_${System.nanoTime()}",
                name = name,
                argumentsJson = args
            )
        } catch (_: Exception) {
            null
        }
    }
}
