package com.example.ai

import com.example.data.db.CachedProviderModelDao
import com.example.data.db.CachedProviderModelEntity
import com.example.data.settings.AiApiProtocol
import com.example.data.settings.AiSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class ModelCatalogService(
    private val cachedModelDao: CachedProviderModelDao,
    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
) {

    fun observeModels(providerId: String): Flow<List<CachedProviderModelEntity>> =
        cachedModelDao.observeByProvider(providerId)

    suspend fun fetchModelsForProvider(settings: AiSettings): Result<List<CachedProviderModelEntity>> =
        withContext(Dispatchers.IO) {
            if (!settings.hasApiKey) {
                return@withContext Result.failure(
                    IllegalStateException("Enter an API key or enable keyless mode for ${settings.effectiveDisplayName} first.")
                )
            }

            val url = resolveModelsEndpoint(settings)
                ?: return@withContext Result.failure(
                    IllegalArgumentException("Could not determine a valid /models endpoint for ${settings.effectiveDisplayName}.")
                )

            val builder = Request.Builder()
                .url(url)
                .get()
                .addHeader("Accept", "application/json")

            if (settings.protocol == AiApiProtocol.ANTHROPIC) {
                builder.addHeader("anthropic-version", "2023-06-01")
            }

            val authValue = settings.buildAuthHeaderValue()
            if (authValue.isNotBlank()) {
                builder.addHeader(settings.effectiveAuthHeaderName, authValue)
            }

            try {
                httpClient.newCall(builder.build()).execute().use { response ->
                    val rawBody = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        val apiError = try {
                            JSONObject(rawBody).optJSONObject("error")?.optString("message").orEmpty()
                        } catch (_: Exception) {
                            ""
                        }
                        val msg = when (response.code) {
                            401, 403 -> "Unauthorized (${response.code}). Check your ${settings.effectiveDisplayName} API key."
                            404 -> "This endpoint does not expose a /models catalog (HTTP 404)."
                            else -> "HTTP ${response.code}: ${apiError.ifBlank { "Unable to fetch models." }}"
                        }
                        return@withContext Result.failure(IllegalStateException(msg))
                    }

                    val parsed = parseModelsResponse(
                        providerId = settings.provider.id,
                        protocol = settings.protocol,
                        rawBody = rawBody
                    )
                    if (parsed.isEmpty()) {
                        return@withContext Result.failure(
                            IllegalStateException("The provider returned 0 models from its catalog.")
                        )
                    }
                    cachedModelDao.deleteForProvider(settings.provider.id)
                    cachedModelDao.upsertAll(parsed)
                    Result.success(parsed)
                }
            } catch (io: IOException) {
                Result.failure(
                    IllegalStateException(
                        "Network error contacting ${settings.effectiveDisplayName}: ${io.localizedMessage ?: "Check connection"}"
                    )
                )
            } catch (e: Exception) {
                Result.failure(
                    IllegalStateException(e.localizedMessage ?: "Failed to parse model catalog.")
                )
            }
        }

    fun resolveModelsEndpoint(settings: AiSettings): String? {
        val raw = settings.customBaseUrl.trim().trimEnd('/')
        if (raw.isBlank() || (!raw.startsWith("https://") && !raw.startsWith("http://"))) {
            return null
        }
        return when (settings.protocol) {
            AiApiProtocol.GEMINI -> {
                val base = when {
                    raw.contains("/models/") -> raw.substringBefore("/models/")
                    raw.endsWith("/models") -> raw.removeSuffix("/models")
                    else -> raw
                }
                "$base/models?pageSize=100"
            }
            AiApiProtocol.ANTHROPIC -> {
                val base = raw.removeSuffix("/messages")
                if (base.endsWith("/models")) base else "$base/models"
            }
            AiApiProtocol.OPENAI_COMPATIBLE -> {
                val withoutQuery = raw.substringBefore("?")
                val base = withoutQuery
                    .removeSuffix("/chat/completions")
                    .removeSuffix("/completions")
                if (base.endsWith("/models")) base else "$base/models"
            }
        }
    }

    fun parseModelsResponse(
        providerId: String,
        protocol: AiApiProtocol,
        rawBody: String
    ): List<CachedProviderModelEntity> {
        val now = System.currentTimeMillis()
        val root = JSONObject(rawBody)
        val result = mutableListOf<CachedProviderModelEntity>()

        when (protocol) {
            AiApiProtocol.GEMINI -> {
                val arr = root.optJSONArray("models") ?: return emptyList()
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val fullName = obj.optString("name").trim()
                    val id = fullName.removePrefix("models/").trim()
                    if (id.isBlank()) continue
                    val displayName = obj.optString("displayName").ifBlank { id }
                    val methods = obj.optJSONArray("supportedGenerationMethods")
                    val isEmbedding = methods?.toString()?.contains("embedContent") == true &&
                        methods.toString().contains("generateContent").not()
                    val capability = if (isEmbedding) CAP_EMBEDDING else classifyCapability(id)
                    result.add(
                        CachedProviderModelEntity(
                            providerId = providerId,
                            modelId = id,
                            displayName = displayName,
                            capability = capability,
                            fetchedAt = now
                        )
                    )
                }
            }
            AiApiProtocol.ANTHROPIC, AiApiProtocol.OPENAI_COMPATIBLE -> {
                val arr = root.optJSONArray("data") ?: root.optJSONArray("models") ?: return emptyList()
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val id = obj.optString("id").ifBlank { obj.optString("name") }.trim()
                    if (id.isBlank()) continue
                    val displayName = obj.optString("display_name").ifBlank { id }
                    result.add(
                        CachedProviderModelEntity(
                            providerId = providerId,
                            modelId = id,
                            displayName = displayName,
                            capability = classifyCapability(id),
                            fetchedAt = now
                        )
                    )
                }
            }
        }
        return result.distinctBy { it.modelId }
    }

    companion object {
        const val CAP_CHAT = "CHAT"
        const val CAP_SPEECH_TTS = "SPEECH_TTS"
        const val CAP_SPEECH_STT = "SPEECH_STT"
        const val CAP_EMBEDDING = "EMBEDDING"

        fun classifyCapability(modelId: String): String {
            val lower = modelId.lowercase()
            return when {
                lower.contains("whisper") || lower.contains("transcribe") || lower.contains("-stt") -> CAP_SPEECH_STT
                lower.contains("tts") || lower.startsWith("tts-") || lower.contains("-speech") -> CAP_SPEECH_TTS
                lower.contains("embed") -> CAP_EMBEDDING
                else -> CAP_CHAT
            }
        }
    }
}
