package com.example.ai

import com.example.data.settings.AiApiProtocol
import com.example.data.settings.AiProviderType
import com.example.data.settings.AiSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class AnthropicProvider(
    private val httpClient: OkHttpClient
) : AiProvider {

    override val protocol: AiApiProtocol = AiApiProtocol.ANTHROPIC

    override suspend fun complete(
        settings: AiSettings,
        systemPrompt: String,
        messages: List<AiMessage>,
        tools: List<AiToolDefinition>
    ): AiResult = withContext(Dispatchers.IO) {
        val baseUrl = settings.customBaseUrl.trim().trimEnd('/')
        val model = settings.model.ifBlank { AiProviderType.ANTHROPIC.defaultModel }
        val url = if (baseUrl.endsWith("/messages")) baseUrl else "$baseUrl/messages"

        val payload = JSONObject().apply {
            put("model", model)
            put("max_tokens", 1024)
            put("temperature", settings.temperature.toDouble())
            if (systemPrompt.isNotBlank()) {
                put("system", systemPrompt)
            }
            put("messages", buildMessages(messages))
            if (tools.isNotEmpty() && settings.enableNativeTools) {
                put("tools", buildTools(tools))
            }
        }

        val builder = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")
            .addHeader("anthropic-version", "2023-06-01")

        val authValue = settings.buildAuthHeaderValue()
        if (authValue.isNotBlank()) {
            builder.addHeader(settings.effectiveAuthHeaderName, authValue)
        }

        val request = builder
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        try {
            httpClient.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext mapHttpError(response.code, rawBody, settings)
                }
                parseResponse(rawBody, model, settings)
            }
        } catch (io: IOException) {
            AiResult.Error(
                userMessage = "Could not connect to ${settings.effectiveDisplayName}. Check your internet connection.",
                details = io.localizedMessage
            )
        } catch (e: Exception) {
            AiResult.Error(
                userMessage = "Unexpected response from ${settings.effectiveDisplayName}.",
                details = e.localizedMessage
            )
        }
    }

    override suspend fun testConnection(settings: AiSettings): Result<String> {
        val result = complete(
            settings = settings,
            systemPrompt = "Reply with OK.",
            messages = listOf(AiMessage(role = AiRole.USER, text = "Say OK")),
            tools = emptyList()
        )
        return when (result) {
            is AiResult.Success -> Result.success("Connected to ${settings.effectiveDisplayName} (${result.completion.model})")
            is AiResult.Error -> Result.failure(IllegalStateException(result.userMessage))
            is AiResult.MissingApiKey -> Result.failure(IllegalStateException("API key is empty."))
            AiResult.Offline -> Result.failure(IllegalStateException("Device is offline."))
        }
    }

    private fun buildMessages(messages: List<AiMessage>): JSONArray {
        val arr = JSONArray()
        for (msg in messages) {
            when (msg.role) {
                AiRole.USER -> {
                    arr.put(
                        JSONObject()
                            .put("role", "user")
                            .put(
                                "content",
                                JSONArray().put(
                                    JSONObject().put("type", "text").put("text", msg.text)
                                )
                            )
                    )
                }
                AiRole.ASSISTANT -> {
                    val blocks = JSONArray()
                    if (msg.text.isNotBlank()) {
                        blocks.put(JSONObject().put("type", "text").put("text", msg.text))
                    }
                    for (call in msg.toolCalls) {
                        val inputObj = try {
                            JSONObject(call.argumentsJson.ifBlank { "{}" })
                        } catch (_: Exception) {
                            JSONObject()
                        }
                        blocks.put(
                            JSONObject()
                                .put("type", "tool_use")
                                .put("id", call.id)
                                .put("name", call.name)
                                .put("input", inputObj)
                        )
                    }
                    if (blocks.length() > 0) {
                        arr.put(JSONObject().put("role", "assistant").put("content", blocks))
                    }
                }
                AiRole.TOOL -> {
                    arr.put(
                        JSONObject()
                            .put("role", "user")
                            .put(
                                "content",
                                JSONArray().put(
                                    JSONObject()
                                        .put("type", "tool_result")
                                        .put("tool_use_id", msg.toolCallId ?: "tool_0")
                                        .put("content", msg.text)
                                )
                            )
                    )
                }
            }
        }
        return arr
    }

    private fun buildTools(tools: List<AiToolDefinition>): JSONArray {
        val arr = JSONArray()
        for (tool in tools) {
            val props = JSONObject()
            val req = JSONArray()
            for (p in tool.parameters) {
                val pObj = JSONObject()
                    .put("type", p.type.lowercase())
                    .put("description", p.description)
                if (!p.enumValues.isNullOrEmpty()) {
                    pObj.put("enum", JSONArray(p.enumValues))
                }
                props.put(p.name, pObj)
                if (p.required) req.put(p.name)
            }
            val schema = JSONObject()
                .put("type", "object")
                .put("properties", props)
            if (req.length() > 0) schema.put("required", req)
            arr.put(
                JSONObject()
                    .put("name", tool.name)
                    .put("description", tool.description)
                    .put("input_schema", schema)
            )
        }
        return arr
    }

    private fun parseResponse(rawBody: String, model: String, settings: AiSettings): AiResult {
        val root = JSONObject(rawBody)
        val content = root.optJSONArray("content") ?: JSONArray()
        val textBuilder = StringBuilder()
        val toolCalls = mutableListOf<AiToolCall>()

        for (i in 0 until content.length()) {
            val block = content.optJSONObject(i) ?: continue
            when (block.optString("type")) {
                "text" -> {
                    if (textBuilder.isNotEmpty()) textBuilder.append("\n")
                    textBuilder.append(block.optString("text"))
                }
                "tool_use" -> {
                    val id = block.optString("id", "claude_$i")
                    val name = block.optString("name")
                    val input = block.optJSONObject("input")?.toString() ?: "{}"
                    if (name.isNotBlank()) {
                        toolCalls.add(AiToolCall(id = id, name = name, argumentsJson = input))
                    }
                }
            }
        }
        return AiResult.Success(
            AiCompletion(
                text = textBuilder.toString().trim(),
                toolCalls = toolCalls,
                provider = settings.provider,
                model = model
            )
        )
    }

    private fun mapHttpError(code: Int, rawBody: String, settings: AiSettings): AiResult {
        val apiMsg = try {
            JSONObject(rawBody).optJSONObject("error")?.optString("message").orEmpty()
        } catch (_: Exception) {
            ""
        }
        val name = settings.effectiveDisplayName
        val friendly = when (code) {
            401, 403 -> "Your $name API key was rejected ($code). Verify it in API Key Settings."
            404 -> "Selected $name model or endpoint was not found."
            429 -> "$name rate limit exceeded. Please wait and retry."
            in 500..599 -> "$name API is temporarily unavailable ($code)."
            else -> "$name API error ($code). ${apiMsg.take(140)}"
        }
        return AiResult.Error(userMessage = friendly, statusCode = code, details = apiMsg)
    }

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }
}
