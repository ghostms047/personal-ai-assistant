package com.example.ai

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import com.example.data.db.DownloadedModelDao
import com.example.data.db.DownloadedModelEntity
import kotlinx.coroutines.flow.Flow
import java.io.File
import java.net.URI

data class DeviceRamInfo(
    val totalBytes: Long,
    val availableBytes: Long
) {
    val totalGb: Double get() = totalBytes / (1024.0 * 1024.0 * 1024.0)
    val availableGb: Double get() = availableBytes / (1024.0 * 1024.0 * 1024.0)
    val isSixGbOrMore: Boolean get() = totalGb >= 5.5
}

data class CuratedModelPreset(
    val id: String,
    val name: String,
    val fileName: String,
    val downloadUrl: String,
    val category: String,
    val runtimeModelName: String,
    val sizeHint: String,
    val formatLabel: String,
    val specsLabel: String,
    val compatibilityLabel: String,
    val description: String,
    val paramBillions: Double,
    val recommendedRamGb: Int,
    val languagesLabel: String,
    val supportsPersian: Boolean
)

class ModelDownloadManager(
    private val context: Context,
    private val downloadedModelDao: DownloadedModelDao
) {
    fun observeDownloadedModels(): Flow<List<DownloadedModelEntity>> =
        downloadedModelDao.observeAll()

    suspend fun enqueueDownload(
        name: String,
        rawUrl: String,
        category: String = CATEGORY_TEXT,
        suggestedFileName: String? = null
    ): Result<Long> {
        val cleanUrl = validateDownloadUrl(rawUrl)
            ?: return Result.failure(
                IllegalArgumentException("Enter a valid https:// or http:// model download URL.")
            )

        val derivedName = suggestedFileName?.takeIf { it.isNotBlank() }
            ?: run {
                val path = Uri.parse(cleanUrl).lastPathSegment.orEmpty()
                path.ifBlank { "model_${System.currentTimeMillis()}.bin" }
            }
        val safeFileName = sanitizeFileName(derivedName)
        val cleanLabel = name.trim().ifBlank { safeFileName }

        val existing = downloadedModelDao.getByUrl(cleanUrl)
        val now = System.currentTimeMillis()
        val id = if (existing != null) {
            val updated = existing.copy(
                name = cleanLabel,
                fileName = safeFileName,
                category = category,
                status = STATUS_QUEUED,
                downloadedBytes = 0L,
                errorMessage = null,
                updatedAt = now
            )
            downloadedModelDao.upsert(updated)
            existing.id
        } else {
            downloadedModelDao.upsert(
                DownloadedModelEntity(
                    name = cleanLabel,
                    fileName = safeFileName,
                    downloadUrl = cleanUrl,
                    category = category,
                    status = STATUS_QUEUED,
                    updatedAt = now
                )
            )
        }

        ModelDownloadWorker.enqueue(context, id)
        return Result.success(id)
    }

    suspend fun cancelDownload(model: DownloadedModelEntity) {
        ModelDownloadWorker.cancel(context, model.id)
        if (model.status == STATUS_QUEUED || model.status == STATUS_DOWNLOADING) {
            downloadedModelDao.upsert(
                model.copy(
                    status = STATUS_CANCELLED,
                    errorMessage = "Cancelled by user",
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
    }

    suspend fun deleteModel(model: DownloadedModelEntity) {
        ModelDownloadWorker.cancel(context, model.id)
        val modelsRoot = File(context.filesDir, "models").canonicalFile
        if (model.localPath.isNotBlank()) {
            runCatching {
                val target = File(model.localPath).canonicalFile
                if (target.path.startsWith(modelsRoot.path)) {
                    target.delete()
                }
            }
        }
        runCatching {
            File(modelsRoot, "${sanitizeFileName(model.fileName)}.part").delete()
        }
        downloadedModelDao.deleteById(model.id)
    }

    companion object {
        const val CATEGORY_TEXT = "Text AI"
        const val CATEGORY_SPEECH_STT = "Speech STT"
        const val CATEGORY_SPEECH_TTS = "Speech TTS"

        const val STATUS_QUEUED = "QUEUED"
        const val STATUS_DOWNLOADING = "DOWNLOADING"
        const val STATUS_COMPLETED = "COMPLETED"
        const val STATUS_FAILED = "FAILED"
        const val STATUS_CANCELLED = "CANCELLED"

        fun isTextCategory(category: String): Boolean =
            category == CATEGORY_TEXT || category == "Open-Weight"

        fun isSpeechSttCategory(category: String): Boolean =
            category == CATEGORY_SPEECH_STT

        fun isSpeechTtsCategory(category: String): Boolean =
            category == CATEGORY_SPEECH_TTS

        fun suggestedRuntimeModelName(model: DownloadedModelEntity): String {
            curatedPresets.firstOrNull { it.downloadUrl == model.downloadUrl || it.fileName == model.fileName }
                ?.let { return it.runtimeModelName }
            return model.fileName.substringBeforeLast('.')
        }

        val curatedPresets: List<CuratedModelPreset> = listOf(
            CuratedModelPreset(
                id = "gemma3_4b",
                name = "Gemma 3 4B Instruct (Q4_K_M)",
                fileName = "gemma-3-4b-it.Q4_K_M.gguf",
                downloadUrl = "https://huggingface.co/MaziyarPanahi/gemma-3-4b-it-GGUF/resolve/main/gemma-3-4b-it.Q4_K_M.gguf",
                category = CATEGORY_TEXT,
                runtimeModelName = "gemma3:4b",
                sizeHint = "~2.49 GB",
                formatLabel = "GGUF (Q4_K_M)",
                specsLabel = "4.0B params • Best Persian Fluency • 6+ GB RAM",
                compatibilityLabel = "llama.cpp / Ollama / LM Studio",
                description = "4B parameter Google Gemma 3 quantized model with strong Persian (فارسی) understanding, reasoning, and multilingual assistant accuracy on 6+ GB RAM devices.",
                paramBillions = 4.0,
                recommendedRamGb = 6,
                languagesLabel = "Persian (فارسی) & 140+ Languages",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "qwen25_3b",
                name = "Qwen 2.5 3B Instruct (Q4_K_M)",
                fileName = "qwen2.5-3b-instruct-q4_k_m.gguf",
                downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q4_k_m.gguf",
                category = CATEGORY_TEXT,
                runtimeModelName = "qwen2.5:3b",
                sizeHint = "~2.10 GB",
                formatLabel = "GGUF (Q4_K_M)",
                specsLabel = "3.0B params • Strong Persian & Tool Calling • 6+ GB RAM",
                compatibilityLabel = "llama.cpp / Ollama / LM Studio",
                description = "3B parameter Qwen 2.5 instruct model combining accurate structured JSON tool-calling with fluent Persian (فارسی) and English assistant replies.",
                paramBillions = 3.0,
                recommendedRamGb = 6,
                languagesLabel = "Persian (فارسی), English & 29+ Languages",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "llama32_3b",
                name = "Llama 3.2 3B Instruct (Q4_K_M)",
                fileName = "Llama-3.2-3B-Instruct-Q4_K_M.gguf",
                downloadUrl = "https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf",
                category = CATEGORY_TEXT,
                runtimeModelName = "llama3.2:3b",
                sizeHint = "~2.02 GB",
                formatLabel = "GGUF (Q4_K_M)",
                specsLabel = "3.0B params • Fast 3B Assistant • 6+ GB RAM",
                compatibilityLabel = "llama.cpp / Ollama / LM Studio",
                description = "3B Meta Llama 3.2 instruct model offering fast mobile-friendly responses, Persian comprehension, and general reasoning for 6+ GB RAM phones.",
                paramBillions = 3.0,
                recommendedRamGb = 6,
                languagesLabel = "Persian (فارسی) & Multilingual",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "whisper_large_v3_turbo",
                name = "Whisper Large-v3-Turbo (Q5_0)",
                fileName = "ggml-large-v3-turbo-q5_0.bin",
                downloadUrl = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo-q5_0.bin",
                category = CATEGORY_SPEECH_STT,
                runtimeModelName = "whisper-large-v3-turbo",
                sizeHint = "~574 MB",
                formatLabel = "GGML (Q5_0)",
                specsLabel = "809M params • High-Accuracy Persian STT • 4+ GB RAM",
                compatibilityLabel = "whisper.cpp / OpenAI Whisper API",
                description = "High-accuracy multilingual speech-to-text model with strong Persian (فارسی) voice recognition and fast turbo decoding.",
                paramBillions = 0.809,
                recommendedRamGb = 4,
                languagesLabel = "Persian (فارسی) & 99 Languages",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "whisper_medium_multi",
                name = "Whisper Medium Multilingual (Q5_0)",
                fileName = "ggml-medium-q5_0.bin",
                downloadUrl = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-medium-q5_0.bin",
                category = CATEGORY_SPEECH_STT,
                runtimeModelName = "whisper-1",
                sizeHint = "~539 MB",
                formatLabel = "GGML (Q5_0)",
                specsLabel = "769M params • Balanced Persian STT • 4+ GB RAM",
                compatibilityLabel = "whisper.cpp / OpenAI Whisper API",
                description = "Accurate multilingual speech recognition model supporting Persian and English dictation with clean punctuation.",
                paramBillions = 0.769,
                recommendedRamGb = 4,
                languagesLabel = "Persian (فارسی) & 99 Languages",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "whisper_small_multi",
                name = "Whisper Small Multilingual (Q5_1)",
                fileName = "ggml-small-q5_1.bin",
                downloadUrl = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small-q5_1.bin",
                category = CATEGORY_SPEECH_STT,
                runtimeModelName = "whisper-1",
                sizeHint = "~190 MB",
                formatLabel = "GGML (Q5_1)",
                specsLabel = "244M params • Lightweight Persian STT • 2+ GB RAM",
                compatibilityLabel = "whisper.cpp / OpenAI Whisper API",
                description = "Fast multilingual Whisper model for everyday Persian and English voice-to-text with minimal storage footprint.",
                paramBillions = 0.244,
                recommendedRamGb = 2,
                languagesLabel = "Persian (فارسی) & 99 Languages",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "piper_amir_fa",
                name = "Piper Amir Persian Voice (fa_IR)",
                fileName = "fa_IR-amir-medium.onnx",
                downloadUrl = "https://huggingface.co/rhasspy/piper-voices/resolve/main/fa/fa_IR/amir/medium/fa_IR-amir-medium.onnx",
                category = CATEGORY_SPEECH_TTS,
                runtimeModelName = "fa_IR-amir-medium",
                sizeHint = "~63 MB",
                formatLabel = "ONNX Neural",
                specsLabel = "Natural Persian Voice (fa_IR) • Text-to-Speech • 2+ GB RAM",
                compatibilityLabel = "Piper TTS / OpenAI-compatible TTS",
                description = "Natural Persian (فارسی) neural voice synthesis model for reading assistant answers aloud.",
                paramBillions = 0.02,
                recommendedRamGb = 2,
                languagesLabel = "Persian (fa_IR)",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "piper_ganji_fa",
                name = "Piper Ganji Persian Voice (fa_IR)",
                fileName = "fa_IR-ganji-medium.onnx",
                downloadUrl = "https://huggingface.co/rhasspy/piper-voices/resolve/main/fa/fa_IR/ganji/medium/fa_IR-ganji-medium.onnx",
                category = CATEGORY_SPEECH_TTS,
                runtimeModelName = "fa_IR-ganji-medium",
                sizeHint = "~63 MB",
                formatLabel = "ONNX Neural",
                specsLabel = "Clear Persian Voice (fa_IR) • Text-to-Speech • 2+ GB RAM",
                compatibilityLabel = "Piper TTS / OpenAI-compatible TTS",
                description = "Alternative clear Persian (فارسی) neural voice model for spoken assistant replies.",
                paramBillions = 0.02,
                recommendedRamGb = 2,
                languagesLabel = "Persian (fa_IR)",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "piper_lessac_en",
                name = "Piper Lessac US Voice (en_US)",
                fileName = "en_US-lessac-medium.onnx",
                downloadUrl = "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/lessac/medium/en_US-lessac-medium.onnx",
                category = CATEGORY_SPEECH_TTS,
                runtimeModelName = "en_US-lessac-medium",
                sizeHint = "~63 MB",
                formatLabel = "ONNX Neural",
                specsLabel = "Natural US English Voice • Text-to-Speech • 2+ GB RAM",
                compatibilityLabel = "Piper TTS / OpenAI-compatible TTS",
                description = "Studio-grade US English neural voice synthesis model for English spoken assistant answers.",
                paramBillions = 0.02,
                recommendedRamGb = 2,
                languagesLabel = "English (en_US)",
                supportsPersian = false
            )
        )

        fun readDeviceRamInfo(context: Context): DeviceRamInfo {
            return runCatching {
                val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                    ?: return DeviceRamInfo(0L, 0L)
                val info = ActivityManager.MemoryInfo()
                activityManager.getMemoryInfo(info)
                DeviceRamInfo(
                    totalBytes = info.totalMem.coerceAtLeast(0L),
                    availableBytes = info.availMem.coerceAtLeast(0L)
                )
            }.getOrElse { DeviceRamInfo(0L, 0L) }
        }

        fun validateDownloadUrl(rawUrl: String): String? {
            val trimmed = rawUrl.trim()
            if (trimmed.isBlank()) return null
            return try {
                val parsed = URI(trimmed)
                val scheme = parsed.scheme?.lowercase() ?: return null
                if (scheme != "https" && scheme != "http") return null
                if (parsed.host.isNullOrBlank()) return null
                trimmed
            } catch (_: Exception) {
                null
            }
        }

        fun sanitizeFileName(raw: String): String {
            val base = raw.substringAfterLast('/').substringAfterLast('\\')
            val cleaned = base.replace(Regex("[^A-Za-z0-9._-]"), "_").trimStart('.')
            return cleaned.ifBlank { "model_${System.currentTimeMillis()}.bin" }
        }
    }
}
