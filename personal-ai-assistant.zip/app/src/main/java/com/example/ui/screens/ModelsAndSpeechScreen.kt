package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ai.ModelDownloadManager
import com.example.data.db.DownloadedModelEntity
import com.example.data.settings.SttEngineMode
import com.example.data.settings.TtsEngineMode
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.UtilityCard
import com.example.ui.components.formatFileSize
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.viewmodel.PersonalAiViewModel
import java.util.Locale

private data class UnifiedDownloadableModel(
    val key: String,
    val name: String,
    val fileName: String,
    val downloadUrl: String,
    val category: String,
    val sizeHint: String,
    val formatLabel: String,
    val specsLabel: String,
    val compatibilityLabel: String,
    val description: String,
    val runtimeModelName: String,
    val paramBillions: Double,
    val recommendedRamGb: Int,
    val languagesLabel: String,
    val supportsPersian: Boolean,
    val downloaded: DownloadedModelEntity?
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ModelsAndSpeechScreen(
    viewModel: PersonalAiViewModel,
    onBack: () -> Unit,
    onOpenApiKeySettings: () -> Unit
) {
    val context = LocalContext.current
    val aiSettings by viewModel.aiSettings.collectAsStateWithLifecycle()
    val speechSettings by viewModel.speechSettings.collectAsStateWithLifecycle()
    val downloadedModels by viewModel.downloadedModels.collectAsStateWithLifecycle()
    val systemVoices by viewModel.availableSystemVoices.collectAsStateWithLifecycle()
    val deviceRamInfo by viewModel.deviceRamInfo.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.isSpeaking.collectAsStateWithLifecycle()
    val presets = viewModel.curatedModelPresets

    var filter by remember { mutableStateOf("ALL") }
    var showCustomUrlDialog by remember { mutableStateOf(false) }
    var showVoiceTuningDialog by remember { mutableStateOf(false) }
    var modelToConfigureRunner by remember { mutableStateOf<DownloadedModelEntity?>(null) }

    val unifiedModels = remember(presets, downloadedModels) {
        val byUrl = downloadedModels.associateBy { it.downloadUrl }
        val presetItems = presets.map { preset ->
            UnifiedDownloadableModel(
                key = preset.id,
                name = preset.name,
                fileName = preset.fileName,
                downloadUrl = preset.downloadUrl,
                category = preset.category,
                sizeHint = preset.sizeHint,
                formatLabel = preset.formatLabel,
                specsLabel = preset.specsLabel,
                compatibilityLabel = preset.compatibilityLabel,
                description = preset.description,
                runtimeModelName = preset.runtimeModelName,
                paramBillions = preset.paramBillions,
                recommendedRamGb = preset.recommendedRamGb,
                languagesLabel = preset.languagesLabel,
                supportsPersian = preset.supportsPersian,
                downloaded = byUrl[preset.downloadUrl]
            )
        }
        val presetUrls = presets.mapTo(mutableSetOf()) { it.downloadUrl }
        val customItems = downloadedModels
            .filter { it.downloadUrl !in presetUrls }
            .map { dl ->
                UnifiedDownloadableModel(
                    key = "custom_${dl.id}",
                    name = dl.name,
                    fileName = dl.fileName,
                    downloadUrl = dl.downloadUrl,
                    category = dl.category,
                    sizeHint = if (dl.totalBytes > 0L) formatFileSize(dl.totalBytes) else "Custom file",
                    formatLabel = dl.fileName.substringAfterLast('.', "BIN").uppercase(),
                    specsLabel = "Custom downloaded model",
                    compatibilityLabel = "OpenAI-compatible / Local runner",
                    description = dl.downloadUrl,
                    runtimeModelName = ModelDownloadManager.suggestedRuntimeModelName(dl),
                    paramBillions = 0.0,
                    recommendedRamGb = 4,
                    languagesLabel = "Custom / User specified",
                    supportsPersian = dl.name.contains("persian", ignoreCase = true) ||
                        dl.name.contains("fa", ignoreCase = true) ||
                        dl.name.contains("qwen", ignoreCase = true) ||
                        dl.name.contains("gemma", ignoreCase = true),
                    downloaded = dl
                )
            }
        customItems + presetItems
    }

    val filteredModels = remember(unifiedModels, filter) {
        when (filter) {
            "TEXT" -> unifiedModels.filter { ModelDownloadManager.isTextCategory(it.category) }
            "SPEECH" -> unifiedModels.filter {
                ModelDownloadManager.isSpeechSttCategory(it.category) ||
                    ModelDownloadManager.isSpeechTtsCategory(it.category)
            }
            "PERSIAN" -> unifiedModels.filter { it.supportsPersian }
            "DOWNLOADED" -> unifiedModels.filter {
                it.downloaded?.status == ModelDownloadManager.STATUS_COMPLETED
            }
            else -> unifiedModels
        }
    }

    val downloadedCount = remember(downloadedModels) {
        downloadedModels.count { it.status == ModelDownloadManager.STATUS_COMPLETED }
    }

    val defaultTextSummary = if (aiSettings.defaultDownloadedTextModelId != null &&
        aiSettings.defaultDownloadedTextModelName.isNotBlank()
    ) {
        "${aiSettings.defaultDownloadedTextModelName} (Downloaded)"
    } else {
        "${aiSettings.effectiveDisplayName} • ${aiSettings.model}"
    }

    val defaultTtsSummary = when {
        speechSettings.defaultDownloadedTtsModelId != null &&
            speechSettings.defaultDownloadedTtsModelName.isNotBlank() ->
            "${speechSettings.defaultDownloadedTtsModelName} (Downloaded)"
        speechSettings.ttsEngine == TtsEngineMode.CLOUD_TTS ->
            "Cloud TTS • ${speechSettings.cloudTtsModel}"
        speechSettings.systemVoiceName.isNotBlank() ->
            "Android Voice • ${speechSettings.systemVoiceName}"
        else -> "Android Offline System Voice"
    }

    val defaultSttSummary = when {
        speechSettings.defaultDownloadedSttModelId != null &&
            speechSettings.defaultDownloadedSttModelName.isNotBlank() ->
            "${speechSettings.defaultDownloadedSttModelName} (Downloaded)"
        speechSettings.sttEngine == SttEngineMode.CLOUD_WHISPER ->
            "Whisper • ${speechSettings.cloudSttModel}"
        else -> "Android Speech Recognition"
    }

    if (showCustomUrlDialog) {
        AddCustomModelDialog(
            onDismiss = { showCustomUrlDialog = false },
            onDownload = { label, url, category ->
                viewModel.startModelDownload(name = label, url = url, category = category)
                showCustomUrlDialog = false
            }
        )
    }

    if (showVoiceTuningDialog) {
        SpeechTuningDialog(
            viewModel = viewModel,
            onDismiss = { showVoiceTuningDialog = false }
        )
    }

    modelToConfigureRunner?.let { target ->
        ConfigureRunnerDialog(
            model = target,
            currentAiBaseUrl = aiSettings.customBaseUrl,
            currentSpeechBaseUrl = speechSettings.cloudSpeechBaseUrl,
            onDismiss = { modelToConfigureRunner = null },
            onConfirm = { servedModelName, endpointUrl, apiKey ->
                viewModel.setDownloadedModelAsDefault(
                    model = target,
                    servedModelName = servedModelName,
                    endpointUrl = endpointUrl,
                    apiKey = apiKey
                )
                modelToConfigureRunner = null
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = {
                    Column {
                        Text("Downloadable AI Models", fontWeight = FontWeight.SemiBold)
                        Text(
                            text = "Download text & speech models and set your default AI",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showCustomUrlDialog = true },
                        modifier = Modifier.testTag("models_add_custom_button")
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = "Add custom model URL")
                    }
                    IconButton(
                        onClick = { showVoiceTuningDialog = true },
                        modifier = Modifier.testTag("models_speech_tuning_button")
                    ) {
                        Icon(Icons.Filled.Tune, contentDescription = "Voice & speech settings")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 720.dp)
            ) {
                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = "Your Active Default AI",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                StatusPill(
                                    granted = true,
                                    grantedLabel = "$downloadedCount Downloaded",
                                    notGrantedLabel = ""
                                )
                            }
                            Text(
                                text = "Text AI: $defaultTextSummary",
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = JetBrainsMonoFontFamily
                            )
                            Text(
                                text = "Speech Voice (TTS): $defaultTtsSummary",
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = JetBrainsMonoFontFamily
                            )
                            Text(
                                text = "Speech Input (STT): $defaultSttSummary",
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = JetBrainsMonoFontFamily
                            )
                            if (deviceRamInfo.totalBytes > 0L) {
                                val totalRamText = String.format(Locale.US, "%.1f", deviceRamInfo.totalGb)
                                val freeRamText = String.format(Locale.US, "%.1f", deviceRamInfo.availableGb)
                                val ramSuitability = if (deviceRamInfo.isSixGbOrMore) {
                                    "6+ GB Ready for >2B Persian AI"
                                } else {
                                    "6+ GB recommended for 3B–4B models"
                                }
                                Text(
                                    text = "Device RAM: $totalRamText GB total ($freeRamText GB free) • $ramSuitability",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (deviceRamInfo.isSixGbOrMore) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { showCustomUrlDialog = true },
                                    modifier = Modifier.testTag("open_custom_download_button")
                                ) {
                                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Custom URL")
                                }
                                OutlinedButton(
                                    onClick = {
                                        if (isSpeaking) {
                                            viewModel.stopSpeaking()
                                        } else {
                                            viewModel.speakText("Personal AI default voice is ready.")
                                        }
                                    },
                                    modifier = Modifier.testTag("quick_test_voice_button")
                                ) {
                                    Icon(
                                        imageVector = if (isSpeaking) Icons.Filled.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (isSpeaking) "Stop Audio" else "Test Voice")
                                }
                                OutlinedButton(
                                    onClick = {
                                        val res = runCatching { context.startActivity(viewModel.getInstallTtsDataIntent()) }
                                        if (res.isFailure) {
                                            viewModel.showNotice("No offline Android TTS installer available on this device.")
                                        }
                                    },
                                    modifier = Modifier.testTag("install_offline_tts_pack_button")
                                ) {
                                    Icon(Icons.Filled.RecordVoiceOver, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Android Voice Packs (${systemVoices.size})")
                                }
                                TextButton(onClick = onOpenApiKeySettings) {
                                    Text("Cloud API Keys")
                                }
                            }
                        }
                    }
                }

                item {
                    SectionHeader(
                        title = "All Downloadable Models",
                        subtitle = ">2B Persian-capable Text AI (6+ GB RAM) & Speech models — download and set your Default AI"
                    )
                }

                item {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = filter == "ALL",
                            onClick = { filter = "ALL" },
                            label = { Text("All (${unifiedModels.size})") },
                            modifier = Modifier.testTag("models_filter_all")
                        )
                        FilterChip(
                            selected = filter == "PERSIAN",
                            onClick = { filter = "PERSIAN" },
                            label = { Text("Persian (فارسی)") },
                            modifier = Modifier.testTag("models_filter_persian")
                        )
                        FilterChip(
                            selected = filter == "TEXT",
                            onClick = { filter = "TEXT" },
                            label = { Text("Text Models") },
                            modifier = Modifier.testTag("models_filter_text")
                        )
                        FilterChip(
                            selected = filter == "SPEECH",
                            onClick = { filter = "SPEECH" },
                            label = { Text("Speech Models") },
                            modifier = Modifier.testTag("models_filter_speech")
                        )
                        FilterChip(
                            selected = filter == "DOWNLOADED",
                            onClick = { filter = "DOWNLOADED" },
                            label = { Text("Downloaded ($downloadedCount)") },
                            modifier = Modifier.testTag("models_filter_downloaded")
                        )
                    }
                }

                if (filteredModels.isEmpty()) {
                    item {
                        UtilityCard(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp)
                            ) {
                                Text(
                                    text = "No Downloaded Models Yet",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Switch back to All Models to download a Text or Speech model.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(onClick = { filter = "ALL" }) {
                                    Text("Show All Models")
                                }
                            }
                        }
                    }
                } else {
                    items(filteredModels, key = { it.key }) { item ->
                        val dl = item.downloaded
                        val isDefault = dl != null && when {
                            ModelDownloadManager.isSpeechSttCategory(item.category) ->
                                speechSettings.defaultDownloadedSttModelId == dl.id
                            ModelDownloadManager.isSpeechTtsCategory(item.category) ->
                                speechSettings.defaultDownloadedTtsModelId == dl.id
                            else ->
                                aiSettings.defaultDownloadedTextModelId == dl.id
                        }
                        UnifiedModelDetailCard(
                            model = item,
                            isDefault = isDefault,
                            deviceTotalRamGb = deviceRamInfo.totalGb,
                            onDownload = {
                                viewModel.startModelDownload(
                                    name = item.name,
                                    url = item.downloadUrl,
                                    category = item.category,
                                    suggestedFileName = item.fileName
                                )
                            },
                            onCancel = { dl?.let { viewModel.cancelModelDownload(it) } },
                            onSetDefault = {
                                if (dl != null) {
                                    val defaultEndpoint = when {
                                        ModelDownloadManager.isSpeechSttCategory(item.category) ||
                                            ModelDownloadManager.isSpeechTtsCategory(item.category) ->
                                            speechSettings.cloudSpeechBaseUrl.ifBlank { "http://127.0.0.1:8080/v1" }
                                        else ->
                                            if (aiSettings.customBaseUrl.startsWith("http://127.0.0.1") ||
                                                aiSettings.customBaseUrl.startsWith("http://10.0.2.2")
                                            ) aiSettings.customBaseUrl else "http://127.0.0.1:8080/v1"
                                    }
                                    viewModel.setDownloadedModelAsDefault(
                                        model = dl,
                                        servedModelName = item.runtimeModelName,
                                        endpointUrl = defaultEndpoint
                                    )
                                }
                            },
                            onConfigureRunner = { dl?.let { modelToConfigureRunner = it } },
                            onDelete = { dl?.let { viewModel.deleteDownloadedModel(it) } }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun UnifiedModelDetailCard(
    model: UnifiedDownloadableModel,
    isDefault: Boolean,
    deviceTotalRamGb: Double,
    onDownload: () -> Unit,
    onCancel: () -> Unit,
    onSetDefault: () -> Unit,
    onConfigureRunner: () -> Unit,
    onDelete: () -> Unit
) {
    val dl = model.downloaded
    val status = dl?.status
    val isDownloading = status == ModelDownloadManager.STATUS_QUEUED ||
        status == ModelDownloadManager.STATUS_DOWNLOADING
    val isCompleted = status == ModelDownloadManager.STATUS_COMPLETED
    val isFailedOrCancelled = status == ModelDownloadManager.STATUS_FAILED ||
        status == ModelDownloadManager.STATUS_CANCELLED
    val isLowRamWarning = deviceTotalRamGb > 0.5 && (deviceTotalRamGb + 0.4) < model.recommendedRamGb

    val categoryIcon = when {
        ModelDownloadManager.isSpeechSttCategory(model.category) -> Icons.Filled.Mic
        ModelDownloadManager.isSpeechTtsCategory(model.category) -> Icons.Filled.GraphicEq
        else -> Icons.Filled.TextFields
    }

    val border = if (isDefault) {
        BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
    } else {
        BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    }

    Card(
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = border,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("model_card_${model.key}")
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            imageVector = categoryIcon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = model.name,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${model.category} • ${model.sizeHint} • ${model.formatLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = JetBrainsMonoFontFamily,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                if (isDefault) {
                    StatusPill(
                        granted = true,
                        grantedLabel = "Default AI",
                        notGrantedLabel = ""
                    )
                } else if (isCompleted) {
                    StatusPill(
                        granted = true,
                        grantedLabel = "Downloaded",
                        notGrantedLabel = ""
                    )
                }
            }

            Text(
                text = model.specsLabel,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Medium
            )

            Text(
                text = "Languages: ${model.languagesLabel} • Needs ${model.recommendedRamGb}+ GB RAM",
                style = MaterialTheme.typography.labelSmall,
                color = if (model.supportsPersian) {
                    MaterialTheme.colorScheme.primary
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                }
            )

            if (isLowRamWarning) {
                Text(
                    text = "Low RAM notice: Device has ${String.format(Locale.US, "%.1f", deviceTotalRamGb)} GB RAM; ${model.recommendedRamGb}+ GB recommended.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Text(
                text = model.description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Text(
                text = "File: ${model.fileName} • Runner: ${model.compatibilityLabel}",
                style = MaterialTheme.typography.labelSmall,
                fontFamily = JetBrainsMonoFontFamily,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (isDownloading && dl != null) {
                if (dl.totalBytes > 0L) {
                    val progress = (dl.downloadedBytes.toFloat() / dl.totalBytes.toFloat()).coerceIn(0f, 1f)
                    LinearProgressIndicator(
                        progress = { progress },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "Downloading: ${formatFileSize(dl.downloadedBytes)} / ${formatFileSize(dl.totalBytes)}",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = JetBrainsMonoFontFamily
                    )
                } else {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text(
                        text = "Downloading: ${formatFileSize(dl.downloadedBytes)}...",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = JetBrainsMonoFontFamily
                    )
                }
            }

            if (isCompleted && dl != null && dl.downloadedBytes > 0L) {
                Text(
                    text = "Stored (${formatFileSize(dl.downloadedBytes)}) • SHA-256: ${dl.sha256.take(12)}...",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (isFailedOrCancelled && !dl?.errorMessage.isNullOrBlank()) {
                Text(
                    text = dl?.errorMessage.orEmpty(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                when {
                    isDownloading -> {
                        OutlinedButton(
                            onClick = onCancel,
                            modifier = Modifier.testTag("cancel_model_${model.key}")
                        ) {
                            Icon(Icons.Filled.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Cancel")
                        }
                    }
                    isCompleted -> {
                        if (isDefault) {
                            OutlinedButton(
                                onClick = onConfigureRunner,
                                modifier = Modifier.testTag("runner_model_${model.key}")
                            ) {
                                Icon(Icons.Filled.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Runner URL")
                            }
                        } else {
                            Button(
                                onClick = onSetDefault,
                                modifier = Modifier.testTag("set_default_${model.key}")
                            ) {
                                Icon(Icons.Filled.Star, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Set as Default AI")
                            }
                        }
                        TextButton(
                            onClick = onDelete,
                            modifier = Modifier.testTag("delete_model_${model.key}")
                        ) {
                            Icon(
                                Icons.Filled.Delete,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Delete", color = MaterialTheme.colorScheme.error)
                        }
                    }
                    else -> {
                        Button(
                            onClick = onDownload,
                            modifier = Modifier.testTag("download_model_${model.key}")
                        ) {
                            Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (isFailedOrCancelled) "Retry Download" else "Download")
                        }
                        if (dl != null) {
                            TextButton(onClick = onDelete) {
                                Text("Remove", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddCustomModelDialog(
    onDismiss: () -> Unit,
    onDownload: (label: String, url: String, category: String) -> Unit
) {
    var customName by remember { mutableStateOf("") }
    var customUrl by remember { mutableStateOf("") }
    var customCategory by remember { mutableStateOf(ModelDownloadManager.CATEGORY_TEXT) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Download Custom Model") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = customName,
                    onValueChange = { customName = it },
                    label = { Text("Model Name") },
                    placeholder = { Text("e.g. Llama 3.2 1B Q4") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("model_download_name_input")
                )
                OutlinedTextField(
                    value = customUrl,
                    onValueChange = { customUrl = it },
                    label = { Text("HTTPS Model URL") },
                    placeholder = { Text("https://huggingface.co/.../model.gguf") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("model_download_url_input")
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        ModelDownloadManager.CATEGORY_TEXT,
                        ModelDownloadManager.CATEGORY_SPEECH_STT,
                        ModelDownloadManager.CATEGORY_SPEECH_TTS
                    ).forEach { cat ->
                        FilterChip(
                            selected = customCategory == cat,
                            onClick = { customCategory = cat },
                            label = { Text(cat) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onDownload(customName, customUrl, customCategory) },
                enabled = customUrl.isNotBlank(),
                modifier = Modifier.testTag("model_download_submit_button")
            ) {
                Text("Download")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ConfigureRunnerDialog(
    model: DownloadedModelEntity,
    currentAiBaseUrl: String,
    currentSpeechBaseUrl: String,
    onDismiss: () -> Unit,
    onConfirm: (servedModelName: String, endpointUrl: String, apiKey: String?) -> Unit
) {
    val isSpeech = ModelDownloadManager.isSpeechSttCategory(model.category) ||
        ModelDownloadManager.isSpeechTtsCategory(model.category)
    val initialUrl = if (isSpeech) {
        currentSpeechBaseUrl.ifBlank { "http://127.0.0.1:8080/v1" }
    } else {
        if (currentAiBaseUrl.startsWith("http://127.0.0.1") || currentAiBaseUrl.startsWith("http://10.0.2.2")) {
            currentAiBaseUrl
        } else {
            "http://127.0.0.1:8080/v1"
        }
    }

    var modelIdDraft by remember(model.id) {
        mutableStateOf(ModelDownloadManager.suggestedRuntimeModelName(model))
    }
    var endpointDraft by remember(model.id) { mutableStateOf(initialUrl) }
    var apiKeyDraft by remember(model.id) { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Runner Endpoint Settings") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Point \"${model.name}\" to your local llama.cpp, Ollama, Whisper, or Piper server.",
                    style = MaterialTheme.typography.bodySmall
                )
                OutlinedTextField(
                    value = modelIdDraft,
                    onValueChange = { modelIdDraft = it },
                    label = { Text("Served Model ID") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = endpointDraft,
                    onValueChange = { endpointDraft = it },
                    label = { Text("Server Base URL") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SuggestionChip(
                        onClick = { endpointDraft = "http://127.0.0.1:8080/v1" },
                        label = { Text("Device 127.0.0.1:8080") }
                    )
                    SuggestionChip(
                        onClick = { endpointDraft = "http://10.0.2.2:11434/v1" },
                        label = { Text("Host Ollama 10.0.2.2") }
                    )
                }
                OutlinedTextField(
                    value = apiKeyDraft,
                    onValueChange = { apiKeyDraft = it },
                    label = { Text("API Key (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(modelIdDraft, endpointDraft, apiKeyDraft.ifBlank { null }) }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun SpeechTuningDialog(
    viewModel: PersonalAiViewModel,
    onDismiss: () -> Unit
) {
    val speechSettings by viewModel.speechSettings.collectAsStateWithLifecycle()
    val systemVoices by viewModel.availableSystemVoices.collectAsStateWithLifecycle()

    var autoSpeak by remember { mutableStateOf(speechSettings.autoSpeakResponses) }
    var rate by remember { mutableFloatStateOf(speechSettings.speechRate) }
    var pitch by remember { mutableFloatStateOf(speechSettings.speechPitch) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Voice & Speech Options") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                SettingToggleRow(
                    title = "Auto-speak AI replies",
                    subtitle = "Automatically read aloud assistant messages in Chat.",
                    checked = autoSpeak,
                    onCheckedChange = { autoSpeak = it }
                )
                Text("Rate: ${String.format("%.2f", rate)}x", style = MaterialTheme.typography.labelMedium)
                Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.5f..2.0f)
                Text("Pitch: ${String.format("%.2f", pitch)}x", style = MaterialTheme.typography.labelMedium)
                Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.5f..2.0f)

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { viewModel.setSystemVoiceAsDefault("") }) {
                        Text("Use System TTS")
                    }
                    OutlinedButton(onClick = { viewModel.setSystemSttAsDefault() }) {
                        Text("Use System STT")
                    }
                }
                if (systemVoices.isNotEmpty()) {
                    Text("Installed System Voices (${systemVoices.size})", style = MaterialTheme.typography.labelMedium)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        systemVoices.take(6).forEach { voice ->
                            FilterChip(
                                selected = speechSettings.ttsEngine == TtsEngineMode.SYSTEM_TTS &&
                                    speechSettings.systemVoiceName == voice.name,
                                onClick = { viewModel.setSystemVoiceAsDefault(voice.name) },
                                label = { Text(voice.localeTag) }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    viewModel.saveSpeechSettings(
                        speechSettings.copy(
                            autoSpeakResponses = autoSpeak,
                            speechRate = rate,
                            speechPitch = pitch
                        )
                    )
                    onDismiss()
                }
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
