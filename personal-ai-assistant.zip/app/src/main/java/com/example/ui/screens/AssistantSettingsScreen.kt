package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.settings.ThemeMode
import com.example.permissions.PermissionId
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.ThemeSelectorList
import com.example.ui.components.UtilityCard
import com.example.ui.viewmodel.PersonalAiViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AssistantSettingsScreen(
    viewModel: PersonalAiViewModel,
    onBack: () -> Unit,
    onOpenMemory: () -> Unit,
    onOpenSetup: () -> Unit
) {
    val context = LocalContext.current
    val settings by viewModel.assistantSettings.collectAsStateWithLifecycle()
    val permissions by viewModel.permissions.collectAsStateWithLifecycle()
    val wakeRunning by viewModel.wakeWordRunning.collectAsStateWithLifecycle()
    val wakeListening by viewModel.wakeWordListening.collectAsStateWithLifecycle()
    val lastWakeHeard by viewModel.lastWakeHeardText.collectAsStateWithLifecycle()

    val defaultStatus = permissions.firstOrNull { it.id == PermissionId.DEFAULT_ASSISTANT }
    val hasMic = permissions.firstOrNull { it.id == PermissionId.MICROPHONE }?.isGranted == true

    var nameInput by remember(settings.assistantName) { mutableStateOf(settings.assistantName) }
    LaunchedEffect(settings.assistantName) {
        nameInput = settings.assistantName
    }

    val roleLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { viewModel.refreshSystemState() }

    val micWakeLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.refreshSystemState()
        if (granted) {
            viewModel.setWakeWordEnabled(true)
        } else {
            viewModel.showNotice("Microphone permission is needed for hands-free wake-word detection.")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Assistant Settings", fontWeight = FontWeight.SemiBold) }
            )
        }
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 680.dp)
            ) {
                item {
                    SectionHeader(
                        title = "AI Name & Voice Wake",
                        subtitle = "Say your AI's chosen name to summon the Google Assistant / Gemini-style bottom overlay"
                    )
                }
                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.Mic,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Wake Name: \"${settings.assistantName}\"",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                StatusPill(
                                    granted = wakeRunning,
                                    grantedLabel = if (wakeListening) "Listening" else "Active",
                                    notGrantedLabel = "Off"
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = nameInput,
                                    onValueChange = { nameInput = it },
                                    label = { Text("Choose AI Name") },
                                    placeholder = { Text("e.g. Nova, Jarvis, سارا") },
                                    singleLine = true,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("assistant_name_input")
                                )
                                Button(
                                    onClick = { viewModel.setAssistantName(nameInput) },
                                    enabled = nameInput.isNotBlank(),
                                    modifier = Modifier.testTag("assistant_name_save_button")
                                ) {
                                    Text("Save")
                                }
                            }

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                listOf("Personal AI", "Nova", "Aria", "Atlas", "سارا").forEach { preset ->
                                    AssistChip(
                                        onClick = {
                                            nameInput = preset
                                            viewModel.setAssistantName(preset)
                                        },
                                        label = { Text(preset) }
                                    )
                                }
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(end = 12.dp)
                                ) {
                                    Text(
                                        text = "Wake when I say \"${settings.assistantName}\"",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = "Runs a foreground microphone listener and pops open the bottom assistant when your AI name is spoken.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = settings.wakeWordEnabled,
                                    onCheckedChange = { enable ->
                                        if (enable && !hasMic) {
                                            micWakeLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                        } else {
                                            viewModel.setWakeWordEnabled(enable)
                                        }
                                    },
                                    modifier = Modifier.testTag("assistant_wake_toggle")
                                )
                            }

                            if (wakeRunning && !lastWakeHeard.isNullOrBlank()) {
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "Last heard: \"$lastWakeHeard\"",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }

                            OutlinedButton(
                                onClick = { viewModel.launchBottomWakeAssistant(context) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("assistant_test_wake_button")
                            ) {
                                Icon(Icons.Filled.GraphicEq, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Preview Bottom Wake Overlay")
                            }
                        }
                    }
                }

                item {
                    SectionHeader("Default Android Assistant")
                }
                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("System Role Status", style = MaterialTheme.typography.titleSmall)
                                StatusPill(
                                    granted = defaultStatus?.isGranted == true,
                                    grantedLabel = "Default",
                                    notGrantedLabel = "Not default"
                                )
                            }
                            Text(
                                text = defaultStatus?.statusDetail.orEmpty(),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = {
                                        val roleIntent = viewModel.getAssistantRoleIntent()
                                        if (roleIntent != null) {
                                            roleLauncher.launch(roleIntent)
                                        } else {
                                            context.startActivity(viewModel.getVoiceInputSettingsIntent())
                                        }
                                    },
                                    modifier = Modifier.testTag("assistant_set_default_button")
                                ) {
                                    Text("Choose Default Assistant")
                                }
                                OutlinedButton(
                                    onClick = { context.startActivity(viewModel.getVoiceInputSettingsIntent()) }
                                ) {
                                    Text("System Settings")
                                }
                            }
                        }
                    }
                }

                item { SectionHeader("Behavior & Safety") }

                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            SettingToggleRow(
                                title = "Confirm sensitive UI actions",
                                subtitle = "Ask before tapping buttons on other apps via Accessibility.",
                                checked = settings.confirmSensitiveActions,
                                onCheckedChange = viewModel::setConfirmSensitiveActions
                            )
                            SettingToggleRow(
                                title = "Auto-attach screen context",
                                subtitle = "Automatically include active screen text when sending queries.",
                                checked = settings.includeScreenContextAutomatically,
                                onCheckedChange = viewModel::setIncludeScreenContextAutomatically
                            )
                            SettingToggleRow(
                                title = "Scan MediaStore public Downloads",
                                subtitle = "Include accessible downloads alongside authorized SAF folders.",
                                checked = settings.indexMediaStorePublicItems,
                                onCheckedChange = viewModel::setIndexMediaStorePublicItems
                            )
                            SettingToggleRow(
                                title = "Personal Memory",
                                subtitle = "Allow saving non-sensitive user preferences locally.",
                                checked = settings.memoryEnabled,
                                onCheckedChange = viewModel::setMemoryEnabled
                            )
                            OutlinedButton(
                                onClick = onOpenMemory,
                                modifier = Modifier.testTag("assistant_manage_memory_button")
                            ) {
                                Text("Manage Saved Memories")
                            }
                        }
                    }
                }

                item { SectionHeader("Appearance & Theme", "Applies to all screens, floating bubble, panel & logo") }

                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text("Select Theme", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            ThemeSelectorList(
                                selectedTheme = settings.themeMode,
                                onSelectTheme = viewModel::setThemeMode
                            )
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                                settings.themeMode != ThemeMode.PERSIAN &&
                                settings.themeMode != ThemeMode.NEON
                            ) {
                                SettingToggleRow(
                                    title = "Material You Dynamic Color",
                                    subtitle = "Blend standard Light/Dark surfaces with your Android wallpaper.",
                                    checked = settings.dynamicColor,
                                    onCheckedChange = viewModel::setDynamicColor
                                )
                            }
                        }
                    }
                }

                item {
                    OutlinedButton(
                        onClick = {
                            viewModel.resetOnboarding()
                            onOpenSetup()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Re-run Guided Setup")
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }
}

@Composable
fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(end = 12.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
            Text(
                subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
