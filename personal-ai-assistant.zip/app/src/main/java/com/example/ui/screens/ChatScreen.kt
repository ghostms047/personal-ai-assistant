package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SettingsSuggest
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.assistant.AssistantOrchestrator
import com.example.assistant.ChatSessionSummary
import com.example.data.db.ChatMessageEntity
import com.example.data.settings.AiRouteIssue
import com.example.data.settings.AiRoutingMode
import com.example.data.settings.SttEngineMode
import com.example.permissions.PermissionId
import com.example.tools.AskUserOption
import com.example.tools.PendingConfirmation
import com.example.ui.components.PersonalAiLogo
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.viewmodel.PersonalAiViewModel
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ChatScreen(
    viewModel: PersonalAiViewModel,
    onBack: () -> Unit,
    onOpenApiKeySettings: () -> Unit,
    onOpenModelsAndSpeech: () -> Unit = {},
    onOpenAssistantSettings: () -> Unit = {},
    onOpenSecurityScan: () -> Unit = {},
    onOpenPatterns: () -> Unit = {}
) {
    val context = LocalContext.current
    @Suppress("DEPRECATION")
    val clipboard = LocalClipboardManager.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    val messages by viewModel.chatMessages.collectAsStateWithLifecycle()
    val chatSessions by viewModel.chatSessions.collectAsStateWithLifecycle()
    val totalStoredMessages by viewModel.totalStoredChatMessages.collectAsStateWithLifecycle()
    val historySearchResults by viewModel.historySearchResults.collectAsStateWithLifecycle()
    val activeSessionId by viewModel.activeChatSessionId.collectAsStateWithLifecycle()
    val isProcessing by viewModel.isProcessingChat.collectAsStateWithLifecycle()
    val activeToolStatus by viewModel.activeToolStatus.collectAsStateWithLifecycle()
    val aiSettings by viewModel.aiSettings.collectAsStateWithLifecycle()
    val assistantSettings by viewModel.assistantSettings.collectAsStateWithLifecycle()
    val speechSettings by viewModel.speechSettings.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.isSpeaking.collectAsStateWithLifecycle()
    val isRecordingWhisper by viewModel.isRecordingCloudStt.collectAsStateWithLifecycle()
    val isTranscribingWhisper by viewModel.isTranscribingCloudStt.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
    val activeAiRoute by viewModel.activeAiRoute.collectAsStateWithLifecycle()
    val permissions by viewModel.permissions.collectAsStateWithLifecycle()

    val chosenName = assistantSettings.assistantName.ifBlank { "Personal AI" }
    val hasMic = permissions.firstOrNull { it.id == PermissionId.MICROPHONE }?.isGranted == true

    var input by remember { mutableStateOf("") }
    var attachScreen by remember { mutableStateOf(false) }
    var isListening by remember { mutableStateOf(false) }
    var lastAutoSpokenId by remember { mutableLongStateOf(messages.lastOrNull()?.id ?: 0L) }
    var historyQuery by remember { mutableStateOf("") }
    var renameTarget by remember { mutableStateOf<ChatSessionSummary?>(null) }
    var renameDraft by remember { mutableStateOf("") }
    var showClearAllConfirm by remember { mutableStateOf(false) }
    var showRoutingDialog by remember { mutableStateOf(false) }
    val dbSizeLabel = remember(totalStoredMessages, chatSessions.size) { viewModel.getLocalDatabaseSizeLabel() }
    val listState = rememberLazyListState()

    BackHandler(enabled = drawerState.isOpen) {
        scope.launch { drawerState.close() }
    }

    val speechRecognizer = remember {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            SpeechRecognizer.createSpeechRecognizer(context)
        } else null
    }

    DisposableEffect(speechRecognizer) {
        onDispose {
            speechRecognizer?.destroy()
            viewModel.cancelCloudWhisperRecording()
        }
    }

    fun startSpeech() {
        val recognizer = speechRecognizer ?: run {
            viewModel.showNotice("Speech recognition service is unavailable on this device.")
            return
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { isListening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { isListening = false }
            override fun onError(error: Int) { isListening = false }
            override fun onResults(results: Bundle?) {
                isListening = false
                val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?.trim()
                    .orEmpty()
                if (spoken.isNotBlank()) {
                    viewModel.sendMessage(spoken, attachScreen = attachScreen)
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer.startListening(intent)
    }

    fun triggerVoiceInput() {
        if (speechSettings.sttEngine == SttEngineMode.CLOUD_WHISPER) {
            viewModel.toggleCloudWhisperRecording { spoken ->
                if (spoken.isNotBlank()) {
                    viewModel.sendMessage(spoken, attachScreen = attachScreen)
                }
            }
        } else {
            startSpeech()
        }
    }

    val micLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.refreshSystemState()
        if (granted) triggerVoiceInput() else viewModel.showNotice("Microphone permission denied. You can still type queries.")
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
            val latest = messages.last()
            if (speechSettings.autoSpeakResponses &&
                latest.role == AssistantOrchestrator.ROLE_ASSISTANT &&
                latest.id > lastAutoSpokenId &&
                latest.content.isNotBlank()
            ) {
                lastAutoSpokenId = latest.id
                viewModel.speakText(latest.content)
            } else if (latest.id > lastAutoSpokenId) {
                lastAutoSpokenId = latest.id
            }
        }
    }

    val latestAssistantId = remember(messages) {
        messages.lastOrNull { it.role == AssistantOrchestrator.ROLE_ASSISTANT }?.id
    }

    if (renameTarget != null) {
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            title = { Text("Rename Conversation") },
            text = {
                OutlinedTextField(
                    value = renameDraft,
                    onValueChange = { renameDraft = it },
                    label = { Text("Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.renameChatSession(renameTarget!!.sessionId, renameDraft)
                        renameTarget = null
                    },
                    enabled = renameDraft.isNotBlank()
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text("Cancel") }
            }
        )
    }

    if (showClearAllConfirm) {
        AlertDialog(
            onDismissRequest = { showClearAllConfirm = false },
            title = { Text("Clear Local Chat History?") },
            text = {
                Text("This removes all $totalStoredMessages locally saved messages and threads from this phone.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearAllChatHistory()
                        showClearAllConfirm = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Clear All") }
            },
            dismissButton = {
                TextButton(onClick = { showClearAllConfirm = false }) { Text("Cancel") }
            }
        )
    }

    if (showRoutingDialog) {
        AlertDialog(
            onDismissRequest = { showRoutingDialog = false },
            title = { Text("Offline / Online AI Mode") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (isOnline) "Network: Online" else "Network: Offline",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    AiRoutingMode.entries.forEach { mode ->
                        val selected = aiSettings.routingMode == mode
                        Surface(
                            onClick = {
                                viewModel.setAiRoutingMode(mode)
                                showRoutingDialog = false
                            },
                            shape = RoundedCornerShape(14.dp),
                            color = if (selected) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.surfaceContainerLow
                            },
                            border = BorderStroke(
                                1.dp,
                                if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = mode.label,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = mode.subtitle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showRoutingDialog = false
                    onOpenApiKeySettings()
                }) { Text("Provider & Local Settings") }
            },
            dismissButton = {
                TextButton(onClick = { showRoutingDialog = false }) { Text("Done") }
            }
        )
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.widthIn(max = 330.dp)) {
                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .padding(14.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        PersonalAiLogo(size = 28.dp)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = chosenName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = activeAiRoute.routeBadge,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        FilledTonalButton(
                            onClick = {
                                viewModel.startNewChatSession()
                                scope.launch { drawerState.close() }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_new_session_button")
                        ) {
                            Icon(Icons.Filled.AddComment, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(5.dp))
                            Text("New Chat", maxLines = 1)
                        }
                        OutlinedButton(
                            onClick = {
                                scope.launch { drawerState.close() }
                                viewModel.launchBottomWakeAssistant(context)
                            },
                            modifier = Modifier.testTag("chat_drawer_wake_button")
                        ) {
                            Icon(Icons.Filled.GraphicEq, contentDescription = "Bottom assistant", modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Local phone chat history search
                    OutlinedTextField(
                        value = historyQuery,
                        onValueChange = {
                            historyQuery = it
                            viewModel.searchChatHistory(it)
                        },
                        placeholder = { Text("Search phone history…", style = MaterialTheme.typography.bodySmall) },
                        leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        trailingIcon = if (historyQuery.isNotBlank()) {
                            {
                                IconButton(
                                    onClick = {
                                        historyQuery = ""
                                        viewModel.clearHistorySearch()
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Filled.Close, contentDescription = "Clear search", modifier = Modifier.size(16.dp))
                                }
                            }
                        } else null,
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("chat_history_search_input")
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    if (historyQuery.isNotBlank()) {
                        Text(
                            text = "Matching Messages (${historySearchResults.size})",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            if (historySearchResults.isEmpty()) {
                                item {
                                    Text(
                                        text = "No matching local messages found.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(8.dp)
                                    )
                                }
                            } else {
                                items(historySearchResults) { hit ->
                                    Surface(
                                        onClick = {
                                            viewModel.selectChatSession(hit.sessionId)
                                            scope.launch { drawerState.close() }
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Text(
                                                text = hit.sessionTitle,
                                                style = MaterialTheme.typography.labelMedium,
                                                fontWeight = FontWeight.SemiBold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = hit.snippet,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        Text(
                            text = "Local Conversations (${chatSessions.size})",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )

                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                        ) {
                            if (chatSessions.isEmpty()) {
                                item {
                                    Text(
                                        text = "Your local phone conversations will be saved here automatically.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 12.dp)
                                    )
                                }
                            } else {
                                items(chatSessions, key = { it.sessionId }) { session ->
                                    val selected = session.sessionId == activeSessionId
                                    NavigationDrawerItem(
                                        selected = selected,
                                        onClick = {
                                            viewModel.selectChatSession(session.sessionId)
                                            scope.launch { drawerState.close() }
                                        },
                                        icon = {
                                            Icon(
                                                if (session.isPinned) Icons.Filled.PushPin else Icons.Outlined.ChatBubbleOutline,
                                                contentDescription = null,
                                                modifier = Modifier.size(17.dp),
                                                tint = if (session.isPinned) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        },
                                        label = {
                                            Column {
                                                Text(
                                                    text = session.title,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    style = MaterialTheme.typography.bodyMedium
                                                )
                                                Text(
                                                    text = "${session.messageCount} msgs • ${formatTimestamp(session.lastTimestamp)}",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        },
                                        badge = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                IconButton(
                                                    onClick = { viewModel.pinChatSession(session.sessionId, !session.isPinned) },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(
                                                        imageVector = if (session.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                                                        contentDescription = "Pin chat",
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                                IconButton(
                                                    onClick = {
                                                        renameTarget = session
                                                        renameDraft = session.title
                                                    },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(
                                                        Icons.Filled.Edit,
                                                        contentDescription = "Rename chat",
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                                IconButton(
                                                    onClick = {
                                                        scope.launch {
                                                            val exported = viewModel.exportChatSessionText(session.sessionId)
                                                            if (exported.isNotBlank()) {
                                                                clipboard.setText(AnnotatedString(exported))
                                                                viewModel.showNotice("Copied chat transcript to clipboard.")
                                                            }
                                                        }
                                                    },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(
                                                        Icons.Filled.ContentCopy,
                                                        contentDescription = "Export chat",
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                                IconButton(
                                                    onClick = { viewModel.deleteChatSession(session.sessionId) },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(
                                                        Icons.Filled.DeleteOutline,
                                                        contentDescription = "Delete chat",
                                                        modifier = Modifier.size(14.dp)
                                                    )
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Local phone storage bar
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Filled.Storage, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "$totalStoredMessages msgs • $dbSizeLabel local",
                                style = MaterialTheme.typography.labelSmall,
                                modifier = Modifier.weight(1f)
                            )
                            if (totalStoredMessages > 0) {
                                TextButton(
                                    onClick = { showClearAllConfirm = true },
                                    modifier = Modifier.testTag("chat_clear_all_history_button")
                                ) {
                                    Text("Clear", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    NavigationDrawerItem(
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onBack()
                        },
                        icon = { Icon(Icons.Filled.Home, contentDescription = null) },
                        label = { Text("Home Dashboard") }
                    )
                    NavigationDrawerItem(
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onOpenSecurityScan()
                        },
                        icon = { Icon(Icons.Filled.Radar, contentDescription = null) },
                        label = { Text("Virus & Malware Scanner") }
                    )
                    NavigationDrawerItem(
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onOpenPatterns()
                        },
                        icon = { Icon(Icons.Filled.AutoAwesome, contentDescription = null) },
                        label = { Text("Learned Patterns & Routines") }
                    )
                    NavigationDrawerItem(
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onOpenModelsAndSpeech()
                        },
                        icon = { Icon(Icons.Filled.RecordVoiceOver, contentDescription = null) },
                        label = { Text("Models & Speech AI") }
                    )
                    NavigationDrawerItem(
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onOpenAssistantSettings()
                        },
                        icon = { Icon(Icons.Filled.SettingsSuggest, contentDescription = null) },
                        label = { Text("AI Name, Wake & Theme") }
                    )
                    NavigationDrawerItem(
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            onOpenApiKeySettings()
                        },
                        icon = { Icon(Icons.Filled.Key, contentDescription = null) },
                        label = { Text("API Keys & Offline Routing") }
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    navigationIcon = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { scope.launch { drawerState.open() } },
                                modifier = Modifier.testTag("chat_drawer_button")
                            ) {
                                Icon(Icons.Filled.Menu, contentDescription = "Open chat history drawer")
                            }
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier.testTag("chat_home_button")
                            ) {
                                Icon(Icons.Filled.Home, contentDescription = "Back to Home")
                            }
                        }
                    },
                    title = {
                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerHigh,
                            modifier = Modifier.clickable { onOpenModelsAndSpeech() }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = chosenName,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = aiSettings.model.substringAfterLast('/'),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.widthIn(max = 110.dp)
                                )
                                Icon(
                                    imageVector = Icons.Filled.KeyboardArrowDown,
                                    contentDescription = "Switch model",
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    },
                    actions = {
                        if (isSpeaking) {
                            IconButton(
                                onClick = { viewModel.stopSpeaking() },
                                modifier = Modifier.testTag("chat_stop_speaking_button")
                            ) {
                                Icon(
                                    Icons.Filled.Stop,
                                    contentDescription = "Stop speaking",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        } else {
                            IconButton(
                                onClick = { viewModel.setAutoSpeakResponses(!speechSettings.autoSpeakResponses) },
                                modifier = Modifier.testTag("chat_autospeak_toggle")
                            ) {
                                Icon(
                                    imageVector = if (speechSettings.autoSpeakResponses) {
                                        Icons.AutoMirrored.Filled.VolumeUp
                                    } else {
                                        Icons.AutoMirrored.Filled.VolumeOff
                                    },
                                    contentDescription = "Toggle auto-speak",
                                    tint = if (speechSettings.autoSpeakResponses) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                        }
                        IconButton(
                            onClick = { viewModel.startNewChatSession() },
                            modifier = Modifier.testTag("chat_new_chat_action")
                        ) {
                            Icon(Icons.Filled.AddComment, contentDescription = "New Chat")
                        }
                    }
                )
            }
        ) { innerPadding ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .imePadding()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 760.dp)
                ) {
                    // Interactive Live AI Routing Bar (Auto / API Key Only / Local AI Only)
                    Surface(
                        onClick = { showRoutingDialog = true },
                        color = if (activeAiRoute.issue != null) {
                            MaterialTheme.colorScheme.errorContainer
                        } else {
                            MaterialTheme.colorScheme.surfaceContainerHigh
                        },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 4.dp)
                            .testTag("chat_routing_mode_pill")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = if (activeAiRoute.issue != null) Icons.Filled.WarningAmber else Icons.Filled.SwapHoriz,
                                contentDescription = "Switch Offline or Online AI mode",
                                tint = if (activeAiRoute.issue != null) {
                                    MaterialTheme.colorScheme.onErrorContainer
                                } else {
                                    MaterialTheme.colorScheme.primary
                                },
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = when (activeAiRoute.issue) {
                                    AiRouteIssue.MISSING_API_KEY -> "API Key needed or tap to switch to Local AI"
                                    AiRouteIssue.OFFLINE_API_ONLY -> "Offline with 'API Key Only' — tap to switch to Auto or Local AI"
                                    AiRouteIssue.MISSING_LOCAL_CONFIG -> "Offline: tap to configure Local AI endpoint"
                                    null -> "${activeAiRoute.routeBadge} • Tap to switch Auto / API Key / Local"
                                },
                                style = MaterialTheme.typography.labelMedium,
                                color = if (activeAiRoute.issue != null) {
                                    MaterialTheme.colorScheme.onErrorContainer
                                } else {
                                    MaterialTheme.colorScheme.onSurfaceVariant
                                },
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    LazyColumn(
                        state = listState,
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        if (messages.isEmpty()) {
                            item {
                                ChatGptEmptyState(
                                    assistantName = chosenName,
                                    modelSubtitle = activeAiRoute.routeBadge,
                                    onSelectPrompt = { prompt ->
                                        viewModel.sendMessage(prompt, attachScreen = attachScreen)
                                    },
                                    onWakeOverlay = { viewModel.launchBottomWakeAssistant(context) }
                                )
                            }
                        } else {
                            items(messages, key = { it.id }) { msg ->
                                ChatGptMessageRow(
                                    message = msg,
                                    assistantName = chosenName,
                                    isLatestAssistant = msg.id == latestAssistantId,
                                    onSelectOption = { opt ->
                                        viewModel.selectDisambiguationOption(msg.id, opt)
                                    },
                                    onConfirmAction = { conf, ok ->
                                        viewModel.resolveConfirmation(msg.id, conf, ok)
                                    },
                                    onCopy = {
                                        clipboard.setText(AnnotatedString(msg.content))
                                        viewModel.showNotice("Copied response to clipboard.")
                                    },
                                    onSpeak = { viewModel.speakText(msg.content) },
                                    onRegenerate = { viewModel.regenerateLastResponse() }
                                )
                            }
                        }
                    }

                    if (isProcessing || activeToolStatus != null) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 4.dp)
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(15.dp), strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = activeToolStatus ?: "$chosenName is thinking…",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    // ChatGPT-style floating pill composer
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(28.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerHigh,
                            border = BorderStroke(
                                1.dp,
                                MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)
                            ),
                            tonalElevation = 2.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                                TextField(
                                    value = input,
                                    onValueChange = { input = it },
                                    placeholder = { Text("Message $chosenName…") },
                                    maxLines = 5,
                                    colors = TextFieldDefaults.colors(
                                        focusedContainerColor = Color.Transparent,
                                        unfocusedContainerColor = Color.Transparent,
                                        focusedIndicatorColor = Color.Transparent,
                                        unfocusedIndicatorColor = Color.Transparent
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("chat_input_field")
                                )

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Surface(
                                            shape = RoundedCornerShape(999.dp),
                                            color = if (attachScreen) {
                                                MaterialTheme.colorScheme.primaryContainer
                                            } else {
                                                MaterialTheme.colorScheme.surface
                                            },
                                            border = BorderStroke(
                                                1.dp,
                                                if (attachScreen) {
                                                    MaterialTheme.colorScheme.primary
                                                } else {
                                                    MaterialTheme.colorScheme.outlineVariant
                                                }
                                            ),
                                            modifier = Modifier.clickable { attachScreen = !attachScreen }
                                        ) {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                            ) {
                                                Icon(
                                                    Icons.Outlined.Visibility,
                                                    contentDescription = "Attach screen context",
                                                    modifier = Modifier.size(16.dp),
                                                    tint = if (attachScreen) {
                                                        MaterialTheme.colorScheme.primary
                                                    } else {
                                                        MaterialTheme.colorScheme.onSurfaceVariant
                                                    }
                                                )
                                                Spacer(modifier = Modifier.width(5.dp))
                                                Text(
                                                    text = "Screen",
                                                    style = MaterialTheme.typography.labelMedium,
                                                    color = if (attachScreen) {
                                                        MaterialTheme.colorScheme.onPrimaryContainer
                                                    } else {
                                                        MaterialTheme.colorScheme.onSurfaceVariant
                                                    }
                                                )
                                            }
                                        }

                                        val voiceActive = isListening || isRecordingWhisper
                                        IconButton(
                                            onClick = {
                                                if (isListening) {
                                                    speechRecognizer?.stopListening()
                                                    isListening = false
                                                } else if (isRecordingWhisper) {
                                                    triggerVoiceInput()
                                                } else if (hasMic) {
                                                    triggerVoiceInput()
                                                } else {
                                                    micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                                }
                                            },
                                            enabled = !isTranscribingWhisper,
                                            modifier = Modifier
                                                .size(44.dp)
                                                .testTag("chat_mic_button")
                                        ) {
                                            if (isTranscribingWhisper) {
                                                CircularProgressIndicator(
                                                    modifier = Modifier.size(18.dp),
                                                    strokeWidth = 2.dp
                                                )
                                            } else {
                                                Icon(
                                                    imageVector = if (voiceActive) Icons.Filled.Stop else Icons.Filled.Mic,
                                                    contentDescription = if (voiceActive) "Stop voice input" else "Voice input",
                                                    tint = if (voiceActive) {
                                                        MaterialTheme.colorScheme.error
                                                    } else {
                                                        MaterialTheme.colorScheme.onSurfaceVariant
                                                    }
                                                )
                                            }
                                        }
                                    }

                                    // Circular Up-Arrow Send or Bottom Wake Overlay button
                                    if (input.isBlank() && !isProcessing) {
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.primaryContainer,
                                            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                                        ) {
                                            IconButton(
                                                onClick = { viewModel.launchBottomWakeAssistant(context) },
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .testTag("chat_wake_overlay_button")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.GraphicEq,
                                                    contentDescription = "Open bottom Gemini wake assistant"
                                                )
                                            }
                                        }
                                    } else {
                                        Surface(
                                            shape = CircleShape,
                                            color = if (input.isNotBlank() && !isProcessing) {
                                                MaterialTheme.colorScheme.primary
                                            } else {
                                                MaterialTheme.colorScheme.surfaceVariant
                                            },
                                            contentColor = if (input.isNotBlank() && !isProcessing) {
                                                MaterialTheme.colorScheme.onPrimary
                                            } else {
                                                MaterialTheme.colorScheme.onSurfaceVariant
                                            }
                                        ) {
                                            IconButton(
                                                onClick = {
                                                    if (input.isNotBlank() && !isProcessing) {
                                                        val text = input
                                                        input = ""
                                                        viewModel.sendMessage(text, attachScreen = attachScreen)
                                                    }
                                                },
                                                enabled = input.isNotBlank() && !isProcessing,
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .testTag("chat_send_button")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.ArrowUpward,
                                                    contentDescription = "Send message"
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ChatGptEmptyState(
    assistantName: String,
    modelSubtitle: String,
    onSelectPrompt: (String) -> Unit,
    onWakeOverlay: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 36.dp, bottom = 16.dp)
    ) {
        PersonalAiLogo(size = 56.dp)
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = "What can I help with?",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "$assistantName • $modelSubtitle",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(22.dp))

        val starters = listOf(
            "Scan my phone for viruses" to "Audit apps, sideloaded APKs & files",
            "Find my installed games & open one" to "Launch & control apps or games",
            "Learn pattern: When I say work mode, open Chrome" to "Teach & replay user routines",
            "برنامه‌های نصب‌شده من رو نشون بده" to "Persian & English commands"
        )
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            maxItemsInEachRow = 2,
            modifier = Modifier.fillMaxWidth()
        ) {
            starters.forEach { (prompt, subtitle) ->
                Surface(
                    onClick = { onSelectPrompt(prompt) },
                    shape = RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.widthIn(min = 150.dp, max = 350.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = prompt,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))
        OutlinedButton(onClick = onWakeOverlay) {
            Icon(Icons.Filled.GraphicEq, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Try Bottom Wake Assistant")
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ChatGptMessageRow(
    message: ChatMessageEntity,
    assistantName: String,
    isLatestAssistant: Boolean,
    onSelectOption: (AskUserOption) -> Unit,
    onConfirmAction: (PendingConfirmation, Boolean) -> Unit,
    onCopy: () -> Unit,
    onSpeak: () -> Unit,
    onRegenerate: () -> Unit
) {
    val isUser = message.role == AssistantOrchestrator.ROLE_USER
    val isTool = message.role == AssistantOrchestrator.ROLE_TOOL
    val isSystem = message.role == AssistantOrchestrator.ROLE_SYSTEM

    val options = remember(message.optionsJson) { parseOptions(message.optionsJson) }
    val confirmation = remember(message.pendingConfirmationJson) { parseConfirmation(message.pendingConfirmationJson) }

    Column(
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
        modifier = Modifier.fillMaxWidth()
    ) {
        when {
            isUser -> {
                // User prompt: right-aligned soft pill like ChatGPT mobile
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    contentColor = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.widthIn(max = 520.dp)
                ) {
                    Text(
                        text = message.content,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 11.dp)
                    )
                }
            }
            isTool -> {
                // Compact inline tool badge
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.widthIn(max = 560.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Icon(
                            imageVector = if (message.toolSuccess == false) {
                                Icons.Filled.WarningAmber
                            } else {
                                Icons.Filled.Build
                            },
                            contentDescription = null,
                            tint = if (message.toolSuccess == false) {
                                MaterialTheme.colorScheme.error
                            } else {
                                MaterialTheme.colorScheme.primary
                            },
                            modifier = Modifier.size(15.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${message.toolName ?: "tool"}: ${message.content}",
                            style = MaterialTheme.typography.bodySmall,
                            fontFamily = JetBrainsMonoFontFamily,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            isSystem -> {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Icon(Icons.Filled.ErrorOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = message.content, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            else -> {
                // Editorial full-width ChatGPT assistant response
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PersonalAiLogo(size = 22.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = assistantName,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    FormattedAssistantContent(
                        content = message.content,
                        onCopyBlock = { block ->
                            // handled via parent or inline copy
                        }
                    )

                    if (message.content.isNotBlank()) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(top = 6.dp)
                        ) {
                            IconButton(
                                onClick = onCopy,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    Icons.Filled.ContentCopy,
                                    contentDescription = "Copy response",
                                    modifier = Modifier.size(16.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = onSpeak,
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(
                                    Icons.AutoMirrored.Filled.VolumeUp,
                                    contentDescription = "Speak response",
                                    modifier = Modifier.size(17.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (isLatestAssistant) {
                                IconButton(
                                    onClick = onRegenerate,
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        Icons.Filled.Refresh,
                                        contentDescription = "Regenerate response",
                                        modifier = Modifier.size(17.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (options.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                options.forEach { opt ->
                    AssistChip(
                        onClick = { onSelectOption(opt) },
                        label = {
                            Column {
                                Text(opt.label, style = MaterialTheme.typography.labelLarge)
                                if (opt.subtitle.isNotBlank()) {
                                    Text(
                                        opt.subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    )
                }
            }
        }

        if (confirmation != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { onConfirmAction(confirmation, true) },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("Approve Action")
                }
                OutlinedButton(onClick = { onConfirmAction(confirmation, false) }) {
                    Text("Cancel")
                }
            }
        }
    }
}

@Composable
private fun FormattedAssistantContent(
    content: String,
    onCopyBlock: (String) -> Unit
) {
    val segments = remember(content) { splitCodeFences(content) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        segments.forEach { segment ->
            if (segment.isCode) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerHighest,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        if (segment.language.isNotBlank()) {
                            Text(
                                text = segment.language,
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFontFamily,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                        Text(
                            text = segment.text,
                            style = MaterialTheme.typography.bodyMedium,
                            fontFamily = JetBrainsMonoFontFamily,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            } else if (segment.text.isNotBlank()) {
                Text(
                    text = segment.text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

private data class ContentSegment(
    val text: String,
    val isCode: Boolean,
    val language: String = ""
)

private fun splitCodeFences(raw: String): List<ContentSegment> {
    if (!raw.contains("```")) {
        return listOf(ContentSegment(text = raw, isCode = false))
    }
    val parts = raw.split("```")
    val out = mutableListOf<ContentSegment>()
    parts.forEachIndexed { idx, chunk ->
        if (idx % 2 == 0) {
            if (chunk.isNotBlank()) out += ContentSegment(text = chunk.trim(), isCode = false)
        } else {
            val firstNewline = chunk.indexOf('\n')
            val lang = if (firstNewline > 0) chunk.substring(0, firstNewline).trim() else ""
            val code = if (firstNewline > 0) chunk.substring(firstNewline + 1).trimEnd() else chunk.trim()
            if (code.isNotBlank()) out += ContentSegment(text = code, isCode = true, language = lang)
        }
    }
    return if (out.isEmpty()) listOf(ContentSegment(text = raw, isCode = false)) else out
}

private fun parseOptions(json: String?): List<AskUserOption> {
    if (json.isNullOrBlank()) return emptyList()
    return try {
        val arr = JSONArray(json)
        List(arr.length()) { idx ->
            val obj = arr.getJSONObject(idx)
            AskUserOption(
                id = obj.optString("id", "opt_$idx"),
                label = obj.optString("label"),
                subtitle = obj.optString("subtitle"),
                replyValue = obj.optString("replyValue", obj.optString("label"))
            )
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun parseConfirmation(json: String?): PendingConfirmation? {
    if (json.isNullOrBlank()) return null
    return try {
        val obj = JSONObject(json)
        PendingConfirmation(
            toolName = obj.optString("toolName"),
            argumentsJson = obj.optString("argumentsJson"),
            humanReadableSummary = obj.optString("summary")
        )
    } catch (_: Exception) {
        null
    }
}
