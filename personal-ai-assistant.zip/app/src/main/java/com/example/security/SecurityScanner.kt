package com.example.security

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.example.data.db.IndexedFileDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.MessageDigest

enum class SecuritySeverity(val label: String, val rank: Int) {
    HIGH("High Risk", 3),
    MEDIUM("Suspicious", 2),
    LOW("Advisory", 1),
    INFO("Info", 0)
}

enum class FindingTargetType {
    APP,
    FILE
}

data class SecurityFinding(
    val id: String,
    val targetType: FindingTargetType,
    val title: String,
    val targetName: String,
    val detail: String,
    val recommendation: String,
    val severity: SecuritySeverity,
    val packageName: String? = null,
    val fileUri: String? = null,
    val sha256: String? = null
)

data class SecurityScanReport(
    val scannedAppsCount: Int = 0,
    val scannedFilesCount: Int = 0,
    val highRiskCount: Int = 0,
    val mediumRiskCount: Int = 0,
    val lowRiskCount: Int = 0,
    val findings: List<SecurityFinding> = emptyList(),
    val scannedAt: Long = System.currentTimeMillis()
) {
    val overallStatusLabel: String
        get() = when {
            highRiskCount > 0 -> "Threats / High-Risk Items Found ($highRiskCount)"
            mediumRiskCount > 0 -> "Suspicious Items Detected ($mediumRiskCount)"
            lowRiskCount > 0 -> "Clean with Advisories ($lowRiskCount)"
            else -> "Device Clean"
        }

    fun toJsonSummary(): String {
        val findingsPreview = findings.take(12).joinToString("; ") { f ->
            "[${f.severity.label}] ${f.title}: ${f.targetName} — ${f.detail}"
        }
        return "Apps scanned: $scannedAppsCount, Files scanned: $scannedFilesCount, " +
            "High risk: $highRiskCount, Suspicious: $mediumRiskCount, Advisories: $lowRiskCount. " +
            if (findingsPreview.isBlank()) "No threats detected." else "Findings: $findingsPreview"
    }
}

/**
 * Policy-compliant Android virus, malware & risky APK/app auditor.
 * Inspects accessible apps via official PackageManager APIs and indexed device files/APKs
 * without bypassing Android sandbox restrictions.
 */
class SecurityScanner(
    private val context: Context,
    private val indexedFileDao: IndexedFileDao
) {
    suspend fun runFullScan(): SecurityScanReport = withContext(Dispatchers.IO) {
        val findings = mutableListOf<SecurityFinding>()
        var appsScanned = 0

        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val launchable = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(
                mainIntent,
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(mainIntent, 0)
        }

        val seenPackages = HashSet<String>()
        for (info in launchable) {
            val pkg = info.activityInfo?.packageName ?: continue
            if (!seenPackages.add(pkg) || pkg == context.packageName) continue
            appsScanned++

            val pkgInfo = runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()))
                } else {
                    @Suppress("DEPRECATION")
                    pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
                }
            }.getOrNull() ?: continue

            val appInfo = pkgInfo.applicationInfo
            val appName = info.loadLabel(pm)?.toString()?.trim().orEmpty().ifBlank { pkg }
            val isSystem = ((appInfo?.flags ?: 0) and ApplicationInfo.FLAG_SYSTEM) != 0
            val isDebuggable = ((appInfo?.flags ?: 0) and ApplicationInfo.FLAG_DEBUGGABLE) != 0
            val installer = resolveInstallerPackage(pm, pkg)
            val perms = pkgInfo.requestedPermissions?.toList().orEmpty()

            evaluateAppRisk(
                packageName = pkg,
                appName = appName,
                requestedPermissions = perms,
                isSystemApp = isSystem,
                isDebuggable = isDebuggable,
                installerPackage = installer
            )?.let { findings += it }
        }

        val indexedFiles = indexedFileDao.searchFiles(query = "", limit = 400)
        var filesScanned = 0
        for (file in indexedFiles) {
            filesScanned++
            val baseFinding = evaluateFileRisk(
                fileName = file.name,
                extension = file.extension,
                mimeType = file.mimeType,
                sizeBytes = file.sizeBytes,
                displayPath = file.displayPath,
                uriString = file.uriString
            )
            if (baseFinding != null) {
                val hash = if (baseFinding.severity.rank >= SecuritySeverity.MEDIUM.rank) {
                    computeUriSha256(file.uriString)
                } else null
                findings += baseFinding.copy(sha256 = hash)
            }
        }

        val sorted = findings.sortedWith(
            compareByDescending<SecurityFinding> { it.severity.rank }.thenBy { it.title }
        )

        SecurityScanReport(
            scannedAppsCount = appsScanned,
            scannedFilesCount = filesScanned,
            highRiskCount = sorted.count { it.severity == SecuritySeverity.HIGH },
            mediumRiskCount = sorted.count { it.severity == SecuritySeverity.MEDIUM },
            lowRiskCount = sorted.count { it.severity == SecuritySeverity.LOW },
            findings = sorted,
            scannedAt = System.currentTimeMillis()
        )
    }

    fun openUninstallDialog(packageName: String): Result<Unit> = runCatching {
        val intent = Intent(Intent.ACTION_DELETE, Uri.parse("package:$packageName")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun openAppDetails(packageName: String): Result<Unit> = runCatching {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    private fun resolveInstallerPackage(pm: PackageManager, pkg: String): String? = runCatching {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            pm.getInstallSourceInfo(pkg).installingPackageName
        } else {
            @Suppress("DEPRECATION")
            pm.getInstallerPackageName(pkg)
        }
    }.getOrNull()

    private fun computeUriSha256(uriString: String): String? = runCatching {
        val uri = Uri.parse(uriString)
        val digest = MessageDigest.getInstance("SHA-256")
        context.contentResolver.openInputStream(uri)?.use { stream ->
            val buf = ByteArray(8192)
            var totalRead = 0L
            while (totalRead < MAX_HASH_BYTES) {
                val n = stream.read(buf)
                if (n <= 0) break
                digest.update(buf, 0, n)
                totalRead += n
            }
            digest.digest().joinToString("") { "%02x".format(it) }.take(16) + "…"
        }
    }.getOrNull()

    companion object {
        private const val MAX_HASH_BYTES = 16L * 1024L * 1024L

        private val trustedStoreInstallers = setOf(
            "com.android.vending",           // Google Play Store
            "com.amazon.venezia",            // Amazon Appstore
            "com.sec.android.app.samsungapps", // Samsung Galaxy Store
            "com.huawei.appmarket",          // Huawei AppGallery
            "com.xiaomi.market",             // Xiaomi GetApps
            "com.google.android.packageinstaller"
        )

        private val dangerousExecutables = setOf("apk", "apks", "xapk", "dex", "jar", "so", "exe", "bat", "sh", "vbs", "ps1")
        private val deceptiveInnerExtensions = setOf(".pdf", ".doc", ".docx", ".jpg", ".jpeg", ".png", ".mp4", ".zip")

        fun evaluateAppRisk(
            packageName: String,
            appName: String,
            requestedPermissions: List<String>,
            isSystemApp: Boolean,
            isDebuggable: Boolean,
            installerPackage: String?
        ): SecurityFinding? {
            if (isSystemApp) return null

            val shortPerms = requestedPermissions.map { it.substringAfterLast('.') }.toSet()
            val sideloaded = installerPackage.isNullOrBlank() || installerPackage !in trustedStoreInstallers

            val hasInstallPkgs = "REQUEST_INSTALL_PACKAGES" in shortPerms
            val hasSms = "READ_SMS" in shortPerms || "RECEIVE_SMS" in shortPerms
            val hasAccessibility = "BIND_ACCESSIBILITY_SERVICE" in shortPerms
            val hasOverlay = "SYSTEM_ALERT_WINDOW" in shortPerms
            val hasDeviceAdmin = "BIND_DEVICE_ADMIN" in shortPerms
            val hasSpywareCombo = ("RECORD_AUDIO" in shortPerms || "CAMERA" in shortPerms) &&
                ("ACCESS_FINE_LOCATION" in shortPerms) &&
                hasSms

            val reasons = mutableListOf<String>()
            var severity = SecuritySeverity.INFO

            if (sideloaded && (hasInstallPkgs || hasDeviceAdmin || hasSms || hasAccessibility)) {
                severity = SecuritySeverity.HIGH
                reasons += "Sideloaded or unknown installer (${installerPackage ?: "unknown"}) with sensitive system/SMS/installer permissions."
            } else if (hasSpywareCombo && sideloaded) {
                severity = SecuritySeverity.HIGH
                reasons += "Sideloaded app requests SMS + Microphone/Camera + Fine Location together."
            } else if (isDebuggable) {
                severity = SecuritySeverity.MEDIUM
                reasons += "App is flagged debuggable, which exposes internal data to external tools."
            } else if (sideloaded && (hasOverlay || hasInstallPkgs)) {
                severity = SecuritySeverity.MEDIUM
                reasons += "Installed outside recognized app stores (${installerPackage ?: "unknown"}) with overlay or package install privileges."
            } else if (sideloaded) {
                severity = SecuritySeverity.LOW
                reasons += "Installed from unknown/sideloaded source (${installerPackage ?: "unknown"})."
            }

            if (severity == SecuritySeverity.INFO || reasons.isEmpty()) return null

            return SecurityFinding(
                id = "app_$packageName",
                targetType = FindingTargetType.APP,
                title = if (severity == SecuritySeverity.HIGH) "High-Risk Sideloaded App" else if (severity == SecuritySeverity.MEDIUM) "Suspicious App Privileges" else "Unknown Installer Source",
                targetName = "$appName ($packageName)",
                detail = reasons.joinToString(" "),
                recommendation = if (severity == SecuritySeverity.HIGH) {
                    "Review this app carefully and uninstall it if you do not recognize or trust it."
                } else {
                    "Verify the publisher and review its Android permissions."
                },
                severity = severity,
                packageName = packageName
            )
        }

        fun evaluateFileRisk(
            fileName: String,
            extension: String,
            mimeType: String,
            sizeBytes: Long,
            displayPath: String,
            uriString: String
        ): SecurityFinding? {
            val lowerName = fileName.lowercase().trim()
            val cleanExt = extension.lowercase().trim().ifBlank {
                lowerName.substringAfterLast('.', "")
            }

            val hasDoubleExtMasquerade = dangerousExecutables.contains(cleanExt) &&
                deceptiveInnerExtensions.any { lowerName.contains("$it.") || lowerName.contains("${it}_") }

            if (hasDoubleExtMasquerade) {
                return SecurityFinding(
                    id = "file_$uriString",
                    targetType = FindingTargetType.FILE,
                    title = "Masquerading Executable / Trojan Pattern",
                    targetName = fileName,
                    detail = "File disguises an executable (.$cleanExt) as a harmless document/media name at $displayPath.",
                    recommendation = "Do not open or install this file unless verified from a trusted source.",
                    severity = SecuritySeverity.HIGH,
                    fileUri = uriString
                )
            }

            if (cleanExt in setOf("apk", "apks", "xapk")) {
                return SecurityFinding(
                    id = "file_$uriString",
                    targetType = FindingTargetType.FILE,
                    title = "Unverified Android Installer Package (APK)",
                    targetName = fileName,
                    detail = "Local APK installer (${sizeBytes / 1024} KB) found at $displayPath. Sideloaded APKs are the #1 Android malware vector.",
                    recommendation = "Delete old APK installers you no longer need or verify the developer signature before installing.",
                    severity = SecuritySeverity.MEDIUM,
                    fileUri = uriString
                )
            }

            if (cleanExt in setOf("dex", "exe", "bat", "vbs", "ps1") ||
                (cleanExt == "jar" && mimeType.contains("java"))
            ) {
                return SecurityFinding(
                    id = "file_$uriString",
                    targetType = FindingTargetType.FILE,
                    title = "Suspicious Executable / Script File",
                    targetName = fileName,
                    detail = "Potentially unsafe script or binary (.$cleanExt) stored at $displayPath.",
                    recommendation = "Verify why this file is on your phone and delete it if unexpected.",
                    severity = SecuritySeverity.MEDIUM,
                    fileUri = uriString
                )
            }

            return null
        }
    }
}
