package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.AppContainer
import com.example.PersonalAiApp
import com.example.ai.CuratedModelPreset
import com.example.ai.DeviceRamInfo
import com.example.ai.ModelDownloadManager
import com.example.assistant.AssistActivity
import com.example.assistant.AssistantOrchestrator
import com.example.assistant.ChatHistorySearchHit
import com.example.assistant.ChatSessionSummary
import com.example.assistant.SilentWakeDetector
import com.example.assistant.WakeWordService
import com.example.data.db.CachedProviderModelEntity
import com.example.data.db.ChatMessageEntity
import com.example.data.db.DownloadedModelEntity
import com.example.data.db.IndexProgressEntity
import com.example.data.db.IndexedFileEntity
import com.example.data.db.InstalledAppEntity
import com.example.data.db.MemoryEntity
import com.example.data.db.UserPatternEntity
import com.example.data.settings.AiApiProtocol
import com.example.data.settings.AiProviderType
import com.example.data.settings.AiRoutingMode
import com.example.data.settings.AiSettings
import com.example.data.settings.AssistantSettings
import com.example.data.settings.FloatingSettings
import com.example.data.settings.ResolvedAiRoute
import com.example.data.settings.SpeechSettings
import com.example.data.settings.SttEngineMode
import com.example.data.settings.ThemeMode
import com.example.data.settings.TtsEngineMode
import com.example.files.AuthorizedFolder
import com.example.files.FileIndexWorker
import com.example.files.FileSearchResult
import com.example.floating.FloatingAssistantService
import com.example.patterns.PatternRunReport
import com.example.patterns.PatternStep
import com.example.permissions.PermissionStatusItem
import com.example.screen.ScreenSnapshot
import com.example.security.SecurityScanReport
import com.example.speech.SystemVoiceInfo
import com.example.tools.AskUserOption
import com.example.tools.PendingConfirmation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PersonalAiViewModel(
    application: Application,
    private val container: AppContainer
) : AndroidViewModel(application) {

    val aiSettings: StateFlow<AiSettings> = container.settingsRepository.aiSettingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AiSettings())

    val configuredProviders: StateFlow<Set<AiProviderType>> = container.settingsRepository.configuredProvidersFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    val assistantSettings: StateFlow<AssistantSettings> = container.settingsRepository.assistantSettingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, AssistantSettings())

    val floatingSettings: StateFlow<FloatingSettings> = container.settingsRepository.floatingSettingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FloatingSettings())

    private val _activeChatSessionId = MutableStateFlow(AssistantOrchestrator.DEFAULT_SESSION_ID)
    val activeChatSessionId: StateFlow<String> = _activeChatSessionId.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val chatMessages: StateFlow<List<ChatMessageEntity>> = _activeChatSessionId
        .flatMapLatest { sessionId -> container.orchestrator.observeMessages(sessionId) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val chatSessions: StateFlow<List<ChatSessionSummary>> = container.orchestrator
        .observeChatSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalStoredChatMessages: StateFlow<Int> = container.orchestrator
        .observeTotalChatMessageCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    private val _historySearchResults = MutableStateFlow<List<ChatHistorySearchHit>>(emptyList())
    val historySearchResults: StateFlow<List<ChatHistorySearchHit>> = _historySearchResults.asStateFlow()

    val isProcessingChat: StateFlow<Boolean> = container.orchestrator.isProcessing
    val activeToolStatus: StateFlow<String?> = container.orchestrator.activeToolStatus
    val lastUsedRouteLabel: StateFlow<String?> = container.orchestrator.lastUsedRouteLabel

    val indexProgress: StateFlow<IndexProgressEntity?> = container.fileIndexer.progressFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val totalIndexedFiles: StateFlow<Int> = container.fileIndexer.totalCountFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val recentFiles: StateFlow<List<IndexedFileEntity>> = container.fileIndexer.recentFilesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val authorizedFolders: StateFlow<List<AuthorizedFolder>> = container.fileIndexer.authorizedFolders

    val launchableApps: StateFlow<List<InstalledAppEntity>> = container.appIndexer.launchableAppsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val installedGames: StateFlow<List<InstalledAppEntity>> = launchableApps
        .map { list -> list.filter { it.category.equals("Game", ignoreCase = true) } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val launchableAppsCount: StateFlow<Int> = container.appIndexer.launchableCountFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val memories: StateFlow<List<MemoryEntity>> = container.memoryRepository.memoriesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userPatterns: StateFlow<List<UserPatternEntity>> = container.patternRepository.patternsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _patternRunResult = MutableStateFlow<PatternRunReport?>(null)
    val patternRunResult: StateFlow<PatternRunReport?> = _patternRunResult.asStateFlow()

    private val _isRunningPattern = MutableStateFlow(false)
    val isRunningPattern: StateFlow<Boolean> = _isRunningPattern.asStateFlow()

    private val _securityReport = MutableStateFlow<SecurityScanReport?>(null)
    val securityReport: StateFlow<SecurityScanReport?> = _securityReport.asStateFlow()

    private val _isScanningSecurity = MutableStateFlow(false)
    val isScanningSecurity: StateFlow<Boolean> = _isScanningSecurity.asStateFlow()

    val latestScreenSnapshot: StateFlow<ScreenSnapshot?> =
        container.screenUnderstandingRepository.latestSnapshot

    val accessibilityConnected: StateFlow<Boolean> =
        container.screenUnderstandingRepository.serviceConnected

    val visionEnabled: StateFlow<Boolean> =
        container.screenUnderstandingRepository.visionEnabled

    private val _isRecordingWakeSample = MutableStateFlow(false)
    val isRecordingWakeSample: StateFlow<Boolean> = _isRecordingWakeSample.asStateFlow()

    val isFloatingRunning: StateFlow<Boolean> = FloatingAssistantService.isRunningFlow
    val wakeWordRunning: StateFlow<Boolean> = WakeWordService.isRunningFlow
    val wakeWordListening: StateFlow<Boolean> = WakeWordService.isListeningFlow
    val lastWakeHeardText: StateFlow<String?> = WakeWordService.lastHeardTextFlow

    private val _permissions = MutableStateFlow(container.permissionChecker.getAllStatuses())
    val permissions: StateFlow<List<PermissionStatusItem>> = _permissions.asStateFlow()

    val isOnline: StateFlow<Boolean> = container.permissionChecker
        .observeNetworkConnectivity()
        .stateIn(
            viewModelScope,
            SharingStarted.Eagerly,
            container.permissionChecker.isNetworkConnected()
        )

    val activeAiRoute: StateFlow<ResolvedAiRoute> = combine(aiSettings, isOnline) { settings, online ->
        settings.resolveEffectiveRoute(online)
    }.stateIn(
        viewModelScope,
        SharingStarted.Eagerly,
        AiSettings().resolveEffectiveRoute(container.permissionChecker.isNetworkConnected())
    )

    private val _fileSearchQuery = MutableStateFlow("")
    val fileSearchQuery: StateFlow<String> = _fileSearchQuery.asStateFlow()

    private val _fileSearchResult = MutableStateFlow<FileSearchResult?>(null)
    val fileSearchResult: StateFlow<FileSearchResult?> = _fileSearchResult.asStateFlow()

    private val _appSearchQuery = MutableStateFlow("")
    val appSearchQuery: StateFlow<String> = _appSearchQuery.asStateFlow()

    private val _filteredApps = MutableStateFlow<List<InstalledAppEntity>>(emptyList())
    val filteredApps: StateFlow<List<InstalledAppEntity>> = _filteredApps.asStateFlow()

    private val _testConnectionState = MutableStateFlow<String?>(null)
    val testConnectionState: StateFlow<String?> = _testConnectionState.asStateFlow()

    private val _isTestingConnection = MutableStateFlow(false)
    val isTestingConnection: StateFlow<Boolean> = _isTestingConnection.asStateFlow()

    val speechSettings: StateFlow<SpeechSettings> = container.settingsRepository.speechSettingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SpeechSettings())

    @OptIn(ExperimentalCoroutinesApi::class)
    val cachedProviderModels: StateFlow<List<CachedProviderModelEntity>> =
        container.settingsRepository.aiSettingsFlow
            .map { it.provider.id }
            .distinctUntilChanged()
            .flatMapLatest { providerId ->
                container.modelCatalogService.observeModels(providerId)
            }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloadedModels: StateFlow<List<DownloadedModelEntity>> =
        container.modelDownloadManager.observeDownloadedModels()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val curatedModelPresets: List<CuratedModelPreset> = ModelDownloadManager.curatedPresets

    private val _deviceRamInfo = MutableStateFlow(ModelDownloadManager.readDeviceRamInfo(application))
    val deviceRamInfo: StateFlow<DeviceRamInfo> = _deviceRamInfo.asStateFlow()

    val availableSystemVoices: StateFlow<List<SystemVoiceInfo>> = container.speechAiManager.availableVoices
    val isTtsReady: StateFlow<Boolean> = container.speechAiManager.isTtsReady
    val isSpeaking: StateFlow<Boolean> = container.speechAiManager.isSpeaking
    val isRecordingCloudStt: StateFlow<Boolean> = container.speechAiManager.isRecordingCloudStt
    val isTranscribingCloudStt: StateFlow<Boolean> = container.speechAiManager.isTranscribingCloudStt

    private val _isFetchingModels = MutableStateFlow(false)
    val isFetchingModels: StateFlow<Boolean> = _isFetchingModels.asStateFlow()

    private val _modelCatalogError = MutableStateFlow<String?>(null)
    val modelCatalogError: StateFlow<String?> = _modelCatalogError.asStateFlow()

    private val _uiNotice = MutableStateFlow<String?>(null)
    val uiNotice: StateFlow<String?> = _uiNotice.asStateFlow()

    init {
        refreshSystemState()
        viewModelScope.launch {
            container.appIndexer.refreshInstalledApps()
            _filteredApps.value = container.appIndexer.searchApps("")
            val savedAssistant = container.settingsRepository.assistantSettingsFlow.first()
            if (savedAssistant.wakeWordEnabled && WakeWordService.hasMicPermission(getApplication())) {
                WakeWordService.start(getApplication())
            }
        }
    }

    fun refreshSystemState() {
        container.fileIndexer.refreshAuthorizedFolders()
        _permissions.value = container.permissionChecker.getAllStatuses()
        _deviceRamInfo.value = ModelDownloadManager.readDeviceRamInfo(getApplication())
    }

    fun clearUiNotice() {
        _uiNotice.value = null
    }

    fun showNotice(message: String) {
        _uiNotice.value = message
    }

    // --- Chat & Orchestrator ---
    fun sendMessage(text: String, attachScreen: Boolean = false) {
        val sessionId = _activeChatSessionId.value
        viewModelScope.launch {
            container.orchestrator.submitUserMessage(
                userText = text,
                sessionId = sessionId,
                attachScreenSnapshot = attachScreen
            )
        }
    }

    fun selectDisambiguationOption(messageId: Long, option: AskUserOption) {
        val sessionId = _activeChatSessionId.value
        viewModelScope.launch {
            container.orchestrator.selectDisambiguationOption(messageId, option, sessionId = sessionId)
        }
    }

    fun resolveConfirmation(messageId: Long, confirmation: PendingConfirmation, approved: Boolean) {
        val sessionId = _activeChatSessionId.value
        viewModelScope.launch {
            container.orchestrator.resolveConfirmation(messageId, confirmation, approved, sessionId = sessionId)
        }
    }

    fun clearChat() {
        val sessionId = _activeChatSessionId.value
        viewModelScope.launch {
            container.orchestrator.clearSession(sessionId)
        }
    }

    fun startNewChatSession() {
        if (chatMessages.value.isNotEmpty()) {
            _activeChatSessionId.value = "chat_${System.currentTimeMillis()}"
        }
    }

    fun selectChatSession(sessionId: String) {
        _activeChatSessionId.value = sessionId
    }

    fun deleteChatSession(sessionId: String) {
        viewModelScope.launch {
            container.orchestrator.clearSession(sessionId)
            if (_activeChatSessionId.value == sessionId) {
                val fallback = chatSessions.value.firstOrNull { it.sessionId != sessionId }?.sessionId
                    ?: AssistantOrchestrator.DEFAULT_SESSION_ID
                _activeChatSessionId.value = fallback
            }
        }
    }

    fun regenerateLastResponse() {
        val sessionId = _activeChatSessionId.value
        viewModelScope.launch {
            container.orchestrator.regenerateLastMessage(sessionId)
        }
    }

    fun searchChatHistory(query: String) {
        if (query.isBlank()) {
            _historySearchResults.value = emptyList()
            return
        }
        viewModelScope.launch {
            _historySearchResults.value = container.orchestrator.searchLocalHistory(query)
        }
    }

    fun clearHistorySearch() {
        _historySearchResults.value = emptyList()
    }

    fun pinChatSession(sessionId: String, pinned: Boolean) {
        viewModelScope.launch {
            container.orchestrator.pinSession(sessionId, pinned)
        }
    }

    fun renameChatSession(sessionId: String, title: String) {
        viewModelScope.launch {
            container.orchestrator.renameSession(sessionId, title)
            _uiNotice.value = "Renamed conversation."
        }
    }

    suspend fun exportChatSessionText(sessionId: String): String =
        container.orchestrator.exportSessionAsText(sessionId)

    fun clearAllChatHistory() {
        viewModelScope.launch {
            container.orchestrator.clearAllChatHistory()
            _activeChatSessionId.value = AssistantOrchestrator.DEFAULT_SESSION_ID
            _historySearchResults.value = emptyList()
            _uiNotice.value = "Cleared all local phone chat history."
        }
    }

    fun getLocalDatabaseSizeLabel(): String {
        val dbFile = getApplication<Application>().getDatabasePath("personal_ai_local.db")
        if (!dbFile.exists()) return "0 KB"
        val bytes = dbFile.length()
        return when {
            bytes < 1024L -> "$bytes B"
            bytes < 1024L * 1024L -> "${bytes / 1024L} KB"
            else -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
        }
    }

    // --- AI Routing Mode (Auto Online/Offline, API Key Only, Local Only) ---
    fun setAiRoutingMode(mode: AiRoutingMode) {
        viewModelScope.launch {
            container.settingsRepository.setAiRoutingMode(mode)
            _uiNotice.value = "AI routing switched to: ${mode.shortLabel}"
        }
    }

    fun saveLocalAiConfig(endpointUrl: String, modelName: String, apiKey: String? = null) {
        viewModelScope.launch {
            container.settingsRepository.saveLocalAiConfig(endpointUrl, modelName, apiKey)
            _uiNotice.value = "Saved Local AI endpoint & model."
        }
    }

    // --- Virus & Malware Scanner ---
    fun runVirusScan() {
        if (_isScanningSecurity.value) return
        viewModelScope.launch {
            _isScanningSecurity.value = true
            val report = container.securityScanner.runFullScan()
            _securityReport.value = report
            _isScanningSecurity.value = false
            _uiNotice.value = report.overallStatusLabel
        }
    }

    fun uninstallFlaggedApp(packageName: String) {
        val res = container.securityScanner.openUninstallDialog(packageName)
        if (res.isFailure) {
            _uiNotice.value = res.exceptionOrNull()?.localizedMessage ?: "Unable to open uninstall dialog."
        }
    }

    fun openFlaggedAppDetails(packageName: String) {
        val res = container.securityScanner.openAppDetails(packageName)
        if (res.isFailure) {
            _uiNotice.value = res.exceptionOrNull()?.localizedMessage ?: "Unable to open app details."
        }
    }

    fun deleteRiskyFile(uriString: String) {
        viewModelScope.launch {
            val deleted = withContext(Dispatchers.IO) {
                runCatching {
                    val uri = Uri.parse(uriString)
                    val doc = DocumentFile.fromSingleUri(getApplication(), uri)
                    if (doc != null && doc.exists() && doc.delete()) {
                        container.database.indexedFileDao().deleteByUri(uriString)
                        true
                    } else {
                        val rows = getApplication<Application>().contentResolver.delete(uri, null, null)
                        if (rows > 0) {
                            container.database.indexedFileDao().deleteByUri(uriString)
                            true
                        } else {
                            false
                        }
                    }
                }.getOrDefault(false)
            }
            if (deleted) {
                _uiNotice.value = "Removed risky file from device."
                runVirusScan()
            } else {
                _uiNotice.value = "Android denied write access to delete this file. Open your Files app to remove it."
            }
        }
    }

    // --- User Patterns & Routines ---
    fun saveUserPattern(
        name: String,
        triggerPhrase: String,
        description: String,
        steps: List<PatternStep>
    ) {
        viewModelScope.launch {
            container.patternRepository.savePattern(
                name = name,
                triggerPhrase = triggerPhrase,
                description = description,
                steps = steps
            )
            _uiNotice.value = "Learned pattern \"$name\" (${steps.size} steps)."
        }
    }

    fun runUserPattern(pattern: UserPatternEntity) {
        if (_isRunningPattern.value) return
        viewModelScope.launch {
            _isRunningPattern.value = true
            val report = container.patternExecutor.execute(pattern)
            _patternRunResult.value = report
            _isRunningPattern.value = false
            _uiNotice.value = "Pattern \"${report.patternName}\": ${report.succeededSteps}/${report.totalSteps} steps succeeded."
        }
    }

    fun deleteUserPattern(id: Long) {
        viewModelScope.launch {
            container.patternRepository.deletePattern(id)
            _uiNotice.value = "Deleted pattern."
        }
    }

    fun clearPatternRunResult() {
        _patternRunResult.value = null
    }

    // --- AI Provider & API Key Settings ---
    fun selectProvider(provider: AiProviderType) {
        viewModelScope.launch {
            container.settingsRepository.selectProvider(provider)
            _testConnectionState.value = null
        }
    }

    suspend fun loadProviderSettings(provider: AiProviderType): AiSettings =
        container.settingsRepository.getSettingsForProvider(provider)

    fun saveProviderConfig(
        provider: AiProviderType,
        protocol: AiApiProtocol = provider.defaultProtocol,
        customLabel: String = "",
        apiKeyInput: String?,
        model: String,
        baseUrl: String,
        authHeaderName: String = protocol.defaultAuthHeader,
        authHeaderPrefix: String = protocol.defaultAuthPrefix,
        enableNativeTools: Boolean = provider.supportsNativeToolsByDefault,
        allowEmptyKey: Boolean = false,
        temperature: Float = 0.2f
    ) {
        viewModelScope.launch {
            container.settingsRepository.saveProviderConfig(
                provider = provider,
                protocol = protocol,
                customLabel = customLabel,
                apiKey = apiKeyInput,
                model = model,
                baseUrl = baseUrl,
                authHeaderName = authHeaderName,
                authHeaderPrefix = authHeaderPrefix,
                enableNativeTools = enableNativeTools,
                allowEmptyKey = allowEmptyKey,
                temperature = temperature
            )
            val label = customLabel.ifBlank { provider.displayName }
            _uiNotice.value = "Saved $label configuration."
        }
    }

    fun clearProviderKey(provider: AiProviderType) {
        viewModelScope.launch {
            container.settingsRepository.clearApiKey(provider)
            _testConnectionState.value = null
            _uiNotice.value = "Removed API key for ${provider.displayName}."
        }
    }

    fun testAiConnection(
        provider: AiProviderType,
        protocol: AiApiProtocol = provider.defaultProtocol,
        customLabel: String = "",
        apiKey: String,
        model: String,
        baseUrl: String,
        authHeaderName: String = protocol.defaultAuthHeader,
        authHeaderPrefix: String = protocol.defaultAuthPrefix,
        allowEmptyKey: Boolean = false
    ) {
        viewModelScope.launch {
            _isTestingConnection.value = true
            _testConnectionState.value = null
            val stored = container.settingsRepository.getSettingsForProvider(provider)
            val effectiveKey = apiKey.ifBlank { stored.apiKey }
            val testConfig = AiSettings(
                provider = provider,
                protocol = protocol,
                customProviderLabel = customLabel,
                apiKey = effectiveKey,
                model = model.ifBlank { provider.defaultModel },
                customBaseUrl = baseUrl.ifBlank { provider.defaultBaseUrl },
                authHeaderName = authHeaderName,
                authHeaderPrefix = authHeaderPrefix,
                allowEmptyKey = allowEmptyKey
            )
            val result = container.aiEngine.testConnection(testConfig)
            _isTestingConnection.value = false
            _testConnectionState.value = result.fold(
                onSuccess = { "Success: $it" },
                onFailure = { "Failed: ${it.localizedMessage ?: "Check key, endpoint, and network."}" }
            )
        }
    }

    // --- Assistant Settings & Onboarding ---
    fun completeOnboarding() {
        viewModelScope.launch {
            container.settingsRepository.setOnboardingCompleted(true)
        }
    }

    fun resetOnboarding() {
        viewModelScope.launch {
            container.settingsRepository.setOnboardingCompleted(false)
        }
    }

    fun setMemoryEnabled(enabled: Boolean) {
        viewModelScope.launch { container.settingsRepository.setMemoryEnabled(enabled) }
    }

    fun setConfirmSensitiveActions(confirm: Boolean) {
        viewModelScope.launch { container.settingsRepository.setConfirmSensitiveActions(confirm) }
    }

    fun setIncludeScreenContextAutomatically(include: Boolean) {
        viewModelScope.launch {
            if (include && !assistantSettings.value.visionEnabled) {
                container.settingsRepository.setVisionEnabled(true)
                container.screenUnderstandingRepository.setVisionEnabled(true)
            }
            container.settingsRepository.setIncludeScreenContextAutomatically(include)
        }
    }

    fun setVisionEnabled(enabled: Boolean) {
        viewModelScope.launch {
            container.settingsRepository.setVisionEnabled(enabled)
            container.screenUnderstandingRepository.setVisionEnabled(enabled)
            _uiNotice.value = if (enabled) {
                "Screen Vision enabled (on-demand only)."
            } else {
                "Screen Vision turned off and snapshot cleared."
            }
        }
    }

    fun clearCachedScreenSnapshot() {
        container.screenUnderstandingRepository.clearSnapshot()
        _uiNotice.value = "Cleared captured screen snapshot."
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { container.settingsRepository.setThemeMode(mode) }
    }

    fun setDynamicColor(enabled: Boolean) {
        viewModelScope.launch { container.settingsRepository.setDynamicColor(enabled) }
    }

    fun setIndexMediaStorePublicItems(enabled: Boolean) {
        viewModelScope.launch { container.settingsRepository.setIndexMediaStorePublicItems(enabled) }
    }

    fun setAssistantName(name: String) {
        val clean = name.trim().ifBlank { "Personal AI" }
        viewModelScope.launch {
            container.settingsRepository.setAssistantName(clean)
            _uiNotice.value = "Assistant wake name set to \"$clean\"."
        }
    }

    fun setWakeWordEnabled(enabled: Boolean) {
        val ctx = getApplication<Application>()
        if (enabled && !WakeWordService.hasMicPermission(ctx)) {
            _uiNotice.value = "Grant Microphone permission to enable silent wake standby."
            return
        }
        viewModelScope.launch {
            container.settingsRepository.setWakeWordEnabled(enabled)
            if (enabled) {
                WakeWordService.start(ctx)
                _uiNotice.value = "Silent wake standby active for \"${assistantSettings.value.assistantName}\"."
            } else {
                WakeWordService.stop(ctx)
                _uiNotice.value = "Wake-word standby stopped."
            }
        }
    }

    fun setWakeAutoListenAfterTrigger(enabled: Boolean) {
        viewModelScope.launch {
            container.settingsRepository.setWakeAutoListenAfterTrigger(enabled)
        }
    }

    fun recordAndSaveWakeSample() {
        val ctx = getApplication<Application>()
        if (!WakeWordService.hasMicPermission(ctx)) {
            _uiNotice.value = "Grant Microphone permission first to record a wake voice sample."
            return
        }
        if (_isRecordingWakeSample.value) return
        viewModelScope.launch {
            _isRecordingWakeSample.value = true
            val wasWakeRunning = WakeWordService.isRunningFlow.value
            if (wasWakeRunning) {
                WakeWordService.isAssistantOverlayActive.value = true
                kotlinx.coroutines.delay(250L)
            }
            val phrase = assistantSettings.value.assistantName.ifBlank { "Personal AI" }
            val result = SilentWakeDetector.recordWakeSample(phraseName = phrase, durationMs = 2200L)
            if (wasWakeRunning) {
                WakeWordService.isAssistantOverlayActive.value = false
            }
            _isRecordingWakeSample.value = false
            result.fold(
                onSuccess = { json ->
                    container.settingsRepository.saveWakeTemplateJson(json)
                    _uiNotice.value = "Saved silent voice sample for \"$phrase\"!"
                },
                onFailure = { err ->
                    _uiNotice.value = err.localizedMessage ?: "Could not record wake sample."
                }
            )
        }
    }

    fun clearWakeVoiceSample() {
        viewModelScope.launch {
            container.settingsRepository.saveWakeTemplateJson("")
            _uiNotice.value = "Cleared saved wake voice sample."
        }
    }

    fun launchBottomWakeAssistant(context: Context = getApplication(), initialCommand: String? = null) {
        val intent = Intent(context, AssistActivity::class.java).apply {
            if (context is Application) {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(AssistActivity.EXTRA_WAKE_TRIGGERED, true)
            if (!initialCommand.isNullOrBlank()) {
                putExtra(AssistActivity.EXTRA_INITIAL_COMMAND, initialCommand)
            }
        }
        context.startActivity(intent)
    }

    // --- File Index & Search ---
    fun onFolderAuthorized(treeUri: Uri?) {
        if (treeUri == null) return
        container.fileIndexer.addSafFolderPermission(treeUri)
        refreshSystemState()
        startFileIndexing(incremental = true)
    }

    fun removeAuthorizedFolder(treeUri: Uri) {
        container.fileIndexer.removeSafFolderPermission(treeUri)
        refreshSystemState()
    }

    fun startFileIndexing(incremental: Boolean = true) {
        FileIndexWorker.enqueue(getApplication(), incremental = incremental)
    }

    fun pauseFileIndexing() {
        container.fileIndexer.requestPause()
    }

    fun cancelFileIndexing() {
        FileIndexWorker.cancel(getApplication())
    }

    fun clearFileIndex() {
        viewModelScope.launch {
            container.database.indexedFileDao().clearAll()
            _uiNotice.value = "Cleared local file index."
        }
    }

    fun searchFiles(query: String) {
        _fileSearchQuery.value = query
        viewModelScope.launch {
            _fileSearchResult.value = if (query.isBlank()) {
                null
            } else {
                container.fileSearch.search(query, limit = 30)
            }
        }
    }

    fun openFile(file: IndexedFileEntity) {
        val result = container.fileIndexer.openFile(file.uriString, file.mimeType)
        if (result.isFailure) {
            _uiNotice.value = result.exceptionOrNull()?.localizedMessage
                ?: "Unable to open ${file.name}."
        }
    }

    // --- Installed Apps ---
    fun refreshInstalledApps() {
        viewModelScope.launch {
            val count = container.appIndexer.refreshInstalledApps()
            _filteredApps.value = container.appIndexer.searchApps(_appSearchQuery.value)
            _uiNotice.value = "Indexed $count launchable apps."
        }
    }

    fun searchInstalledApps(query: String) {
        _appSearchQuery.value = query
        viewModelScope.launch {
            _filteredApps.value = container.appIndexer.searchApps(query)
        }
    }

    fun launchApp(packageName: String) {
        val res = container.appIndexer.launchApp(packageName)
        if (res.isFailure) {
            _uiNotice.value = res.exceptionOrNull()?.localizedMessage
                ?: "Could not launch app."
        }
    }

    fun openAppSystemInfo(packageName: String) {
        container.appIndexer.openAppSystemInfo(packageName)
    }

    fun loadAppIcon(packageName: String) = container.appIndexer.loadAppIcon(packageName)

    // --- Screen Understanding ---
    fun refreshScreenSnapshot(userTriggered: Boolean = true) {
        val snap = container.screenUnderstandingRepository.refreshFromAccessibility(userTriggered = userTriggered)
        if (snap == null) {
            _uiNotice.value = "No external screen captured yet. Enable Accessibility Screen Reader and switch to an app."
        }
    }

    // --- Memory Management ---
    fun addMemory(fact: String, category: String = "Preference") {
        viewModelScope.launch {
            val ok = container.memoryRepository.saveMemory(fact, category)
            if (!ok) {
                _uiNotice.value = "Memory not saved (check that Memory is enabled and no API keys/passwords are included)."
            }
        }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch { container.memoryRepository.deleteMemory(id) }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            container.memoryRepository.clearAll()
            _uiNotice.value = "Cleared all saved memories."
        }
    }

    // --- Floating Assistant ---
    fun setFloatingOverlayRunning(enable: Boolean) {
        val ctx = getApplication<Application>()
        if (enable) {
            if (!container.permissionChecker.canDrawOverlays()) {
                _uiNotice.value = "Grant 'Display over other apps' permission first."
                return
            }
            FloatingAssistantService.start(ctx)
        } else {
            FloatingAssistantService.stop(ctx)
        }
        viewModelScope.launch {
            container.settingsRepository.updateFloatingSettings { it.copy(enabled = enable) }
        }
    }

    fun updateFloatingSettings(transform: (FloatingSettings) -> FloatingSettings) {
        viewModelScope.launch {
            container.settingsRepository.updateFloatingSettings(transform)
        }
    }

    // --- AI Models Catalog & Downloads ---
    fun fetchProviderModels(overrideSettings: AiSettings? = null) {
        viewModelScope.launch {
            _isFetchingModels.value = true
            _modelCatalogError.value = null
            val target = overrideSettings ?: aiSettings.value
            val result = container.modelCatalogService.fetchModelsForProvider(target)
            _isFetchingModels.value = false
            result.fold(
                onSuccess = { list ->
                    _uiNotice.value = "Fetched ${list.size} models from ${target.effectiveDisplayName}."
                },
                onFailure = { err ->
                    _modelCatalogError.value = err.localizedMessage ?: "Failed to fetch models."
                    _uiNotice.value = _modelCatalogError.value
                }
            )
        }
    }

    fun applyModelFromCatalog(model: CachedProviderModelEntity) {
        viewModelScope.launch {
            when (model.capability) {
                com.example.ai.ModelCatalogService.CAP_SPEECH_TTS -> {
                    val currentSpeech = speechSettings.value
                    container.settingsRepository.saveSpeechSettings(
                        currentSpeech.copy(
                            ttsEngine = TtsEngineMode.CLOUD_TTS,
                            cloudTtsModel = model.modelId,
                            defaultDownloadedTtsModelId = null,
                            defaultDownloadedTtsModelName = ""
                        )
                    )
                    _uiNotice.value = "Default Speech TTS set to ${model.modelId}"
                }
                com.example.ai.ModelCatalogService.CAP_SPEECH_STT -> {
                    val currentSpeech = speechSettings.value
                    container.settingsRepository.saveSpeechSettings(
                        currentSpeech.copy(
                            sttEngine = SttEngineMode.CLOUD_WHISPER,
                            cloudSttModel = model.modelId,
                            defaultDownloadedSttModelId = null,
                            defaultDownloadedSttModelName = ""
                        )
                    )
                    _uiNotice.value = "Default Speech STT set to ${model.modelId}"
                }
                else -> {
                    val current = aiSettings.value
                    container.settingsRepository.clearDefaultDownloadedTextModel()
                    container.settingsRepository.saveProviderConfig(
                        provider = current.provider,
                        protocol = current.protocol,
                        customLabel = current.customProviderLabel,
                        apiKey = null,
                        model = model.modelId,
                        baseUrl = current.customBaseUrl,
                        authHeaderName = current.authHeaderName,
                        authHeaderPrefix = current.authHeaderPrefix,
                        enableNativeTools = current.enableNativeTools,
                        allowEmptyKey = current.allowEmptyKey,
                        temperature = current.temperature
                    )
                    _uiNotice.value = "Default Text AI set to ${model.modelId}"
                }
            }
        }
    }

    fun setDownloadedModelAsDefault(
        model: DownloadedModelEntity,
        servedModelName: String,
        endpointUrl: String,
        apiKey: String? = null
    ) {
        viewModelScope.launch {
            val cleanModel = servedModelName.trim()
                .ifBlank { ModelDownloadManager.suggestedRuntimeModelName(model) }
            val cleanEndpoint = endpointUrl.trim()

            when {
                ModelDownloadManager.isSpeechSttCategory(model.category) -> {
                    val current = speechSettings.value
                    container.settingsRepository.saveSpeechSettings(
                        current.copy(
                            sttEngine = SttEngineMode.CLOUD_WHISPER,
                            cloudSttModel = cleanModel,
                            cloudSpeechBaseUrl = cleanEndpoint.ifBlank { current.cloudSpeechBaseUrl },
                            defaultDownloadedSttModelId = model.id,
                            defaultDownloadedSttModelName = model.name
                        ),
                        newCloudSpeechApiKey = apiKey?.takeIf { it.isNotBlank() }
                    )
                    _uiNotice.value = "Default Speech Input AI set to ${model.name}."
                }
                ModelDownloadManager.isSpeechTtsCategory(model.category) -> {
                    val current = speechSettings.value
                    container.settingsRepository.saveSpeechSettings(
                        current.copy(
                            ttsEngine = TtsEngineMode.CLOUD_TTS,
                            cloudTtsModel = cleanModel,
                            cloudSpeechBaseUrl = cleanEndpoint.ifBlank { current.cloudSpeechBaseUrl },
                            defaultDownloadedTtsModelId = model.id,
                            defaultDownloadedTtsModelName = model.name
                        ),
                        newCloudSpeechApiKey = apiKey?.takeIf { it.isNotBlank() }
                    )
                    _uiNotice.value = "Default Speech Voice AI set to ${model.name}."
                }
                else -> {
                    val resolvedEndpoint = cleanEndpoint.ifBlank { "http://127.0.0.1:8080/v1" }
                    container.settingsRepository.setDefaultDownloadedTextModel(
                        modelId = model.id,
                        displayName = model.name,
                        servedModelName = cleanModel,
                        endpointUrl = resolvedEndpoint,
                        apiKey = apiKey
                    )
                    _uiNotice.value = "Default Text AI set to ${model.name}."
                }
            }
        }
    }

    fun setSystemVoiceAsDefault(voiceName: String) {
        viewModelScope.launch {
            val current = speechSettings.value
            container.settingsRepository.saveSpeechSettings(
                current.copy(
                    ttsEngine = TtsEngineMode.SYSTEM_TTS,
                    systemVoiceName = voiceName,
                    defaultDownloadedTtsModelId = null,
                    defaultDownloadedTtsModelName = ""
                )
            )
            _uiNotice.value = if (voiceName.isBlank()) {
                "Default Speech Voice set to Device Default TTS."
            } else {
                "Default Speech Voice set to $voiceName."
            }
        }
    }

    fun setSystemSttAsDefault() {
        viewModelScope.launch {
            val current = speechSettings.value
            container.settingsRepository.saveSpeechSettings(
                current.copy(
                    sttEngine = SttEngineMode.SYSTEM_STT,
                    defaultDownloadedSttModelId = null,
                    defaultDownloadedSttModelName = ""
                )
            )
            _uiNotice.value = "Default Speech Input set to Android Speech Recognition."
        }
    }

    fun startModelDownload(
        name: String,
        url: String,
        category: String = ModelDownloadManager.CATEGORY_TEXT,
        suggestedFileName: String? = null
    ) {
        viewModelScope.launch {
            val res = container.modelDownloadManager.enqueueDownload(
                name = name,
                rawUrl = url,
                category = category,
                suggestedFileName = suggestedFileName
            )
            res.fold(
                onSuccess = { _uiNotice.value = "Started background download: $name" },
                onFailure = { err -> _uiNotice.value = err.localizedMessage ?: "Invalid download URL." }
            )
        }
    }

    fun cancelModelDownload(model: DownloadedModelEntity) {
        viewModelScope.launch {
            container.modelDownloadManager.cancelDownload(model)
            _uiNotice.value = "Cancelled ${model.name}."
        }
    }

    fun deleteDownloadedModel(model: DownloadedModelEntity) {
        viewModelScope.launch {
            if (aiSettings.value.defaultDownloadedTextModelId == model.id) {
                container.settingsRepository.clearDefaultDownloadedTextModel()
            }
            val currentSpeech = speechSettings.value
            if (currentSpeech.defaultDownloadedTtsModelId == model.id ||
                currentSpeech.defaultDownloadedSttModelId == model.id
            ) {
                container.settingsRepository.saveSpeechSettings(
                    currentSpeech.copy(
                        ttsEngine = if (currentSpeech.defaultDownloadedTtsModelId == model.id) {
                            TtsEngineMode.SYSTEM_TTS
                        } else currentSpeech.ttsEngine,
                        sttEngine = if (currentSpeech.defaultDownloadedSttModelId == model.id) {
                            SttEngineMode.SYSTEM_STT
                        } else currentSpeech.sttEngine,
                        defaultDownloadedTtsModelId = if (currentSpeech.defaultDownloadedTtsModelId == model.id) null else currentSpeech.defaultDownloadedTtsModelId,
                        defaultDownloadedTtsModelName = if (currentSpeech.defaultDownloadedTtsModelId == model.id) "" else currentSpeech.defaultDownloadedTtsModelName,
                        defaultDownloadedSttModelId = if (currentSpeech.defaultDownloadedSttModelId == model.id) null else currentSpeech.defaultDownloadedSttModelId,
                        defaultDownloadedSttModelName = if (currentSpeech.defaultDownloadedSttModelId == model.id) "" else currentSpeech.defaultDownloadedSttModelName
                    )
                )
            }
            container.modelDownloadManager.deleteModel(model)
            _uiNotice.value = "Deleted ${model.name}."
        }
    }

    // --- Speech AI (TTS & STT) ---
    fun refreshSystemVoices() {
        container.speechAiManager.refreshVoices()
    }

    fun saveSpeechSettings(
        settings: SpeechSettings,
        newCloudSpeechApiKey: String? = null
    ) {
        viewModelScope.launch {
            container.settingsRepository.saveSpeechSettings(settings, newCloudSpeechApiKey)
            _uiNotice.value = "Saved Speech AI settings."
        }
    }

    fun setAutoSpeakResponses(enabled: Boolean) {
        viewModelScope.launch {
            container.settingsRepository.saveSpeechSettings(
                speechSettings.value.copy(autoSpeakResponses = enabled)
            )
        }
    }

    fun speakText(text: String) {
        viewModelScope.launch {
            val res = container.speechAiManager.speakText(
                text = text,
                speechSettings = speechSettings.value,
                aiSettings = aiSettings.value
            )
            if (res.isFailure) {
                _uiNotice.value = res.exceptionOrNull()?.localizedMessage ?: "Unable to speak response."
            }
        }
    }

    fun stopSpeaking() {
        container.speechAiManager.stopSpeaking()
    }

    fun toggleCloudWhisperRecording(onTranscribed: (String) -> Unit) {
        if (isRecordingCloudStt.value) {
            viewModelScope.launch {
                val res = container.speechAiManager.stopAndTranscribeCloudStt(
                    speechSettings = speechSettings.value,
                    aiSettings = aiSettings.value
                )
                res.fold(
                    onSuccess = { text -> onTranscribed(text) },
                    onFailure = { err -> _uiNotice.value = err.localizedMessage ?: "Whisper transcription failed." }
                )
            }
        } else {
            val startRes = container.speechAiManager.startCloudSttRecording()
            if (startRes.isFailure) {
                _uiNotice.value = startRes.exceptionOrNull()?.localizedMessage ?: "Could not start recording."
            }
        }
    }

    fun cancelCloudWhisperRecording() {
        container.speechAiManager.cancelCloudSttRecording()
    }

    fun isOnDeviceSpeechSupported(): Boolean =
        container.speechAiManager.isOnDeviceSpeechRecognitionSupported()

    fun getInstallTtsDataIntent(): Intent = container.speechAiManager.createInstallTtsDataIntent()
    fun getTtsSettingsIntent(): Intent = container.speechAiManager.createTtsSettingsIntent()

    // --- Permission Intent Helpers ---
    fun getAssistantRoleIntent(): Intent? = container.permissionChecker.createAssistantRoleRequestIntent()
    fun getVoiceInputSettingsIntent(): Intent = container.permissionChecker.createVoiceInputSettingsIntent()
    fun getOverlaySettingsIntent(): Intent = container.permissionChecker.createOverlaySettingsIntent()
    fun getAccessibilitySettingsIntent(): Intent = container.permissionChecker.createAccessibilitySettingsIntent()
    fun getNotificationSettingsIntent(): Intent = container.permissionChecker.createAppNotificationSettingsIntent()
    fun getOwnAppInfoIntent(): Intent = Intent(
        android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
        Uri.parse("package:${getApplication<Application>().packageName}")
    )

    class Factory(private val application: Application) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            val container = (application as PersonalAiApp).container
            return PersonalAiViewModel(application, container) as T
        }
    }
}
