package com.example.data.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.security.KeystoreCryptoManager
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.personalAiDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "personal_ai_preferences"
)

class SettingsRepository(
    private val context: Context,
    private val cryptoManager: KeystoreCryptoManager
) {
    private val dataStore = context.personalAiDataStore

    val aiSettingsFlow: Flow<AiSettings> = dataStore.data.map { prefs ->
        val provider = AiProviderType.fromId(prefs[KEY_PROVIDER])
        readProviderSettings(prefs, provider)
    }

    val configuredProvidersFlow: Flow<Set<AiProviderType>> = dataStore.data.map { prefs ->
        AiProviderType.entries.filterTo(mutableSetOf()) { provider ->
            val enc = prefs[apiKeyPrefFor(provider)].orEmpty()
            val allowEmpty = prefs[allowEmptyKeyPrefFor(provider)] ?: false
            cryptoManager.decrypt(enc).isNotBlank() || allowEmpty
        }
    }

    suspend fun getSettingsForProvider(provider: AiProviderType): AiSettings {
        val prefs = dataStore.data.first()
        return readProviderSettings(prefs, provider)
    }

    private fun readProviderSettings(prefs: Preferences, provider: AiProviderType): AiSettings {
        val encryptedKey = prefs[apiKeyPrefFor(provider)] ?: ""
        val decryptedKey = cryptoManager.decrypt(encryptedKey)
        val protocol = AiApiProtocol.fromId(prefs[protocolPrefFor(provider)]) ?: provider.defaultProtocol
        val customLabel = prefs[customLabelPrefFor(provider)].orEmpty()
        val model = prefs[modelPrefFor(provider)].orEmpty().ifBlank { provider.defaultModel }
        val baseUrl = prefs[baseUrlPrefFor(provider)].orEmpty().ifBlank { provider.defaultBaseUrl }
        val authHeader = prefs[authHeaderPrefFor(provider)] ?: provider.defaultAuthHeader
        val authPrefix = prefs[authPrefixPrefFor(provider)] ?: provider.defaultAuthPrefix
        val nativeTools = prefs[nativeToolsPrefFor(provider)] ?: provider.supportsNativeToolsByDefault
        val allowEmpty = prefs[allowEmptyKeyPrefFor(provider)] ?: false
        val temperature = prefs[KEY_TEMPERATURE] ?: 0.2f
        val defaultTextModelId = prefs[KEY_DEFAULT_DOWNLOADED_TEXT_ID]
        val defaultTextModelName = prefs[KEY_DEFAULT_DOWNLOADED_TEXT_NAME].orEmpty()
        val routingMode = AiRoutingMode.fromId(prefs[KEY_AI_ROUTING_MODE])
        val localEndpointUrl = prefs[KEY_LOCAL_ENDPOINT_URL].orEmpty().ifBlank { AiSettings.DEFAULT_LOCAL_ENDPOINT }
        val localModelName = prefs[KEY_LOCAL_MODEL_NAME].orEmpty().ifBlank { AiSettings.DEFAULT_LOCAL_MODEL }
        val localApiKey = cryptoManager.decrypt(prefs[KEY_LOCAL_API_KEY].orEmpty())

        return AiSettings(
            provider = provider,
            protocol = protocol,
            customProviderLabel = customLabel,
            apiKey = decryptedKey,
            model = model,
            customBaseUrl = baseUrl,
            authHeaderName = authHeader,
            authHeaderPrefix = authPrefix,
            enableNativeTools = nativeTools,
            allowEmptyKey = allowEmpty,
            temperature = temperature,
            defaultDownloadedTextModelId = defaultTextModelId,
            defaultDownloadedTextModelName = defaultTextModelName,
            routingMode = routingMode,
            localEndpointUrl = localEndpointUrl,
            localModelName = localModelName,
            localApiKey = localApiKey
        )
    }

    val assistantSettingsFlow: Flow<AssistantSettings> = dataStore.data.map { prefs ->
        AssistantSettings(
            assistantName = prefs[KEY_ASSISTANT_NAME].orEmpty().ifBlank { "Personal AI" },
            wakeWordEnabled = prefs[KEY_WAKE_WORD_ENABLED] ?: false,
            wakeAutoListenAfterTrigger = prefs[KEY_WAKE_AUTO_LISTEN] ?: false,
            wakeTemplateJson = prefs[KEY_WAKE_TEMPLATE_JSON].orEmpty(),
            visionEnabled = prefs[KEY_VISION_ENABLED] ?: false,
            onboardingCompleted = prefs[KEY_ONBOARDING_COMPLETED] ?: false,
            memoryEnabled = prefs[KEY_MEMORY_ENABLED] ?: true,
            confirmSensitiveActions = prefs[KEY_CONFIRM_SENSITIVE_ACTIONS] ?: true,
            includeScreenContextAutomatically = prefs[KEY_AUTO_SCREEN_CONTEXT] ?: false,
            themeMode = ThemeMode.fromId(prefs[KEY_THEME_MODE]),
            dynamicColor = prefs[KEY_DYNAMIC_COLOR] ?: false,
            indexMediaStorePublicItems = prefs[KEY_INDEX_MEDIASTORE] ?: true
        )
    }

    val floatingSettingsFlow: Flow<FloatingSettings> = dataStore.data.map { prefs ->
        FloatingSettings(
            enabled = prefs[KEY_FLOATING_ENABLED] ?: false,
            startOnRightEdge = prefs[KEY_FLOATING_RIGHT_EDGE] ?: true,
            bubbleOpacity = prefs[KEY_FLOATING_OPACITY] ?: 0.94f,
            compactBubbleLabel = prefs[KEY_FLOATING_COMPACT] ?: true,
            autoMinimizeAfterAction = prefs[KEY_FLOATING_AUTO_MINIMIZE] ?: false
        )
    }

    val speechSettingsFlow: Flow<SpeechSettings> = dataStore.data.map { prefs ->
        SpeechSettings(
            ttsEngine = TtsEngineMode.fromId(prefs[KEY_SPEECH_TTS_ENGINE]),
            sttEngine = SttEngineMode.fromId(prefs[KEY_SPEECH_STT_ENGINE]),
            autoSpeakResponses = prefs[KEY_SPEECH_AUTO_SPEAK] ?: false,
            systemVoiceName = prefs[KEY_SPEECH_SYSTEM_VOICE].orEmpty(),
            speechRate = prefs[KEY_SPEECH_RATE] ?: 1.0f,
            speechPitch = prefs[KEY_SPEECH_PITCH] ?: 1.0f,
            cloudTtsModel = prefs[KEY_SPEECH_CLOUD_TTS_MODEL].orEmpty().ifBlank { "gpt-4o-mini-tts" },
            cloudTtsVoice = prefs[KEY_SPEECH_CLOUD_TTS_VOICE].orEmpty().ifBlank { "alloy" },
            cloudSttModel = prefs[KEY_SPEECH_CLOUD_STT_MODEL].orEmpty().ifBlank { "whisper-1" },
            cloudSpeechBaseUrl = prefs[KEY_SPEECH_CLOUD_BASE_URL].orEmpty(),
            cloudSpeechApiKey = cryptoManager.decrypt(prefs[KEY_SPEECH_CLOUD_API_KEY].orEmpty()),
            defaultDownloadedTtsModelId = prefs[KEY_DEFAULT_DOWNLOADED_TTS_ID],
            defaultDownloadedTtsModelName = prefs[KEY_DEFAULT_DOWNLOADED_TTS_NAME].orEmpty(),
            defaultDownloadedSttModelId = prefs[KEY_DEFAULT_DOWNLOADED_STT_ID],
            defaultDownloadedSttModelName = prefs[KEY_DEFAULT_DOWNLOADED_STT_NAME].orEmpty()
        )
    }

    suspend fun selectProvider(provider: AiProviderType) {
        dataStore.edit { prefs ->
            prefs[KEY_PROVIDER] = provider.id
            if (provider != AiProviderType.CUSTOM) {
                prefs.remove(KEY_DEFAULT_DOWNLOADED_TEXT_ID)
                prefs.remove(KEY_DEFAULT_DOWNLOADED_TEXT_NAME)
            }
        }
    }

    suspend fun saveProviderConfig(
        provider: AiProviderType,
        protocol: AiApiProtocol = provider.defaultProtocol,
        customLabel: String = "",
        apiKey: String?,
        model: String,
        baseUrl: String,
        authHeaderName: String = protocol.defaultAuthHeader,
        authHeaderPrefix: String = protocol.defaultAuthPrefix,
        enableNativeTools: Boolean = provider.supportsNativeToolsByDefault,
        allowEmptyKey: Boolean = false,
        temperature: Float = 0.2f
    ) {
        dataStore.edit { prefs ->
            prefs[KEY_PROVIDER] = provider.id
            prefs[protocolPrefFor(provider)] = protocol.id
            if (customLabel.isNotBlank()) {
                prefs[customLabelPrefFor(provider)] = customLabel.trim()
            } else {
                prefs.remove(customLabelPrefFor(provider))
            }
            if (apiKey != null) {
                if (apiKey.isBlank()) {
                    prefs.remove(apiKeyPrefFor(provider))
                } else {
                    prefs[apiKeyPrefFor(provider)] = cryptoManager.encrypt(apiKey.trim())
                }
            }
            prefs[modelPrefFor(provider)] = model.trim().ifBlank { provider.defaultModel }
            prefs[baseUrlPrefFor(provider)] = baseUrl.trim().ifBlank { provider.defaultBaseUrl }
            prefs[authHeaderPrefFor(provider)] = authHeaderName.trim().ifBlank { protocol.defaultAuthHeader }
            prefs[authPrefixPrefFor(provider)] = authHeaderPrefix
            prefs[nativeToolsPrefFor(provider)] = enableNativeTools
            prefs[allowEmptyKeyPrefFor(provider)] = allowEmptyKey
            prefs[KEY_TEMPERATURE] = temperature.coerceIn(0f, 1f)
            if (provider != AiProviderType.CUSTOM) {
                prefs.remove(KEY_DEFAULT_DOWNLOADED_TEXT_ID)
                prefs.remove(KEY_DEFAULT_DOWNLOADED_TEXT_NAME)
            }
        }
    }

    suspend fun setDefaultDownloadedTextModel(
        modelId: Long,
        displayName: String,
        servedModelName: String,
        endpointUrl: String,
        apiKey: String? = null
    ) {
        dataStore.edit { prefs ->
            val provider = AiProviderType.CUSTOM
            prefs[KEY_PROVIDER] = provider.id
            prefs[protocolPrefFor(provider)] = AiApiProtocol.OPENAI_COMPATIBLE.id
            prefs[customLabelPrefFor(provider)] = displayName.trim()
            prefs[modelPrefFor(provider)] = servedModelName.trim().ifBlank { displayName.trim() }
            prefs[baseUrlPrefFor(provider)] = endpointUrl.trim().ifBlank { "http://127.0.0.1:8080/v1" }
            prefs[authHeaderPrefFor(provider)] = AiApiProtocol.OPENAI_COMPATIBLE.defaultAuthHeader
            prefs[authPrefixPrefFor(provider)] = AiApiProtocol.OPENAI_COMPATIBLE.defaultAuthPrefix
            prefs[allowEmptyKeyPrefFor(provider)] = apiKey.isNullOrBlank()
            if (apiKey != null) {
                if (apiKey.isBlank()) {
                    prefs.remove(apiKeyPrefFor(provider))
                } else {
                    prefs[apiKeyPrefFor(provider)] = cryptoManager.encrypt(apiKey.trim())
                }
            }
            prefs[KEY_DEFAULT_DOWNLOADED_TEXT_ID] = modelId
            prefs[KEY_DEFAULT_DOWNLOADED_TEXT_NAME] = displayName.trim()
            prefs[KEY_LOCAL_ENDPOINT_URL] = endpointUrl.trim().ifBlank { AiSettings.DEFAULT_LOCAL_ENDPOINT }
            prefs[KEY_LOCAL_MODEL_NAME] = servedModelName.trim().ifBlank { displayName.trim() }
            if (apiKey != null) {
                if (apiKey.isBlank()) {
                    prefs.remove(KEY_LOCAL_API_KEY)
                } else {
                    prefs[KEY_LOCAL_API_KEY] = cryptoManager.encrypt(apiKey.trim())
                }
            }
        }
    }

    suspend fun setAiRoutingMode(mode: AiRoutingMode) {
        dataStore.edit { prefs -> prefs[KEY_AI_ROUTING_MODE] = mode.id }
    }

    suspend fun saveLocalAiConfig(
        endpointUrl: String,
        modelName: String,
        apiKey: String? = null
    ) {
        dataStore.edit { prefs ->
            prefs[KEY_LOCAL_ENDPOINT_URL] = endpointUrl.trim().ifBlank { AiSettings.DEFAULT_LOCAL_ENDPOINT }
            prefs[KEY_LOCAL_MODEL_NAME] = modelName.trim().ifBlank { AiSettings.DEFAULT_LOCAL_MODEL }
            if (apiKey != null) {
                if (apiKey.isBlank()) {
                    prefs.remove(KEY_LOCAL_API_KEY)
                } else {
                    prefs[KEY_LOCAL_API_KEY] = cryptoManager.encrypt(apiKey.trim())
                }
            }
        }
    }

    suspend fun clearDefaultDownloadedTextModel() {
        dataStore.edit { prefs ->
            prefs.remove(KEY_DEFAULT_DOWNLOADED_TEXT_ID)
            prefs.remove(KEY_DEFAULT_DOWNLOADED_TEXT_NAME)
        }
    }

    suspend fun clearApiKey(provider: AiProviderType) {
        dataStore.edit { prefs ->
            prefs.remove(apiKeyPrefFor(provider))
            prefs.remove(allowEmptyKeyPrefFor(provider))
        }
    }

    suspend fun setAssistantName(name: String) {
        val clean = name.trim().take(28).ifBlank { "Personal AI" }
        dataStore.edit { prefs -> prefs[KEY_ASSISTANT_NAME] = clean }
    }

    suspend fun setWakeWordEnabled(enabled: Boolean) {
        dataStore.edit { prefs -> prefs[KEY_WAKE_WORD_ENABLED] = enabled }
    }

    suspend fun setWakeAutoListenAfterTrigger(enabled: Boolean) {
        dataStore.edit { prefs -> prefs[KEY_WAKE_AUTO_LISTEN] = enabled }
    }

    suspend fun saveWakeTemplateJson(templateJson: String) {
        dataStore.edit { prefs ->
            if (templateJson.isBlank()) {
                prefs.remove(KEY_WAKE_TEMPLATE_JSON)
            } else {
                prefs[KEY_WAKE_TEMPLATE_JSON] = templateJson
            }
        }
    }

    suspend fun setVisionEnabled(enabled: Boolean) {
        dataStore.edit { prefs ->
            prefs[KEY_VISION_ENABLED] = enabled
            if (!enabled) {
                prefs[KEY_AUTO_SCREEN_CONTEXT] = false
            }
        }
    }

    suspend fun setOnboardingCompleted(completed: Boolean) {
        dataStore.edit { prefs -> prefs[KEY_ONBOARDING_COMPLETED] = completed }
    }

    suspend fun setMemoryEnabled(enabled: Boolean) {
        dataStore.edit { prefs -> prefs[KEY_MEMORY_ENABLED] = enabled }
    }

    suspend fun setConfirmSensitiveActions(confirm: Boolean) {
        dataStore.edit { prefs -> prefs[KEY_CONFIRM_SENSITIVE_ACTIONS] = confirm }
    }

    suspend fun setIncludeScreenContextAutomatically(include: Boolean) {
        dataStore.edit { prefs -> prefs[KEY_AUTO_SCREEN_CONTEXT] = include }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        dataStore.edit { prefs -> prefs[KEY_THEME_MODE] = mode.id }
    }

    suspend fun setDynamicColor(enabled: Boolean) {
        dataStore.edit { prefs -> prefs[KEY_DYNAMIC_COLOR] = enabled }
    }

    suspend fun setIndexMediaStorePublicItems(enabled: Boolean) {
        dataStore.edit { prefs -> prefs[KEY_INDEX_MEDIASTORE] = enabled }
    }

    suspend fun updateFloatingSettings(transform: (FloatingSettings) -> FloatingSettings) {
        dataStore.edit { prefs ->
            val current = FloatingSettings(
                enabled = prefs[KEY_FLOATING_ENABLED] ?: false,
                startOnRightEdge = prefs[KEY_FLOATING_RIGHT_EDGE] ?: true,
                bubbleOpacity = prefs[KEY_FLOATING_OPACITY] ?: 0.94f,
                compactBubbleLabel = prefs[KEY_FLOATING_COMPACT] ?: true,
                autoMinimizeAfterAction = prefs[KEY_FLOATING_AUTO_MINIMIZE] ?: false
            )
            val updated = transform(current)
            prefs[KEY_FLOATING_ENABLED] = updated.enabled
            prefs[KEY_FLOATING_RIGHT_EDGE] = updated.startOnRightEdge
            prefs[KEY_FLOATING_OPACITY] = updated.bubbleOpacity
            prefs[KEY_FLOATING_COMPACT] = updated.compactBubbleLabel
            prefs[KEY_FLOATING_AUTO_MINIMIZE] = updated.autoMinimizeAfterAction
        }
    }

    suspend fun saveSpeechSettings(
        settings: SpeechSettings,
        newCloudSpeechApiKey: String? = null
    ) {
        dataStore.edit { prefs ->
            prefs[KEY_SPEECH_TTS_ENGINE] = settings.ttsEngine.id
            prefs[KEY_SPEECH_STT_ENGINE] = settings.sttEngine.id
            prefs[KEY_SPEECH_AUTO_SPEAK] = settings.autoSpeakResponses
            prefs[KEY_SPEECH_SYSTEM_VOICE] = settings.systemVoiceName
            prefs[KEY_SPEECH_RATE] = settings.speechRate.coerceIn(0.5f, 2.0f)
            prefs[KEY_SPEECH_PITCH] = settings.speechPitch.coerceIn(0.5f, 2.0f)
            prefs[KEY_SPEECH_CLOUD_TTS_MODEL] = settings.cloudTtsModel.trim().ifBlank { "gpt-4o-mini-tts" }
            prefs[KEY_SPEECH_CLOUD_TTS_VOICE] = settings.cloudTtsVoice.trim().ifBlank { "alloy" }
            prefs[KEY_SPEECH_CLOUD_STT_MODEL] = settings.cloudSttModel.trim().ifBlank { "whisper-1" }
            prefs[KEY_SPEECH_CLOUD_BASE_URL] = settings.cloudSpeechBaseUrl.trim()
            if (settings.defaultDownloadedTtsModelId != null) {
                prefs[KEY_DEFAULT_DOWNLOADED_TTS_ID] = settings.defaultDownloadedTtsModelId
                prefs[KEY_DEFAULT_DOWNLOADED_TTS_NAME] = settings.defaultDownloadedTtsModelName
            } else {
                prefs.remove(KEY_DEFAULT_DOWNLOADED_TTS_ID)
                prefs.remove(KEY_DEFAULT_DOWNLOADED_TTS_NAME)
            }
            if (settings.defaultDownloadedSttModelId != null) {
                prefs[KEY_DEFAULT_DOWNLOADED_STT_ID] = settings.defaultDownloadedSttModelId
                prefs[KEY_DEFAULT_DOWNLOADED_STT_NAME] = settings.defaultDownloadedSttModelName
            } else {
                prefs.remove(KEY_DEFAULT_DOWNLOADED_STT_ID)
                prefs.remove(KEY_DEFAULT_DOWNLOADED_STT_NAME)
            }
            if (newCloudSpeechApiKey != null) {
                if (newCloudSpeechApiKey.isBlank()) {
                    prefs.remove(KEY_SPEECH_CLOUD_API_KEY)
                } else {
                    prefs[KEY_SPEECH_CLOUD_API_KEY] = cryptoManager.encrypt(newCloudSpeechApiKey.trim())
                }
            }
        }
    }

    private fun apiKeyPrefFor(provider: AiProviderType) =
        stringPreferencesKey("encrypted_api_key_${provider.id}")

    private fun protocolPrefFor(provider: AiProviderType) =
        stringPreferencesKey("protocol_${provider.id}")

    private fun customLabelPrefFor(provider: AiProviderType) =
        stringPreferencesKey("custom_label_${provider.id}")

    private fun modelPrefFor(provider: AiProviderType) =
        stringPreferencesKey("model_${provider.id}")

    private fun baseUrlPrefFor(provider: AiProviderType) =
        stringPreferencesKey("base_url_${provider.id}")

    private fun authHeaderPrefFor(provider: AiProviderType) =
        stringPreferencesKey("auth_header_${provider.id}")

    private fun authPrefixPrefFor(provider: AiProviderType) =
        stringPreferencesKey("auth_prefix_${provider.id}")

    private fun nativeToolsPrefFor(provider: AiProviderType) =
        booleanPreferencesKey("native_tools_${provider.id}")

    private fun allowEmptyKeyPrefFor(provider: AiProviderType) =
        booleanPreferencesKey("allow_empty_key_${provider.id}")

    companion object {
        private val KEY_PROVIDER = stringPreferencesKey("active_provider")
        private val KEY_TEMPERATURE = floatPreferencesKey("temperature")
        private val KEY_ASSISTANT_NAME = stringPreferencesKey("assistant_name")
        private val KEY_WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
        private val KEY_WAKE_AUTO_LISTEN = booleanPreferencesKey("wake_auto_listen_after_trigger")
        private val KEY_WAKE_TEMPLATE_JSON = stringPreferencesKey("wake_template_json")
        private val KEY_VISION_ENABLED = booleanPreferencesKey("vision_enabled")
        private val KEY_ONBOARDING_COMPLETED = booleanPreferencesKey("onboarding_completed")
        private val KEY_MEMORY_ENABLED = booleanPreferencesKey("memory_enabled")
        private val KEY_CONFIRM_SENSITIVE_ACTIONS = booleanPreferencesKey("confirm_sensitive_actions")
        private val KEY_AUTO_SCREEN_CONTEXT = booleanPreferencesKey("auto_screen_context")
        private val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
        private val KEY_DYNAMIC_COLOR = booleanPreferencesKey("dynamic_color")
        private val KEY_INDEX_MEDIASTORE = booleanPreferencesKey("index_mediastore")
        private val KEY_FLOATING_ENABLED = booleanPreferencesKey("floating_enabled")
        private val KEY_FLOATING_RIGHT_EDGE = booleanPreferencesKey("floating_right_edge")
        private val KEY_FLOATING_OPACITY = floatPreferencesKey("floating_opacity")
        private val KEY_FLOATING_COMPACT = booleanPreferencesKey("floating_compact")
        private val KEY_FLOATING_AUTO_MINIMIZE = booleanPreferencesKey("floating_auto_minimize")
        private val KEY_SPEECH_TTS_ENGINE = stringPreferencesKey("speech_tts_engine")
        private val KEY_SPEECH_STT_ENGINE = stringPreferencesKey("speech_stt_engine")
        private val KEY_SPEECH_AUTO_SPEAK = booleanPreferencesKey("speech_auto_speak")
        private val KEY_SPEECH_SYSTEM_VOICE = stringPreferencesKey("speech_system_voice")
        private val KEY_SPEECH_RATE = floatPreferencesKey("speech_rate")
        private val KEY_SPEECH_PITCH = floatPreferencesKey("speech_pitch")
        private val KEY_SPEECH_CLOUD_TTS_MODEL = stringPreferencesKey("speech_cloud_tts_model")
        private val KEY_SPEECH_CLOUD_TTS_VOICE = stringPreferencesKey("speech_cloud_tts_voice")
        private val KEY_SPEECH_CLOUD_STT_MODEL = stringPreferencesKey("speech_cloud_stt_model")
        private val KEY_SPEECH_CLOUD_BASE_URL = stringPreferencesKey("speech_cloud_base_url")
        private val KEY_SPEECH_CLOUD_API_KEY = stringPreferencesKey("speech_cloud_api_key")
        private val KEY_DEFAULT_DOWNLOADED_TEXT_ID = longPreferencesKey("default_downloaded_text_id")
        private val KEY_DEFAULT_DOWNLOADED_TEXT_NAME = stringPreferencesKey("default_downloaded_text_name")
        private val KEY_DEFAULT_DOWNLOADED_TTS_ID = longPreferencesKey("default_downloaded_tts_id")
        private val KEY_DEFAULT_DOWNLOADED_TTS_NAME = stringPreferencesKey("default_downloaded_tts_name")
        private val KEY_DEFAULT_DOWNLOADED_STT_ID = longPreferencesKey("default_downloaded_stt_id")
        private val KEY_DEFAULT_DOWNLOADED_STT_NAME = stringPreferencesKey("default_downloaded_stt_name")
        private val KEY_AI_ROUTING_MODE = stringPreferencesKey("ai_routing_mode")
        private val KEY_LOCAL_ENDPOINT_URL = stringPreferencesKey("local_endpoint_url")
        private val KEY_LOCAL_MODEL_NAME = stringPreferencesKey("local_model_name")
        private val KEY_LOCAL_API_KEY = stringPreferencesKey("local_api_key")
    }
}
