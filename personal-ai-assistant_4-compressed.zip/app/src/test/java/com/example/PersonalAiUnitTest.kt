package com.example

import com.example.ai.AiMessage
import com.example.ai.AiRole
import com.example.ai.AiToolCall
import com.example.ai.GeminiProvider
import com.example.ai.ModelCatalogService
import com.example.ai.ModelDownloadManager
import com.example.ai.local.GgufMetadataParser
import com.example.ai.local.GgufParseResult
import com.example.assistant.SilentWakeDetector
import com.example.assistant.WakeVoiceTemplate
import com.example.assistant.WakeWordMatcher
import org.robolectric.RuntimeEnvironment
import com.example.data.db.AppDatabase
import com.example.data.db.CachedProviderModelDao
import com.example.data.db.CachedProviderModelEntity
import com.example.data.settings.AiApiProtocol
import com.example.data.settings.AiProviderType
import com.example.data.settings.AiRouteIssue
import com.example.data.settings.AiRoutingMode
import com.example.data.settings.AiSettings
import com.example.data.settings.SpeechSettings
import com.example.data.settings.ThemeMode
import com.example.patterns.PatternRepository
import com.example.patterns.PatternStep
import com.example.security.SecurityScanner
import com.example.security.SecuritySeverity
import com.example.speech.SpeechAiManager
import com.example.ui.theme.isDarkAppearance
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class PersonalAiUnitTest {

    @Test
    fun `model download manager validates urls and sanitizes filenames`() {
        assertEquals(
            "https://huggingface.co/model.gguf",
            ModelDownloadManager.validateDownloadUrl("  https://huggingface.co/model.gguf  ")
        )
        assertNull(ModelDownloadManager.validateDownloadUrl("file:///etc/passwd"))
        assertNull(ModelDownloadManager.validateDownloadUrl("content://media/external/file/1"))
        assertNull(ModelDownloadManager.validateDownloadUrl("javascript:alert(1)"))
        assertNull(ModelDownloadManager.validateDownloadUrl(""))
        assertEquals("safe_model.bin", ModelDownloadManager.sanitizeFileName("../../safe model.bin"))
    }

    @Test
    fun `model catalog classifies speech tts stt embedding and chat models`() {
        assertEquals(ModelCatalogService.CAP_SPEECH_STT, ModelCatalogService.classifyCapability("whisper-1"))
        assertEquals(ModelCatalogService.CAP_SPEECH_STT, ModelCatalogService.classifyCapability("gpt-4o-transcribe"))
        assertEquals(ModelCatalogService.CAP_SPEECH_TTS, ModelCatalogService.classifyCapability("gpt-4o-mini-tts"))
        assertEquals(ModelCatalogService.CAP_SPEECH_TTS, ModelCatalogService.classifyCapability("tts-1-hd"))
        assertEquals(ModelCatalogService.CAP_EMBEDDING, ModelCatalogService.classifyCapability("text-embedding-3-small"))
        assertEquals(ModelCatalogService.CAP_CHAT, ModelCatalogService.classifyCapability("gemini-2.5-flash"))
    }

    @Test
    fun `speech ai manager resolves speech endpoints and cleans markdown`() {
        val speechSettings = SpeechSettings()
        val openAi = AiSettings(
            provider = AiProviderType.OPENAI,
            customBaseUrl = "https://api.openai.com/v1/chat/completions"
        )
        assertEquals(
            "https://api.openai.com/v1",
            SpeechAiManager.resolveSpeechBaseUrl(speechSettings, openAi)
        )

        val customSpeech = SpeechSettings(cloudSpeechBaseUrl = "https://api.groq.com/openai/v1/")
        val gemini = AiSettings(provider = AiProviderType.GEMINI)
        assertEquals(
            "https://api.groq.com/openai/v1",
            SpeechAiManager.resolveSpeechBaseUrl(customSpeech, gemini)
        )

        val cleaned = SpeechAiManager.cleanTextForSpeech("### **Hello** `world`!")
        assertEquals("Hello world!", cleaned)
    }

    @Test
    fun `universal ai settings format auth headers for all protocols`() {
        val openai = AiSettings(
            provider = AiProviderType.OPENAI,
            apiKey = "sk-test-123"
        )
        assertEquals("Authorization", openai.effectiveAuthHeaderName)
        assertEquals("Bearer sk-test-123", openai.buildAuthHeaderValue())

        val anthropic = AiSettings(
            provider = AiProviderType.ANTHROPIC,
            protocol = AiApiProtocol.ANTHROPIC,
            apiKey = "sk-ant-xyz"
        )
        assertEquals("x-api-key", anthropic.effectiveAuthHeaderName)
        assertEquals("sk-ant-xyz", anthropic.buildAuthHeaderValue())
    }

    @Test
    fun `curated presets include over 2B persian text models and persian speech models`() {
        val textPresets = ModelDownloadManager.curatedPresets.filter {
            ModelDownloadManager.isTextCategory(it.category)
        }
        val sttPresets = ModelDownloadManager.curatedPresets.filter {
            ModelDownloadManager.isSpeechSttCategory(it.category)
        }
        val ttsPresets = ModelDownloadManager.curatedPresets.filter {
            ModelDownloadManager.isSpeechTtsCategory(it.category)
        }
        org.junit.Assert.assertTrue(textPresets.isNotEmpty())
        org.junit.Assert.assertTrue(sttPresets.isNotEmpty())
        org.junit.Assert.assertTrue(ttsPresets.isNotEmpty())

        // All curated Text AI models must exceed 2B parameters and support Persian for 6+ GB RAM devices
        org.junit.Assert.assertTrue(textPresets.all { it.paramBillions > 2.0 })
        org.junit.Assert.assertTrue(textPresets.all { it.supportsPersian })
        org.junit.Assert.assertTrue(textPresets.all { it.recommendedRamGb <= 6 })
        org.junit.Assert.assertTrue(
            textPresets.all {
                it.formatLabel.isNotBlank() &&
                    it.specsLabel.isNotBlank() &&
                    it.compatibilityLabel.isNotBlank() &&
                    it.languagesLabel.isNotBlank()
            }
        )

        // Persian-capable Speech STT & TTS presets must be included
        org.junit.Assert.assertTrue(sttPresets.any { it.supportsPersian })
        org.junit.Assert.assertTrue(ttsPresets.any { it.supportsPersian && it.fileName.startsWith("fa_IR") })

        val gemmaPreset = textPresets.first { it.id == "gemma3_4b" }
        val entity = com.example.data.db.DownloadedModelEntity(
            id = 42L,
            name = gemmaPreset.name,
            fileName = gemmaPreset.fileName,
            downloadUrl = gemmaPreset.downloadUrl,
            category = ModelDownloadManager.CATEGORY_TEXT
        )
        assertEquals("gemma3:4b", ModelDownloadManager.suggestedRuntimeModelName(entity))

        val defaultDownloadedAi = AiSettings(
            provider = AiProviderType.CUSTOM,
            customProviderLabel = "Fallback",
            allowEmptyKey = true,
            defaultDownloadedTextModelId = 42L,
            defaultDownloadedTextModelName = gemmaPreset.name
        )
        assertEquals("Gemma 3 4B Instruct (Q4_K_M)", defaultDownloadedAi.effectiveDisplayName)
        org.junit.Assert.assertTrue(defaultDownloadedAi.hasApiKey)
        org.junit.Assert.assertTrue(SpeechAiManager.isLocalSpeechEndpoint("http://127.0.0.1:8080/v1"))
        org.junit.Assert.assertFalse(SpeechAiManager.isLocalSpeechEndpoint("https://api.openai.com/v1"))
    }

    @Test
    fun `theme modes resolve persian and neon variants and dark appearance`() {
        assertEquals(ThemeMode.PERSIAN, ThemeMode.fromId("persian"))
        assertEquals(ThemeMode.NEON, ThemeMode.fromId("neon"))
        assertEquals(ThemeMode.SYSTEM, ThemeMode.fromId("unknown_theme"))

        org.junit.Assert.assertFalse(ThemeMode.PERSIAN.isDarkAppearance(systemIsDark = true))
        org.junit.Assert.assertTrue(ThemeMode.NEON.isDarkAppearance(systemIsDark = false))
        org.junit.Assert.assertTrue(ThemeMode.DARK.isDarkAppearance(systemIsDark = false))
        org.junit.Assert.assertFalse(ThemeMode.LIGHT.isDarkAppearance(systemIsDark = true))
        org.junit.Assert.assertTrue(ThemeMode.SYSTEM.isDarkAppearance(systemIsDark = true))
        org.junit.Assert.assertFalse(ThemeMode.SYSTEM.isDarkAppearance(systemIsDark = false))
    }

    @Test
    fun `wake word matcher detects custom AI names in English and Persian and extracts commands`() {
        val exact = WakeWordMatcher.matchWakePhrase("Nova", "Nova")
        assertNotNull(exact)
        assertEquals("", exact?.remainingCommand)

        val command = WakeWordMatcher.matchWakePhrase("Hey Nova open Chrome", "Nova")
        assertNotNull(command)
        assertEquals("open Chrome", command?.remainingCommand)

        val punctuated = WakeWordMatcher.matchWakePhrase("nova, what is on my screen?", "Nova")
        assertNotNull(punctuated)
        assertEquals("what is on my screen?", punctuated?.remainingCommand)

        val persian = WakeWordMatcher.matchWakePhrase("سلام سارا ساعت چنده", "سارا")
        assertNotNull(persian)
        assertEquals("ساعت چنده", persian?.remainingCommand)

        // Partial substring must not falsely trigger wake word
        assertNull(WakeWordMatcher.matchWakePhrase("home renovation plan", "Nova"))
        assertNull(WakeWordMatcher.matchWakePhrase("hello", "A"))
    }

    @Test
    fun `ai routing switches cleanly between cloud api key, embedded on-device gguf, and optional external server`() {
        val baseOnDevice = AiSettings(
            provider = AiProviderType.OPENAI,
            apiKey = "sk-cloud-123",
            model = "gpt-4o-mini",
            routingMode = AiRoutingMode.AUTO_NETWORK,
            localUseExternalServer = false,
            defaultDownloadedTextModelId = 7L,
            defaultDownloadedTextModelName = "Gemma 3 4B Instruct (Q4_K_M)",
            defaultDownloadedTextModelPath = "/data/user/0/app/files/models/gemma-3-4b-it.Q4_K_M.gguf"
        )

        val autoOnline = baseOnDevice.resolveEffectiveRoute(isOnline = true)
        assertFalse(autoOnline.isUsingLocal)
        assertFalse(autoOnline.isUsingEmbeddedRuntime)
        assertNull(autoOnline.issue)
        assertEquals("gpt-4o-mini", autoOnline.effectiveSettings.model)

        val autoOffline = baseOnDevice.resolveEffectiveRoute(isOnline = false)
        assertTrue(autoOffline.isUsingLocal)
        assertTrue(autoOffline.isUsingEmbeddedRuntime)
        assertNull(autoOffline.issue)
        assertEquals("Gemma 3 4B Instruct (Q4_K_M)", autoOffline.effectiveSettings.model)
        assertEquals("", autoOffline.effectiveSettings.customBaseUrl)

        val apiOnlyOffline = baseOnDevice.copy(routingMode = AiRoutingMode.ONLY_API_KEY).resolveEffectiveRoute(isOnline = false)
        assertFalse(apiOnlyOffline.isUsingLocal)
        assertEquals(AiRouteIssue.OFFLINE_API_ONLY, apiOnlyOffline.issue)

        val localOnlyOnline = baseOnDevice.copy(routingMode = AiRoutingMode.ONLY_LOCAL).resolveEffectiveRoute(isOnline = true)
        assertTrue(localOnlyOnline.isUsingLocal)
        assertTrue(localOnlyOnline.isUsingEmbeddedRuntime)
        assertNull(localOnlyOnline.issue)
        assertTrue(localOnlyOnline.routeBadge.contains("Local • On-device"))

        val unconfiguredOnDevice = baseOnDevice.copy(
            routingMode = AiRoutingMode.ONLY_LOCAL,
            defaultDownloadedTextModelId = null,
            defaultDownloadedTextModelPath = ""
        ).resolveEffectiveRoute(isOnline = true)
        assertTrue(unconfiguredOnDevice.isUsingEmbeddedRuntime)
        assertEquals(AiRouteIssue.MISSING_LOCAL_CONFIG, unconfiguredOnDevice.issue)

        val externalServer = baseOnDevice.copy(
            routingMode = AiRoutingMode.ONLY_LOCAL,
            localUseExternalServer = true,
            localEndpointUrl = "http://127.0.0.1:8080/v1",
            localModelName = "gemma3:4b"
        ).resolveEffectiveRoute(isOnline = false)
        assertTrue(externalServer.isUsingLocal)
        assertFalse(externalServer.isUsingEmbeddedRuntime)
        assertNull(externalServer.issue)
        assertEquals("gemma3:4b", externalServer.effectiveSettings.model)
        assertEquals("http://127.0.0.1:8080/v1", externalServer.effectiveSettings.customBaseUrl)
    }

    @Test
    fun `security scanner detects high risk sideloaded apps and masquerading apks while trusting play store apps`() {
        val cleanPlayApp = SecurityScanner.evaluateAppRisk(
            packageName = "com.example.notes",
            appName = "Clean Notes",
            requestedPermissions = listOf("android.permission.INTERNET"),
            isSystemApp = false,
            isDebuggable = false,
            installerPackage = "com.android.vending"
        )
        assertNull(cleanPlayApp)

        val maliciousApp = SecurityScanner.evaluateAppRisk(
            packageName = "com.bad.trojan",
            appName = "Free Update",
            requestedPermissions = listOf(
                "android.permission.RECEIVE_SMS",
                "android.permission.REQUEST_INSTALL_PACKAGES"
            ),
            isSystemApp = false,
            isDebuggable = false,
            installerPackage = null
        )
        assertNotNull(maliciousApp)
        assertEquals(SecuritySeverity.HIGH, maliciousApp?.severity)

        val masqueradeApk = SecurityScanner.evaluateFileRisk(
            fileName = "invoice.pdf.apk",
            extension = "apk",
            mimeType = "application/vnd.android.package-archive",
            sizeBytes = 409600L,
            displayPath = "Downloads/invoice.pdf.apk",
            uriString = "content://downloads/1"
        )
        assertNotNull(masqueradeApk)
        assertEquals(SecuritySeverity.HIGH, masqueradeApk?.severity)

        // Safe OEM store, Xiaomi PackageInstaller, restored app (null installer) with normal perms must NOT be flagged
        assertNull(
            SecurityScanner.evaluateAppRisk(
                packageName = "com.example.shop",
                appName = "Shop App",
                requestedPermissions = listOf("android.permission.INTERNET", "android.permission.CAMERA"),
                isSystemApp = false,
                isDebuggable = false,
                installerPackage = "com.xiaomi.mipicks"
            )
        )
        assertNull(
            SecurityScanner.evaluateAppRisk(
                packageName = "com.whatsapp",
                appName = "WhatsApp",
                requestedPermissions = listOf(
                    "android.permission.INTERNET",
                    "android.permission.CAMERA",
                    "android.permission.RECORD_AUDIO",
                    "android.permission.SYSTEM_ALERT_WINDOW"
                ),
                isSystemApp = false,
                isDebuggable = false,
                installerPackage = null
            )
        )
        assertNull(
            SecurityScanner.evaluateAppRisk(
                packageName = "com.spotify.music",
                appName = "Spotify",
                requestedPermissions = listOf("android.permission.INTERNET", "android.permission.SYSTEM_ALERT_WINDOW"),
                isSystemApp = false,
                isDebuggable = false,
                installerPackage = "com.miui.packageinstaller"
            )
        )
    }

    @Test
    fun `silent wake detector encodes decodes templates and separates matching tones from silence or mismatched tones`() {
        val sampleRate = SilentWakeDetector.SAMPLE_RATE
        fun synthSine(freqHz: Double, samples: Int, amp: Double = 14000.0): ShortArray =
            ShortArray(samples) { i ->
                (kotlin.math.sin(2.0 * kotlin.math.PI * freqHz * i / sampleRate) * amp).toInt().toShort()
            }

        val utteranceA = synthSine(440.0, 9600) // ~0.6s 440Hz tone
        val utteranceASlightlyFaster = synthSine(445.0, 8200)
        val utteranceDifferent = synthSine(2600.0, 9600) // very different spectral band

        val framesA = SilentWakeDetector.extractFramesFromPcm(utteranceA)
        val framesB = SilentWakeDetector.extractFramesFromPcm(utteranceASlightlyFaster)
        val framesDiff = SilentWakeDetector.extractFramesFromPcm(utteranceDifferent)

        assertTrue(framesA.size >= 15)
        val template = WakeVoiceTemplate(phrase = "Nova", frames = framesA)
        val encoded = SilentWakeDetector.encodeTemplate(template)
        val decoded = SilentWakeDetector.decodeTemplate(encoded)
        assertNotNull(decoded)
        assertEquals("Nova", decoded?.phrase)
        assertEquals(framesA.size, decoded?.frames?.size)

        assertTrue(SilentWakeDetector.matchesTemplate(framesB, decoded!!))
        assertFalse(SilentWakeDetector.matchesTemplate(framesDiff, decoded))
    }

    @Test
    fun `pattern repository encodes and decodes multi step routines cleanly`() {
        val steps = listOf(
            PatternStep(action = "open_app", target = "Chrome"),
            PatternStep(action = "type_text", target = "Search", value = "news", delayMs = 400L),
            PatternStep(action = "tap_coordinates", target = "540,1200")
        )
        val encoded = PatternRepository.encodeSteps(steps)
        val decoded = PatternRepository.decodeSteps(encoded)
        assertEquals(3, decoded.size)
        assertEquals("open_app", decoded[0].action)
        assertEquals("Chrome", decoded[0].target)
        assertEquals("type_text", decoded[1].action)
        assertEquals("news", decoded[1].value)
        assertEquals("540,1200", decoded[2].target)
    }
}
