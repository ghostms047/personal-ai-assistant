package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.db.AppDatabase
import com.example.data.db.IndexedFileEntity
import com.example.data.security.KeystoreCryptoManager
import com.example.data.settings.SettingsRepository
import com.example.files.FileIndexer
import com.example.files.NaturalLanguageFileSearch
import com.example.memory.MemoryRepository
import com.example.tools.ToolExecutionOutcome
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class PersonalAiCoreTest {

    private lateinit var context: Context
    private lateinit var db: AppDatabase

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `natural language file search parses type, date, and matches indexed files`() = runTest {
        val now = System.currentTimeMillis()
        val twoDaysAgo = now - 2L * 86_400_000L
        val fortyDaysAgo = now - 40L * 86_400_000L

        db.indexedFileDao().upsertAll(
            listOf(
                IndexedFileEntity(
                    uriString = "content://test/magic_wand.zip",
                    name = "magic-wand-project.zip",
                    displayPath = "Projects/magic-wand-project.zip",
                    folderName = "Projects",
                    extension = "zip",
                    mimeType = "application/zip",
                    sizeBytes = 20480L,
                    createdAt = twoDaysAgo,
                    modifiedAt = twoDaysAgo,
                    category = FileIndexer.CATEGORY_ARCHIVE,
                    extractedText = "",
                    sourceType = "SAF",
                    lastIndexedAt = now
                ),
                IndexedFileEntity(
                    uriString = "content://test/school_report.pdf",
                    name = "biology_notes.pdf",
                    displayPath = "School/biology_notes.pdf",
                    folderName = "School",
                    extension = "pdf",
                    mimeType = "application/pdf",
                    sizeBytes = 51200L,
                    createdAt = fortyDaysAgo,
                    modifiedAt = fortyDaysAgo,
                    category = FileIndexer.CATEGORY_DOCUMENT,
                    extractedText = "School project summary about photosynthesis",
                    sourceType = "SAF",
                    lastIndexedAt = now
                )
            )
        )

        val search = NaturalLanguageFileSearch(db.indexedFileDao())
        val zipRes = search.search("Show ZIP files modified this week")
        assertEquals(1, zipRes.files.size)
        assertEquals("magic-wand-project.zip", zipRes.files.first().name)

        val pdfRes = search.search("Find the PDF about my school project")
        assertTrue(pdfRes.files.any { it.name == "biology_notes.pdf" })
    }

    @Test
    fun `tool registry blocks unknown tools and unsafe shell payloads`() = runTest {
        val app = context as PersonalAiApp
        val registry = app.container.toolRegistry

        val unknownOutcome = registry.execute("exec_shell", "{}")
        assertTrue(unknownOutcome is ToolExecutionOutcome.Executed)
        assertFalse((unknownOutcome as ToolExecutionOutcome.Executed).success)

        val unsafeOutcome = registry.execute(
            "search_files",
            """{"query": "/system/bin/sh -c rm -rf"}"""
        )
        assertTrue(unsafeOutcome is ToolExecutionOutcome.Executed)
        assertFalse((unsafeOutcome as ToolExecutionOutcome.Executed).success)

        val askOutcome = registry.execute(
            "ask_user",
            """{"question": "Which file?", "options": [{"label": "a.zip", "value": "Open a.zip"}]}"""
        )
        assertTrue(askOutcome is ToolExecutionOutcome.Executed)
        val executed = askOutcome as ToolExecutionOutcome.Executed
        assertEquals("Which file?", executed.askUserQuestion)
        assertEquals(1, executed.askUserOptions.size)
    }

    @Test
    fun `memory repository blocks secrets and stores valid user preferences`() = runTest {
        val settingsRepo = SettingsRepository(context, KeystoreCryptoManager())
        val memoryRepo = MemoryRepository(db.memoryDao(), settingsRepo)

        val rejected = memoryRepo.saveMemory("My API key is sk-1234567890abcdef")
        assertFalse(rejected)

        val saved = memoryRepo.saveMemory("Prefer Firefox as my default browser", "Browser")
        assertTrue(saved)

        val promptContext = memoryRepo.getPromptContext()
        assertNotNull(promptContext)
        assertTrue(promptContext.contains("Prefer Firefox"))
    }

    @Test
    fun `universal ai settings format auth headers for any company or custom provider`() {
        val openai = com.example.data.settings.AiSettings(
            provider = com.example.data.settings.AiProviderType.OPENAI,
            apiKey = "sk-any-format-123"
        )
        assertEquals("Authorization", openai.effectiveAuthHeaderName)
        assertEquals("Bearer sk-any-format-123", openai.buildAuthHeaderValue())

        val azure = com.example.data.settings.AiSettings(
            provider = com.example.data.settings.AiProviderType.AZURE_OPENAI,
            apiKey = "azure_raw_key_xyz"
        )
        assertEquals("api-key", azure.effectiveAuthHeaderName)
        assertEquals("azure_raw_key_xyz", azure.buildAuthHeaderValue())

        val custom = com.example.data.settings.AiSettings(
            provider = com.example.data.settings.AiProviderType.CUSTOM,
            customProviderLabel = "Acme AI",
            apiKey = "Bearer already_prefixed",
            authHeaderName = "X-Acme-Token",
            authHeaderPrefix = "Bearer "
        )
        assertEquals("Acme AI", custom.effectiveDisplayName)
        assertEquals("X-Acme-Token", custom.effectiveAuthHeaderName)
        assertEquals("Bearer already_prefixed", custom.buildAuthHeaderValue())
    }

    @Test
    fun `model catalog parses openai gemini anthropic models and caches in room`() = runTest {
        val service = com.example.ai.ModelCatalogService(db.cachedProviderModelDao())

        val openAiJson = """
            {"data":[
              {"id":"gpt-4o-mini"},
              {"id":"tts-1"},
              {"id":"whisper-1"},
              {"id":"text-embedding-3-small"}
            ]}
        """.trimIndent()
        val parsedOpenAi = service.parseModelsResponse(
            providerId = "openai",
            protocol = com.example.data.settings.AiApiProtocol.OPENAI_COMPATIBLE,
            rawBody = openAiJson
        )
        assertEquals(4, parsedOpenAi.size)
        assertEquals(
            com.example.ai.ModelCatalogService.CAP_SPEECH_TTS,
            parsedOpenAi.first { it.modelId == "tts-1" }.capability
        )
        assertEquals(
            com.example.ai.ModelCatalogService.CAP_SPEECH_STT,
            parsedOpenAi.first { it.modelId == "whisper-1" }.capability
        )
        assertEquals(
            com.example.ai.ModelCatalogService.CAP_EMBEDDING,
            parsedOpenAi.first { it.modelId == "text-embedding-3-small" }.capability
        )

        db.cachedProviderModelDao().upsertAll(parsedOpenAi)
        val geminiJson = """
            {"models":[
              {"name":"models/gemini-2.5-flash","displayName":"Gemini 2.5 Flash","supportedGenerationMethods":["generateContent"]}
            ]}
        """.trimIndent()
        val parsedGemini = service.parseModelsResponse(
            providerId = "gemini",
            protocol = com.example.data.settings.AiApiProtocol.GEMINI,
            rawBody = geminiJson
        )
        assertEquals(1, parsedGemini.size)
        assertEquals("gemini-2.5-flash", parsedGemini.first().modelId)
    }

    @Test
    fun `model download manager validates urls and sanitizes filenames`() {
        assertEquals(
            "https://huggingface.co/model.gguf",
            com.example.ai.ModelDownloadManager.validateDownloadUrl("  https://huggingface.co/model.gguf  ")
        )
        assertEquals(
            null,
            com.example.ai.ModelDownloadManager.validateDownloadUrl("file:///etc/passwd")
        )
        assertEquals(
            null,
            com.example.ai.ModelDownloadManager.validateDownloadUrl("content://media/external/file/1")
        )
        assertEquals(
            null,
            com.example.ai.ModelDownloadManager.validateDownloadUrl("javascript:alert(1)")
        )
        assertEquals(
            "safe_model.bin",
            com.example.ai.ModelDownloadManager.sanitizeFileName("../../safe model.bin")
        )
    }

    @Test
    fun `speech settings persist tts stt modes and encrypted speech key`() = runTest {
        val repo = SettingsRepository(context, KeystoreCryptoManager())
        val updated = com.example.data.settings.SpeechSettings(
            ttsEngine = com.example.data.settings.TtsEngineMode.CLOUD_TTS,
            sttEngine = com.example.data.settings.SttEngineMode.CLOUD_WHISPER,
            autoSpeakResponses = true,
            cloudTtsModel = "tts-1-hd",
            cloudTtsVoice = "nova",
            cloudSttModel = "whisper-large-v3-turbo",
            cloudSpeechBaseUrl = "https://api.groq.com/openai/v1"
        )
        repo.saveSpeechSettings(updated, newCloudSpeechApiKey = "gsk_speech_test_999")
        val loaded = repo.speechSettingsFlow.first()
        assertEquals(com.example.data.settings.TtsEngineMode.CLOUD_TTS, loaded.ttsEngine)
        assertEquals(com.example.data.settings.SttEngineMode.CLOUD_WHISPER, loaded.sttEngine)
        assertTrue(loaded.autoSpeakResponses)
        assertEquals("nova", loaded.cloudTtsVoice)
        assertEquals("whisper-large-v3-turbo", loaded.cloudSttModel)
        assertEquals("https://api.groq.com/openai/v1", loaded.cloudSpeechBaseUrl)
    }
}
