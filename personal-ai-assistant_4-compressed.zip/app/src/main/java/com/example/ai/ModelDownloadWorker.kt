package com.example.ai

import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.StatFs
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.PersonalAiApp
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class ModelDownloadWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val modelId = inputData.getLong(KEY_MODEL_ID, -1L)
        if (modelId <= 0L) return Result.failure()

        val container = (applicationContext as? PersonalAiApp)?.container ?: return Result.failure()
        val dao = container.database.downloadedModelDao()
        val initialEntity = dao.getById(modelId) ?: return Result.failure()

        try {
            setForeground(createForegroundInfo(initialEntity.name))
        } catch (_: Exception) {
            // Notification permission may be denied; continue background download safely
        }

        val modelsDir = File(applicationContext.filesDir, "models").apply { mkdirs() }
        val safeName = ModelDownloadManager.sanitizeFileName(initialEntity.fileName)
        val partFile = File(modelsDir, "$safeName.part")
        val finalFile = File(modelsDir, safeName)

        var existingPartBytes = if (partFile.exists()) partFile.length().coerceAtLeast(0L) else 0L

        dao.upsert(
            initialEntity.copy(
                status = ModelDownloadManager.STATUS_DOWNLOADING,
                downloadedBytes = existingPartBytes,
                errorMessage = null,
                updatedAt = System.currentTimeMillis()
            )
        )

        val client = OkHttpClient.Builder()
            .connectTimeout(25, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()

        return try {
            val reqBuilder = Request.Builder()
                .url(initialEntity.downloadUrl)
                .get()
            if (existingPartBytes > 0L) {
                reqBuilder.addHeader("Range", "bytes=$existingPartBytes-")
            }

            client.newCall(reqBuilder.build()).execute().use { response ->
                // 416 Range Not Satisfiable can mean file is already completely downloaded in .part
                if (response.code == 416 && existingPartBytes > 0L) {
                    val contentRangeTotal = parseContentRangeTotal(response.header("Content-Range"))
                    if (contentRangeTotal > 0L && existingPartBytes >= contentRangeTotal) {
                        if (finalFile.exists()) finalFile.delete()
                        if (!partFile.renameTo(finalFile)) {
                            partFile.copyTo(finalFile, overwrite = true)
                            partFile.delete()
                        }
                        val downloadedEntity = initialEntity.copy(
                            localPath = finalFile.absolutePath,
                            totalBytes = contentRangeTotal,
                            downloadedBytes = existingPartBytes,
                            status = ModelDownloadManager.STATUS_DOWNLOADED,
                            errorMessage = null,
                            updatedAt = System.currentTimeMillis()
                        )
                        dao.upsert(downloadedEntity)
                        container.modelDownloadManager.verifyModelEntity(downloadedEntity)
                        return Result.success()
                    }
                    // Otherwise .part offset was invalid; clean up and require clean retry
                    partFile.delete()
                    dao.upsert(
                        initialEntity.copy(
                            status = ModelDownloadManager.STATUS_ERROR,
                            downloadedBytes = 0L,
                            errorMessage = "Resume offset mismatch (HTTP 416). Tap Redownload.",
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    return Result.failure()
                }

                if (!response.isSuccessful) {
                    dao.upsert(
                        initialEntity.copy(
                            status = if (existingPartBytes > 0L) ModelDownloadManager.STATUS_PAUSED else ModelDownloadManager.STATUS_ERROR,
                            downloadedBytes = existingPartBytes,
                            errorMessage = "Server returned HTTP ${response.code}",
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    return Result.failure()
                }

                val isPartialAppend = response.code == 206 && existingPartBytes > 0L
                val body = response.body ?: run {
                    dao.upsert(
                        initialEntity.copy(
                            status = ModelDownloadManager.STATUS_ERROR,
                            errorMessage = "Empty HTTP response body.",
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    return Result.failure()
                }

                val remainingContentLen = body.contentLength().coerceAtLeast(-1L)
                val contentRangeTotal = parseContentRangeTotal(response.header("Content-Range"))
                val totalBytes = when {
                    contentRangeTotal > 0L -> contentRangeTotal
                    isPartialAppend && remainingContentLen > 0L -> existingPartBytes + remainingContentLen
                    !isPartialAppend && remainingContentLen > 0L -> remainingContentLen
                    initialEntity.expectedBytes > 0L -> initialEntity.expectedBytes
                    else -> initialEntity.totalBytes
                }

                if (!isPartialAppend) {
                    existingPartBytes = 0L
                }

                // Check disk headroom before streaming gigabytes
                val remainingToWrite = if (totalBytes > existingPartBytes) totalBytes - existingPartBytes else 0L
                val availDisk = runCatching { StatFs(modelsDir.path).availableBytes }.getOrDefault(0L)
                if (availDisk > 0L && remainingToWrite > 0L && availDisk < remainingToWrite + ModelDownloadManager.MIN_STORAGE_RESERVE_BYTES) {
                    val availGb = String.format("%.2f", availDisk / (1024.0 * 1024.0 * 1024.0))
                    val needGb = String.format("%.2f", (remainingToWrite + ModelDownloadManager.MIN_STORAGE_RESERVE_BYTES) / (1024.0 * 1024.0 * 1024.0))
                    dao.upsert(
                        initialEntity.copy(
                            status = ModelDownloadManager.STATUS_ERROR,
                            totalBytes = totalBytes,
                            downloadedBytes = existingPartBytes,
                            errorMessage = "Insufficient storage ($availGb GB free, need ~${needGb} GB).",
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    return Result.failure()
                }

                var downloaded = existingPartBytes
                var lastEmit = 0L
                val buffer = ByteArray(32 * 1024)

                body.byteStream().use { input ->
                    FileOutputStream(partFile, isPartialAppend).use { output ->
                        while (true) {
                            if (isStopped) {
                                output.flush()
                                val latest = dao.getById(modelId)
                                val currentStatus = latest?.status
                                if (currentStatus == ModelDownloadManager.STATUS_NOT_DOWNLOADED) {
                                    // User explicitly cancelled & cleared
                                    partFile.delete()
                                } else {
                                    // Paused by user or stopped by OS -> preserve .part for resume
                                    dao.upsert(
                                        (latest ?: initialEntity).copy(
                                            status = ModelDownloadManager.STATUS_PAUSED,
                                            totalBytes = totalBytes,
                                            downloadedBytes = downloaded,
                                            errorMessage = if (currentStatus == ModelDownloadManager.STATUS_PAUSED) null else "Download paused.",
                                            updatedAt = System.currentTimeMillis()
                                        )
                                    )
                                }
                                return Result.failure()
                            }

                            val read = input.read(buffer)
                            if (read == -1) break
                            output.write(buffer, 0, read)
                            downloaded += read

                            val now = System.currentTimeMillis()
                            if (now - lastEmit >= 350L) {
                                lastEmit = now
                                val latest = dao.getById(modelId)
                                if (latest?.status == ModelDownloadManager.STATUS_PAUSED ||
                                    latest?.status == ModelDownloadManager.STATUS_NOT_DOWNLOADED
                                ) {
                                    output.flush()
                                    if (latest.status == ModelDownloadManager.STATUS_NOT_DOWNLOADED) {
                                        partFile.delete()
                                    } else {
                                        dao.upsert(
                                            latest.copy(
                                                totalBytes = totalBytes,
                                                downloadedBytes = downloaded,
                                                updatedAt = now
                                            )
                                        )
                                    }
                                    return Result.failure()
                                }
                                dao.upsert(
                                    (latest ?: initialEntity).copy(
                                        status = ModelDownloadManager.STATUS_DOWNLOADING,
                                        totalBytes = totalBytes,
                                        downloadedBytes = downloaded,
                                        updatedAt = now
                                    )
                                )
                            }
                        }
                        output.flush()
                    }
                }

                // Confirm download completeness before promoting .part -> final file
                if (totalBytes > 0L && downloaded < totalBytes) {
                    dao.upsert(
                        initialEntity.copy(
                            status = ModelDownloadManager.STATUS_PAUSED,
                            totalBytes = totalBytes,
                            downloadedBytes = downloaded,
                            errorMessage = "Incomplete download ($downloaded / $totalBytes bytes). Tap Resume.",
                            updatedAt = System.currentTimeMillis()
                        )
                    )
                    return Result.failure()
                }

                if (finalFile.exists()) finalFile.delete()
                if (!partFile.renameTo(finalFile)) {
                    partFile.copyTo(finalFile, overwrite = true)
                    partFile.delete()
                }

                val downloadedRow = (dao.getById(modelId) ?: initialEntity).copy(
                    localPath = finalFile.absolutePath,
                    totalBytes = if (totalBytes > 0L) totalBytes else downloaded,
                    downloadedBytes = downloaded,
                    status = ModelDownloadManager.STATUS_DOWNLOADED,
                    errorMessage = null,
                    updatedAt = System.currentTimeMillis()
                )
                dao.upsert(downloadedRow)

                val verified = container.modelDownloadManager.verifyModelEntity(downloadedRow)
                if (verified.status == ModelDownloadManager.STATUS_READY) {
                    Result.success()
                } else {
                    Result.failure()
                }
            }
        } catch (e: Exception) {
            // Preserve .part file on transient network interruptions so user can resume instead of losing GBs!
            val partLen = if (partFile.exists()) partFile.length().coerceAtLeast(0L) else 0L
            dao.upsert(
                (dao.getById(modelId) ?: initialEntity).copy(
                    status = if (partLen > 0L) ModelDownloadManager.STATUS_PAUSED else ModelDownloadManager.STATUS_ERROR,
                    downloadedBytes = partLen,
                    errorMessage = e.localizedMessage ?: "Download interrupted",
                    updatedAt = System.currentTimeMillis()
                )
            )
            Result.failure()
        }
    }

    private fun createForegroundInfo(modelName: String): ForegroundInfo {
        val nm = NotificationManagerCompat.from(applicationContext)
        val channel = NotificationChannelCompat.Builder(
            CHANNEL_ID,
            NotificationManagerCompat.IMPORTANCE_LOW
        )
            .setName("Model Downloads")
            .build()
        nm.createNotificationChannel(channel)

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setContentTitle("Downloading AI Model")
            .setContentText(modelName)
            .setSmallIcon(com.example.R.mipmap.ic_launcher)
            .setOngoing(true)
            .setSilent(true)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    companion object {
        private const val KEY_MODEL_ID = "model_id"
        private const val CHANNEL_ID = "personal_ai_model_downloads"
        private const val NOTIFICATION_ID = 4103

        fun workNameFor(id: Long): String = "personal_ai_model_dl_$id"

        fun parseContentRangeTotal(header: String?): Long {
            if (header.isNullOrBlank()) return -1L
            val slashPart = header.substringAfterLast('/', "").trim()
            return slashPart.toLongOrNull() ?: -1L
        }

        fun isWorkEnqueuedOrRunning(context: Context, modelId: Long): Boolean {
            return runCatching {
                val infos = WorkManager.getInstance(context)
                    .getWorkInfosForUniqueWork(workNameFor(modelId))
                    .get()
                infos.any { it.state == WorkInfo.State.RUNNING || it.state == WorkInfo.State.ENQUEUED }
            }.getOrDefault(false)
        }

        fun enqueue(context: Context, modelId: Long) {
            val request = OneTimeWorkRequestBuilder<ModelDownloadWorker>()
                .setInputData(workDataOf(KEY_MODEL_ID to modelId))
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                workNameFor(modelId),
                ExistingWorkPolicy.KEEP,
                request
            )
        }

        fun cancel(context: Context, modelId: Long) {
            WorkManager.getInstance(context).cancelUniqueWork(workNameFor(modelId))
        }
    }
}
