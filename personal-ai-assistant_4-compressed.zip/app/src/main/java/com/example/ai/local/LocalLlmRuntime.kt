package com.example.ai.local

import android.content.Context
import com.example.ai.AiMessage
import com.example.ai.AiRole
import com.example.ai.DeviceRamInfo
import com.example.ai.ModelDownloadManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

enum class LocalRuntimeStatus {
    NOT_LOADED,
    LOADING,
    LOADED,
    ERROR
}

data class LocalRuntimeState(
    val status: LocalRuntimeStatus = LocalRuntimeStatus.NOT_LOADED,
    val loadedModelId: Long? = null,
    val loadedModelPath: String = "",
    val loadedModelName: String = "",
    val architecture: String = "",
    val quantization: String = "",
    val contextLength: Int = 0,
    val statusNote: String = "",
    val errorMessage: String? = null
)

class LocalLlmRuntime(
    private val context: Context,
    private val bridge: LlamaBridge = NativeLlamaBridge,
    private val ramInfoProvider: () -> DeviceRamInfo = { ModelDownloadManager.readDeviceRamInfo(context) }
) {
    private val runtimeMutex = Mutex()
    private var activeHandle: Long = 0L
    private var activeMetadata: GgufMetadata? = null

    private val _state = MutableStateFlow(LocalRuntimeState())
    val state: StateFlow<LocalRuntimeState> = _state.asStateFlow()

    fun isModelLoadedOrLoading(modelId: Long?, modelPath: String?): Boolean {
        val s = _state.value
        if (s.status != LocalRuntimeStatus.LOADING && s.status != LocalRuntimeStatus.LOADED) {
            return false
        }
        if (modelId != null && s.loadedModelId != null && s.loadedModelId == modelId) return true
        if (!modelPath.isNullOrBlank() && s.loadedModelPath == modelPath) return true
        return false
    }

    suspend fun loadModel(
        modelId: Long?,
        modelPath: String,
        displayName: String,
        onStatusChanged: (suspend (LocalRuntimeStatus, String?) -> Unit)? = null
    ): Result<LocalRuntimeState> = runtimeMutex.withLock {
        val current = _state.value
        if (current.status == LocalRuntimeStatus.LOADED &&
            current.loadedModelPath == modelPath &&
            activeHandle != 0L
        ) {
            return@withLock Result.success(current)
        }

        if (!bridge.isSupportedAbi()) {
            val msg = "On-device inference requires arm64-v8a CPU architecture (device ABIs: ${bridge.supportedAbisSummary()})."
            _state.value = LocalRuntimeState(
                status = LocalRuntimeStatus.ERROR,
                loadedModelId = modelId,
                loadedModelPath = modelPath,
                loadedModelName = displayName,
                errorMessage = msg
            )
            onStatusChanged?.invoke(LocalRuntimeStatus.ERROR, msg)
            return@withLock Result.failure(IllegalStateException(msg))
        }

        val file = File(modelPath)
        if (!file.exists() || !file.isFile || file.length() <= 0L) {
            val msg = "Model file not found on device. Redownload the model first."
            _state.value = LocalRuntimeState(
                status = LocalRuntimeStatus.ERROR,
                loadedModelId = modelId,
                loadedModelPath = modelPath,
                loadedModelName = displayName,
                errorMessage = msg
            )
            onStatusChanged?.invoke(LocalRuntimeStatus.ERROR, msg)
            return@withLock Result.failure(IllegalStateException(msg))
        }

        _state.value = LocalRuntimeState(
            status = LocalRuntimeStatus.LOADING,
            loadedModelId = modelId,
            loadedModelPath = modelPath,
            loadedModelName = displayName,
            statusNote = "Validating GGUF & RAM…"
        )
        onStatusChanged?.invoke(LocalRuntimeStatus.LOADING, null)

        val ramInfo = ramInfoProvider()
        val parsed = withContext(Dispatchers.IO) { GgufMetadataParser.parse(file) }
        if (parsed is GgufParseResult.Invalid) {
            val msg = "Invalid GGUF model: ${parsed.reason}"
            _state.value = LocalRuntimeState(
                status = LocalRuntimeStatus.ERROR,
                loadedModelId = modelId,
                loadedModelPath = modelPath,
                loadedModelName = displayName,
                errorMessage = msg
            )
            onStatusChanged?.invoke(LocalRuntimeStatus.ERROR, msg)
            return@withLock Result.failure(IllegalStateException(msg))
        }

        val meta = (parsed as GgufParseResult.Valid).metadata
        val compat = GgufMetadataParser.checkCompatibility(
            metadata = meta,
            fileName = file.name,
            modelFileBytes = file.length(),
            totalDeviceRamBytes = ramInfo.totalBytes
        )
        if (!compat.compatible) {
            val userMsg = if (compat.summary.contains("RAM", ignoreCase = true)) {
                LOW_RAM_ERROR_FA
            } else {
                compat.summary
            }
            _state.value = LocalRuntimeState(
                status = LocalRuntimeStatus.ERROR,
                loadedModelId = modelId,
                loadedModelPath = modelPath,
                loadedModelName = displayName,
                architecture = meta.architecture,
                quantization = meta.quantizationLabel,
                errorMessage = userMsg
            )
            onStatusChanged?.invoke(LocalRuntimeStatus.ERROR, userMsg)
            return@withLock Result.failure(IllegalStateException(userMsg))
        }

        // Preflight check against current free RAM so Android LMK doesn't hard-kill the process.
        val minFreeNeedBytes = (file.length() * 0.72).toLong() + 260L * 1024L * 1024L
        if (ramInfo.availableBytes > 0L && ramInfo.availableBytes < minFreeNeedBytes) {
            val availMb = ramInfo.availableBytes / (1024L * 1024L)
            val needMb = minFreeNeedBytes / (1024L * 1024L)
            val msg = "$LOW_RAM_ERROR_FA (آزاد: ${availMb} MB، نیاز تقریبی: ${needMb} MB)"
            _state.value = LocalRuntimeState(
                status = LocalRuntimeStatus.ERROR,
                loadedModelId = modelId,
                loadedModelPath = modelPath,
                loadedModelName = displayName,
                architecture = meta.architecture,
                quantization = meta.quantizationLabel,
                errorMessage = msg
            )
            onStatusChanged?.invoke(LocalRuntimeStatus.ERROR, msg)
            return@withLock Result.failure(IllegalStateException(msg))
        }

        if (!bridge.isNativeLibraryAvailable()) {
            val msg = "Embedded llama.cpp native library is unavailable: ${bridge.loadError() ?: "unknown error"}"
            _state.value = LocalRuntimeState(
                status = LocalRuntimeStatus.ERROR,
                loadedModelId = modelId,
                loadedModelPath = modelPath,
                loadedModelName = displayName,
                errorMessage = msg
            )
            onStatusChanged?.invoke(LocalRuntimeStatus.ERROR, msg)
            return@withLock Result.failure(IllegalStateException(msg))
        }

        // Unload any previously loaded model cleanly before allocating another KV cache.
        unloadInternalLocked()

        val cpuCores = Runtime.getRuntime().availableProcessors().coerceAtLeast(2)
        val nThreads = (cpuCores / 2).coerceIn(2, 4)
        val nCtx = compat.recommendedContextLength.coerceIn(512, 4096)
        val nBatch = if (ramInfo.totalBytes in 1L..5_000_000_000L) 128 else 256

        val handle = withContext(Dispatchers.IO) {
            bridge.loadModel(modelPath, nCtx, nThreads, nBatch)
        }

        if (handle == 0L) {
            val nativeErr = bridge.getLastError()
            val msg = if (nativeErr.contains("alloc", ignoreCase = true) ||
                nativeErr.contains("memory", ignoreCase = true) ||
                nativeErr.contains("ram", ignoreCase = true)
            ) {
                "$LOW_RAM_ERROR_FA (${nativeErr.take(120)})"
            } else {
                "Failed to load GGUF model on-device: ${nativeErr.ifBlank { "check file integrity and free RAM." }}"
            }
            _state.value = LocalRuntimeState(
                status = LocalRuntimeStatus.ERROR,
                loadedModelId = modelId,
                loadedModelPath = modelPath,
                loadedModelName = displayName,
                architecture = meta.architecture,
                quantization = meta.quantizationLabel,
                errorMessage = msg
            )
            onStatusChanged?.invoke(LocalRuntimeStatus.ERROR, msg)
            return@withLock Result.failure(IllegalStateException(msg))
        }

        activeHandle = handle
        activeMetadata = meta
        val readyState = LocalRuntimeState(
            status = LocalRuntimeStatus.LOADED,
            loadedModelId = modelId,
            loadedModelPath = modelPath,
            loadedModelName = displayName,
            architecture = meta.architecture,
            quantization = meta.quantizationLabel,
            contextLength = nCtx,
            statusNote = compat.summary
        )
        _state.value = readyState
        onStatusChanged?.invoke(LocalRuntimeStatus.LOADED, null)
        Result.success(readyState)
    }

    suspend fun unloadModel(): Unit = runtimeMutex.withLock {
        unloadInternalLocked()
        _state.value = LocalRuntimeState(status = LocalRuntimeStatus.NOT_LOADED)
    }

    fun requestStop() {
        val h = activeHandle
        if (h != 0L) {
            bridge.requestStop(h)
        }
    }

    suspend fun generateChatCompletion(
        modelId: Long?,
        modelPath: String,
        displayName: String,
        systemPrompt: String,
        messages: List<AiMessage>,
        temperature: Float,
        maxTokens: Int = 768,
        onToken: ((String) -> Unit)? = null,
        onModelStatusUpdate: (suspend (LocalRuntimeStatus, String?) -> Unit)? = null
    ): Result<String> {
        val loaded = _state.value
        if (loaded.status != LocalRuntimeStatus.LOADED ||
            loaded.loadedModelPath != modelPath ||
            activeHandle == 0L
        ) {
            val loadRes = loadModel(modelId, modelPath, displayName, onModelStatusUpdate)
            if (loadRes.isFailure) {
                return Result.failure(loadRes.exceptionOrNull() ?: IllegalStateException("Could not load local model."))
            }
        }

        return runtimeMutex.withLock {
            val handle = activeHandle
            if (handle == 0L) {
                return@withLock Result.failure(IllegalStateException("Local model runtime is not loaded."))
            }

            val prompt = formatPrompt(
                handle = handle,
                architecture = activeMetadata?.architecture.orEmpty(),
                systemPrompt = systemPrompt,
                messages = messages
            )

            val output = withContext(Dispatchers.IO) {
                bridge.generate(
                    handle = handle,
                    prompt = prompt,
                    maxTokens = maxTokens,
                    temperature = temperature,
                    callback = onToken?.let { cb -> NativeLlamaBridge.TokenCallback { piece -> cb(piece) } }
                )
            }

            if (output.isBlank()) {
                val nativeErr = bridge.getLastError()
                if (nativeErr.isNotBlank()) {
                    return@withLock Result.failure(
                        IllegalStateException("On-device inference error: $nativeErr")
                    )
                }
            }
            Result.success(output.trim())
        }
    }

    private suspend fun unloadInternalLocked() {
        val h = activeHandle
        activeHandle = 0L
        activeMetadata = null
        if (h != 0L) {
            withContext(Dispatchers.IO) {
                bridge.unloadModel(h)
            }
        }
    }

    private fun formatPrompt(
        handle: Long,
        architecture: String,
        systemPrompt: String,
        messages: List<AiMessage>
    ): String {
        val nativePairs = buildNativeRoleMessagePairs(architecture, systemPrompt, messages)
        val roles = nativePairs.map { it.first }.toTypedArray()
        val contents = nativePairs.map { it.second }.toTypedArray()
        val templated = bridge.applyChatTemplate(handle, roles, contents, addAssistant = true)
        if (!templated.isNullOrBlank()) {
            return templated
        }
        return formatFallbackPrompt(architecture, nativePairs)
    }

    companion object {
        const val LOW_RAM_ERROR_FA = "این مدل برای حافظه فعلی دستگاه مناسب نیست."

        internal fun buildNativeRoleMessagePairs(
            architecture: String,
            systemPrompt: String,
            messages: List<AiMessage>
        ): List<Pair<String, String>> {
            val arch = architecture.lowercase()
            val out = mutableListOf<Pair<String, String>>()
            val supportsSystemRole = !arch.startsWith("gemma")
            var pendingSystem = systemPrompt.trim()

            if (pendingSystem.isNotBlank() && supportsSystemRole) {
                out.add("system" to pendingSystem)
                pendingSystem = ""
            }

            for (msg in messages) {
                val role = when (msg.role) {
                    AiRole.USER -> "user"
                    AiRole.ASSISTANT -> "assistant"
                    AiRole.TOOL -> "user"
                }
                val rawText = when {
                    msg.role == AiRole.TOOL -> {
                        "[Tool Result (${msg.toolName ?: "tool"})]\n${msg.text}"
                    }
                    msg.role == AiRole.ASSISTANT && msg.toolCalls.isNotEmpty() -> {
                        val callsText = msg.toolCalls.joinToString("\n") {
                            """{"tool_call":{"name":"${it.name}","arguments":${it.argumentsJson}}}"""
                        }
                        if (msg.text.isBlank()) callsText else "${msg.text}\n$callsText"
                    }
                    else -> msg.text
                }
                val withSys = if (pendingSystem.isNotBlank() && role == "user") {
                    val merged = "System Instructions:\n$pendingSystem\n\nUser:\n$rawText"
                    pendingSystem = ""
                    merged
                } else {
                    rawText
                }
                if (withSys.isNotBlank()) {
                    out.add(role to withSys)
                }
            }
            if (out.isEmpty() || out.last().first != "user") {
                val fallbackUser = if (pendingSystem.isNotBlank()) pendingSystem else "Hello"
                out.add("user" to fallbackUser)
            }
            return out
        }

        internal fun formatFallbackPrompt(
            architecture: String,
            pairs: List<Pair<String, String>>
        ): String {
            val arch = architecture.lowercase()
            return when {
                arch.startsWith("gemma") -> buildString {
                    append("<bos>")
                    for ((role, content) in pairs) {
                        val gemmaRole = if (role == "assistant") "model" else "user"
                        append("<start_of_turn>$gemmaRole\n$content<end_of_turn>\n")
                    }
                    append("<start_of_turn>model\n")
                }
                arch.startsWith("qwen") -> buildString {
                    for ((role, content) in pairs) {
                        append("<|im_start|>$role\n$content<|im_end|>\n")
                    }
                    append("<|im_start|>assistant\n")
                }
                else -> buildString {
                    append("<|begin_of_text|>")
                    for ((role, content) in pairs) {
                        append("<|start_header_id|>$role<|end_header_id|>\n\n$content<|eot_id|>")
                    }
                    append("<|start_header_id|>assistant<|end_header_id|>\n\n")
                }
            }
        }
    }
}
