package com.example.ai

import com.example.ai.local.LocalLlmRuntime
import com.example.ai.local.LocalRuntimeStatus
import com.example.data.db.DownloadedModelDao
import com.example.data.settings.AiApiProtocol
import com.example.data.settings.AiRouteIssue
import com.example.data.settings.AiSettings
import com.example.data.settings.SettingsRepository
import com.example.permissions.PermissionChecker
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import okhttp3.OkHttpClient
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class AiEngine(
    private val settingsRepository: SettingsRepository,
    private val permissionChecker: PermissionChecker,
    private val localLlmRuntime: LocalLlmRuntime,
    private val downloadedModelDao: DownloadedModelDao
) {
    private val _lastUsedRouteLabel = MutableStateFlow<String?>(null)
    val lastUsedRouteLabel: StateFlow<String?> = _lastUsedRouteLabel.asStateFlow()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    private val providers: Map<AiApiProtocol, AiProvider> = mapOf(
        AiApiProtocol.GEMINI to GeminiProvider(httpClient),
        AiApiProtocol.OPENAI_COMPATIBLE to OpenAiProvider(httpClient),
        AiApiProtocol.ANTHROPIC to AnthropicProvider(httpClient)
    )

    fun cancelActiveLocalGeneration() {
        localLlmRuntime.requestStop()
    }

    suspend fun complete(
        systemPrompt: String,
        messages: List<AiMessage>,
        tools: List<AiToolDefinition>
    ): AiResult {
        val rawSettings = settingsRepository.aiSettingsFlow.first()
        val isOnline = permissionChecker.isNetworkConnected()
        val route = rawSettings.resolveEffectiveRoute(isOnline = isOnline)
        _lastUsedRouteLabel.value = route.routeBadge

        when (route.issue) {
            AiRouteIssue.MISSING_API_KEY -> return AiResult.MissingApiKey(rawSettings.provider)
            AiRouteIssue.OFFLINE_API_ONLY -> return AiResult.Offline
            AiRouteIssue.MISSING_LOCAL_CONFIG -> {
                return AiResult.Error(
                    if (rawSettings.localUseExternalServer) {
                        "External Local Server is enabled, but no server URL/model is configured. Configure it in API Key & Routing Settings or disable External Server to use On-Device GGUF."
                    } else {
                        "No on-device AI model is selected yet. Open Downloadable Models to download a GGUF model (such as Gemma 3 4B) and tap 'Set as Default AI'."
                    }
                )
            }
            null -> {}
        }

        // Route 1: Embedded On-Device GGUF Inference via llama.cpp (never touches 127.0.0.1:8080 or cloud)
        if (route.isUsingEmbeddedRuntime) {
            return completeWithEmbeddedRuntime(rawSettings, systemPrompt, messages, tools)
        }

        // Route 2: Cloud API Provider or Explicit External Local Server
        val settings = route.effectiveSettings
        val isLoopback = AiSettings.isLoopbackEndpoint(settings.customBaseUrl)
        if (!route.isUsingLocal && !isLoopback && !isOnline) {
            return AiResult.Offline
        }

        val provider = providers[settings.protocol]
            ?: return AiResult.Error("Unsupported API protocol configured.")

        if (!settings.enableNativeTools && tools.isNotEmpty()) {
            return completeWithPromptToolFallback(provider, settings, systemPrompt, messages, tools)
        }

        val result = provider.complete(settings, systemPrompt, messages, tools)
        if (result is AiResult.Error &&
            tools.isNotEmpty() &&
            (result.statusCode == 400 || result.statusCode == 422) &&
            isToolsUnsupportedError(result.details.orEmpty() + " " + result.userMessage)
        ) {
            return completeWithPromptToolFallback(provider, settings, systemPrompt, messages, tools)
        }
        if (result is AiResult.Error && route.isUsingLocal && result.statusCode == null) {
            return result.copy(
                userMessage = "External Local Server (${settings.model}) at ${settings.customBaseUrl} did not respond. Check that the external server is running, or disable External Server mode to use On-Device GGUF."
            )
        }
        return result
    }

    private suspend fun completeWithEmbeddedRuntime(
        settings: AiSettings,
        systemPrompt: String,
        messages: List<AiMessage>,
        tools: List<AiToolDefinition>
    ): AiResult {
        val modelId = settings.defaultDownloadedTextModelId
        val modelEntity = modelId?.let { downloadedModelDao.getById(it) }
        val modelPath = modelEntity?.localPath?.ifBlank { settings.defaultDownloadedTextModelPath }
            ?: settings.defaultDownloadedTextModelPath
        val modelName = modelEntity?.name?.ifBlank { settings.defaultDownloadedTextModelName }
            ?: settings.defaultDownloadedTextModelName

        if (modelPath.isBlank()) {
            return AiResult.Error(
                "No verified on-device GGUF model path found. Open Downloadable Models and set your downloaded model as Default AI."
            )
        }
        if (modelEntity != null && !ModelDownloadManager.isReadyStatus(modelEntity.status)) {
            return AiResult.Error(
                "Selected on-device model '$modelName' is currently ${modelEntity.status}. ${modelEntity.errorMessage.orEmpty()}".trim()
            )
        }

        val effectiveSystem = if (tools.isNotEmpty()) {
            buildString {
                appendLine(systemPrompt)
                appendLine()
                appendLine("Available tools (when you need a device action, reply ONLY with JSON {\"tool_call\": {\"name\": \"<tool_name>\", \"arguments\": {...}}}):")
                tools.forEach { t ->
                    val params = t.parameters.joinToString(", ") { "${it.name}:${it.type}" }
                    appendLine("- ${t.name}($params): ${t.description}")
                }
            }
        } else {
            systemPrompt
        }

        val genResult = localLlmRuntime.generateChatCompletion(
            modelId = modelId,
            modelPath = modelPath,
            displayName = modelName.ifBlank { "On-Device Model" },
            systemPrompt = effectiveSystem,
            messages = messages,
            temperature = settings.temperature,
            onModelStatusUpdate = { status, err ->
                if (modelId != null) {
                    val mapped = when (status) {
                        LocalRuntimeStatus.LOADING -> ModelDownloadManager.STATUS_LOADING
                        LocalRuntimeStatus.LOADED -> ModelDownloadManager.STATUS_LOADED
                        LocalRuntimeStatus.ERROR -> ModelDownloadManager.STATUS_ERROR
                        LocalRuntimeStatus.NOT_LOADED -> ModelDownloadManager.STATUS_READY
                    }
                    downloadedModelDao.updateStatus(modelId, mapped, err, System.currentTimeMillis())
                }
            }
        )

        return genResult.fold(
            onSuccess = { text ->
                val parsedCall = if (tools.isNotEmpty()) tryExtractJsonToolCall(text) else null
                if (parsedCall != null) {
                    AiResult.Success(
                        AiCompletion(
                            text = "",
                            toolCalls = listOf(parsedCall),
                            provider = settings.provider,
                            model = modelName.ifBlank { "local-gguf" }
                        )
                    )
                } else {
                    AiResult.Success(
                        AiCompletion(
                            text = text,
                            toolCalls = emptyList(),
                            provider = settings.provider,
                            model = modelName.ifBlank { "local-gguf" }
                        )
                    )
                }
            },
            onFailure = { err ->
                AiResult.Error(
                    userMessage = err.localizedMessage ?: "Failed to run on-device inference."
                )
            }
        )
    }

    suspend fun testConnection(settings: AiSettings): Result<String> {
        if (!settings.hasApiKey) {
            return Result.failure(IllegalStateException("Enter an API key or enable keyless local mode first."))
        }
        val cleanUrl = settings.customBaseUrl.trim()
        if (!cleanUrl.startsWith("https://") && !cleanUrl.startsWith("http://")) {
            return Result.failure(IllegalStateException("Endpoint URL must start with https:// or http://."))
        }
        if (settings.model.trim().isBlank()) {
            return Result.failure(IllegalStateException("Enter a Model ID before testing connection."))
        }
        if (!AiSettings.isLoopbackEndpoint(cleanUrl) && !permissionChecker.isNetworkConnected()) {
            return Result.failure(IllegalStateException("Device appears offline."))
        }
        val provider = providers[settings.protocol]
            ?: return Result.failure(IllegalStateException("Unsupported API protocol."))
        return provider.testConnection(settings)
    }

    private suspend fun completeWithPromptToolFallback(
        provider: AiProvider,
        settings: AiSettings,
        systemPrompt: String,
        messages: List<AiMessage>,
        tools: List<AiToolDefinition>
    ): AiResult {
        val toolCatalog = buildString {
            appendLine(systemPrompt)
            appendLine()
            appendLine("Available tools (when you need a device action, reply ONLY with JSON {\"tool_call\": {\"name\": \"<tool_name>\", \"arguments\": {...}}}):")
            tools.forEach { t ->
                val params = t.parameters.joinToString(", ") { "${it.name}:${it.type}" }
                appendLine("- ${t.name}($params): ${t.description}")
            }
        }
        val fallbackSettings = settings.copy(enableNativeTools = false)
        val rawResult = provider.complete(fallbackSettings, toolCatalog, messages, emptyList())
        if (rawResult !is AiResult.Success) return rawResult

        val parsedCall = tryExtractJsonToolCall(rawResult.completion.text)
        return if (parsedCall != null) {
            AiResult.Success(
                rawResult.completion.copy(
                    text = "",
                    toolCalls = listOf(parsedCall)
                )
            )
        } else {
            rawResult
        }
    }

    private fun isToolsUnsupportedError(text: String): Boolean {
        val lower = text.lowercase()
        return lower.contains("tool") || lower.contains("function") || lower.contains("unsupported")
    }

    private fun tryExtractJsonToolCall(text: String): AiToolCall? {
        val trimmed = text.trim()
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()
        if (!trimmed.startsWith("{") || !trimmed.contains("tool_call")) return null
        return try {
            val root = JSONObject(trimmed)
            val call = root.optJSONObject("tool_call") ?: return null
            val name = call.optString("name")
            if (name.isBlank()) return null
            val args = call.optJSONObject("arguments")?.toString() ?: "{}"
            AiToolCall(
                id = "prompt_tool_${System.nanoTime()}",
                name = name,
                argumentsJson = args
            )
        } catch (_: Exception) {
            null
        }
    }
}
