package com.example.ai

import com.example.data.settings.AiApiProtocol
import com.example.data.settings.AiProviderType
import com.example.data.settings.AiSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class GeminiProvider(
    private val httpClient: OkHttpClient
) : AiProvider {

    override val protocol: AiApiProtocol = AiApiProtocol.GEMINI

    override suspend fun complete(
        settings: AiSettings,
        systemPrompt: String,
        messages: List<AiMessage>,
        tools: List<AiToolDefinition>
    ): AiResult = withContext(Dispatchers.IO) {
        val cleanModel = normalizeGeminiModelId(settings.model)
        if (!isValidModelId(cleanModel)) {
            return@withContext AiResult.Error(
                userMessage = "Invalid Google Gemini model ID ('$cleanModel'). Open API Key Settings -> Fetch Models and select a valid Gemini model."
            )
        }

        val url = resolveGenerateContentUrl(settings.customBaseUrl, cleanModel)
            ?: return@withContext AiResult.Error(
                userMessage = "Invalid Google Gemini endpoint URL ('${settings.customBaseUrl}'). Use https://generativelanguage.googleapis.com/v1beta."
            )

        val payload = JSONObject().apply {
            if (systemPrompt.isNotBlank()) {
                put(
                    "systemInstruction",
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", systemPrompt))
                    )
                )
            }
            put("contents", buildContents(messages))
            if (tools.isNotEmpty() && settings.enableNativeTools) {
                put(
                    "tools",
                    JSONArray().put(
                        JSONObject().put("functionDeclarations", buildFunctionDeclarations(tools))
                    )
                )
            }
            put(
                "generationConfig",
                JSONObject().put("temperature", settings.temperature.toDouble())
            )
        }

        val builder = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")

        val authValue = settings.buildAuthHeaderValue()
        if (authValue.isNotBlank()) {
            builder.addHeader(settings.effectiveAuthHeaderName, authValue)
        }

        val request = builder
            .post(payload.toString().toRequestBody(JSON_MEDIA_TYPE))
            .build()

        try {
            httpClient.newCall(request).execute().use { response ->
                val rawBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext mapHttpError(response.code, rawBody, cleanModel, settings)
                }
                parseGeminiResponse(rawBody, cleanModel, settings)
            }
        } catch (io: IOException) {
            AiResult.Error(
                userMessage = "Could not reach ${settings.effectiveDisplayName}. Check your internet connection or endpoint URL.",
                details = io.localizedMessage
            )
        } catch (e: Exception) {
            AiResult.Error(
                userMessage = "Unexpected response from ${settings.effectiveDisplayName}.",
                details = e.localizedMessage
            )
        }
    }

    override suspend fun testConnection(settings: AiSettings): Result<String> {
        val result = complete(
            settings = settings,
            systemPrompt = "Reply with OK.",
            messages = listOf(AiMessage(role = AiRole.USER, text = "Say OK")),
            tools = emptyList()
        )
        return when (result) {
            is AiResult.Success -> Result.success("Connected to ${settings.effectiveDisplayName} (${result.completion.model})")
            is AiResult.Error -> Result.failure(IllegalStateException(result.userMessage))
            is AiResult.MissingApiKey -> Result.failure(IllegalStateException("API key is empty."))
            AiResult.Offline -> Result.failure(IllegalStateException("Device is offline."))
        }
    }

    internal fun buildContents(messages: List<AiMessage>): JSONArray {
        val array = JSONArray()
        var pendingToolParts = JSONArray()

        fun flushToolParts() {
            if (pendingToolParts.length() > 0) {
                array.put(
                    JSONObject()
                        .put("role", "user")
                        .put("parts", pendingToolParts)
                )
                pendingToolParts = JSONArray()
            }
        }

        for (msg in messages) {
            when (msg.role) {
                AiRole.TOOL -> {
                    val respObj = try {
                        JSONObject(msg.text)
                    } catch (_: Exception) {
                        JSONObject().put("result", msg.text)
                    }
                    pendingToolParts.put(
                        JSONObject().put(
                            "functionResponse",
                            JSONObject()
                                .put("name", msg.toolName ?: "tool")
                                .put("response", respObj)
                        )
                    )
                }
                AiRole.USER -> {
                    flushToolParts()
                    if (msg.text.isNotBlank()) {
                        array.put(
                            JSONObject()
                                .put("role", "user")
                                .put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
                        )
                    }
                }
                AiRole.ASSISTANT -> {
                    flushToolParts()
                    // Gemini requires conversation history to start with a user turn.
                    if (array.length() == 0) continue
                    val parts = JSONArray()
                    if (msg.text.isNotBlank()) {
                        parts.put(JSONObject().put("text", msg.text))
                    }
                    for (call in msg.toolCalls) {
                        val argsObj = try {
                            JSONObject(call.argumentsJson.ifBlank { "{}" })
                        } catch (_: Exception) {
                            JSONObject()
                        }
                        parts.put(
                            JSONObject().put(
                                "functionCall",
                                JSONObject()
                                    .put("name", call.name)
                                    .put("args", argsObj)
                            )
                        )
                    }
                    if (parts.length() > 0) {
                        array.put(JSONObject().put("role", "model").put("parts", parts))
                    }
                }
            }
        }
        flushToolParts()
        return array
    }

    private fun buildFunctionDeclarations(tools: List<AiToolDefinition>): JSONArray {
        val declarations = JSONArray()
        for (tool in tools) {
            val props = JSONObject()
            val required = JSONArray()
            for (param in tool.parameters) {
                val pObj = JSONObject()
                    .put("type", param.type.uppercase())
                    .put("description", param.description)
                if (!param.enumValues.isNullOrEmpty()) {
                    pObj.put("enum", JSONArray(param.enumValues))
                }
                props.put(param.name, pObj)
                if (param.required) required.put(param.name)
            }
            val schema = JSONObject()
                .put("type", "OBJECT")
                .put("properties", props)
            if (required.length() > 0) {
                schema.put("required", required)
            }
            declarations.put(
                JSONObject()
                    .put("name", tool.name)
                    .put("description", tool.description)
                    .put("parameters", schema)
            )
        }
        return declarations
    }

    private fun parseGeminiResponse(rawBody: String, model: String, settings: AiSettings): AiResult {
        val root = JSONObject(rawBody)
        val candidates = root.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            val blockReason = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            return AiResult.Error(
                userMessage = if (blockReason.isNotBlank()) {
                    "Request was blocked by safety filter ($blockReason)."
                } else {
                    "${settings.effectiveDisplayName} returned an empty response."
                }
            )
        }
        val firstCand = candidates.getJSONObject(0)
        val content = firstCand.optJSONObject("content")
            ?: run {
                val finishReason = firstCand.optString("finishReason").orEmpty()
                val note = if (finishReason.isNotBlank()) " ($finishReason)" else ""
                return AiResult.Error("${settings.effectiveDisplayName} returned no content$note.")
            }
        val parts = content.optJSONArray("parts") ?: JSONArray()

        val textBuilder = StringBuilder()
        val toolCalls = mutableListOf<AiToolCall>()
        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            if (part.has("text") && !part.optBoolean("thought", false)) {
                if (textBuilder.isNotEmpty()) textBuilder.append("\n")
                textBuilder.append(part.optString("text"))
            }
            val fnCall = part.optJSONObject("functionCall")
            if (fnCall != null) {
                val name = fnCall.optString("name")
                val args = fnCall.optJSONObject("args")?.toString() ?: "{}"
                if (name.isNotBlank()) {
                    toolCalls.add(
                        AiToolCall(
                            id = "gemini_${System.nanoTime()}_$i",
                            name = name,
                            argumentsJson = args
                        )
                    )
                }
            }
        }
        return AiResult.Success(
            AiCompletion(
                text = textBuilder.toString().trim(),
                toolCalls = toolCalls,
                provider = settings.provider,
                model = model
            )
        )
    }

    private fun mapHttpError(code: Int, rawBody: String, model: String, settings: AiSettings): AiResult {
        val apiMessage = try {
            JSONObject(rawBody).optJSONObject("error")?.optString("message").orEmpty()
        } catch (_: Exception) {
            ""
        }
        val name = settings.effectiveDisplayName
        val friendly = when (code) {
            400 -> "$name rejected the request. ${apiMessage.ifBlank { "Check model name ($model) or parameters." }}"
            401, 403 -> "Your $name API key was rejected ($code). ${apiMessage.ifBlank { "Verify your key in API Key Settings." }}"
            404 -> "Selected $name model ('$model') or endpoint was not found. Use Fetch Models in API Key Settings to choose a supported model."
            429 -> "$name rate limit or quota exceeded. Please wait a moment and try again."
            in 500..599 -> "$name service is temporarily unavailable ($code)."
            else -> "$name API error ($code). ${apiMessage.take(160)}"
        }
        return AiResult.Error(userMessage = friendly, statusCode = code, details = apiMessage)
    }

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()

        fun normalizeGeminiModelId(rawModel: String): String {
            var clean = rawModel.trim()
            if (clean.isBlank()) return AiProviderType.GEMINI.defaultModel
            if (clean.startsWith("http://") || clean.startsWith("https://")) {
                clean = clean.substringAfterLast("/models/", "")
            }
            clean = clean.removePrefix("models/")
                .substringBefore(":generateContent")
                .substringBefore(":streamGenerateContent")
                .substringBefore("?")
                .trim()
            return clean.ifBlank { AiProviderType.GEMINI.defaultModel }
        }

        fun isValidModelId(model: String): Boolean {
            if (model.isBlank() || model.contains(' ') || model.contains("://")) return false
            return model.matches(Regex("[A-Za-z0-9._-]+"))
        }

        fun normalizeGeminiBaseUrl(rawBaseUrl: String): String? {
            var base = rawBaseUrl.trim()
                .ifBlank { AiProviderType.GEMINI.defaultBaseUrl }
                .substringBefore("?")
                .trimEnd('/')
            if (!base.startsWith("https://") && !base.startsWith("http://")) return null

            // Strip any accidental /models/... or :generateContent suffix if pasted from docs
            if (base.contains("/models/")) {
                base = base.substringBefore("/models/")
            } else if (base.endsWith("/models")) {
                base = base.removeSuffix("/models")
            }
            base = base.trimEnd('/')

            val parsed = base.toHttpUrlOrNull() ?: return null
            if (parsed.host.equals("generativelanguage.googleapis.com", ignoreCase = true)) {
                val segs = parsed.pathSegments.filter { it.isNotBlank() }
                if (segs.isEmpty()) {
                    base = "$base/v1beta"
                }
            }
            return base.toHttpUrlOrNull()?.toString()?.trimEnd('/')
        }

        fun resolveGenerateContentUrl(rawBaseUrl: String, rawModel: String): String? {
            val trimmedRaw = rawBaseUrl.trim()
            if (trimmedRaw.contains(":generateContent")) {
                return trimmedRaw.toHttpUrlOrNull()?.toString()
            }
            val base = normalizeGeminiBaseUrl(rawBaseUrl) ?: return null
            val model = normalizeGeminiModelId(rawModel)
            return "$base/models/$model:generateContent"
        }
    }
}
