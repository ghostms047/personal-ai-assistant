package com.example.ai

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import android.os.StatFs
import com.example.ai.local.GgufMetadataParser
import com.example.ai.local.GgufParseResult
import com.example.ai.local.LocalLlmRuntime
import com.example.data.db.DownloadedModelDao
import com.example.data.db.DownloadedModelEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.net.URI
import java.security.MessageDigest

data class DeviceRamInfo(
    val totalBytes: Long,
    val availableBytes: Long
) {
    val totalGb: Double get() = totalBytes / (1024.0 * 1024.0 * 1024.0)
    val availableGb: Double get() = availableBytes / (1024.0 * 1024.0 * 1024.0)
    val isSixGbOrMore: Boolean get() = totalGb >= 5.5
}

data class CuratedModelPreset(
    val id: String,
    val name: String,
    val fileName: String,
    val downloadUrl: String,
    val category: String,
    val runtimeModelName: String,
    val sizeHint: String,
    val expectedBytes: Long = 0L,
    val expectedSha256: String = "",
    val formatLabel: String,
    val specsLabel: String,
    val compatibilityLabel: String,
    val description: String,
    val paramBillions: Double,
    val recommendedRamGb: Int,
    val languagesLabel: String,
    val supportsPersian: Boolean
)

class ModelDownloadManager(
    private val context: Context,
    private val downloadedModelDao: DownloadedModelDao,
    private val localRuntimeProvider: () -> LocalLlmRuntime? = { null }
) {
    fun observeDownloadedModels(): Flow<List<DownloadedModelEntity>> =
        downloadedModelDao.observeAll()

    fun getModelsDirectory(): File =
        File(context.filesDir, "models").apply { mkdirs() }

    fun getAvailableStorageBytes(): Long =
        runCatching {
            val dir = getModelsDirectory()
            StatFs(dir.path).availableBytes
        }.getOrDefault(0L)

    suspend fun enqueueDownload(
        name: String,
        rawUrl: String,
        category: String = CATEGORY_TEXT,
        suggestedFileName: String? = null,
        expectedBytes: Long = 0L,
        expectedSha256: String = "",
        forceRedownload: Boolean = false
    ): Result<Long> {
        val cleanUrl = validateDownloadUrl(rawUrl)
            ?: return Result.failure(
                IllegalArgumentException("Enter a valid https:// or http:// model download URL.")
            )

        val derivedName = suggestedFileName?.takeIf { it.isNotBlank() }
            ?: run {
                val path = Uri.parse(cleanUrl).lastPathSegment.orEmpty()
                path.ifBlank { "model_${System.currentTimeMillis()}.bin" }
            }
        val safeFileName = sanitizeFileName(derivedName)
        val cleanLabel = name.trim().ifBlank { safeFileName }

        val existing = downloadedModelDao.getByUrl(cleanUrl)
        if (existing != null) {
            if (!forceRedownload && existing.status == STATUS_DOWNLOADING) {
                return Result.failure(IllegalStateException("${existing.name} is already downloading."))
            }
            if (localRuntimeProvider()?.isModelLoadedOrLoading(existing.id, existing.localPath) == true) {
                return Result.failure(IllegalStateException("Unload ${existing.name} before redownloading."))
            }
        }

        val modelsDir = getModelsDirectory()
        val partFile = File(modelsDir, "$safeFileName.part")
        val finalFile = File(modelsDir, safeFileName)
        if (forceRedownload) {
            runCatching { partFile.delete() }
            runCatching { finalFile.delete() }
        }

        val existingPartLen = if (partFile.exists()) partFile.length().coerceAtLeast(0L) else 0L
        val remainingEstimate = if (expectedBytes > 0L) (expectedBytes - existingPartLen).coerceAtLeast(0L) else 0L
        val freeBytes = getAvailableStorageBytes()
        if (freeBytes > 0L && remainingEstimate > 0L && freeBytes < remainingEstimate + MIN_STORAGE_RESERVE_BYTES) {
            val availGb = String.format("%.2f", freeBytes / (1024.0 * 1024.0 * 1024.0))
            val needGb = String.format("%.2f", (remainingEstimate + MIN_STORAGE_RESERVE_BYTES) / (1024.0 * 1024.0 * 1024.0))
            return Result.failure(
                IllegalStateException("Insufficient storage space ($availGb GB free, need ~${needGb} GB).")
            )
        } else if (freeBytes in 1L until MIN_STORAGE_RESERVE_BYTES) {
            return Result.failure(
                IllegalStateException("Insufficient storage space on device (less than 128 MB free).")
            )
        }

        val now = System.currentTimeMillis()
        val id = if (existing != null) {
            val updated = existing.copy(
                name = cleanLabel,
                fileName = safeFileName,
                category = category,
                status = STATUS_DOWNLOADING,
                totalBytes = if (expectedBytes > 0L) expectedBytes else existing.totalBytes,
                downloadedBytes = existingPartLen,
                expectedSha256 = expectedSha256.ifBlank { existing.expectedSha256 },
                expectedBytes = if (expectedBytes > 0L) expectedBytes else existing.expectedBytes,
                localPath = if (forceRedownload) "" else existing.localPath,
                errorMessage = null,
                updatedAt = now
            )
            downloadedModelDao.upsert(updated)
            existing.id
        } else {
            downloadedModelDao.upsert(
                DownloadedModelEntity(
                    name = cleanLabel,
                    fileName = safeFileName,
                    downloadUrl = cleanUrl,
                    category = category,
                    status = STATUS_DOWNLOADING,
                    totalBytes = expectedBytes,
                    downloadedBytes = existingPartLen,
                    expectedSha256 = expectedSha256,
                    expectedBytes = expectedBytes,
                    updatedAt = now
                )
            )
        }

        ModelDownloadWorker.enqueue(context, id)
        return Result.success(id)
    }

    suspend fun pauseDownload(model: DownloadedModelEntity) {
        if (!isDownloadingOrQueued(model.status)) return
        val partLen = File(getModelsDirectory(), "${sanitizeFileName(model.fileName)}.part")
            .takeIf { it.exists() }?.length() ?: model.downloadedBytes
        downloadedModelDao.upsert(
            model.copy(
                status = STATUS_PAUSED,
                downloadedBytes = partLen,
                errorMessage = null,
                updatedAt = System.currentTimeMillis()
            )
        )
        ModelDownloadWorker.cancel(context, model.id)
    }

    suspend fun resumeDownload(model: DownloadedModelEntity): Result<Long> {
        return enqueueDownload(
            name = model.name,
            rawUrl = model.downloadUrl,
            category = model.category,
            suggestedFileName = model.fileName,
            expectedBytes = model.expectedBytes,
            expectedSha256 = model.expectedSha256,
            forceRedownload = false
        )
    }

    suspend fun cancelDownload(model: DownloadedModelEntity) {
        downloadedModelDao.upsert(
            model.copy(
                status = STATUS_NOT_DOWNLOADED,
                downloadedBytes = 0L,
                errorMessage = "Cancelled by user",
                updatedAt = System.currentTimeMillis()
            )
        )
        ModelDownloadWorker.cancel(context, model.id)
        runCatching {
            File(getModelsDirectory(), "${sanitizeFileName(model.fileName)}.part").delete()
        }
    }

    suspend fun deleteModel(model: DownloadedModelEntity): Result<Unit> {
        if (localRuntimeProvider()?.isModelLoadedOrLoading(model.id, model.localPath) == true) {
            return Result.failure(
                IllegalStateException("Cannot delete '${model.name}' while it is loaded in memory. Unload it first.")
            )
        }
        ModelDownloadWorker.cancel(context, model.id)
        val modelsRoot = getModelsDirectory().canonicalFile
        if (model.localPath.isNotBlank()) {
            runCatching {
                val target = File(model.localPath).canonicalFile
                if (target.path.startsWith(modelsRoot.path)) {
                    target.delete()
                }
            }
        }
        runCatching {
            File(modelsRoot, "${sanitizeFileName(model.fileName)}.part").delete()
        }
        downloadedModelDao.deleteById(model.id)
        return Result.success(Unit)
    }

    suspend fun verifyModelEntity(entity: DownloadedModelEntity): DownloadedModelEntity = withContext(Dispatchers.IO) {
        val now = System.currentTimeMillis()
        downloadedModelDao.updateStatus(entity.id, STATUS_VERIFYING, null, now)

        val file = File(entity.localPath)
        if (!file.exists() || !file.isFile || file.length() <= 0L) {
            val err = entity.copy(
                status = STATUS_ERROR,
                errorMessage = "Downloaded file missing or empty. Tap Redownload.",
                updatedAt = System.currentTimeMillis()
            )
            downloadedModelDao.upsert(err)
            return@withContext err
        }

        val actualBytes = file.length()
        if (entity.expectedBytes > 0L && actualBytes != entity.expectedBytes) {
            val err = entity.copy(
                status = STATUS_ERROR,
                downloadedBytes = actualBytes,
                errorMessage = "File size mismatch (got $actualBytes bytes, expected ${entity.expectedBytes}).",
                updatedAt = System.currentTimeMillis()
            )
            downloadedModelDao.upsert(err)
            return@withContext err
        }

        // Guard against HTML error pages saved as model files
        if (looksLikeTextErrorPage(file)) {
            val err = entity.copy(
                status = STATUS_ERROR,
                errorMessage = "Downloaded file appears to be an HTML/JSON error page instead of model weights.",
                updatedAt = System.currentTimeMillis()
            )
            downloadedModelDao.upsert(err)
            return@withContext err
        }

        val sha256 = entity.sha256.ifBlank { computeSha256(file) }
        if (entity.expectedSha256.isNotBlank() && !sha256.equals(entity.expectedSha256.trim(), ignoreCase = true)) {
            runCatching { file.delete() }
            val err = entity.copy(
                status = STATUS_ERROR,
                sha256 = sha256,
                localPath = "",
                errorMessage = "SHA-256 checksum mismatch. File removed for safety.",
                updatedAt = System.currentTimeMillis()
            )
            downloadedModelDao.upsert(err)
            return@withContext err
        }

        if (isTextCategory(entity.category)) {
            when (val parse = GgufMetadataParser.parse(file)) {
                is GgufParseResult.Invalid -> {
                    val err = entity.copy(
                        status = STATUS_ERROR,
                        downloadedBytes = actualBytes,
                        sha256 = sha256,
                        errorMessage = parse.reason,
                        updatedAt = System.currentTimeMillis()
                    )
                    downloadedModelDao.upsert(err)
                    return@withContext err
                }
                is GgufParseResult.Valid -> {
                    val meta = parse.metadata
                    val ramInfo = readDeviceRamInfo(context)
                    val compat = GgufMetadataParser.checkCompatibility(
                        metadata = meta,
                        fileName = file.name,
                        modelFileBytes = actualBytes,
                        totalDeviceRamBytes = ramInfo.totalBytes
                    )
                    // Reject structurally unsupported architectures/missing tokenizers immediately as ERROR;
                    // allow READY when metadata is valid so user receives localized low-RAM feedback when attempting load.
                    val unsupportedArch = meta.architecture.lowercase() !in GgufMetadataParser.SUPPORTED_ARCHITECTURES
                    val missingVocab = meta.tokenizerTokenCount <= 0 && meta.tokenizerModel.isBlank()
                    val status = if (unsupportedArch || missingVocab || meta.tensorCount <= 0L) {
                        STATUS_ERROR
                    } else {
                        STATUS_READY
                    }
                    val verified = entity.copy(
                        status = status,
                        downloadedBytes = actualBytes,
                        totalBytes = if (entity.totalBytes > 0L) entity.totalBytes else actualBytes,
                        sha256 = sha256,
                        architecture = meta.architecture,
                        quantization = meta.quantizationLabel,
                        contextLength = compat.recommendedContextLength.takeIf { it > 0 } ?: meta.contextLength,
                        verifiedAt = System.currentTimeMillis(),
                        compatibilityNote = compat.summary,
                        errorMessage = if (status == STATUS_ERROR) compat.summary else null,
                        updatedAt = System.currentTimeMillis()
                    )
                    downloadedModelDao.upsert(verified)
                    return@withContext verified
                }
            }
        }

        val ready = entity.copy(
            status = STATUS_READY,
            downloadedBytes = actualBytes,
            totalBytes = if (entity.totalBytes > 0L) entity.totalBytes else actualBytes,
            sha256 = sha256,
            verifiedAt = System.currentTimeMillis(),
            compatibilityNote = "Verified ${file.extension.uppercase()} speech weights on-device.",
            errorMessage = null,
            updatedAt = System.currentTimeMillis()
        )
        downloadedModelDao.upsert(ready)
        return@withContext ready
    }

    suspend fun reconcileOnStartup() = withContext(Dispatchers.IO) {
        val all = downloadedModelDao.getAllOnce()
        val modelsDir = getModelsDirectory()
        val now = System.currentTimeMillis()

        for (item in all) {
            when (item.status) {
                STATUS_LOADING, STATUS_LOADED -> {
                    // Process died while model was active in native memory; verify file cleanly -> READY or ERROR.
                    verifyModelEntity(item)
                }
                STATUS_DOWNLOADING, "QUEUED" -> {
                    val isWorkActive = ModelDownloadWorker.isWorkEnqueuedOrRunning(context, item.id)
                    if (!isWorkActive) {
                        val partFile = File(modelsDir, "${sanitizeFileName(item.fileName)}.part")
                        if (partFile.exists() && partFile.length() > 0L) {
                            downloadedModelDao.upsert(
                                item.copy(
                                    status = STATUS_PAUSED,
                                    downloadedBytes = partFile.length(),
                                    errorMessage = "Paused after app restart. Tap Resume.",
                                    updatedAt = now
                                )
                            )
                        } else {
                            downloadedModelDao.upsert(
                                item.copy(
                                    status = STATUS_ERROR,
                                    downloadedBytes = 0L,
                                    errorMessage = "Download interrupted. Tap Redownload.",
                                    updatedAt = now
                                )
                            )
                        }
                    }
                }
                STATUS_DOWNLOADED, STATUS_VERIFYING, "COMPLETED" -> {
                    verifyModelEntity(item)
                }
                STATUS_READY -> {
                    val f = File(item.localPath)
                    if (!f.exists() || f.length() <= 0L) {
                        downloadedModelDao.upsert(
                            item.copy(
                                status = STATUS_ERROR,
                                errorMessage = "Model file missing from storage. Tap Redownload.",
                                updatedAt = now
                            )
                        )
                    }
                }
                "FAILED" -> {
                    downloadedModelDao.updateStatus(item.id, STATUS_ERROR, item.errorMessage, now)
                }
                "CANCELLED" -> {
                    downloadedModelDao.updateStatus(item.id, STATUS_NOT_DOWNLOADED, null, now)
                }
            }
        }
    }

    companion object {
        const val CATEGORY_TEXT = "Text AI"
        const val CATEGORY_SPEECH_STT = "Speech STT"
        const val CATEGORY_SPEECH_TTS = "Speech TTS"

        const val STATUS_NOT_DOWNLOADED = "NOT_DOWNLOADED"
        const val STATUS_DOWNLOADING = "DOWNLOADING"
        const val STATUS_PAUSED = "PAUSED"
        const val STATUS_DOWNLOADED = "DOWNLOADED"
        const val STATUS_VERIFYING = "VERIFYING"
        const val STATUS_READY = "READY"
        const val STATUS_LOADING = "LOADING"
        const val STATUS_LOADED = "LOADED"
        const val STATUS_ERROR = "ERROR"

        // Legacy constants preserved only for backward string compatibility during DB upgrades
        const val STATUS_QUEUED = "QUEUED"
        const val STATUS_COMPLETED = "COMPLETED"
        const val STATUS_FAILED = "FAILED"
        const val STATUS_CANCELLED = "CANCELLED"

        const val MIN_STORAGE_RESERVE_BYTES = 128L * 1024L * 1024L

        fun isReadyStatus(status: String?): Boolean =
            status == STATUS_READY || status == STATUS_LOADING || status == STATUS_LOADED || status == STATUS_COMPLETED

        fun isDownloadingOrQueued(status: String?): Boolean =
            status == STATUS_DOWNLOADING || status == STATUS_QUEUED

        fun isPausedStatus(status: String?): Boolean =
            status == STATUS_PAUSED

        fun isVerifyingStatus(status: String?): Boolean =
            status == STATUS_VERIFYING || status == STATUS_DOWNLOADED

        fun isErrorStatus(status: String?): Boolean =
            status == STATUS_ERROR || status == STATUS_FAILED || status == STATUS_CANCELLED

        fun isTextCategory(category: String): Boolean =
            category == CATEGORY_TEXT || category == "Open-Weight"

        fun isSpeechSttCategory(category: String): Boolean =
            category == CATEGORY_SPEECH_STT

        fun isSpeechTtsCategory(category: String): Boolean =
            category == CATEGORY_SPEECH_TTS

        fun suggestedRuntimeModelName(model: DownloadedModelEntity): String {
            curatedPresets.firstOrNull { it.downloadUrl == model.downloadUrl || it.fileName == model.fileName }
                ?.let { return it.runtimeModelName }
            return model.fileName.substringBeforeLast('.')
        }

        fun computeSha256(file: File): String {
            val digest = MessageDigest.getInstance("SHA-256")
            val buf = ByteArray(64 * 1024)
            FileInputStream(file).use { input ->
                while (true) {
                    val r = input.read(buf)
                    if (r < 0) break
                    digest.update(buf, 0, r)
                }
            }
            return digest.digest().joinToString("") { "%02x".format(it) }
        }

        fun looksLikeTextErrorPage(file: File): Boolean {
            if (!file.exists() || file.length() == 0L) return true
            val head = ByteArray(256)
            val count = FileInputStream(file).use { it.read(head) }.coerceAtLeast(0)
            val text = String(head, 0, count).trimStart().lowercase()
            return text.startsWith("<!doctype html") ||
                text.startsWith("<html") ||
                (text.startsWith("{") && text.contains("\"error\""))
        }

        val curatedPresets: List<CuratedModelPreset> = listOf(
            CuratedModelPreset(
                id = "gemma3_4b",
                name = "Gemma 3 4B Instruct (Q4_K_M)",
                fileName = "gemma-3-4b-it.Q4_K_M.gguf",
                downloadUrl = "https://huggingface.co/MaziyarPanahi/gemma-3-4b-it-GGUF/resolve/main/gemma-3-4b-it.Q4_K_M.gguf",
                category = CATEGORY_TEXT,
                runtimeModelName = "gemma3:4b",
                sizeHint = "~2.49 GB",
                formatLabel = "GGUF (Q4_K_M)",
                specsLabel = "4.0B params • Best Persian Fluency • 6+ GB RAM",
                compatibilityLabel = "Embedded On-Device llama.cpp",
                description = "4B parameter Google Gemma 3 quantized model running directly on-device via embedded llama.cpp with strong Persian (فارسی) understanding and offline assistant reasoning.",
                paramBillions = 4.0,
                recommendedRamGb = 6,
                languagesLabel = "Persian (فارسی) & 140+ Languages",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "qwen25_3b",
                name = "Qwen 2.5 3B Instruct (Q4_K_M)",
                fileName = "qwen2.5-3b-instruct-q4_k_m.gguf",
                downloadUrl = "https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q4_k_m.gguf",
                category = CATEGORY_TEXT,
                runtimeModelName = "qwen2.5:3b",
                sizeHint = "~2.10 GB",
                formatLabel = "GGUF (Q4_K_M)",
                specsLabel = "3.0B params • Strong Persian & Tool Calling • 6+ GB RAM",
                compatibilityLabel = "Embedded On-Device llama.cpp",
                description = "3B parameter Qwen 2.5 instruct model running offline on-device with accurate Persian (فارسی), English, and structured tool calling.",
                paramBillions = 3.0,
                recommendedRamGb = 6,
                languagesLabel = "Persian (فارسی), English & 29+ Languages",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "llama32_3b",
                name = "Llama 3.2 3B Instruct (Q4_K_M)",
                fileName = "Llama-3.2-3B-Instruct-Q4_K_M.gguf",
                downloadUrl = "https://huggingface.co/bartowski/Llama-3.2-3B-Instruct-GGUF/resolve/main/Llama-3.2-3B-Instruct-Q4_K_M.gguf",
                category = CATEGORY_TEXT,
                runtimeModelName = "llama3.2:3b",
                sizeHint = "~2.02 GB",
                formatLabel = "GGUF (Q4_K_M)",
                specsLabel = "3.0B params • Fast 3B Assistant • 6+ GB RAM",
                compatibilityLabel = "Embedded On-Device llama.cpp",
                description = "3B Meta Llama 3.2 instruct model running directly on phone for fast multilingual and Persian assistance on 6+ GB RAM devices.",
                paramBillions = 3.0,
                recommendedRamGb = 6,
                languagesLabel = "Persian (فارسی) & Multilingual",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "whisper_large_v3_turbo",
                name = "Whisper Large-v3-Turbo (Q5_0)",
                fileName = "ggml-large-v3-turbo-q5_0.bin",
                downloadUrl = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo-q5_0.bin",
                category = CATEGORY_SPEECH_STT,
                runtimeModelName = "whisper-large-v3-turbo",
                sizeHint = "~574 MB",
                formatLabel = "GGML (Q5_0)",
                specsLabel = "809M params • High-Accuracy Persian STT • 4+ GB RAM",
                compatibilityLabel = "Android Speech / External Whisper Server",
                description = "High-accuracy multilingual speech-to-text weights stored locally for Persian (فارسی) dictation with an external whisper.cpp server or Android voice input.",
                paramBillions = 0.809,
                recommendedRamGb = 4,
                languagesLabel = "Persian (فارسی) & 99 Languages",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "whisper_medium_multi",
                name = "Whisper Medium Multilingual (Q5_0)",
                fileName = "ggml-medium-q5_0.bin",
                downloadUrl = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-medium-q5_0.bin",
                category = CATEGORY_SPEECH_STT,
                runtimeModelName = "whisper-1",
                sizeHint = "~539 MB",
                formatLabel = "GGML (Q5_0)",
                specsLabel = "769M params • Balanced Persian STT • 4+ GB RAM",
                compatibilityLabel = "Android Speech / External Whisper Server",
                description = "Accurate multilingual speech recognition weights stored locally for Persian and English dictation.",
                paramBillions = 0.769,
                recommendedRamGb = 4,
                languagesLabel = "Persian (فارسی) & 99 Languages",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "whisper_small_multi",
                name = "Whisper Small Multilingual (Q5_1)",
                fileName = "ggml-small-q5_1.bin",
                downloadUrl = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small-q5_1.bin",
                category = CATEGORY_SPEECH_STT,
                runtimeModelName = "whisper-1",
                sizeHint = "~190 MB",
                formatLabel = "GGML (Q5_1)",
                specsLabel = "244M params • Lightweight Persian STT • 2+ GB RAM",
                compatibilityLabel = "Android Speech / External Whisper Server",
                description = "Fast multilingual Whisper weights with minimal storage footprint.",
                paramBillions = 0.244,
                recommendedRamGb = 2,
                languagesLabel = "Persian (فارسی) & 99 Languages",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "piper_amir_fa",
                name = "Piper Amir Persian Voice (fa_IR)",
                fileName = "fa_IR-amir-medium.onnx",
                downloadUrl = "https://huggingface.co/rhasspy/piper-voices/resolve/main/fa/fa_IR/amir/medium/fa_IR-amir-medium.onnx",
                category = CATEGORY_SPEECH_TTS,
                runtimeModelName = "fa_IR-amir-medium",
                sizeHint = "~63 MB",
                formatLabel = "ONNX Neural",
                specsLabel = "Natural Persian Voice (fa_IR) • Text-to-Speech • 2+ GB RAM",
                compatibilityLabel = "Android TTS / External Piper Server",
                description = "Persian (فارسی) neural voice weights stored on-device; pair with Android offline TTS voice packs or an external Piper endpoint.",
                paramBillions = 0.02,
                recommendedRamGb = 2,
                languagesLabel = "Persian (fa_IR)",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "piper_ganji_fa",
                name = "Piper Ganji Persian Voice (fa_IR)",
                fileName = "fa_IR-ganji-medium.onnx",
                downloadUrl = "https://huggingface.co/rhasspy/piper-voices/resolve/main/fa/fa_IR/ganji/medium/fa_IR-ganji-medium.onnx",
                category = CATEGORY_SPEECH_TTS,
                runtimeModelName = "fa_IR-ganji-medium",
                sizeHint = "~63 MB",
                formatLabel = "ONNX Neural",
                specsLabel = "Clear Persian Voice (fa_IR) • Text-to-Speech • 2+ GB RAM",
                compatibilityLabel = "Android TTS / External Piper Server",
                description = "Alternative clear Persian (فارسی) neural voice model stored on-device.",
                paramBillions = 0.02,
                recommendedRamGb = 2,
                languagesLabel = "Persian (fa_IR)",
                supportsPersian = true
            ),
            CuratedModelPreset(
                id = "piper_lessac_en",
                name = "Piper Lessac US Voice (en_US)",
                fileName = "en_US-lessac-medium.onnx",
                downloadUrl = "https://huggingface.co/rhasspy/piper-voices/resolve/main/en/en_US/lessac/medium/en_US-lessac-medium.onnx",
                category = CATEGORY_SPEECH_TTS,
                runtimeModelName = "en_US-lessac-medium",
                sizeHint = "~63 MB",
                formatLabel = "ONNX Neural",
                specsLabel = "Natural US English Voice • Text-to-Speech • 2+ GB RAM",
                compatibilityLabel = "Android TTS / External Piper Server",
                description = "Studio-grade US English neural voice synthesis weights.",
                paramBillions = 0.02,
                recommendedRamGb = 2,
                languagesLabel = "English (en_US)",
                supportsPersian = false
            )
        )

        fun readDeviceRamInfo(context: Context): DeviceRamInfo {
            return runCatching {
                val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                    ?: return DeviceRamInfo(0L, 0L)
                val info = ActivityManager.MemoryInfo()
                activityManager.getMemoryInfo(info)
                DeviceRamInfo(
                    totalBytes = info.totalMem.coerceAtLeast(0L),
                    availableBytes = info.availMem.coerceAtLeast(0L)
                )
            }.getOrElse { DeviceRamInfo(0L, 0L) }
        }

        fun validateDownloadUrl(rawUrl: String): String? {
            val trimmed = rawUrl.trim()
            if (trimmed.isBlank()) return null
            return try {
                val parsed = URI(trimmed)
                val scheme = parsed.scheme?.lowercase() ?: return null
                if (scheme != "https" && scheme != "http") return null
                if (parsed.host.isNullOrBlank()) return null
                trimmed
            } catch (_: Exception) {
                null
            }
        }

        fun sanitizeFileName(raw: String): String {
            val base = raw.substringAfterLast('/').substringAfterLast('\\')
            val cleaned = base.replace(Regex("[^A-Za-z0-9._-]"), "_").trimStart('.')
            return cleaned.ifBlank { "model_${System.currentTimeMillis()}.bin" }
        }
    }
}
