package com.example.ai

import com.example.data.settings.AiProviderType

enum class AiRole {
    USER,
    ASSISTANT,
    TOOL
}

data class AiToolCall(
    val id: String,
    val name: String,
    val argumentsJson: String
)

data class AiMessage(
    val role: AiRole,
    val text: String = "",
    val toolCalls: List<AiToolCall> = emptyList(),
    val toolCallId: String? = null,
    val toolName: String? = null
)

data class AiToolParameter(
    val name: String,
    val type: String,
    val description: String,
    val required: Boolean = true,
    val enumValues: List<String>? = null
)

data class AiToolDefinition(
    val name: String,
    val description: String,
    val parameters: List<AiToolParameter>
)

data class AiCompletion(
    val text: String,
    val toolCalls: List<AiToolCall>,
    val provider: AiProviderType,
    val model: String
)

sealed interface AiResult {
    data class Success(val completion: AiCompletion) : AiResult
    data class MissingApiKey(val provider: AiProviderType) : AiResult
    data object Offline : AiResult
    data class Error(
        val userMessage: String,
        val statusCode: Int? = null,
        val details: String? = null
    ) : AiResult
}
