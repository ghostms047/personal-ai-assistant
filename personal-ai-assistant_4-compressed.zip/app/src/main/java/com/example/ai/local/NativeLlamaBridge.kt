package com.example.ai.local

import android.os.Build

interface LlamaBridge {
    fun isNativeLibraryAvailable(): Boolean
    fun isSupportedAbi(): Boolean
    fun supportedAbisSummary(): String
    fun loadError(): String?
    fun loadModel(modelPath: String, nCtx: Int, nThreads: Int, nBatch: Int): Long
    fun applyChatTemplate(
        handle: Long,
        roles: Array<String>,
        contents: Array<String>,
        addAssistant: Boolean
    ): String?

    fun generate(
        handle: Long,
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        callback: NativeLlamaBridge.TokenCallback?
    ): String

    fun requestStop(handle: Long)
    fun unloadModel(handle: Long)
    fun getModelDescription(handle: Long): String
    fun systemInfo(): String
    fun getLastError(): String
}

object NativeLlamaBridge : LlamaBridge {

    fun interface TokenCallback {
        fun onToken(piece: String)
    }

    @Volatile
    private var libraryLoaded = false

    @Volatile
    private var libraryLoadError: String? = null

    private fun ensureLoaded(): Boolean {
        if (libraryLoaded) return true
        if (libraryLoadError != null) return false
        synchronized(this) {
            if (libraryLoaded) return true
            if (libraryLoadError != null) return false
            return try {
                System.loadLibrary("personalai_llama")
                libraryLoaded = true
                true
            } catch (t: Throwable) {
                libraryLoadError = t.localizedMessage ?: t.javaClass.simpleName
                false
            }
        }
    }

    override fun isNativeLibraryAvailable(): Boolean = ensureLoaded()

    override fun isSupportedAbi(): Boolean =
        Build.SUPPORTED_ABIS.any { it.equals("arm64-v8a", ignoreCase = true) }

    override fun supportedAbisSummary(): String =
        Build.SUPPORTED_ABIS.joinToString(", ").ifBlank { "unknown" }

    override fun loadError(): String? = libraryLoadError

    override fun loadModel(modelPath: String, nCtx: Int, nThreads: Int, nBatch: Int): Long {
        if (!ensureLoaded()) return 0L
        return nativeLoadModel(modelPath, nCtx, nThreads, nBatch)
    }

    override fun applyChatTemplate(
        handle: Long,
        roles: Array<String>,
        contents: Array<String>,
        addAssistant: Boolean
    ): String? {
        if (!ensureLoaded() || handle == 0L) return null
        return nativeApplyChatTemplate(handle, roles, contents, addAssistant)
    }

    override fun generate(
        handle: Long,
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        callback: TokenCallback?
    ): String {
        if (!ensureLoaded() || handle == 0L) return ""
        return nativeGenerate(handle, prompt, maxTokens, temperature, callback)
    }

    override fun requestStop(handle: Long) {
        if (libraryLoaded && handle != 0L) {
            nativeRequestStop(handle)
        }
    }

    override fun unloadModel(handle: Long) {
        if (libraryLoaded && handle != 0L) {
            nativeUnloadModel(handle)
        }
    }

    override fun getModelDescription(handle: Long): String {
        if (!libraryLoaded || handle == 0L) return ""
        return nativeGetModelDescription(handle)
    }

    override fun systemInfo(): String {
        if (!ensureLoaded()) return ""
        return nativeSystemInfo()
    }

    override fun getLastError(): String {
        if (!libraryLoaded) return libraryLoadError.orEmpty()
        return nativeGetLastError()
    }

    @JvmStatic
    private external fun nativeLoadModel(
        modelPath: String,
        nCtx: Int,
        nThreads: Int,
        nBatch: Int
    ): Long

    @JvmStatic
    private external fun nativeApplyChatTemplate(
        handle: Long,
        roles: Array<String>,
        contents: Array<String>,
        addAssistant: Boolean
    ): String?

    @JvmStatic
    private external fun nativeGenerate(
        handle: Long,
        prompt: String,
        maxTokens: Int,
        temperature: Float,
        callback: TokenCallback?
    ): String

    @JvmStatic
    private external fun nativeRequestStop(handle: Long)

    @JvmStatic
    private external fun nativeUnloadModel(handle: Long)

    @JvmStatic
    private external fun nativeGetModelDescription(handle: Long): String

    @JvmStatic
    private external fun nativeSystemInfo(): String

    @JvmStatic
    private external fun nativeGetLastError(): String
}
