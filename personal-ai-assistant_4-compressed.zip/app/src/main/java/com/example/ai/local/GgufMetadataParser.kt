package com.example.ai.local

import java.io.BufferedInputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.StandardCharsets

data class GgufMetadata(
    val formatVersion: Int,
    val tensorCount: Long,
    val kvCount: Long,
    val architecture: String,
    val modelName: String,
    val fileTypeCode: Int,
    val quantizationLabel: String,
    val contextLength: Int,
    val embeddingLength: Int,
    val blockCount: Int,
    val headCount: Int,
    val tokenizerModel: String,
    val tokenizerTokenCount: Int,
    val hasChatTemplate: Boolean
)

sealed class GgufParseResult {
    data class Valid(val metadata: GgufMetadata) : GgufParseResult()
    data class Invalid(val reason: String) : GgufParseResult()
}

data class GgufCompatibilityReport(
    val compatible: Boolean,
    val summary: String,
    val recommendedContextLength: Int
)

object GgufMetadataParser {

    private const val GGUF_MAGIC_LE = 0x46554747 // "GGUF" little-endian
    private const val MAX_KV_PAIRS = 8192L
    private const val MAX_KEY_BYTES = 4096L
    private const val MAX_ARRAY_LEN = 2_000_000L

    private const val TYPE_UINT8 = 0
    private const val TYPE_INT8 = 1
    private const val TYPE_UINT16 = 2
    private const val TYPE_INT16 = 3
    private const val TYPE_UINT32 = 4
    private const val TYPE_INT32 = 5
    private const val TYPE_FLOAT32 = 6
    private const val TYPE_BOOL = 7
    private const val TYPE_STRING = 8
    private const val TYPE_ARRAY = 9
    private const val TYPE_UINT64 = 10
    private const val TYPE_INT64 = 11
    private const val TYPE_FLOAT64 = 12

    val SUPPORTED_ARCHITECTURES = setOf(
        "gemma", "gemma2", "gemma3", "gemma3n",
        "llama", "llama4",
        "qwen2", "qwen2moe", "qwen2vl", "qwen3", "qwen3moe",
        "phi2", "phi3", "phimoe",
        "mistral", "mistral3", "starcoder2", "command-r", "cohere2",
        "smollm", "internlm2", "deepseek", "deepseek2", "falcon", "olmo2"
    )

    fun parse(file: File): GgufParseResult {
        if (!file.exists() || !file.isFile) {
            return GgufParseResult.Invalid("Model file does not exist.")
        }
        val fileLength = file.length()
        if (fileLength < 24L) {
            return GgufParseResult.Invalid("File is too small (${fileLength} bytes) to be a valid GGUF model.")
        }

        return try {
            BufferedInputStream(FileInputStream(file), 64 * 1024).use { input ->
                val reader = LittleEndianStreamReader(input)
                val magic = reader.readInt()
                if (magic != GGUF_MAGIC_LE) {
                    return GgufParseResult.Invalid(
                        "Invalid GGUF header signature (0x${magic.toUInt().toString(16)}). Download may be corrupt or an HTML error page."
                    )
                }

                val version = reader.readInt()
                if (version !in 2..3) {
                    return GgufParseResult.Invalid(
                        "Unsupported GGUF format version: $version (expected GGUF v2 or v3)."
                    )
                }

                val tensorCount = reader.readLong()
                val kvCount = reader.readLong()
                if (tensorCount < 0L || kvCount < 0L || kvCount > MAX_KV_PAIRS) {
                    return GgufParseResult.Invalid(
                        "Corrupt GGUF counts (tensors=$tensorCount, kv=$kvCount)."
                    )
                }

                var architecture = ""
                var modelName = ""
                var fileTypeCode = -1
                var contextLength = 0
                var embeddingLength = 0
                var blockCount = 0
                var headCount = 0
                var tokenizerModel = ""
                var tokenizerTokenCount = 0
                var hasChatTemplate = false

                for (i in 0 until kvCount) {
                    val key = reader.readString(MAX_KEY_BYTES)
                    val valueType = reader.readInt()
                    when (valueType) {
                        TYPE_STRING -> {
                            val str = if (
                                key == "general.architecture" ||
                                key == "general.name" ||
                                key == "tokenizer.ggml.model" ||
                                key == "tokenizer.chat_template"
                            ) {
                                reader.readString(65536L)
                            } else {
                                reader.skipString(16L * 1024L * 1024L)
                                null
                            }
                            when (key) {
                                "general.architecture" -> architecture = str.orEmpty().trim()
                                "general.name" -> modelName = str.orEmpty().trim()
                                "tokenizer.ggml.model" -> tokenizerModel = str.orEmpty().trim()
                                "tokenizer.chat_template" -> hasChatTemplate = !str.isNullOrBlank()
                            }
                        }
                        TYPE_UINT32, TYPE_INT32 -> {
                            val v = reader.readInt()
                            when {
                                key == "general.file_type" -> fileTypeCode = v
                                key.endsWith(".context_length") && v > 0 -> contextLength = v
                                key.endsWith(".embedding_length") && v > 0 -> embeddingLength = v
                                key.endsWith(".block_count") && v > 0 -> blockCount = v
                                key.endsWith(".attention.head_count") && v > 0 -> headCount = v
                            }
                        }
                        TYPE_UINT64, TYPE_INT64 -> {
                            val v = reader.readLong()
                            val safeInt = v.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()
                            when {
                                key.endsWith(".context_length") && safeInt > 0 -> contextLength = safeInt
                                key.endsWith(".embedding_length") && safeInt > 0 -> embeddingLength = safeInt
                                key.endsWith(".block_count") && safeInt > 0 -> blockCount = safeInt
                                key.endsWith(".attention.head_count") && safeInt > 0 -> headCount = safeInt
                            }
                        }
                        TYPE_UINT8, TYPE_INT8, TYPE_BOOL -> reader.skipBytes(1L)
                        TYPE_UINT16, TYPE_INT16 -> reader.skipBytes(2L)
                        TYPE_FLOAT32 -> reader.skipBytes(4L)
                        TYPE_FLOAT64 -> reader.skipBytes(8L)
                        TYPE_ARRAY -> {
                            val elemType = reader.readInt()
                            val count = reader.readLong()
                            if (count < 0L || count > MAX_ARRAY_LEN) {
                                return GgufParseResult.Invalid("Invalid GGUF array length ($count) for '$key'.")
                            }
                            if (key == "tokenizer.ggml.tokens") {
                                tokenizerTokenCount = count.coerceIn(0L, Int.MAX_VALUE.toLong()).toInt()
                            }
                            skipArrayElements(reader, elemType, count)
                        }
                        else -> {
                            return GgufParseResult.Invalid("Unknown GGUF metadata type ($valueType) for '$key'.")
                        }
                    }
                }

                val quantLabel = resolveQuantizationLabel(fileTypeCode, file.name)
                GgufParseResult.Valid(
                    GgufMetadata(
                        formatVersion = version,
                        tensorCount = tensorCount,
                        kvCount = kvCount,
                        architecture = architecture,
                        modelName = modelName,
                        fileTypeCode = fileTypeCode,
                        quantizationLabel = quantLabel,
                        contextLength = contextLength,
                        embeddingLength = embeddingLength,
                        blockCount = blockCount,
                        headCount = headCount,
                        tokenizerModel = tokenizerModel,
                        tokenizerTokenCount = tokenizerTokenCount,
                        hasChatTemplate = hasChatTemplate
                    )
                )
            }
        } catch (eof: EOFException) {
            GgufParseResult.Invalid("GGUF file is truncated or incomplete (unexpected end of file).")
        } catch (e: Exception) {
            GgufParseResult.Invalid(e.localizedMessage ?: "Failed to parse GGUF metadata.")
        }
    }

    fun checkCompatibility(
        metadata: GgufMetadata,
        fileName: String,
        modelFileBytes: Long,
        totalDeviceRamBytes: Long
    ): GgufCompatibilityReport {
        val arch = metadata.architecture.lowercase()
        if (arch.isBlank()) {
            return GgufCompatibilityReport(
                compatible = false,
                summary = "GGUF file is missing general.architecture metadata.",
                recommendedContextLength = 0
            )
        }
        if (arch !in SUPPORTED_ARCHITECTURES) {
            return GgufCompatibilityReport(
                compatible = false,
                summary = "Architecture '$arch' is not supported by the embedded runtime.",
                recommendedContextLength = 0
            )
        }
        if (metadata.tensorCount <= 0L) {
            return GgufCompatibilityReport(
                compatible = false,
                summary = "GGUF file contains zero weight tensors.",
                recommendedContextLength = 0
            )
        }
        if (metadata.tokenizerTokenCount <= 0 && metadata.tokenizerModel.isBlank()) {
            return GgufCompatibilityReport(
                compatible = false,
                summary = "GGUF file is missing embedded tokenizer vocabulary metadata.",
                recommendedContextLength = 0
            )
        }

        // Check memory feasibility based on GGUF file size + KV cache overhead (~450 MB).
        val estimatedRequiredBytes = (modelFileBytes * 1.15).toLong() + 384L * 1024L * 1024L
        if (totalDeviceRamBytes > 0L && estimatedRequiredBytes > totalDeviceRamBytes) {
            val fileGb = String.format("%.2f", modelFileBytes / (1024.0 * 1024.0 * 1024.0))
            val ramGb = String.format("%.2f", totalDeviceRamBytes / (1024.0 * 1024.0 * 1024.0))
            return GgufCompatibilityReport(
                compatible = false,
                summary = "Model (${fileGb} GB, ${metadata.quantizationLabel}) exceeds device total RAM (${ramGb} GB). Choose Q4_K_M / smaller quantization.",
                recommendedContextLength = 0
            )
        }

        val maxModelCtx = metadata.contextLength.takeIf { it > 0 } ?: 4096
        val safeCtx = when {
            totalDeviceRamBytes in 1L..(4_500_000_000L) -> minOf(maxModelCtx, 1024)
            totalDeviceRamBytes in 4_500_000_001L..(6_500_000_000L) -> minOf(maxModelCtx, 2048)
            else -> minOf(maxModelCtx, 4096)
        }
        val gemmaNote = if (arch == "gemma3") "Gemma 3 verified" else "GGUF $arch verified"
        return GgufCompatibilityReport(
            compatible = true,
            summary = "$gemmaNote • ${metadata.quantizationLabel} • ${metadata.tensorCount} tensors • ctx=$safeCtx",
            recommendedContextLength = safeCtx
        )
    }

    fun resolveQuantizationLabel(fileTypeCode: Int, fileName: String): String {
        val fromCode = when (fileTypeCode) {
            0 -> "F32"
            1 -> "F16"
            2 -> "Q4_0"
            3 -> "Q4_1"
            7 -> "Q8_0"
            8 -> "Q5_0"
            9 -> "Q5_1"
            10 -> "Q2_K"
            11 -> "Q3_K_S"
            12 -> "Q3_K_M"
            13 -> "Q3_K_L"
            14 -> "Q4_K_S"
            15 -> "Q4_K_M"
            16 -> "Q5_K_S"
            17 -> "Q5_K_M"
            18 -> "Q6_K"
            19 -> "IQ2_XXS"
            20 -> "IQ2_XS"
            21 -> "Q2_K_S"
            22 -> "IQ3_XS"
            23 -> "IQ3_XXS"
            24 -> "IQ1_S"
            25 -> "IQ4_NL"
            26 -> "IQ3_S"
            27 -> "IQ3_M"
            28 -> "IQ2_S"
            29 -> "IQ2_M"
            30 -> "IQ4_XS"
            31 -> "IQ1_M"
            32 -> "BF16"
            36 -> "TQ1_0"
            37 -> "TQ2_0"
            else -> ""
        }
        if (fromCode.isNotBlank()) return fromCode

        val upper = fileName.uppercase()
        val known = listOf(
            "Q4_K_M", "Q4_K_S", "Q5_K_M", "Q5_K_S", "Q6_K", "Q8_0", "Q4_0", "Q3_K_M", "Q2_K", "F16", "BF16"
        )
        return known.firstOrNull { upper.contains(it) } ?: "GGUF"
    }

    private fun skipArrayElements(reader: LittleEndianStreamReader, elemType: Int, count: Long) {
        when (elemType) {
            TYPE_UINT8, TYPE_INT8, TYPE_BOOL -> reader.skipBytes(count)
            TYPE_UINT16, TYPE_INT16 -> reader.skipBytes(count * 2L)
            TYPE_UINT32, TYPE_INT32, TYPE_FLOAT32 -> reader.skipBytes(count * 4L)
            TYPE_UINT64, TYPE_INT64, TYPE_FLOAT64 -> reader.skipBytes(count * 8L)
            TYPE_STRING -> {
                for (j in 0 until count) {
                    reader.skipString(16L * 1024L * 1024L)
                }
            }
            TYPE_ARRAY -> {
                for (j in 0 until count) {
                    val nestedType = reader.readInt()
                    val nestedCount = reader.readLong()
                    if (nestedCount < 0L || nestedCount > MAX_ARRAY_LEN) {
                        throw IllegalArgumentException("Corrupt nested GGUF array length: $nestedCount")
                    }
                    skipArrayElements(reader, nestedType, nestedCount)
                }
            }
            else -> throw IllegalArgumentException("Unsupported GGUF array element type: $elemType")
        }
    }

    private class LittleEndianStreamReader(private val input: BufferedInputStream) {
        private val buf8 = ByteArray(8)
        private val byteBuffer = ByteBuffer.wrap(buf8).order(ByteOrder.LITTLE_ENDIAN)

        fun readInt(): Int {
            readFully(buf8, 4)
            byteBuffer.clear()
            return byteBuffer.getInt(0)
        }

        fun readLong(): Long {
            readFully(buf8, 8)
            byteBuffer.clear()
            return byteBuffer.getLong(0)
        }

        fun readString(maxLen: Long): String {
            val len = readLong()
            if (len < 0L || len > maxLen) {
                throw IllegalArgumentException("Invalid GGUF string length: $len")
            }
            if (len == 0L) return ""
            val bytes = ByteArray(len.toInt())
            readFully(bytes, len.toInt())
            return String(bytes, StandardCharsets.UTF_8)
        }

        fun skipString(maxLen: Long) {
            val len = readLong()
            if (len < 0L || len > maxLen) {
                throw IllegalArgumentException("Invalid GGUF string length: $len")
            }
            skipBytes(len)
        }

        fun skipBytes(count: Long) {
            var remaining = count
            while (remaining > 0L) {
                val skipped = input.skip(remaining)
                if (skipped > 0L) {
                    remaining -= skipped
                } else {
                    if (input.read() == -1) throw EOFException()
                    remaining -= 1L
                }
            }
        }

        private fun readFully(dest: ByteArray, length: Int) {
            var offset = 0
            while (offset < length) {
                val read = input.read(dest, offset, length - offset)
                if (read < 0) throw EOFException()
                offset += read
            }
        }
    }
}
