package com.example.ai

import com.example.data.settings.AiApiProtocol
import com.example.data.settings.AiSettings

interface AiProvider {
    val protocol: AiApiProtocol

    suspend fun complete(
        settings: AiSettings,
        systemPrompt: String,
        messages: List<AiMessage>,
        tools: List<AiToolDefinition>
    ): AiResult

    suspend fun testConnection(settings: AiSettings): Result<String>
}
