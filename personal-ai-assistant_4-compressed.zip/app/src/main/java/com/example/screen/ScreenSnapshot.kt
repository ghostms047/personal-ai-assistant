package com.example.screen

import android.graphics.Rect

data class ScreenElement(
    val index: Int,
    val text: String,
    val contentDescription: String,
    val viewId: String,
    val className: String,
    val isClickable: Boolean,
    val isEditable: Boolean,
    val isScrollable: Boolean,
    val bounds: Rect
) {
    val displayLabel: String
        get() = text.ifBlank { contentDescription }.ifBlank { viewId.substringAfterLast('/') }
}

data class ScreenSnapshot(
    val packageName: String,
    val windowTitle: String,
    val source: String,
    val capturedAt: Long,
    val fullText: String,
    val elements: List<ScreenElement>
) {
    val interactiveElements: List<ScreenElement>
        get() = elements.filter { (it.isClickable || it.isEditable) && it.displayLabel.isNotBlank() }

    fun toPromptContext(maxChars: Int = 4500): String {
        val sb = StringBuilder()
        sb.appendLine("Active App Package: $packageName")
        if (windowTitle.isNotBlank()) sb.appendLine("Window Title: $windowTitle")
        sb.appendLine("Capture Source: $source")
        sb.appendLine("--- Visible Text ---")
        sb.appendLine(fullText.take(2400))
        if (interactiveElements.isNotEmpty()) {
            sb.appendLine("--- Interactive UI Elements ---")
            interactiveElements.take(35).forEach { el ->
                val kind = if (el.isEditable) "Input" else "Button/Item"
                val cx = el.bounds.centerX()
                val cy = el.bounds.centerY()
                sb.appendLine("[$kind] \"${el.displayLabel}\" (id=${el.viewId.ifBlank { "none" }}, center=$cx,$cy)")
            }
        }
        return sb.toString().take(maxChars)
    }
}
