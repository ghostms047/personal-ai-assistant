package com.example.screen

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.PersonalAiApp

class PersonalAiAccessibilityService : AccessibilityService() {

    private var lastCaptureTimestamp = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        (applicationContext as? PersonalAiApp)?.container?.screenUnderstandingRepository
            ?.attachService(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Passive background screen capture is disabled for privacy.
        // Screen snapshots are captured strictly on-demand when the user triggers Vision.
    }

    override fun onInterrupt() {
        // No ongoing speech/feedback to interrupt
    }

    override fun onDestroy() {
        (applicationContext as? PersonalAiApp)?.container?.screenUnderstandingRepository
            ?.detachService()
        super.onDestroy()
    }

    fun captureCurrentWindowSnapshot(): ScreenSnapshot? {
        val root = rootInActiveWindow ?: return null
        val rootPackage = root.packageName?.toString().orEmpty()
        if (rootPackage == packageName) {
            // Try finding another active normal application window if available
            val altWindow = windows?.firstOrNull { win ->
                win.type == android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION &&
                    win.root?.packageName?.toString() != packageName
            }
            val altRoot = altWindow?.root
            if (altRoot != null) {
                return extractSnapshot(altRoot, altWindow.title?.toString().orEmpty())
            }
        }
        return extractSnapshot(root, "")
    }

    private fun extractSnapshot(root: AccessibilityNodeInfo, windowTitle: String): ScreenSnapshot {
        val elements = mutableListOf<ScreenElement>()
        val textParts = LinkedHashSet<String>()
        var counter = 0

        fun traverse(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 28 || elements.size >= 160) return
            val text = node.text?.toString()?.trim().orEmpty()
            val desc = node.contentDescription?.toString()?.trim().orEmpty()
            val viewId = node.viewIdResourceName?.trim().orEmpty()
            val className = node.className?.toString()?.substringAfterLast('.').orEmpty()

            if (text.isNotBlank()) textParts.add(text)
            if (desc.isNotBlank() && desc != text) textParts.add(desc)

            if (text.isNotBlank() || desc.isNotBlank() || node.isClickable || node.isEditable) {
                val bounds = Rect()
                node.getBoundsInScreen(bounds)
                elements.add(
                    ScreenElement(
                        index = counter++,
                        text = text,
                        contentDescription = desc,
                        viewId = viewId,
                        className = className,
                        isClickable = node.isClickable,
                        isEditable = node.isEditable,
                        isScrollable = node.isScrollable,
                        bounds = bounds
                    )
                )
            }

            for (i in 0 until node.childCount) {
                traverse(node.getChild(i), depth + 1)
            }
        }

        traverse(root, 0)
        return ScreenSnapshot(
            packageName = root.packageName?.toString().orEmpty().ifBlank { "unknown" },
            windowTitle = windowTitle,
            source = "Accessibility Service",
            capturedAt = System.currentTimeMillis(),
            fullText = textParts.joinToString("\n"),
            elements = elements
        )
    }

    fun clickElementMatching(query: String): Result<String> {
        val targetQuery = query.trim().lowercase()
        if (targetQuery.isBlank()) {
            return Result.failure(IllegalArgumentException("No element label was provided to click."))
        }
        val root = rootInActiveWindow
            ?: return Result.failure(IllegalStateException("No active screen window is currently available."))

        val matchingNode = findNodeMatching(root, targetQuery)
            ?: return Result.failure(
                IllegalStateException("Could not find a visible UI element matching \"$query\".")
            )

        var clickableNode: AccessibilityNodeInfo? = matchingNode
        var hops = 0
        while (clickableNode != null && !clickableNode.isClickable && hops < 5) {
            clickableNode = clickableNode.parent
            hops++
        }

        val target = if (clickableNode?.isClickable == true) clickableNode else matchingNode
        val clicked = target.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        return if (clicked) {
            Result.success("Clicked \"${matchingNode.text ?: matchingNode.contentDescription ?: query}\".")
        } else {
            Result.failure(
                IllegalStateException("Found \"$query\", but Android did not allow clicking that element.")
            )
        }
    }

    private fun findNodeMatching(
        node: AccessibilityNodeInfo?,
        lowerQuery: String,
        depth: Int = 0
    ): AccessibilityNodeInfo? {
        if (node == null || depth > 28) return null
        val text = node.text?.toString()?.trim()?.lowercase().orEmpty()
        val desc = node.contentDescription?.toString()?.trim()?.lowercase().orEmpty()
        val viewId = node.viewIdResourceName?.substringAfterLast('/')?.lowercase().orEmpty()

        if (text == lowerQuery || desc == lowerQuery || viewId == lowerQuery) {
            return node
        }
        if (text.contains(lowerQuery) || desc.contains(lowerQuery)) {
            return node
        }
        for (i in 0 until node.childCount) {
            val found = findNodeMatching(node.getChild(i), lowerQuery, depth + 1)
            if (found != null) return found
        }
        return null
    }

    fun performGlobalNavigationAction(action: String): Result<String> {
        val globalId = when (action.lowercase().trim()) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents", "overview" -> GLOBAL_ACTION_RECENTS
            "notifications" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick_settings" -> GLOBAL_ACTION_QUICK_SETTINGS
            else -> return Result.failure(
                IllegalArgumentException("Unsupported navigation action '$action'. Supported: back, home, recents, notifications, quick_settings.")
            )
        }
        val ok = performGlobalAction(globalId)
        return if (ok) {
            Result.success("Performed system navigation action: $action.")
        } else {
            Result.failure(IllegalStateException("Android declined global action '$action'."))
        }
    }

    fun typeTextInElement(query: String, textToType: String): Result<String> {
        val root = rootInActiveWindow
            ?: return Result.failure(IllegalStateException("No active screen window is currently available."))
        val targetQuery = query.trim().lowercase()
        val node = if (targetQuery.isBlank()) {
            findFocusedOrFirstEditable(root)
        } else {
            findNodeMatching(root, targetQuery)?.let { matched ->
                if (matched.isEditable) matched else findFirstEditableDescendant(matched) ?: matched
            } ?: findFocusedOrFirstEditable(root)
        } ?: return Result.failure(IllegalStateException("Could not find an editable input field matching \"$query\"."))

        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, textToType)
        }
        val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return if (ok) {
            Result.success("Typed text into \"${node.text ?: node.hintText ?: query.ifBlank { "input field" }}\".")
        } else {
            Result.failure(IllegalStateException("Android did not allow typing text into that field."))
        }
    }

    fun scrollScreen(direction: String): Result<String> {
        val dir = direction.lowercase().trim()
        val root = rootInActiveWindow
        if (root != null && (dir == "forward" || dir == "backward")) {
            val scrollable = findFirstScrollable(root)
            if (scrollable != null) {
                val action = if (dir == "forward") {
                    AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                } else {
                    AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                }
                if (scrollable.performAction(action)) {
                    return Result.success("Scrolled $dir.")
                }
            }
        }
        val dm = resources.displayMetrics
        val cx = dm.widthPixels / 2f
        val cy = dm.heightPixels / 2f
        val (x1, y1, x2, y2) = when (dir) {
            "up", "backward" -> listOf(cx, dm.heightPixels * 0.35f, cx, dm.heightPixels * 0.72f)
            "left" -> listOf(dm.widthPixels * 0.25f, cy, dm.widthPixels * 0.80f, cy)
            "right" -> listOf(dm.widthPixels * 0.80f, cy, dm.widthPixels * 0.25f, cy)
            else -> listOf(cx, dm.heightPixels * 0.72f, cx, dm.heightPixels * 0.32f) // down / forward
        }
        return swipeCoordinates(x1, y1, x2, y2, 320L)
    }

    fun tapAtCoordinates(x: Float, y: Float): Result<String> {
        val dm = resources.displayMetrics
        val safeX = x.coerceIn(1f, (dm.widthPixels - 1).coerceAtLeast(1).toFloat())
        val safeY = y.coerceIn(1f, (dm.heightPixels - 1).coerceAtLeast(1).toFloat())
        val path = Path().apply { moveTo(safeX, safeY) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, 65L)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val dispatched = dispatchGesture(gesture, null, null)
        return if (dispatched) {
            Result.success("Tapped screen at (${safeX.toInt()}, ${safeY.toInt()}).")
        } else {
            Result.failure(IllegalStateException("Android declined accessibility tap gesture."))
        }
    }

    fun swipeCoordinates(
        startX: Float,
        startY: Float,
        endX: Float,
        endY: Float,
        durationMs: Long = 320L
    ): Result<String> {
        val dm = resources.displayMetrics
        val maxW = (dm.widthPixels - 1).coerceAtLeast(1).toFloat()
        val maxH = (dm.heightPixels - 1).coerceAtLeast(1).toFloat()
        val sx = startX.coerceIn(1f, maxW)
        val sy = startY.coerceIn(1f, maxH)
        val ex = endX.coerceIn(1f, maxW)
        val ey = endY.coerceIn(1f, maxH)
        val path = Path().apply {
            moveTo(sx, sy)
            lineTo(ex, ey)
        }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs.coerceIn(80L, 2000L))
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val dispatched = dispatchGesture(gesture, null, null)
        return if (dispatched) {
            Result.success("Swiped from (${sx.toInt()},${sy.toInt()}) to (${ex.toInt()},${ey.toInt()}).")
        } else {
            Result.failure(IllegalStateException("Android declined accessibility swipe gesture."))
        }
    }

    private fun findFocusedOrFirstEditable(node: AccessibilityNodeInfo?, depth: Int = 0): AccessibilityNodeInfo? {
        if (node == null || depth > 28) return null
        if (node.isEditable && node.isFocused) return node
        for (i in 0 until node.childCount) {
            findFocusedOrFirstEditable(node.getChild(i), depth + 1)?.let { return it }
        }
        return findFirstEditableDescendant(node)
    }

    private fun findFirstEditableDescendant(node: AccessibilityNodeInfo?, depth: Int = 0): AccessibilityNodeInfo? {
        if (node == null || depth > 28) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            findFirstEditableDescendant(node.getChild(i), depth + 1)?.let { return it }
        }
        return null
    }

    private fun findFirstScrollable(node: AccessibilityNodeInfo?, depth: Int = 0): AccessibilityNodeInfo? {
        if (node == null || depth > 28) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            findFirstScrollable(node.getChild(i), depth + 1)?.let { return it }
        }
        return null
    }
}
