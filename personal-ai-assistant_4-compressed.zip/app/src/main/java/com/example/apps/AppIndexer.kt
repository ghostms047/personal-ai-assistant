package com.example.apps

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.provider.Settings
import com.example.data.db.InstalledAppDao
import com.example.data.db.InstalledAppEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class AppIndexer(
    private val context: Context,
    private val installedAppDao: InstalledAppDao
) {
    val launchableAppsFlow: Flow<List<InstalledAppEntity>> = installedAppDao.observeLaunchableApps()
    val launchableCountFlow: Flow<Int> = installedAppDao.observeLaunchableCount()

    suspend fun refreshInstalledApps(): Int = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(
                mainIntent,
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(mainIntent, 0)
        }

        val now = System.currentTimeMillis()
        val seenPackages = HashSet<String>()
        val entities = mutableListOf<InstalledAppEntity>()

        for (resolveInfo in resolveInfos) {
            val activityInfo = resolveInfo.activityInfo ?: continue
            val pkg = activityInfo.packageName ?: continue
            if (!seenPackages.add(pkg)) continue

            val appName = resolveInfo.loadLabel(pm)?.toString()?.trim().orEmpty()
                .ifBlank { pkg }

            val pkgInfo = try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    pm.getPackageInfo(
                        pkg,
                        PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong())
                    )
                } else {
                    @Suppress("DEPRECATION")
                    pm.getPackageInfo(pkg, PackageManager.GET_PERMISSIONS)
                }
            } catch (_: Exception) {
                null
            }

            val versionName = pkgInfo?.versionName ?: "1.0"
            val versionCode = if (pkgInfo != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                pkgInfo.longVersionCode
            } else {
                @Suppress("DEPRECATION")
                (pkgInfo?.versionCode?.toLong() ?: 1L)
            }

            val appInfo = activityInfo.applicationInfo
            val category = mapCategory(appInfo)
            val perms = pkgInfo?.requestedPermissions
                ?.map { it.substringAfterLast('.') }
                ?.distinct()
                ?.take(8)
                ?.joinToString(", ")
                ?: "Standard"

            val launchIntent = pm.getLaunchIntentForPackage(pkg)
            entities.add(
                InstalledAppEntity(
                    packageName = pkg,
                    appName = appName,
                    versionName = versionName,
                    versionCode = versionCode,
                    isLaunchable = launchIntent != null,
                    category = category,
                    permissionsSummary = perms.ifBlank { "Standard" },
                    lastUpdatedAt = now
                )
            )
        }

        if (entities.isNotEmpty()) {
            installedAppDao.upsertAll(entities)
            installedAppDao.deleteStale(now)
        }
        entities.size
    }

    suspend fun searchApps(query: String): List<InstalledAppEntity> = withContext(Dispatchers.IO) {
        val cleaned = query.trim()
        val allLaunchable = installedAppDao.searchApps("", limit = 200)
        if (allLaunchable.isEmpty()) {
            refreshInstalledApps()
        }
        val direct = installedAppDao.searchApps(cleaned, limit = 30)
        if (direct.isNotEmpty()) return@withContext direct

        // Semantic/category keyword helper (e.g. "browser", "music", "photo editing")
        val lower = cleaned.lowercase()
        val all = installedAppDao.searchApps("", limit = 250)
        val semanticMatches = all.filter { app ->
            val hay = "${app.appName} ${app.packageName} ${app.category}".lowercase()
            when {
                lower.contains("browser") || lower.contains("web") ->
                    hay.contains("chrome") || hay.contains("browser") || hay.contains("firefox") ||
                        hay.contains("edge") || hay.contains("opera") || hay.contains("brave") ||
                        hay.contains("duckduckgo")
                lower.contains("music") || lower.contains("audio") ->
                    app.category.equals("Audio", ignoreCase = true) ||
                        hay.contains("music") || hay.contains("spotify") || hay.contains("ytmusic") ||
                        hay.contains("soundcloud") || hay.contains("podcast")
                lower.contains("photo") || lower.contains("image") || lower.contains("edit") ->
                    app.category.equals("Image", ignoreCase = true) ||
                        hay.contains("photo") || hay.contains("camera") || hay.contains("gallery") ||
                        hay.contains("lightroom") || hay.contains("snapseed") || hay.contains("canva")
                lower.contains("video") ->
                    app.category.equals("Video", ignoreCase = true) ||
                        hay.contains("youtube") || hay.contains("video") || hay.contains("vlc")
                lower.contains("map") || lower.contains("navigation") ->
                    app.category.equals("Maps", ignoreCase = true) ||
                        hay.contains("map") || hay.contains("waze") || hay.contains("navigation")
                lower.contains("mail") || lower.contains("email") ->
                    hay.contains("mail") || hay.contains("gmail") || hay.contains("outlook")
                lower.contains("message") || lower.contains("chat") ->
                    app.category.equals("Social", ignoreCase = true) ||
                        hay.contains("whatsapp") || hay.contains("telegram") || hay.contains("signal") ||
                        hay.contains("messages") || hay.contains("slack") || hay.contains("discord")
                lower.contains("game") || lower.contains("play") ->
                    app.category.equals("Game", ignoreCase = true) ||
                        hay.contains("game") || hay.contains("pubg") || hay.contains("minecraft") ||
                        hay.contains("roblox") || hay.contains("chess") || hay.contains("clash")
                else -> {
                    val tokens = lower.split(Regex("\\s+")).filter { it.length >= 2 }
                    tokens.any { hay.contains(it) }
                }
            }
        }
        semanticMatches.take(20)
    }

    suspend fun getInstalledGames(): List<InstalledAppEntity> = withContext(Dispatchers.IO) {
        val all = installedAppDao.searchApps("", limit = 250)
        if (all.isEmpty()) {
            refreshInstalledApps()
        }
        installedAppDao.searchApps("", limit = 250)
            .filter { it.category.equals("Game", ignoreCase = true) }
    }

    suspend fun getAppInfo(packageOrName: String): InstalledAppEntity? = withContext(Dispatchers.IO) {
        installedAppDao.getByPackage(packageOrName)
            ?: installedAppDao.searchApps(packageOrName, limit = 1).firstOrNull()
    }

    fun launchApp(packageName: String): Result<String> {
        return try {
            val pm = context.packageManager
            val intent = pm.getLaunchIntentForPackage(packageName)
                ?: return Result.failure(
                    IllegalStateException("App '$packageName' cannot be launched or is not installed.")
                )
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            Result.success(packageName)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun openAppSystemInfo(packageName: String): Result<Unit> {
        return try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:$packageName")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun loadAppIcon(packageName: String): Drawable? =
        try {
            context.packageManager.getApplicationIcon(packageName)
        } catch (_: Exception) {
            null
        }

    private fun mapCategory(appInfo: ApplicationInfo?): String {
        if (appInfo == null) return "Utility"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return when (appInfo.category) {
                ApplicationInfo.CATEGORY_GAME -> "Game"
                ApplicationInfo.CATEGORY_AUDIO -> "Audio"
                ApplicationInfo.CATEGORY_VIDEO -> "Video"
                ApplicationInfo.CATEGORY_IMAGE -> "Image"
                ApplicationInfo.CATEGORY_SOCIAL -> "Social"
                ApplicationInfo.CATEGORY_NEWS -> "News"
                ApplicationInfo.CATEGORY_MAPS -> "Maps"
                ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productivity"
                ApplicationInfo.CATEGORY_ACCESSIBILITY -> "Accessibility"
                else -> "Utility"
            }
        }
        return "Utility"
    }
}
