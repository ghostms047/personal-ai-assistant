package com.example.speech

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.content.ContextCompat
import com.example.data.settings.AiSettings
import com.example.data.settings.SpeechSettings
import com.example.data.settings.TtsEngineMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit

data class SystemVoiceInfo(
    val name: String,
    val localeTag: String,
    val isNetworkConnectionRequired: Boolean,
    val quality: Int
)

class SpeechAiManager(private val context: Context) {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val _isTtsReady = MutableStateFlow(false)
    val isTtsReady: StateFlow<Boolean> = _isTtsReady.asStateFlow()

    private val _availableVoices = MutableStateFlow<List<SystemVoiceInfo>>(emptyList())
    val availableVoices: StateFlow<List<SystemVoiceInfo>> = _availableVoices.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isRecordingCloudStt = MutableStateFlow(false)
    val isRecordingCloudStt: StateFlow<Boolean> = _isRecordingCloudStt.asStateFlow()

    private val _isTranscribingCloudStt = MutableStateFlow(false)
    val isTranscribingCloudStt: StateFlow<Boolean> = _isTranscribingCloudStt.asStateFlow()

    private var tts: TextToSpeech? = null
    private var mediaPlayer: MediaPlayer? = null
    private var mediaRecorder: MediaRecorder? = null
    private var activeRecordingFile: File? = null
    private var activeTtsAudioFile: File? = null

    init {
        initSystemTts()
    }

    private fun initSystemTts() {
        try {
            tts = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    _isTtsReady.value = true
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            _isSpeaking.value = true
                        }

                        override fun onDone(utteranceId: String?) {
                            _isSpeaking.value = false
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            _isSpeaking.value = false
                        }

                        override fun onError(utteranceId: String?, errorCode: Int) {
                            _isSpeaking.value = false
                        }
                    })
                    refreshVoices()
                } else {
                    _isTtsReady.value = false
                }
            }
        } catch (_: Throwable) {
            _isTtsReady.value = false
        }
    }

    fun refreshVoices() {
        val engine = tts ?: return
        try {
            val defaultLang = Locale.getDefault().language
            val voices = engine.voices.orEmpty()
                .map { voice ->
                    SystemVoiceInfo(
                        name = voice.name,
                        localeTag = voice.locale?.toLanguageTag().orEmpty(),
                        isNetworkConnectionRequired = voice.isNetworkConnectionRequired,
                        quality = voice.quality
                    )
                }
                .sortedWith(
                    compareByDescending<SystemVoiceInfo> { it.localeTag.startsWith(defaultLang) }
                        .thenBy { it.isNetworkConnectionRequired }
                        .thenByDescending { it.quality }
                        .thenBy { it.name }
                )
            _availableVoices.value = voices
        } catch (_: Throwable) {
            _availableVoices.value = emptyList()
        }
    }

    suspend fun speakText(
        text: String,
        speechSettings: SpeechSettings,
        aiSettings: AiSettings
    ): Result<Unit> {
        val cleaned = cleanTextForSpeech(text)
        if (cleaned.isBlank()) {
            return Result.failure(IllegalArgumentException("Nothing to speak."))
        }
        stopSpeaking()

        return when (speechSettings.ttsEngine) {
            TtsEngineMode.SYSTEM_TTS -> speakWithSystemTts(cleaned, speechSettings)
            TtsEngineMode.CLOUD_TTS -> speakWithCloudTts(cleaned, speechSettings, aiSettings)
        }
    }

    private fun speakWithSystemTts(
        text: String,
        settings: SpeechSettings
    ): Result<Unit> {
        val engine = tts
        if (engine == null || !_isTtsReady.value) {
            return Result.failure(
                IllegalStateException("System Text-to-Speech is not ready. Install a voice pack in Models & Speech.")
            )
        }
        return try {
            if (settings.systemVoiceName.isNotBlank()) {
                val match = engine.voices?.firstOrNull { it.name == settings.systemVoiceName }
                if (match != null) {
                    engine.voice = match
                }
            }
            engine.setSpeechRate(settings.speechRate.coerceIn(0.5f, 2.0f))
            engine.setPitch(settings.speechPitch.coerceIn(0.5f, 2.0f))
            val res = engine.speak(
                text.take(3900),
                TextToSpeech.QUEUE_FLUSH,
                null,
                "utt_${UUID.randomUUID()}"
            )
            if (res == TextToSpeech.ERROR) {
                Result.failure(IllegalStateException("System TTS failed to queue speech."))
            } else {
                _isSpeaking.value = true
                Result.success(Unit)
            }
        } catch (e: Exception) {
            _isSpeaking.value = false
            Result.failure(e)
        }
    }

    private suspend fun speakWithCloudTts(
        text: String,
        speechSettings: SpeechSettings,
        aiSettings: AiSettings
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val baseUrl = resolveSpeechBaseUrl(speechSettings, aiSettings)
            ?: return@withContext Result.failure(
                IllegalStateException("Configure a Cloud Speech Base URL (or OpenAI-compatible provider URL) first.")
            )
        val apiKey = speechSettings.cloudSpeechApiKey.ifBlank { aiSettings.apiKey }.trim()
        val allowKeyless = aiSettings.allowEmptyKey ||
            speechSettings.defaultDownloadedTtsModelId != null ||
            isLocalSpeechEndpoint(baseUrl)
        if (apiKey.isBlank() && !allowKeyless) {
            return@withContext Result.failure(
                IllegalStateException("No API key found for Cloud Speech TTS.")
            )
        }

        val url = if (baseUrl.endsWith("/audio/speech")) baseUrl else "$baseUrl/audio/speech"
        val payload = JSONObject()
            .put("model", speechSettings.cloudTtsModel.ifBlank { "gpt-4o-mini-tts" })
            .put("input", text.take(4000))
            .put("voice", speechSettings.cloudTtsVoice.ifBlank { "alloy" })
            .put("response_format", "mp3")

        val reqBuilder = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))

        if (apiKey.isNotBlank()) {
            reqBuilder.addHeader("Authorization", "Bearer $apiKey")
        }

        try {
            httpClient.newCall(reqBuilder.build()).execute().use { response ->
                if (!response.isSuccessful) {
                    val errBody = response.body?.string().orEmpty()
                    val msg = runCatching {
                        JSONObject(errBody).optJSONObject("error")?.optString("message")
                    }.getOrNull().orEmpty()
                    return@withContext Result.failure(
                        IllegalStateException("Cloud TTS HTTP ${response.code}: ${msg.ifBlank { "Check Speech model & endpoint." }}")
                    )
                }

                val audioBytes = response.body?.bytes()
                    ?: return@withContext Result.failure(IllegalStateException("Cloud TTS returned empty audio."))
                val tempFile = File.createTempFile("cloud_tts_", ".mp3", context.cacheDir)
                tempFile.writeBytes(audioBytes)
                activeTtsAudioFile = tempFile

                withContext(Dispatchers.Main) {
                    playAudioFile(tempFile)
                }
                Result.success(Unit)
            }
        } catch (io: IOException) {
            Result.failure(IllegalStateException("Cloud TTS network error: ${io.localizedMessage}"))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun playAudioFile(file: File) {
        mediaPlayer?.release()
        val player = MediaPlayer()
        mediaPlayer = player
        player.setDataSource(file.absolutePath)
        player.setOnCompletionListener {
            _isSpeaking.value = false
            cleanupTtsPlayer()
        }
        player.setOnErrorListener { _, _, _ ->
            _isSpeaking.value = false
            cleanupTtsPlayer()
            true
        }
        player.prepare()
        player.start()
        _isSpeaking.value = true
    }

    fun stopSpeaking() {
        runCatching { tts?.stop() }
        cleanupTtsPlayer()
        _isSpeaking.value = false
    }

    private fun cleanupTtsPlayer() {
        runCatching {
            mediaPlayer?.stop()
        }
        runCatching {
            mediaPlayer?.release()
        }
        mediaPlayer = null
        activeTtsAudioFile?.delete()
        activeTtsAudioFile = null
    }

    fun startCloudSttRecording(): Result<Unit> {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return Result.failure(IllegalStateException("Microphone permission is required."))
        }
        cancelCloudSttRecording()

        return try {
            val outFile = File.createTempFile("whisper_stt_", ".m4a", context.cacheDir)
            val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            recorder.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(16000)
                setAudioEncodingBitRate(64000)
                setOutputFile(outFile.absolutePath)
                prepare()
                start()
            }
            mediaRecorder = recorder
            activeRecordingFile = outFile
            _isRecordingCloudStt.value = true
            Result.success(Unit)
        } catch (e: Exception) {
            cancelCloudSttRecording()
            Result.failure(IllegalStateException("Could not start microphone recording: ${e.localizedMessage}"))
        }
    }

    suspend fun stopAndTranscribeCloudStt(
        speechSettings: SpeechSettings,
        aiSettings: AiSettings
    ): Result<String> {
        val recorder = mediaRecorder
        val audioFile = activeRecordingFile
        mediaRecorder = null
        activeRecordingFile = null
        _isRecordingCloudStt.value = false

        try {
            recorder?.stop()
        } catch (_: Exception) {
            audioFile?.delete()
            runCatching { recorder?.release() }
            return Result.failure(IllegalStateException("Recording was too short or interrupted."))
        }
        runCatching { recorder?.release() }

        if (audioFile == null || !audioFile.exists() || audioFile.length() == 0L) {
            audioFile?.delete()
            return Result.failure(IllegalStateException("No audio was captured."))
        }

        val baseUrl = resolveSpeechBaseUrl(speechSettings, aiSettings)
        val apiKey = speechSettings.cloudSpeechApiKey.ifBlank { aiSettings.apiKey }.trim()
        val allowKeyless = aiSettings.allowEmptyKey ||
            speechSettings.defaultDownloadedSttModelId != null ||
            (baseUrl != null && isLocalSpeechEndpoint(baseUrl))
        if (baseUrl == null || (apiKey.isBlank() && !allowKeyless)) {
            audioFile.delete()
            return@stopAndTranscribeCloudStt Result.failure(
                IllegalStateException("Configure a Speech Base URL and API key (or local runner) in Models & Speech.")
            )
        }

        _isTranscribingCloudStt.value = true
        return withContext(Dispatchers.IO) {
            try {
                val url = if (baseUrl.endsWith("/audio/transcriptions")) baseUrl else "$baseUrl/audio/transcriptions"
                val multipart = MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart(
                        "file",
                        "speech.m4a",
                        audioFile.asRequestBody("audio/mp4".toMediaType())
                    )
                    .addFormDataPart("model", speechSettings.cloudSttModel.ifBlank { "whisper-1" })
                    .build()

                val reqBuilder = Request.Builder()
                    .url(url)
                    .post(multipart)
                if (apiKey.isNotBlank()) {
                    reqBuilder.addHeader("Authorization", "Bearer $apiKey")
                }

                httpClient.newCall(reqBuilder.build()).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        val err = runCatching {
                            JSONObject(raw).optJSONObject("error")?.optString("message")
                        }.getOrNull().orEmpty()
                        return@withContext Result.failure(
                            IllegalStateException("Whisper STT HTTP ${response.code}: ${err.ifBlank { "Check model & endpoint." }}")
                        )
                    }
                    val text = JSONObject(raw).optString("text").trim()
                    if (text.isBlank()) {
                        Result.failure(IllegalStateException("No speech detected in audio."))
                    } else {
                        Result.success(text)
                    }
                }
            } catch (io: IOException) {
                Result.failure(IllegalStateException("Whisper STT network error: ${io.localizedMessage}"))
            } catch (e: Exception) {
                Result.failure(e)
            } finally {
                audioFile.delete()
                _isTranscribingCloudStt.value = false
            }
        }
    }

    fun cancelCloudSttRecording() {
        runCatching { mediaRecorder?.stop() }
        runCatching { mediaRecorder?.release() }
        mediaRecorder = null
        activeRecordingFile?.delete()
        activeRecordingFile = null
        _isRecordingCloudStt.value = false
    }

    fun isOnDeviceSpeechRecognitionSupported(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            SpeechRecognizer.isOnDeviceRecognitionAvailable(context)

    fun createInstallTtsDataIntent(): Intent =
        Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun createTtsSettingsIntent(): Intent =
        Intent("com.android.settings.TTS_SETTINGS")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun shutdown() {
        stopSpeaking()
        cancelCloudSttRecording()
        runCatching { tts?.shutdown() }
        tts = null
    }

    companion object {
        fun isLocalSpeechEndpoint(url: String): Boolean {
            val lower = url.trim().lowercase()
            return lower.startsWith("http://127.0.0.1") ||
                lower.startsWith("http://localhost") ||
                lower.startsWith("http://10.0.2.2") ||
                lower.startsWith("http://192.168.") ||
                lower.startsWith("http://10.")
        }

        fun resolveSpeechBaseUrl(speechSettings: SpeechSettings, aiSettings: AiSettings): String? {
            val explicit = speechSettings.cloudSpeechBaseUrl.trim().trimEnd('/')
            if (explicit.startsWith("https://") || explicit.startsWith("http://")) {
                return explicit
            }
            val aiBase = aiSettings.customBaseUrl.trim().trimEnd('/')
                .substringBefore("?")
                .removeSuffix("/chat/completions")
                .removeSuffix("/messages")
            val isOpenAiStyleSpeechCapable =
                aiSettings.provider.id in setOf("openai", "groq", "custom") &&
                    (aiBase.startsWith("https://") || aiBase.startsWith("http://"))
            return if (isOpenAiStyleSpeechCapable) aiBase else null
        }

        fun cleanTextForSpeech(raw: String): String =
            raw.replace(Regex("```[\\s\\S]*?```"), " code block ")
                .replace("**", "")
                .replace("__", "")
                .replace("`", "")
                .replace(Regex("^#+\\s*", RegexOption.MULTILINE), "")
                .trim()
    }
}
