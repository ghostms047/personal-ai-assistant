package com.example.memory

import com.example.data.db.MemoryDao
import com.example.data.db.MemoryEntity
import com.example.data.settings.SettingsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class MemoryRepository(
    private val memoryDao: MemoryDao,
    private val settingsRepository: SettingsRepository
) {
    val memoriesFlow: Flow<List<MemoryEntity>> = memoryDao.observeAll()

    suspend fun isMemoryEnabled(): Boolean =
        settingsRepository.assistantSettingsFlow.first().memoryEnabled

    suspend fun saveMemory(fact: String, category: String = "General"): Boolean {
        if (!isMemoryEnabled()) return false
        val cleaned = fact.trim()
        if (cleaned.isBlank() || containsPotentialSecret(cleaned)) return false
        val existing = memoryDao.findExact(cleaned)
        if (existing != null) {
            memoryDao.insert(existing.copy(updatedAt = System.currentTimeMillis()))
            return true
        }
        memoryDao.insert(
            MemoryEntity(
                fact = cleaned.take(280),
                category = category.take(40)
            )
        )
        return true
    }

    suspend fun deleteMemory(id: Long) {
        memoryDao.deleteById(id)
    }

    suspend fun clearAll() {
        memoryDao.clearAll()
    }

    suspend fun getPromptContext(): String {
        if (!isMemoryEnabled()) return ""
        val items = memoryDao.getTopMemories(15)
        if (items.isEmpty()) return ""
        return items.joinToString("\n") { "- [${it.category}] ${it.fact}" }
    }

    private fun containsPotentialSecret(text: String): Boolean {
        val lower = text.lowercase()
        val secretKeywords = listOf("api key", "api_key", "password", "passcode", "secret key", "token=")
        if (secretKeywords.any { lower.contains(it) }) return true
        if (text.contains("AIza") || text.contains("sk-")) return true
        return false
    }
}
