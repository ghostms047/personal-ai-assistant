package com.example.patterns

import com.example.data.db.UserPatternDao
import com.example.data.db.UserPatternEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

@Serializable
data class PatternStep(
    val action: String,      // open_app, open_settings, click_element, type_text, tap_coordinates, swipe, scroll, scan_viruses, open_url, wait
    val target: String = "", // package/app name, element label, coordinates "x,y", direction, or URL
    val value: String = "",  // optional text to type or swipe end "x2,y2"
    val delayMs: Long = 350L
)

class PatternRepository(
    private val userPatternDao: UserPatternDao
) {
    val patternsFlow: Flow<List<UserPatternEntity>> = userPatternDao.observeAll()

    suspend fun getAllPatterns(): List<UserPatternEntity> = userPatternDao.getAllOnce()

    suspend fun findMatchingPattern(userInput: String): UserPatternEntity? {
        val clean = userInput.trim()
        if (clean.length < 2) return null
        return userPatternDao.findBestMatch(clean)
    }

    suspend fun savePattern(
        name: String,
        triggerPhrase: String,
        description: String,
        steps: List<PatternStep>
    ): Long {
        val cleanName = name.trim().ifBlank { triggerPhrase.trim() }
        val cleanTrigger = triggerPhrase.trim().ifBlank { cleanName }
        val stepsJson = encodeSteps(steps)
        val existing = userPatternDao.findBestMatch(cleanTrigger)
        val now = System.currentTimeMillis()
        val entity = if (existing != null && existing.triggerPhrase.equals(cleanTrigger, ignoreCase = true)) {
            existing.copy(
                name = cleanName,
                description = description.trim(),
                stepsJson = stepsJson,
                updatedAt = now
            )
        } else {
            UserPatternEntity(
                name = cleanName,
                triggerPhrase = cleanTrigger,
                description = description.trim(),
                stepsJson = stepsJson,
                createdAt = now,
                updatedAt = now
            )
        }
        return userPatternDao.upsert(entity)
    }

    suspend fun savePatternRaw(
        name: String,
        triggerPhrase: String,
        description: String,
        stepsJson: String
    ): Long {
        val parsed = decodeSteps(stepsJson)
        return savePattern(name, triggerPhrase, description, parsed)
    }

    suspend fun recordPatternUsed(id: Long) {
        userPatternDao.recordUsage(id)
    }

    suspend fun deletePattern(id: Long) {
        userPatternDao.deleteById(id)
    }

    suspend fun getPromptContext(): String {
        val patterns = userPatternDao.getAllOnce().take(12)
        if (patterns.isEmpty()) return ""
        return patterns.joinToString("\n") { p ->
            val stepCount = decodeSteps(p.stepsJson).size
            "- Pattern \"${p.name}\" (trigger: \"${p.triggerPhrase}\", $stepCount steps, used ${p.useCount}x): ${p.description}"
        }
    }

    companion object {
        val supportedActions = listOf(
            "open_app",
            "click_element",
            "type_text",
            "tap_coordinates",
            "swipe",
            "scroll",
            "open_settings",
            "scan_viruses",
            "open_url",
            "wait"
        )

        private val json = Json {
            ignoreUnknownKeys = true
            encodeDefaults = true
        }

        fun encodeSteps(steps: List<PatternStep>): String {
            val sanitized = steps.map { step ->
                PatternStep(
                    action = step.action.trim().lowercase(),
                    target = step.target.trim(),
                    value = step.value.trim(),
                    delayMs = step.delayMs.coerceIn(0L, 10000L)
                )
            }
            return json.encodeToString(sanitized)
        }

        fun decodeSteps(stepsJson: String): List<PatternStep> {
            if (stepsJson.isBlank()) return emptyList()
            return try {
                json.decodeFromString<List<PatternStep>>(stepsJson)
                    .map { step ->
                        step.copy(
                            action = step.action.trim().lowercase(),
                            target = step.target.trim(),
                            value = step.value.trim(),
                            delayMs = step.delayMs.coerceIn(0L, 10000L)
                        )
                    }
                    .filter { it.action.isNotBlank() }
            } catch (_: Exception) {
                emptyList()
            }
        }
    }
}
