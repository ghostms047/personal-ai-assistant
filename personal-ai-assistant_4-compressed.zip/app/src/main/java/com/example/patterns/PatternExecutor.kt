package com.example.patterns

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.example.apps.AppIndexer
import com.example.data.db.UserPatternEntity
import com.example.screen.ScreenUnderstandingRepository
import com.example.security.SecurityScanner
import kotlinx.coroutines.delay

data class PatternRunReport(
    val patternName: String,
    val succeededSteps: Int,
    val totalSteps: Int,
    val logs: List<String>,
    val allSucceeded: Boolean
)

class PatternExecutor(
    private val context: Context,
    private val appIndexer: AppIndexer,
    private val screenRepo: ScreenUnderstandingRepository,
    private val securityScanner: SecurityScanner,
    private val patternRepository: PatternRepository
) {
    suspend fun execute(pattern: UserPatternEntity): PatternRunReport {
        val steps = PatternRepository.decodeSteps(pattern.stepsJson)
        if (steps.isEmpty()) {
            return PatternRunReport(
                patternName = pattern.name,
                succeededSteps = 0,
                totalSteps = 0,
                logs = listOf("Pattern \"${pattern.name}\" has no steps."),
                allSucceeded = false
            )
        }

        patternRepository.recordPatternUsed(pattern.id)

        val logs = mutableListOf<String>()
        var succeeded = 0

        for ((index, step) in steps.withIndex()) {
            val stepNum = index + 1
            val stepResult = executeSingleStep(step)
            if (stepResult.isSuccess) {
                succeeded++
                logs += "Step $stepNum (${step.action}): ${stepResult.getOrNull() ?: "Done"}"
            } else {
                logs += "Step $stepNum (${step.action}) failed: ${stepResult.exceptionOrNull()?.localizedMessage ?: "Error"}"
            }
            if (step.delayMs > 0L && index < steps.lastIndex) {
                delay(step.delayMs.coerceIn(50L, 5000L))
            }
        }

        return PatternRunReport(
            patternName = pattern.name,
            succeededSteps = succeeded,
            totalSteps = steps.size,
            logs = logs,
            allSucceeded = succeeded == steps.size
        )
    }

    private suspend fun executeSingleStep(step: PatternStep): Result<String> {
        return when (step.action.lowercase().trim()) {
            "open_app" -> {
                val query = step.target.ifBlank { step.value }
                if (query.isBlank()) {
                    Result.failure(IllegalArgumentException("Missing app name or package"))
                } else {
                    val direct = appIndexer.launchApp(query)
                    if (direct.isSuccess) {
                        Result.success("Opened $query")
                    } else {
                        val match = appIndexer.searchApps(query).firstOrNull()
                            ?: return Result.failure(IllegalStateException("App \"$query\" not found"))
                        appIndexer.launchApp(match.packageName).map { "Opened ${match.appName}" }
                    }
                }
            }
            "click_element" -> screenRepo.clickElementByQuery(step.target.ifBlank { step.value })
            "type_text" -> screenRepo.typeInElement(step.target, step.value)
            "tap_coordinates" -> {
                val coords = parseCoords(step.target.ifBlank { step.value })
                    ?: return Result.failure(IllegalArgumentException("Invalid tap coordinates '${step.target}'. Use 'x,y'."))
                screenRepo.tapCoordinates(coords.first, coords.second)
            }
            "swipe" -> {
                val start = parseCoords(step.target)
                    ?: return Result.failure(IllegalArgumentException("Invalid swipe start '${step.target}'. Use 'x,y'."))
                val end = parseCoords(step.value)
                    ?: return Result.failure(IllegalArgumentException("Invalid swipe end '${step.value}'. Use 'x,y'."))
                screenRepo.swipeCoordinates(start.first, start.second, end.first, end.second)
            }
            "scroll" -> screenRepo.scrollScreen(step.target.ifBlank { step.value }.ifBlank { "down" })
            "open_settings" -> runCatching {
                val action = when (step.target.lowercase()) {
                    "wifi" -> Settings.ACTION_WIFI_SETTINGS
                    "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
                    "apps" -> Settings.ACTION_APPLICATION_SETTINGS
                    "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
                    else -> Settings.ACTION_SETTINGS
                }
                context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "Opened ${step.target.ifBlank { "general" }} settings"
            }
            "open_url" -> runCatching {
                val raw = step.target.ifBlank { step.value }.trim()
                require(raw.startsWith("https://") || raw.startsWith("http://")) {
                    "Only http/https URLs are supported"
                }
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(raw)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                "Opened URL $raw"
            }
            "scan_viruses" -> {
                val report = securityScanner.runFullScan()
                Result.success(report.overallStatusLabel)
            }
            "wait" -> {
                val waitMs = step.value.toLongOrNull() ?: step.target.toLongOrNull() ?: step.delayMs
                delay(waitMs.coerceIn(50L, 5000L))
                Result.success("Waited ${waitMs}ms")
            }
            else -> Result.failure(IllegalArgumentException("Unsupported pattern step '${step.action}'"))
        }
    }

    private fun parseCoords(raw: String): Pair<Float, Float>? {
        val parts = raw.split(',', 'x', ' ').mapNotNull { it.trim().toFloatOrNull() }
        if (parts.size < 2) return null
        return parts[0] to parts[1]
    }
}
