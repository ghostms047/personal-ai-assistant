package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface IndexedFileDao {

    @Query("SELECT * FROM indexed_files ORDER BY modifiedAt DESC LIMIT :limit OFFSET :offset")
    fun observePagedFiles(limit: Int, offset: Int): Flow<List<IndexedFileEntity>>

    @Query("SELECT * FROM indexed_files ORDER BY modifiedAt DESC LIMIT :limit")
    fun observeRecentFiles(limit: Int = 50): Flow<List<IndexedFileEntity>>

    @Query("SELECT COUNT(*) FROM indexed_files")
    fun observeTotalCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM indexed_files WHERE category = :category")
    fun observeCategoryCount(category: String): Flow<Int>

    @Query("SELECT COUNT(*) FROM indexed_files")
    suspend fun getTotalCount(): Int

    @Query(
        """
        SELECT * FROM indexed_files
        WHERE (:category IS NULL OR category = :category)
          AND (:extension IS NULL OR LOWER(extension) = LOWER(:extension))
          AND (:minModified IS NULL OR modifiedAt >= :minModified)
          AND (:maxModified IS NULL OR modifiedAt <= :maxModified)
          AND (
            :query = ''
            OR LOWER(name) LIKE '%' || LOWER(:query) || '%'
            OR LOWER(displayPath) LIKE '%' || LOWER(:query) || '%'
            OR LOWER(folderName) LIKE '%' || LOWER(:query) || '%'
            OR LOWER(extractedText) LIKE '%' || LOWER(:query) || '%'
            OR LOWER(mimeType) LIKE '%' || LOWER(:query) || '%'
          )
        ORDER BY modifiedAt DESC
        LIMIT :limit
        """
    )
    suspend fun searchFiles(
        query: String,
        category: String? = null,
        extension: String? = null,
        minModified: Long? = null,
        maxModified: Long? = null,
        limit: Int = 40
    ): List<IndexedFileEntity>

    @Query("SELECT * FROM indexed_files WHERE uriString = :uriString LIMIT 1")
    suspend fun getByUri(uriString: String): IndexedFileEntity?

    @Query("SELECT uriString FROM indexed_files WHERE sourceType = :sourceType")
    suspend fun getUrisBySource(sourceType: String): List<String>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(files: List<IndexedFileEntity>)

    @Query("DELETE FROM indexed_files WHERE lastIndexedAt < :cutoffTimestamp AND sourceType = :sourceType")
    suspend fun deleteStaleBySource(sourceType: String, cutoffTimestamp: Long)

    @Query("DELETE FROM indexed_files WHERE uriString = :uriString")
    suspend fun deleteByUri(uriString: String)

    @Query("DELETE FROM indexed_files")
    suspend fun clearAll()
}

@Dao
interface IndexProgressDao {
    @Query("SELECT * FROM index_progress WHERE id = 1")
    fun observeProgress(): Flow<IndexProgressEntity?>

    @Query("SELECT * FROM index_progress WHERE id = 1")
    suspend fun getProgress(): IndexProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProgress(progress: IndexProgressEntity)
}

@Dao
interface InstalledAppDao {
    @Query("SELECT * FROM installed_apps WHERE isLaunchable = 1 ORDER BY appName ASC")
    fun observeLaunchableApps(): Flow<List<InstalledAppEntity>>

    @Query("SELECT COUNT(*) FROM installed_apps WHERE isLaunchable = 1")
    fun observeLaunchableCount(): Flow<Int>

    @Query(
        """
        SELECT * FROM installed_apps
        WHERE isLaunchable = 1
          AND (
            :query = ''
            OR LOWER(appName) LIKE '%' || LOWER(:query) || '%'
            OR LOWER(packageName) LIKE '%' || LOWER(:query) || '%'
            OR LOWER(category) LIKE '%' || LOWER(:query) || '%'
          )
        ORDER BY appName ASC
        LIMIT :limit
        """
    )
    suspend fun searchApps(query: String, limit: Int = 30): List<InstalledAppEntity>

    @Query("SELECT * FROM installed_apps WHERE packageName = :packageName LIMIT 1")
    suspend fun getByPackage(packageName: String): InstalledAppEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(apps: List<InstalledAppEntity>)

    @Query("DELETE FROM installed_apps WHERE lastUpdatedAt < :cutoff")
    suspend fun deleteStale(cutoff: Long)
}

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY timestamp ASC, id ASC")
    fun observeMessages(sessionId: String): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY timestamp DESC, id DESC LIMIT :limit")
    suspend fun getRecentMessages(sessionId: String, limit: Int = 24): List<ChatMessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: ChatMessageEntity): Long

    @Query("UPDATE chat_messages SET pendingConfirmationJson = NULL WHERE id = :id")
    suspend fun clearPendingConfirmation(id: Long)

    @Query("UPDATE chat_messages SET optionsJson = NULL WHERE id = :id")
    suspend fun clearOptions(id: Long)

    @Query("SELECT * FROM chat_messages WHERE role = 'USER' AND sessionId != 'floating_session' ORDER BY timestamp ASC, id ASC")
    fun observeAllUserChatMessages(): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY timestamp ASC, id ASC")
    suspend fun getMessagesForSessionOnce(sessionId: String): List<ChatMessageEntity>

    @Query(
        """
        SELECT * FROM chat_messages
        WHERE sessionId != 'floating_session'
          AND LOWER(content) LIKE '%' || LOWER(:query) || '%'
        ORDER BY timestamp DESC
        LIMIT :limit
        """
    )
    suspend fun searchMessages(query: String, limit: Int = 40): List<ChatMessageEntity>

    @Query("SELECT COUNT(*) FROM chat_messages WHERE sessionId != 'floating_session'")
    fun observeTotalChatMessagesCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM chat_messages WHERE sessionId = :sessionId")
    suspend fun getSessionMessageCount(sessionId: String): Int

    @Query("DELETE FROM chat_messages WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM chat_messages WHERE sessionId = :sessionId")
    suspend fun clearSession(sessionId: String)

    @Query("DELETE FROM chat_messages WHERE sessionId != 'floating_session'")
    suspend fun clearAllChatMessages()
}

@Dao
interface MemoryDao {
    @Query("SELECT * FROM memories ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<MemoryEntity>>

    @Query("SELECT * FROM memories ORDER BY updatedAt DESC LIMIT :limit")
    suspend fun getTopMemories(limit: Int = 25): List<MemoryEntity>

    @Query("SELECT * FROM memories WHERE LOWER(fact) = LOWER(:fact) LIMIT 1")
    suspend fun findExact(fact: String): MemoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(memory: MemoryEntity): Long

    @Query("DELETE FROM memories WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM memories")
    suspend fun clearAll()
}

@Dao
interface CachedProviderModelDao {
    @Query("SELECT * FROM cached_provider_models WHERE providerId = :providerId ORDER BY capability ASC, modelId ASC")
    fun observeByProvider(providerId: String): Flow<List<CachedProviderModelEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(models: List<CachedProviderModelEntity>)

    @Query("DELETE FROM cached_provider_models WHERE providerId = :providerId")
    suspend fun deleteForProvider(providerId: String)
}

@Dao
interface DownloadedModelDao {
    @Query("SELECT * FROM downloaded_models ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<DownloadedModelEntity>>

    @Query("SELECT * FROM downloaded_models ORDER BY updatedAt DESC")
    suspend fun getAllOnce(): List<DownloadedModelEntity>

    @Query("SELECT * FROM downloaded_models WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): DownloadedModelEntity?

    @Query("SELECT * FROM downloaded_models WHERE downloadUrl = :url LIMIT 1")
    suspend fun getByUrl(url: String): DownloadedModelEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(model: DownloadedModelEntity): Long

    @Query("UPDATE downloaded_models SET status = :status, errorMessage = :errorMessage, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updateStatus(id: Long, status: String, errorMessage: String?, updatedAt: Long)

    @Query("DELETE FROM downloaded_models WHERE id = :id")
    suspend fun deleteById(id: Long)
}

@Dao
interface ChatSessionDao {
    @Query("SELECT * FROM chat_sessions ORDER BY isPinned DESC, updatedAt DESC")
    fun observeAllSessions(): Flow<List<ChatSessionEntity>>

    @Query(
        """
        SELECT * FROM chat_sessions
        WHERE LOWER(title) LIKE '%' || LOWER(:query) || '%'
           OR LOWER(lastMessagePreview) LIKE '%' || LOWER(:query) || '%'
        ORDER BY isPinned DESC, updatedAt DESC
        """
    )
    suspend fun searchSessions(query: String): List<ChatSessionEntity>

    @Query("SELECT * FROM chat_sessions WHERE sessionId = :sessionId LIMIT 1")
    suspend fun getById(sessionId: String): ChatSessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(session: ChatSessionEntity)

    @Query("UPDATE chat_sessions SET isPinned = :pinned WHERE sessionId = :sessionId")
    suspend fun setPinned(sessionId: String, pinned: Boolean)

    @Query("UPDATE chat_sessions SET title = :title WHERE sessionId = :sessionId")
    suspend fun renameSession(sessionId: String, title: String)

    @Query("DELETE FROM chat_sessions WHERE sessionId = :sessionId")
    suspend fun deleteById(sessionId: String)

    @Query("DELETE FROM chat_sessions")
    suspend fun clearAll()
}

@Dao
interface UserPatternDao {
    @Query("SELECT * FROM user_patterns ORDER BY useCount DESC, updatedAt DESC")
    fun observeAll(): Flow<List<UserPatternEntity>>

    @Query("SELECT * FROM user_patterns ORDER BY useCount DESC, updatedAt DESC")
    suspend fun getAllOnce(): List<UserPatternEntity>

    @Query("SELECT * FROM user_patterns WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): UserPatternEntity?

    @Query(
        """
        SELECT * FROM user_patterns
        WHERE LOWER(triggerPhrase) = LOWER(:query)
           OR LOWER(name) = LOWER(:query)
           OR LOWER(:query) LIKE '%' || LOWER(triggerPhrase) || '%'
        ORDER BY LENGTH(triggerPhrase) DESC, useCount DESC
        LIMIT 1
        """
    )
    suspend fun findBestMatch(query: String): UserPatternEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(pattern: UserPatternEntity): Long

    @Query("UPDATE user_patterns SET useCount = useCount + 1, lastUsedAt = :timestamp, updatedAt = :timestamp WHERE id = :id")
    suspend fun recordUsage(id: Long, timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM user_patterns WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM user_patterns")
    suspend fun clearAll()
}
