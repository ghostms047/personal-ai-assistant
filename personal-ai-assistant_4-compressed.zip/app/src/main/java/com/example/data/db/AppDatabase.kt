package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        IndexedFileEntity::class,
        IndexProgressEntity::class,
        InstalledAppEntity::class,
        ChatMessageEntity::class,
        MemoryEntity::class,
        CachedProviderModelEntity::class,
        DownloadedModelEntity::class,
        ChatSessionEntity::class,
        UserPatternEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun indexedFileDao(): IndexedFileDao
    abstract fun indexProgressDao(): IndexProgressDao
    abstract fun installedAppDao(): InstalledAppDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun memoryDao(): MemoryDao
    abstract fun cachedProviderModelDao(): CachedProviderModelDao
    abstract fun downloadedModelDao(): DownloadedModelDao
    abstract fun chatSessionDao(): ChatSessionDao
    abstract fun userPatternDao(): UserPatternDao

    companion object {
        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE downloaded_models ADD COLUMN architecture TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE downloaded_models ADD COLUMN quantization TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE downloaded_models ADD COLUMN contextLength INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE downloaded_models ADD COLUMN expectedSha256 TEXT NOT NULL DEFAULT ''")
                db.execSQL("ALTER TABLE downloaded_models ADD COLUMN expectedBytes INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE downloaded_models ADD COLUMN verifiedAt INTEGER NOT NULL DEFAULT 0")
                db.execSQL("ALTER TABLE downloaded_models ADD COLUMN compatibilityNote TEXT NOT NULL DEFAULT ''")
            }
        }

        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "personal_ai_local.db"
            )
                .addMigrations(MIGRATION_3_4)
                .build()
    }
}
