package com.example.data.settings

enum class AiApiProtocol(
    val id: String,
    val displayName: String,
    val defaultAuthHeader: String,
    val defaultAuthPrefix: String
) {
    OPENAI_COMPATIBLE(
        id = "openai_compatible",
        displayName = "OpenAI Chat Completions",
        defaultAuthHeader = "Authorization",
        defaultAuthPrefix = "Bearer "
    ),
    GEMINI(
        id = "gemini",
        displayName = "Google Gemini API",
        defaultAuthHeader = "x-goog-api-key",
        defaultAuthPrefix = ""
    ),
    ANTHROPIC(
        id = "anthropic",
        displayName = "Anthropic Messages API",
        defaultAuthHeader = "x-api-key",
        defaultAuthPrefix = ""
    );

    companion object {
        fun fromId(id: String?): AiApiProtocol? =
            entries.firstOrNull { it.id == id }
    }
}

enum class AiProviderType(
    val id: String,
    val displayName: String,
    val defaultProtocol: AiApiProtocol,
    val defaultBaseUrl: String,
    val defaultModel: String,
    val suggestedModels: List<String>,
    val keyHint: String,
    val defaultAuthHeader: String = defaultProtocol.defaultAuthHeader,
    val defaultAuthPrefix: String = defaultProtocol.defaultAuthPrefix,
    val supportsNativeToolsByDefault: Boolean = true
) {
    GEMINI(
        id = "gemini",
        displayName = "Google Gemini",
        defaultProtocol = AiApiProtocol.GEMINI,
        defaultBaseUrl = "https://generativelanguage.googleapis.com/v1beta",
        defaultModel = "gemini-2.5-flash",
        suggestedModels = listOf("gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash"),
        keyHint = "AIza..."
    ),
    OPENAI(
        id = "openai",
        displayName = "OpenAI",
        defaultProtocol = AiApiProtocol.OPENAI_COMPATIBLE,
        defaultBaseUrl = "https://api.openai.com/v1",
        defaultModel = "gpt-4o-mini",
        suggestedModels = listOf("gpt-4o-mini", "gpt-4o", "gpt-4.1-mini"),
        keyHint = "sk-..."
    ),
    ANTHROPIC(
        id = "anthropic",
        displayName = "Anthropic Claude",
        defaultProtocol = AiApiProtocol.ANTHROPIC,
        defaultBaseUrl = "https://api.anthropic.com/v1",
        defaultModel = "claude-3-5-haiku-latest",
        suggestedModels = listOf("claude-3-5-haiku-latest", "claude-3-7-sonnet-latest"),
        keyHint = "sk-ant-..."
    ),
    XAI(
        id = "xai",
        displayName = "xAI (Grok)",
        defaultProtocol = AiApiProtocol.OPENAI_COMPATIBLE,
        defaultBaseUrl = "https://api.x.ai/v1",
        defaultModel = "grok-3-mini",
        suggestedModels = listOf("grok-3-mini", "grok-3", "grok-2-latest"),
        keyHint = "xai-..."
    ),
    GROQ(
        id = "groq",
        displayName = "Groq",
        defaultProtocol = AiApiProtocol.OPENAI_COMPATIBLE,
        defaultBaseUrl = "https://api.groq.com/openai/v1",
        defaultModel = "llama-3.3-70b-versatile",
        suggestedModels = listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant", "mixtral-8x7b-32768"),
        keyHint = "gsk_..."
    ),
    MISTRAL(
        id = "mistral",
        displayName = "Mistral AI",
        defaultProtocol = AiApiProtocol.OPENAI_COMPATIBLE,
        defaultBaseUrl = "https://api.mistral.ai/v1",
        defaultModel = "mistral-small-latest",
        suggestedModels = listOf("mistral-small-latest", "mistral-large-latest", "codestral-latest"),
        keyHint = "Mistral API key"
    ),
    DEEPSEEK(
        id = "deepseek",
        displayName = "DeepSeek",
        defaultProtocol = AiApiProtocol.OPENAI_COMPATIBLE,
        defaultBaseUrl = "https://api.deepseek.com/v1",
        defaultModel = "deepseek-chat",
        suggestedModels = listOf("deepseek-chat", "deepseek-reasoner"),
        keyHint = "sk-..."
    ),
    OPENROUTER(
        id = "openrouter",
        displayName = "OpenRouter",
        defaultProtocol = AiApiProtocol.OPENAI_COMPATIBLE,
        defaultBaseUrl = "https://openrouter.ai/api/v1",
        defaultModel = "google/gemini-2.5-flash",
        suggestedModels = listOf("google/gemini-2.5-flash", "openai/gpt-4o-mini", "anthropic/claude-3.5-sonnet"),
        keyHint = "sk-or-..."
    ),
    TOGETHER(
        id = "together",
        displayName = "Together AI",
        defaultProtocol = AiApiProtocol.OPENAI_COMPATIBLE,
        defaultBaseUrl = "https://api.together.xyz/v1",
        defaultModel = "meta-llama/Llama-3.3-70B-Instruct-Turbo",
        suggestedModels = listOf("meta-llama/Llama-3.3-70B-Instruct-Turbo", "Qwen/Qwen2.5-72B-Instruct-Turbo"),
        keyHint = "Together API key"
    ),
    FIREWORKS(
        id = "fireworks",
        displayName = "Fireworks AI",
        defaultProtocol = AiApiProtocol.OPENAI_COMPATIBLE,
        defaultBaseUrl = "https://api.fireworks.ai/inference/v1",
        defaultModel = "accounts/fireworks/models/llama-v3p3-70b-instruct",
        suggestedModels = listOf("accounts/fireworks/models/llama-v3p3-70b-instruct"),
        keyHint = "fw_..."
    ),
    PERPLEXITY(
        id = "perplexity",
        displayName = "Perplexity",
        defaultProtocol = AiApiProtocol.OPENAI_COMPATIBLE,
        defaultBaseUrl = "https://api.perplexity.ai",
        defaultModel = "sonar",
        suggestedModels = listOf("sonar", "sonar-pro"),
        keyHint = "pplx-...",
        supportsNativeToolsByDefault = false
    ),
    COHERE(
        id = "cohere",
        displayName = "Cohere",
        defaultProtocol = AiApiProtocol.OPENAI_COMPATIBLE,
        defaultBaseUrl = "https://api.cohere.ai/compatibility/v1",
        defaultModel = "command-a-03-2025",
        suggestedModels = listOf("command-a-03-2025", "command-r-plus"),
        keyHint = "Cohere API key"
    ),
    AZURE_OPENAI(
        id = "azure_openai",
        displayName = "Azure OpenAI",
        defaultProtocol = AiApiProtocol.OPENAI_COMPATIBLE,
        defaultBaseUrl = "https://YOUR-RESOURCE.openai.azure.com/openai/deployments/YOUR-DEPLOYMENT/chat/completions?api-version=2024-10-21",
        defaultModel = "gpt-4o-mini",
        suggestedModels = listOf("gpt-4o-mini", "gpt-4o"),
        keyHint = "Azure OpenAI resource key",
        defaultAuthHeader = "api-key",
        defaultAuthPrefix = ""
    ),
    CUSTOM(
        id = "custom",
        displayName = "Custom / Any AI",
        defaultProtocol = AiApiProtocol.OPENAI_COMPATIBLE,
        defaultBaseUrl = "https://api.example.com/v1",
        defaultModel = "default-model",
        suggestedModels = emptyList(),
        keyHint = "Any API key or bearer token"
    );

    companion object {
        fun fromId(id: String?): AiProviderType =
            when (id) {
                "openai_compatible" -> OPENROUTER
                else -> entries.firstOrNull { it.id == id } ?: GEMINI
            }
    }
}

enum class ThemeMode(
    val id: String,
    val label: String,
    val subtitle: String
) {
    SYSTEM("system", "System Default", "Match device light or dark mode"),
    LIGHT("light", "Precision Light", "Crisp slate & cobalt light palette"),
    DARK("dark", "Obsidian Dark", "Deep charcoal & sky-cobalt dark palette"),
    PERSIAN("persian", "Persian (Firoozeh)", "Isfahan turquoise, lapis & saffron gold"),
    NEON("neon", "Neon Cyber", "Electric cyan, laser magenta & ultraviolet");

    companion object {
        fun fromId(id: String?): ThemeMode =
            entries.firstOrNull { it.id == id } ?: SYSTEM
    }
}

enum class AiRoutingMode(
    val id: String,
    val label: String,
    val shortLabel: String,
    val subtitle: String
) {
    AUTO_NETWORK(
        id = "auto",
        label = "Auto (Online → API Key, Offline → On-Device AI)",
        shortLabel = "Auto",
        subtitle = "Uses your Cloud API key when online, and automatically switches to your embedded On-Device AI model when offline."
    ),
    ONLY_API_KEY(
        id = "api_key_only",
        label = "API Key Only (Cloud)",
        shortLabel = "API Key Only",
        subtitle = "Always uses your configured Cloud AI API key (requires internet connection)."
    ),
    ONLY_LOCAL(
        id = "local_only",
        label = "Local AI Only (On-Device)",
        shortLabel = "Local Only",
        subtitle = "Runs GGUF models directly on your phone (or an optional external local server if enabled)."
    );

    companion object {
        fun fromId(id: String?): AiRoutingMode =
            entries.firstOrNull { it.id == id } ?: AUTO_NETWORK
    }
}

enum class AiRouteIssue {
    MISSING_API_KEY,
    OFFLINE_API_ONLY,
    MISSING_LOCAL_CONFIG
}

data class ResolvedAiRoute(
    val effectiveSettings: AiSettings,
    val isUsingLocal: Boolean,
    val isUsingEmbeddedRuntime: Boolean,
    val routeBadge: String,
    val issue: AiRouteIssue? = null
)

data class AiSettings(
    val provider: AiProviderType = AiProviderType.GEMINI,
    val protocol: AiApiProtocol = provider.defaultProtocol,
    val customProviderLabel: String = "",
    val apiKey: String = "",
    val model: String = provider.defaultModel,
    val customBaseUrl: String = provider.defaultBaseUrl,
    val authHeaderName: String = provider.defaultAuthHeader,
    val authHeaderPrefix: String = provider.defaultAuthPrefix,
    val enableNativeTools: Boolean = provider.supportsNativeToolsByDefault,
    val allowEmptyKey: Boolean = false,
    val temperature: Float = 0.2f,
    val defaultDownloadedTextModelId: Long? = null,
    val defaultDownloadedTextModelName: String = "",
    val defaultDownloadedTextModelPath: String = "",
    val routingMode: AiRoutingMode = AiRoutingMode.AUTO_NETWORK,
    val localUseExternalServer: Boolean = false,
    val localEndpointUrl: String = DEFAULT_LOCAL_ENDPOINT,
    val localModelName: String = DEFAULT_LOCAL_MODEL,
    val localApiKey: String = ""
) {
    val hasApiKey: Boolean get() = apiKey.isNotBlank() || allowEmptyKey

    val hasOnDeviceModelConfigured: Boolean
        get() = defaultDownloadedTextModelId != null && defaultDownloadedTextModelPath.isNotBlank()

    val hasExternalLocalServerConfigured: Boolean
        get() = localEndpointUrl.isNotBlank() && localModelName.isNotBlank()

    val hasLocalConfigured: Boolean
        get() = if (localUseExternalServer) hasExternalLocalServerConfigured else hasOnDeviceModelConfigured

    val effectiveDisplayName: String
        get() = when {
            defaultDownloadedTextModelId != null && defaultDownloadedTextModelName.isNotBlank() && routingMode != AiRoutingMode.ONLY_API_KEY ->
                defaultDownloadedTextModelName
            routingMode == AiRoutingMode.ONLY_LOCAL && localUseExternalServer ->
                "External Local Server ($localModelName)"
            provider == AiProviderType.CUSTOM && customProviderLabel.isNotBlank() ->
                customProviderLabel
            else -> provider.displayName
        }

    val effectiveActiveModelLabel: String
        get() = when {
            routingMode == AiRoutingMode.ONLY_LOCAL && !localUseExternalServer ->
                defaultDownloadedTextModelName.ifBlank { "No GGUF loaded" }
            routingMode == AiRoutingMode.ONLY_LOCAL && localUseExternalServer ->
                localModelName
            else -> model
        }

    val maskedApiKey: String
        get() = when {
            allowEmptyKey && apiKey.isBlank() -> "No key required"
            apiKey.isBlank() -> "Not configured"
            apiKey.length <= 8 -> "••••••••"
            else -> "${apiKey.take(4)}••••${apiKey.takeLast(4)}"
        }

    val effectiveAuthHeaderName: String
        get() = authHeaderName.trim().ifBlank { protocol.defaultAuthHeader }

    fun buildAuthHeaderValue(): String {
        val trimmedKey = apiKey.trim()
        if (trimmedKey.isBlank()) return ""
        return if (authHeaderPrefix.isNotEmpty() && !trimmedKey.startsWith(authHeaderPrefix, ignoreCase = true)) {
            "$authHeaderPrefix$trimmedKey"
        } else {
            trimmedKey
        }
    }

    fun buildOnDeviceAiConfig(): AiSettings {
        val targetModel = defaultDownloadedTextModelName
            .ifBlank { localModelName }
            .ifBlank { "On-Device GGUF" }
        return copy(
            customProviderLabel = "Local • On-device",
            model = targetModel,
            customBaseUrl = "",
            allowEmptyKey = true
        )
    }

    fun buildExternalLocalServerConfig(): AiSettings {
        val targetUrl = localEndpointUrl.trim().ifBlank { DEFAULT_LOCAL_ENDPOINT }
        val targetModel = localModelName.trim().ifBlank { DEFAULT_LOCAL_MODEL }
        return copy(
            provider = AiProviderType.CUSTOM,
            protocol = AiApiProtocol.OPENAI_COMPATIBLE,
            customProviderLabel = "External Server ($targetModel)",
            apiKey = localApiKey.trim(),
            model = targetModel,
            customBaseUrl = targetUrl,
            authHeaderName = AiApiProtocol.OPENAI_COMPATIBLE.defaultAuthHeader,
            authHeaderPrefix = AiApiProtocol.OPENAI_COMPATIBLE.defaultAuthPrefix,
            allowEmptyKey = localApiKey.isBlank()
        )
    }

    fun resolveEffectiveRoute(isOnline: Boolean): ResolvedAiRoute {
        val currentIsLoopback = isLoopbackEndpoint(customBaseUrl)
        return when (routingMode) {
            AiRoutingMode.ONLY_LOCAL -> resolveLocalTargetRoute(prefix = "Local Only")
            AiRoutingMode.ONLY_API_KEY -> {
                when {
                    !hasApiKey -> ResolvedAiRoute(
                        effectiveSettings = this,
                        isUsingLocal = false,
                        isUsingEmbeddedRuntime = false,
                        routeBadge = "API Key Only (Key Needed)",
                        issue = AiRouteIssue.MISSING_API_KEY
                    )
                    !currentIsLoopback && !isOnline -> ResolvedAiRoute(
                        effectiveSettings = this,
                        isUsingLocal = false,
                        isUsingEmbeddedRuntime = false,
                        routeBadge = "API Key Only (Offline)",
                        issue = AiRouteIssue.OFFLINE_API_ONLY
                    )
                    else -> ResolvedAiRoute(
                        effectiveSettings = this,
                        isUsingLocal = currentIsLoopback,
                        isUsingEmbeddedRuntime = false,
                        routeBadge = "API Key • $effectiveDisplayName (${model.substringAfterLast('/')})"
                    )
                }
            }
            AiRoutingMode.AUTO_NETWORK -> {
                if (isOnline) {
                    if (hasApiKey) {
                        ResolvedAiRoute(
                            effectiveSettings = this,
                            isUsingLocal = currentIsLoopback,
                            isUsingEmbeddedRuntime = false,
                            routeBadge = if (currentIsLoopback) {
                                "Auto • External ($model)"
                            } else {
                                "Auto • Online ($effectiveDisplayName)"
                            }
                        )
                    } else if (hasLocalConfigured) {
                        resolveLocalTargetRoute(prefix = "Local Fallback")
                    } else {
                        ResolvedAiRoute(
                            effectiveSettings = this,
                            isUsingLocal = false,
                            isUsingEmbeddedRuntime = false,
                            routeBadge = "Auto • Setup Needed",
                            issue = AiRouteIssue.MISSING_API_KEY
                        )
                    }
                } else {
                    resolveLocalTargetRoute(prefix = "Offline")
                }
            }
        }
    }

    private fun resolveLocalTargetRoute(prefix: String): ResolvedAiRoute {
        return if (localUseExternalServer) {
            val ext = buildExternalLocalServerConfig()
            if (!hasExternalLocalServerConfigured) {
                ResolvedAiRoute(
                    effectiveSettings = ext,
                    isUsingLocal = true,
                    isUsingEmbeddedRuntime = false,
                    routeBadge = "External Server (Unconfigured)",
                    issue = AiRouteIssue.MISSING_LOCAL_CONFIG
                )
            } else {
                ResolvedAiRoute(
                    effectiveSettings = ext,
                    isUsingLocal = true,
                    isUsingEmbeddedRuntime = false,
                    routeBadge = "$prefix • External Server (${ext.model})"
                )
            }
        } else {
            val onDevice = buildOnDeviceAiConfig()
            if (!hasOnDeviceModelConfigured) {
                ResolvedAiRoute(
                    effectiveSettings = onDevice,
                    isUsingLocal = true,
                    isUsingEmbeddedRuntime = true,
                    routeBadge = "Local • On-device (No Model)",
                    issue = AiRouteIssue.MISSING_LOCAL_CONFIG
                )
            } else {
                ResolvedAiRoute(
                    effectiveSettings = onDevice,
                    isUsingLocal = true,
                    isUsingEmbeddedRuntime = true,
                    routeBadge = "Local • On-device (${onDevice.model})"
                )
            }
        }
    }

    companion object {
        const val DEFAULT_LOCAL_ENDPOINT = "http://127.0.0.1:8080/v1"
        const val DEFAULT_LOCAL_MODEL = "gemma3:4b"

        fun isLoopbackEndpoint(url: String): Boolean {
            val lower = url.trim().lowercase()
            return lower.startsWith("http://127.0.0.1") ||
                lower.startsWith("http://localhost") ||
                lower.startsWith("http://10.0.2.2") ||
                lower.startsWith("https://127.0.0.1") ||
                lower.startsWith("https://localhost")
        }
    }
}

data class AssistantSettings(
    val assistantName: String = "Personal AI",
    val wakeWordEnabled: Boolean = false,
    val wakeAutoListenAfterTrigger: Boolean = false,
    val wakeTemplateJson: String = "",
    val visionEnabled: Boolean = false,
    val onboardingCompleted: Boolean = false,
    val memoryEnabled: Boolean = true,
    val confirmSensitiveActions: Boolean = true,
    val includeScreenContextAutomatically: Boolean = false,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val dynamicColor: Boolean = false,
    val indexMediaStorePublicItems: Boolean = true
)

data class FloatingSettings(
    val enabled: Boolean = false,
    val startOnRightEdge: Boolean = true,
    val bubbleOpacity: Float = 0.94f,
    val compactBubbleLabel: Boolean = true,
    val autoMinimizeAfterAction: Boolean = false
)

enum class TtsEngineMode(val id: String, val label: String) {
    SYSTEM_TTS("system_tts", "On-Device System Voice (TTS)"),
    CLOUD_TTS("cloud_tts", "Cloud Speech AI (OpenAI / Compatible)");

    companion object {
        fun fromId(id: String?): TtsEngineMode =
            entries.firstOrNull { it.id == id } ?: SYSTEM_TTS
    }
}

enum class SttEngineMode(val id: String, val label: String) {
    SYSTEM_STT("system_stt", "Android Speech Recognition"),
    CLOUD_WHISPER("cloud_whisper", "Cloud Whisper Speech AI");

    companion object {
        fun fromId(id: String?): SttEngineMode =
            entries.firstOrNull { it.id == id } ?: SYSTEM_STT
    }
}

data class SpeechSettings(
    val ttsEngine: TtsEngineMode = TtsEngineMode.SYSTEM_TTS,
    val sttEngine: SttEngineMode = SttEngineMode.SYSTEM_STT,
    val autoSpeakResponses: Boolean = false,
    val systemVoiceName: String = "",
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f,
    val cloudTtsModel: String = "gpt-4o-mini-tts",
    val cloudTtsVoice: String = "alloy",
    val cloudSttModel: String = "whisper-1",
    val cloudSpeechBaseUrl: String = "",
    val cloudSpeechApiKey: String = "",
    val defaultDownloadedTtsModelId: Long? = null,
    val defaultDownloadedTtsModelName: String = "",
    val defaultDownloadedSttModelId: Long? = null,
    val defaultDownloadedSttModelName: String = ""
)
