package com.example.floating

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DragIndicator
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Minimize
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.assistant.AssistantOrchestrator
import com.example.data.db.ChatMessageEntity
import com.example.data.settings.FloatingSettings
import com.example.data.settings.ThemeMode
import com.example.tools.AskUserOption
import com.example.tools.PendingConfirmation
import com.example.ui.components.PersonalAiLogo
import com.example.ui.theme.LocalThemeMode
import com.example.ui.theme.NeonPrimary
import com.example.ui.theme.NeonSecondary
import com.example.ui.theme.PersianPrimary
import com.example.ui.theme.PersianTertiary
import org.json.JSONArray
import org.json.JSONObject

@Composable
fun FloatingBubbleView(
    settings: FloatingSettings,
    isProcessing: Boolean,
    onTapExpand: () -> Unit,
    onDragDelta: (Float, Float) -> Unit
) {
    val themeMode = LocalThemeMode.current
    val bubbleShape = when (themeMode) {
        ThemeMode.NEON -> RoundedCornerShape(14.dp)
        ThemeMode.PERSIAN -> RoundedCornerShape(26.dp)
        else -> RoundedCornerShape(24.dp)
    }
    val bubbleBorder = when (themeMode) {
        ThemeMode.NEON -> BorderStroke(
            1.6.dp,
            Brush.linearGradient(listOf(NeonPrimary, NeonSecondary))
        )
        ThemeMode.PERSIAN -> BorderStroke(
            1.6.dp,
            Brush.linearGradient(listOf(PersianTertiary, PersianPrimary))
        )
        else -> BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    }
    val bubbleBg = when (themeMode) {
        ThemeMode.PERSIAN -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.92f)
        else -> MaterialTheme.colorScheme.surface
    }

    Surface(
        onClick = onTapExpand,
        shape = bubbleShape,
        color = bubbleBg,
        contentColor = MaterialTheme.colorScheme.onSurface,
        tonalElevation = 4.dp,
        shadowElevation = 10.dp,
        border = bubbleBorder,
        modifier = Modifier
            .alpha(settings.bubbleOpacity.coerceIn(0.6f, 1f))
            .testTag("floating_bubble_button")
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDragDelta(dragAmount.x, dragAmount.y)
                }
            }
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            if (isProcessing) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    strokeWidth = 2.dp
                )
            } else {
                PersonalAiLogo(
                    themeMode = themeMode,
                    size = 24.dp
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (settings.compactBubbleLabel) "AI" else "Personal AI",
                style = if (settings.compactBubbleLabel) {
                    MaterialTheme.typography.labelMedium
                } else {
                    MaterialTheme.typography.labelLarge
                },
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun FloatingPanelView(
    messages: List<ChatMessageEntity>,
    isProcessing: Boolean,
    activeToolStatus: String?,
    hasApiKey: Boolean,
    hasMicPermission: Boolean,
    isListening: Boolean,
    onSendMessage: (String, Boolean) -> Unit,
    onSelectOption: (Long, AskUserOption) -> Unit,
    onConfirmAction: (Long, PendingConfirmation, Boolean) -> Unit,
    onToggleListening: () -> Unit,
    onOpenFullApp: () -> Unit,
    onOpenApiKeySettings: () -> Unit,
    onMinimize: () -> Unit,
    onClose: () -> Unit,
    onDragHeaderDelta: (Float, Float) -> Unit
) {
    val themeMode = LocalThemeMode.current
    var inputText by remember { mutableStateOf("") }
    var attachScreen by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    val panelBorder = when (themeMode) {
        ThemeMode.NEON -> BorderStroke(
            1.6.dp,
            Brush.linearGradient(listOf(NeonPrimary, NeonSecondary))
        )
        ThemeMode.PERSIAN -> BorderStroke(
            1.5.dp,
            Brush.linearGradient(listOf(PersianTertiary, PersianPrimary))
        )
        else -> BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    }

    Surface(
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp,
        shadowElevation = 14.dp,
        border = panelBorder,
        modifier = Modifier
            .widthIn(min = 310.dp, max = 360.dp)
            .testTag("floating_assistant_panel")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Draggable Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            onDragHeaderDelta(dragAmount.x, dragAmount.y)
                        }
                    }
            ) {
                Icon(
                    imageVector = Icons.Filled.DragIndicator,
                    contentDescription = "Drag floating panel",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                PersonalAiLogo(themeMode = themeMode, size = 22.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Personal AI",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = onOpenFullApp,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("floating_open_app_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.OpenInNew,
                        contentDescription = "Open full Personal AI app",
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(
                    onClick = onMinimize,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("floating_minimize_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Minimize,
                        contentDescription = "Minimize floating assistant",
                        modifier = Modifier.size(18.dp)
                    )
                }
                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(36.dp)
                        .testTag("floating_close_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Close,
                        contentDescription = "Close floating assistant",
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            if (!hasApiKey) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "Add an API key in Settings to enable AI replies.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = onOpenApiKeySettings) {
                            Text("Configure")
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Conversation list
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 140.dp, max = 260.dp)
            ) {
                if (messages.isEmpty()) {
                    Column(
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 24.dp, horizontal = 8.dp)
                    ) {
                        Text(
                            text = "How can I help?",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Ask about this screen, search indexed files, or launch an app.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        contentPadding = PaddingValues(vertical = 4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(messages, key = { it.id }) { msg ->
                            FloatingMessageBubble(
                                message = msg,
                                onSelectOption = { opt -> onSelectOption(msg.id, opt) },
                                onConfirmAction = { conf, ok -> onConfirmAction(msg.id, conf, ok) }
                            )
                        }
                    }
                }
            }

            if (isProcessing || activeToolStatus != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 6.dp, bottom = 2.dp)
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(14.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = activeToolStatus ?: "Processing...",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Screen context toggle + input row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(
                    onClick = { attachScreen = !attachScreen },
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Visibility,
                        contentDescription = "Attach active screen context",
                        tint = if (attachScreen) {
                            MaterialTheme.colorScheme.primary
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }

                IconButton(
                    onClick = onToggleListening,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("floating_mic_button")
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Filled.Stop else Icons.Filled.Mic,
                        contentDescription = if (hasMicPermission) "Voice input" else "Microphone permission required",
                        tint = if (isListening) {
                            MaterialTheme.colorScheme.error
                        } else {
                            MaterialTheme.colorScheme.onSurfaceVariant
                        }
                    )
                }

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = {
                        Text(
                            text = if (attachScreen) "Ask about screen..." else "Type a message...",
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("floating_text_input")
                )

                Spacer(modifier = Modifier.width(6.dp))

                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ) {
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank() && !isProcessing) {
                                val prompt = inputText
                                inputText = ""
                                onSendMessage(prompt, attachScreen)
                            }
                        },
                        enabled = inputText.isNotBlank() && !isProcessing,
                        modifier = Modifier
                            .size(42.dp)
                            .testTag("floating_send_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FloatingMessageBubble(
    message: ChatMessageEntity,
    onSelectOption: (AskUserOption) -> Unit,
    onConfirmAction: (PendingConfirmation, Boolean) -> Unit
) {
    val isUser = message.role == AssistantOrchestrator.ROLE_USER
    val isTool = message.role == AssistantOrchestrator.ROLE_TOOL
    val isSystem = message.role == AssistantOrchestrator.ROLE_SYSTEM

    val bg = when {
        isUser -> MaterialTheme.colorScheme.primaryContainer
        isSystem -> MaterialTheme.colorScheme.errorContainer
        isTool -> MaterialTheme.colorScheme.surfaceVariant
        else -> MaterialTheme.colorScheme.surfaceContainerLow
    }
    val fg = when {
        isUser -> MaterialTheme.colorScheme.onPrimaryContainer
        isSystem -> MaterialTheme.colorScheme.onErrorContainer
        else -> MaterialTheme.colorScheme.onSurface
    }

    Column(
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
        modifier = Modifier.fillMaxWidth()
    ) {
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = bg,
            contentColor = fg
        ) {
            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                if (isTool && !message.toolName.isNullOrBlank()) {
                    Text(
                        text = "Tool: ${message.toolName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Text(
                    text = message.content,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        // Interactive options if present
        val options = remember(message.optionsJson) { parseOptions(message.optionsJson) }
        if (options.isNotEmpty()) {
            Spacer(modifier = Modifier.height(4.dp))
            options.forEach { opt ->
                OutlinedButton(
                    onClick = { onSelectOption(opt) },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                ) {
                    Text(
                        text = opt.label,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // Sensitive action confirmation if present
        val confirmation = remember(message.pendingConfirmationJson) {
            parseConfirmation(message.pendingConfirmationJson)
        }
        if (confirmation != null) {
            Spacer(modifier = Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { onConfirmAction(confirmation, true) },
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text("Confirm", style = MaterialTheme.typography.labelSmall)
                }
                OutlinedButton(
                    onClick = { onConfirmAction(confirmation, false) }
                ) {
                    Text("Cancel", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

private fun parseOptions(json: String?): List<AskUserOption> {
    if (json.isNullOrBlank()) return emptyList()
    return try {
        val arr = JSONArray(json)
        List(arr.length()) { idx ->
            val obj = arr.getJSONObject(idx)
            AskUserOption(
                id = obj.optString("id", "opt_$idx"),
                label = obj.optString("label"),
                subtitle = obj.optString("subtitle"),
                replyValue = obj.optString("replyValue", obj.optString("label"))
            )
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun parseConfirmation(json: String?): PendingConfirmation? {
    if (json.isNullOrBlank()) return null
    return try {
        val obj = JSONObject(json)
        PendingConfirmation(
            toolName = obj.optString("toolName"),
            argumentsJson = obj.optString("argumentsJson"),
            humanReadableSummary = obj.optString("summary")
        )
    } catch (_: Exception) {
        null
    }
}
