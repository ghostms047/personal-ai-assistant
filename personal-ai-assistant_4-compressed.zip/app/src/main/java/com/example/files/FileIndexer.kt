package com.example.files

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.documentfile.provider.DocumentFile
import com.example.data.db.IndexProgressDao
import com.example.data.db.IndexProgressEntity
import com.example.data.db.IndexedFileDao
import com.example.data.db.IndexedFileEntity
import com.example.data.settings.SettingsRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

data class AuthorizedFolder(
    val uri: Uri,
    val displayName: String,
    val grantedTime: Long
)

class FileIndexer(
    private val context: Context,
    private val indexedFileDao: IndexedFileDao,
    private val indexProgressDao: IndexProgressDao,
    private val settingsRepository: SettingsRepository
) {
    val progressFlow: Flow<IndexProgressEntity?> = indexProgressDao.observeProgress()
    val totalCountFlow: Flow<Int> = indexedFileDao.observeTotalCount()
    val recentFilesFlow: Flow<List<IndexedFileEntity>> = indexedFileDao.observeRecentFiles(80)

    private val _authorizedFolders = MutableStateFlow(loadAuthorizedFolders())
    val authorizedFolders: StateFlow<List<AuthorizedFolder>> = _authorizedFolders.asStateFlow()

    @Volatile
    private var pauseRequested = false

    fun requestPause() {
        pauseRequested = true
    }

    fun refreshAuthorizedFolders() {
        _authorizedFolders.value = loadAuthorizedFolders()
    }

    fun addSafFolderPermission(treeUri: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        try {
            context.contentResolver.takePersistableUriPermission(treeUri, flags)
        } catch (_: SecurityException) {
            // Some providers only allow temporary permission; still attempt refresh
        }
        refreshAuthorizedFolders()
    }

    fun removeSafFolderPermission(treeUri: Uri) {
        try {
            context.contentResolver.releasePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        refreshAuthorizedFolders()
    }

    private fun loadAuthorizedFolders(): List<AuthorizedFolder> {
        return context.contentResolver.persistedUriPermissions
            .filter { it.isReadPermission }
            .map { perm ->
                val doc = DocumentFile.fromTreeUri(context, perm.uri)
                val name = doc?.name?.takeIf { it.isNotBlank() }
                    ?: perm.uri.lastPathSegment?.substringAfterLast(':')
                    ?: "Authorized Folder"
                AuthorizedFolder(
                    uri = perm.uri,
                    displayName = name,
                    grantedTime = perm.persistedTime
                )
            }
    }

    suspend fun runIndexScan(
        incremental: Boolean = true,
        isCancelled: () -> Boolean = { false }
    ): IndexProgressEntity = withContext(Dispatchers.IO) {
        pauseRequested = false
        val scanStartedAt = System.currentTimeMillis()
        val folders = loadAuthorizedFolders()
        _authorizedFolders.value = folders
        val includeMediaStore = settingsRepository.assistantSettingsFlow.first().indexMediaStorePublicItems

        var total = 0
        var images = 0
        var videos = 0
        var documents = 0
        var audio = 0
        var other = 0

        suspend fun emitProgress(status: String, currentFolder: String, error: String? = null) {
            indexProgressDao.upsertProgress(
                IndexProgressEntity(
                    id = 1,
                    status = status,
                    totalIndexed = total,
                    imagesCount = images,
                    videosCount = videos,
                    documentsCount = documents,
                    audioCount = audio,
                    otherCount = other,
                    currentFolder = currentFolder,
                    lastScanTimestamp = scanStartedAt,
                    errorMessage = error
                )
            )
        }

        emitProgress("SCANNING", "Preparing scan...")

        val batch = ArrayList<IndexedFileEntity>(BATCH_SIZE)

        suspend fun flushBatch(currentFolder: String) {
            if (batch.isNotEmpty()) {
                indexedFileDao.upsertAll(batch.toList())
                batch.clear()
                emitProgress("SCANNING", currentFolder)
            }
        }

        try {
            // 1. Traverse all user-authorized Storage Access Framework (SAF) folder trees
            for (folder in folders) {
                if (isCancelled() || pauseRequested) break
                val rootDoc = DocumentFile.fromTreeUri(context, folder.uri) ?: continue
                val stack = ArrayDeque<Pair<DocumentFile, String>>()
                stack.add(rootDoc to folder.displayName)

                while (stack.isNotEmpty()) {
                    if (isCancelled() || pauseRequested) break
                    val (dir, path) = stack.removeLast()
                    val children = try {
                        dir.listFiles()
                    } catch (_: Exception) {
                        emptyArray()
                    }
                    for (child in children) {
                        if (isCancelled() || pauseRequested) break
                        val name = child.name ?: continue
                        if (name.startsWith(".")) continue
                        if (child.isDirectory) {
                            stack.add(child to "$path/$name")
                        } else if (child.isFile) {
                            val uriStr = child.uri.toString()
                            val modified = child.lastModified()
                            val existing = if (incremental) indexedFileDao.getByUri(uriStr) else null

                            val entity = if (existing != null && existing.modifiedAt == modified && modified > 0L) {
                                existing.copy(lastIndexedAt = scanStartedAt)
                            } else {
                                val mime = child.type
                                    ?: guessMimeType(name)
                                val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                                val category = categorize(ext, mime)
                                val extractedText = extractSearchableText(child.uri, ext, mime, child.length())
                                IndexedFileEntity(
                                    id = existing?.id ?: 0L,
                                    uriString = uriStr,
                                    name = name,
                                    displayPath = "$path/$name",
                                    folderName = path.substringAfterLast('/'),
                                    extension = ext,
                                    mimeType = mime,
                                    sizeBytes = child.length(),
                                    createdAt = modified,
                                    modifiedAt = modified,
                                    category = category,
                                    extractedText = extractedText,
                                    sourceType = "SAF",
                                    lastIndexedAt = scanStartedAt
                                )
                            }

                            total++
                            when (entity.category) {
                                CATEGORY_IMAGE -> images++
                                CATEGORY_VIDEO -> videos++
                                CATEGORY_DOCUMENT, CATEGORY_CODE -> documents++
                                CATEGORY_AUDIO -> audio++
                                else -> other++
                            }
                            batch.add(entity)
                            if (batch.size >= BATCH_SIZE) {
                                flushBatch(path)
                            }
                        }
                    }
                }
                flushBatch(folder.displayName)
            }

            // 2. Query publicly accessible MediaStore Downloads if enabled (zero broad permissions)
            if (includeMediaStore && !isCancelled() && !pauseRequested && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val mediaItems = scanAccessibleDownloads(scanStartedAt, incremental)
                for (item in mediaItems) {
                    if (isCancelled() || pauseRequested) break
                    total++
                    when (item.category) {
                        CATEGORY_IMAGE -> images++
                        CATEGORY_VIDEO -> videos++
                        CATEGORY_DOCUMENT, CATEGORY_CODE -> documents++
                        CATEGORY_AUDIO -> audio++
                        else -> other++
                    }
                    batch.add(item)
                    if (batch.size >= BATCH_SIZE) {
                        flushBatch("Downloads (MediaStore)")
                    }
                }
                flushBatch("Downloads (MediaStore)")
            }

            if (isCancelled()) {
                val cancelled = IndexProgressEntity(
                    id = 1,
                    status = "CANCELLED",
                    totalIndexed = indexedFileDao.getTotalCount(),
                    imagesCount = images,
                    videosCount = videos,
                    documentsCount = documents,
                    audioCount = audio,
                    otherCount = other,
                    currentFolder = "Scan cancelled",
                    lastScanTimestamp = scanStartedAt
                )
                indexProgressDao.upsertProgress(cancelled)
                return@withContext cancelled
            }

            if (pauseRequested) {
                val paused = IndexProgressEntity(
                    id = 1,
                    status = "PAUSED",
                    totalIndexed = indexedFileDao.getTotalCount(),
                    imagesCount = images,
                    videosCount = videos,
                    documentsCount = documents,
                    audioCount = audio,
                    otherCount = other,
                    currentFolder = "Scan paused — tap Resume to continue",
                    lastScanTimestamp = scanStartedAt
                )
                indexProgressDao.upsertProgress(paused)
                return@withContext paused
            }

            // Remove deleted SAF entries only if full scan completed without interruption
            if (folders.isNotEmpty()) {
                indexedFileDao.deleteStaleBySource("SAF", scanStartedAt)
            }
            if (includeMediaStore) {
                indexedFileDao.deleteStaleBySource("MEDIASTORE", scanStartedAt)
            }

            val finalTotal = indexedFileDao.getTotalCount()
            val completed = IndexProgressEntity(
                id = 1,
                status = "COMPLETED",
                totalIndexed = finalTotal,
                imagesCount = images,
                videosCount = videos,
                documentsCount = documents,
                audioCount = audio,
                otherCount = other,
                currentFolder = if (folders.isEmpty()) "No SAF folders authorized yet" else "Up to date",
                lastScanTimestamp = scanStartedAt
            )
            indexProgressDao.upsertProgress(completed)
            completed
        } catch (ce: CancellationException) {
            emitProgress("CANCELLED", "Scan cancelled")
            throw ce
        } catch (e: Exception) {
            val err = IndexProgressEntity(
                id = 1,
                status = "ERROR",
                totalIndexed = indexedFileDao.getTotalCount(),
                imagesCount = images,
                videosCount = videos,
                documentsCount = documents,
                audioCount = audio,
                otherCount = other,
                currentFolder = "",
                lastScanTimestamp = scanStartedAt,
                errorMessage = e.localizedMessage ?: "File indexing failed."
            )
            indexProgressDao.upsertProgress(err)
            err
        }
    }

    private suspend fun scanAccessibleDownloads(
        scanStartedAt: Long,
        incremental: Boolean
    ): List<IndexedFileEntity> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return emptyList()
        val result = mutableListOf<IndexedFileEntity>()
        val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Downloads._ID,
            MediaStore.Downloads.DISPLAY_NAME,
            MediaStore.Downloads.MIME_TYPE,
            MediaStore.Downloads.SIZE,
            MediaStore.Downloads.DATE_ADDED,
            MediaStore.Downloads.DATE_MODIFIED,
            MediaStore.Downloads.RELATIVE_PATH
        )
        try {
            context.contentResolver.query(uri, projection, null, null, "${MediaStore.Downloads.DATE_MODIFIED} DESC")?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.MIME_TYPE)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.SIZE)
                val addedCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DATE_ADDED)
                val modCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DATE_MODIFIED)
                val pathCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.RELATIVE_PATH)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: continue
                    val mime = cursor.getString(mimeCol) ?: guessMimeType(name)
                    val size = cursor.getLong(sizeCol)
                    val added = cursor.getLong(addedCol) * 1000L
                    val modified = cursor.getLong(modCol) * 1000L
                    val relPath = cursor.getString(pathCol) ?: "Download/"
                    val itemUri = Uri.withAppendedPath(uri, id.toString())
                    val uriStr = itemUri.toString()

                    val existing = if (incremental) indexedFileDao.getByUri(uriStr) else null
                    if (existing != null && existing.modifiedAt == modified && modified > 0L) {
                        result.add(existing.copy(lastIndexedAt = scanStartedAt))
                        continue
                    }

                    val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                    val category = categorize(ext, mime)
                    val extractedText = extractSearchableText(itemUri, ext, mime, size)
                    result.add(
                        IndexedFileEntity(
                            id = existing?.id ?: 0L,
                            uriString = uriStr,
                            name = name,
                            displayPath = "$relPath$name",
                            folderName = relPath.trimEnd('/').substringAfterLast('/').ifBlank { "Download" },
                            extension = ext,
                            mimeType = mime,
                            sizeBytes = size,
                            createdAt = added,
                            modifiedAt = modified,
                            category = category,
                            extractedText = extractedText,
                            sourceType = "MEDIASTORE",
                            lastIndexedAt = scanStartedAt
                        )
                    )
                }
            }
        } catch (_: SecurityException) {
            // Expected when scoped storage denies other-app items; never crash
        } catch (_: Exception) {
        }
        return result
    }

    private fun extractSearchableText(
        uri: Uri,
        ext: String,
        mimeType: String,
        sizeBytes: Long
    ): String {
        if (sizeBytes > MAX_TEXT_EXTRACT_BYTES) return ""
        val isPlainText = ext in TEXT_EXTENSIONS || mimeType.startsWith("text/") || mimeType == "application/json"
        if (isPlainText) {
            return try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    BufferedReader(InputStreamReader(stream)).use { reader ->
                        val buffer = CharArray(MAX_EXTRACTED_CHARS)
                        val count = reader.read(buffer, 0, buffer.size)
                        if (count > 0) String(buffer, 0, count).replace(Regex("\\s+"), " ").trim() else ""
                    }
                } ?: ""
            } catch (_: Exception) {
                ""
            }
        }
        if (ext == "pdf" || mimeType == "application/pdf") {
            return try {
                // Lightweight local ASCII literal extraction for uncompressed PDF text snippets
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val bytes = stream.readBytes().take(128_000).toByteArray()
                    val raw = String(bytes, Charsets.ISO_8859_1)
                    val matches = Regex("\\(([^()]{3,80})\\)")
                        .findAll(raw)
                        .map { it.groupValues[1] }
                        .filter { s -> s.count { it.isLetterOrDigit() || it == ' ' } > s.length * 0.7 }
                        .take(40)
                        .joinToString(" ")
                    matches.take(MAX_EXTRACTED_CHARS)
                } ?: ""
            } catch (_: Exception) {
                ""
            }
        }
        return ""
    }

    fun openFile(uriString: String, mimeType: String): Result<Unit> {
        return try {
            val uri = Uri.parse(uriString)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType.ifBlank { "*/*" })
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(intent)
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(
                IllegalStateException("No installed app can open this file type, or access was revoked.", e)
            )
        }
    }

    private fun guessMimeType(fileName: String): String {
        val ext = fileName.substringAfterLast('.', "").lowercase(Locale.ROOT)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun categorize(ext: String, mime: String): String = when {
        mime.startsWith("image/") || ext in setOf("jpg", "jpeg", "png", "webp", "gif", "heic", "svg") -> CATEGORY_IMAGE
        mime.startsWith("video/") || ext in setOf("mp4", "mkv", "mov", "avi", "webm") -> CATEGORY_VIDEO
        mime.startsWith("audio/") || ext in setOf("mp3", "wav", "ogg", "m4a", "flac", "aac") -> CATEGORY_AUDIO
        ext in setOf("zip", "tar", "gz", "7z", "rar") -> CATEGORY_ARCHIVE
        ext in setOf("kt", "java", "py", "js", "ts", "json", "xml", "yaml", "yml", "html", "css", "sql") -> CATEGORY_CODE
        mime.startsWith("text/") || ext in setOf("pdf", "doc", "docx", "txt", "md", "csv", "xls", "xlsx", "ppt", "pptx", "rtf") -> CATEGORY_DOCUMENT
        else -> CATEGORY_OTHER
    }

    companion object {
        const val CATEGORY_IMAGE = "IMAGE"
        const val CATEGORY_VIDEO = "VIDEO"
        const val CATEGORY_DOCUMENT = "DOCUMENT"
        const val CATEGORY_AUDIO = "AUDIO"
        const val CATEGORY_ARCHIVE = "ARCHIVE"
        const val CATEGORY_CODE = "CODE"
        const val CATEGORY_OTHER = "OTHER"

        private const val BATCH_SIZE = 50
        private const val MAX_TEXT_EXTRACT_BYTES = 1_500_000L
        private const val MAX_EXTRACTED_CHARS = 2000
        private val TEXT_EXTENSIONS = setOf(
            "txt", "md", "json", "xml", "csv", "kt", "java", "py", "js", "ts", "html", "log", "yaml", "yml", "ini"
        )
    }
}
