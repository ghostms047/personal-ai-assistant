package com.example.files

import com.example.data.db.IndexedFileDao
import com.example.data.db.IndexedFileEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Locale

data class ParsedFileQuery(
    val rawQuery: String,
    val keywords: List<String>,
    val category: String?,
    val extension: String?,
    val minModifiedAt: Long?,
    val maxModifiedAt: Long?
)

data class FileSearchResult(
    val files: List<IndexedFileEntity>,
    val parsedQuery: ParsedFileQuery,
    val confidence: Float
)

class NaturalLanguageFileSearch(
    private val indexedFileDao: IndexedFileDao
) {
    suspend fun search(naturalQuery: String, limit: Int = 30): FileSearchResult =
        withContext(Dispatchers.IO) {
            val parsed = parseQuery(naturalQuery)
            val candidates = LinkedHashMap<Long, IndexedFileEntity>()

            if (parsed.keywords.isEmpty()) {
                indexedFileDao.searchFiles(
                    query = "",
                    category = parsed.category,
                    extension = parsed.extension,
                    minModified = parsed.minModifiedAt,
                    maxModified = parsed.maxModifiedAt,
                    limit = limit
                ).forEach { candidates[it.id] = it }
            } else {
                // Run full phrase + individual keywords to maximize recall, then score
                indexedFileDao.searchFiles(
                    query = parsed.keywords.joinToString(" "),
                    category = parsed.category,
                    extension = parsed.extension,
                    minModified = parsed.minModifiedAt,
                    maxModified = parsed.maxModifiedAt,
                    limit = limit
                ).forEach { candidates[it.id] = it }

                for (kw in parsed.keywords.take(5)) {
                    indexedFileDao.searchFiles(
                        query = kw,
                        category = parsed.category,
                        extension = parsed.extension,
                        minModified = parsed.minModifiedAt,
                        maxModified = parsed.maxModifiedAt,
                        limit = limit
                    ).forEach { candidates[it.id] = it }
                }

                // Fallback without strict category/extension filter if nothing matched
                if (candidates.isEmpty() && (parsed.category != null || parsed.extension != null)) {
                    for (kw in parsed.keywords.take(4)) {
                        indexedFileDao.searchFiles(
                            query = kw,
                            category = null,
                            extension = null,
                            minModified = parsed.minModifiedAt,
                            maxModified = parsed.maxModifiedAt,
                            limit = limit
                        ).forEach { candidates[it.id] = it }
                    }
                }
            }

            val scored = candidates.values.map { file ->
                file to scoreMatch(file, parsed)
            }.sortedByDescending { it.second }

            val topScore = scored.firstOrNull()?.second ?: 0f
            val results = scored.take(limit).map { it.first }
            val confidence = when {
                results.isEmpty() -> 0f
                topScore >= 5f -> 0.95f
                topScore >= 2.5f -> 0.75f
                else -> 0.45f
            }

            FileSearchResult(
                files = results,
                parsedQuery = parsed,
                confidence = confidence
            )
        }

    fun parseQuery(raw: String, nowMillis: Long = System.currentTimeMillis()): ParsedFileQuery {
        val lower = raw.lowercase(Locale.ROOT).trim()

        val extension = when {
            Regex("\\bpdf(s)?\\b").containsMatchIn(lower) -> "pdf"
            Regex("\\bzip(s)?\\b").containsMatchIn(lower) -> "zip"
            Regex("\\bjson\\b").containsMatchIn(lower) -> "json"
            Regex("\\bcsv\\b").containsMatchIn(lower) -> "csv"
            Regex("\\btxt\\b").containsMatchIn(lower) -> "txt"
            Regex("\\bdocx?\\b").containsMatchIn(lower) -> "docx"
            Regex("\\bapk\\b").containsMatchIn(lower) -> "apk"
            else -> null
        }

        val category = when {
            extension == "zip" -> FileIndexer.CATEGORY_ARCHIVE
            extension == "pdf" || extension == "docx" || extension == "txt" -> FileIndexer.CATEGORY_DOCUMENT
            Regex("\\b(image|images|photo|photos|picture|pictures|screenshot|screenshots)\\b").containsMatchIn(lower) ->
                FileIndexer.CATEGORY_IMAGE
            Regex("\\b(video|videos|movie|movies|clip|clips)\\b").containsMatchIn(lower) ->
                FileIndexer.CATEGORY_VIDEO
            Regex("\\b(audio|song|songs|music|recording|recordings)\\b").containsMatchIn(lower) ->
                FileIndexer.CATEGORY_AUDIO
            Regex("\\b(document|documents|doc|docs|report|reports|notes)\\b").containsMatchIn(lower) ->
                FileIndexer.CATEGORY_DOCUMENT
            Regex("\\b(archive|archives|compressed)\\b").containsMatchIn(lower) ->
                FileIndexer.CATEGORY_ARCHIVE
            else -> null
        }

        val (minDate, maxDate) = parseDateRange(lower, nowMillis)

        val stopWords = setOf(
            "find", "search", "show", "open", "get", "the", "a", "an", "for", "my", "me",
            "about", "with", "from", "modified", "created", "updated", "in", "on", "of",
            "file", "files", "folder", "where", "is", "are", "this", "last", "week",
            "month", "today", "yesterday", "pdf", "pdfs", "zip", "zips", "image", "images",
            "photo", "photos", "video", "videos", "document", "documents", "audio", "project"
        )

        val rawTokens = lower.split(Regex("[^a-z0-9._-]+"))
            .filter { it.length >= 2 }

        // Keep "project" if there are no other content keywords, otherwise strip noise words
        val filtered = rawTokens.filter { it !in stopWords }
        val finalKeywords = if (filtered.isNotEmpty()) {
            filtered
        } else {
            rawTokens.filter { it !in setOf("find", "search", "show", "open", "get", "the", "my", "file", "files", "where", "is") }
        }

        return ParsedFileQuery(
            rawQuery = raw,
            keywords = finalKeywords.distinct(),
            category = category,
            extension = extension,
            minModifiedAt = minDate,
            maxModifiedAt = maxDate
        )
    }

    private fun parseDateRange(lower: String, nowMillis: Long): Pair<Long?, Long?> {
        val cal = Calendar.getInstance().apply { timeInMillis = nowMillis }
        return when {
            lower.contains("today") -> {
                cal.set(Calendar.HOUR_OF_DAY, 0)
                cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0)
                cal.timeInMillis to nowMillis
            }
            lower.contains("yesterday") -> {
                cal.add(Calendar.DAY_OF_YEAR, -1)
                cal.set(Calendar.HOUR_OF_DAY, 0)
                cal.set(Calendar.MINUTE, 0)
                val start = cal.timeInMillis
                cal.set(Calendar.HOUR_OF_DAY, 23)
                cal.set(Calendar.MINUTE, 59)
                start to cal.timeInMillis
            }
            lower.contains("this week") -> {
                cal.add(Calendar.DAY_OF_YEAR, -7)
                cal.timeInMillis to nowMillis
            }
            lower.contains("last week") -> {
                val end = cal.timeInMillis - 7L * 86_400_000L
                val start = end - 7L * 86_400_000L
                start to end
            }
            lower.contains("this month") -> {
                cal.set(Calendar.DAY_OF_MONTH, 1)
                cal.set(Calendar.HOUR_OF_DAY, 0)
                cal.timeInMillis to nowMillis
            }
            lower.contains("last month") -> {
                cal.add(Calendar.MONTH, -1)
                cal.set(Calendar.DAY_OF_MONTH, 1)
                val start = cal.timeInMillis
                cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
                cal.set(Calendar.HOUR_OF_DAY, 23)
                start to cal.timeInMillis
            }
            else -> null to null
        }
    }

    private fun scoreMatch(file: IndexedFileEntity, parsed: ParsedFileQuery): Float {
        var score = 0.5f
        val nameLower = file.name.lowercase(Locale.ROOT)
        val pathLower = file.displayPath.lowercase(Locale.ROOT)
        val textLower = file.extractedText.lowercase(Locale.ROOT)

        if (parsed.extension != null && file.extension.equals(parsed.extension, ignoreCase = true)) {
            score += 2.0f
        }
        if (parsed.category != null && file.category == parsed.category) {
            score += 1.5f
        }
        for (kw in parsed.keywords) {
            if (nameLower == kw || nameLower.substringBeforeLast('.') == kw) score += 6.0f
            else if (nameLower.contains(kw)) score += 3.5f
            if (pathLower.contains(kw)) score += 1.5f
            if (textLower.contains(kw)) score += 2.0f
        }
        return score
    }
}
