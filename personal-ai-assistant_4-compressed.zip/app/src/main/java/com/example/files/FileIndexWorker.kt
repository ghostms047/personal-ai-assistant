package com.example.files

import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.example.PersonalAiApp
import com.example.R

class FileIndexWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val incremental = inputData.getBoolean(KEY_INCREMENTAL, true)
        val container = (applicationContext as? PersonalAiApp)?.container
            ?: return Result.failure()

        try {
            setForeground(createForegroundInfo())
        } catch (_: Exception) {
            // Notifications permission might be denied; continue running safely as worker
        }

        val result = container.fileIndexer.runIndexScan(
            incremental = incremental,
            isCancelled = { isStopped }
        )

        return if (result.status == "ERROR") Result.failure() else Result.success()
    }

    private fun createForegroundInfo(): ForegroundInfo {
        val nm = NotificationManagerCompat.from(applicationContext)
        val channel = NotificationChannelCompat.Builder(
            CHANNEL_ID,
            NotificationManagerCompat.IMPORTANCE_LOW
        )
            .setName(applicationContext.getString(R.string.indexing_notification_channel_name))
            .build()
        nm.createNotificationChannel(channel)

        val notification = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setContentTitle(applicationContext.getString(R.string.indexing_notification_title))
            .setContentText("Scanning authorized folders locally...")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setSilent(true)
            .build()

        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ForegroundInfo(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            ForegroundInfo(NOTIFICATION_ID, notification)
        }
    }

    companion object {
        const val WORK_NAME = "personal_ai_file_index_work"
        private const val KEY_INCREMENTAL = "incremental"
        private const val CHANNEL_ID = "personal_ai_file_indexing"
        private const val NOTIFICATION_ID = 4102

        fun enqueue(context: Context, incremental: Boolean = true) {
            val request = OneTimeWorkRequestBuilder<FileIndexWorker>()
                .setInputData(workDataOf(KEY_INCREMENTAL to incremental))
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
        }
    }
}
