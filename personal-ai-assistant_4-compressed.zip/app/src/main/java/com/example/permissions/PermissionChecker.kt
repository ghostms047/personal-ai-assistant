package com.example.permissions

import android.Manifest
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.NotificationManager
import android.app.role.RoleManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import androidx.core.content.ContextCompat
import com.example.screen.PersonalAiAccessibilityService
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

enum class PermissionId {
    DEFAULT_ASSISTANT,
    OVERLAY,
    ACCESSIBILITY,
    FILE_ACCESS,
    MICROPHONE,
    NOTIFICATIONS
}

data class PermissionStatusItem(
    val id: PermissionId,
    val title: String,
    val description: String,
    val fallbackExplanation: String,
    val isGranted: Boolean,
    val isSupported: Boolean = true,
    val statusDetail: String = ""
)

class PermissionChecker(private val context: Context) {

    fun isDefaultAssistant(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_ASSISTANT)) {
                return roleManager.isRoleHeld(RoleManager.ROLE_ASSISTANT)
            }
        }
        val current = Settings.Secure.getString(context.contentResolver, "assistant") ?: ""
        return current.contains(context.packageName)
    }

    fun isAssistantRoleSupported(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(RoleManager::class.java)
            if (roleManager != null) {
                return roleManager.isRoleAvailable(RoleManager.ROLE_ASSISTANT)
            }
        }
        return true
    }

    fun canDrawOverlays(): Boolean = Settings.canDrawOverlays(context)

    fun isAccessibilityEnabled(): Boolean {
        val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as? AccessibilityManager
            ?: return false
        val expectedComponent = ComponentName(context, PersonalAiAccessibilityService::class.java)
        val enabledServices = am.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_ALL_MASK
        )
        if (enabledServices.any {
                it.resolveInfo?.serviceInfo?.let { si ->
                    si.packageName == expectedComponent.packageName &&
                        si.name == expectedComponent.className
                } == true
            }
        ) {
            return true
        }
        val enabledFlat = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabledFlat.split(':').any {
            ComponentName.unflattenFromString(it) == expectedComponent
        }
    }

    fun getGrantedSafFoldersCount(): Int =
        context.contentResolver.persistedUriPermissions.count { it.isReadPermission }

    fun hasFileAccess(): Boolean = getGrantedSafFoldersCount() > 0

    fun hasMicrophonePermission(): Boolean =
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

    fun hasNotificationsPermission(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val runtimeGranted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!runtimeGranted) return false
        }
        val nm = context.getSystemService(NotificationManager::class.java)
        return nm?.areNotificationsEnabled() ?: true
    }

    fun isNetworkConnected(): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    fun observeNetworkConnectivity(): Flow<Boolean> = callbackFlow {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        trySend(isNetworkConnected())
        if (cm == null) {
            close()
            return@callbackFlow
        }
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                trySend(isNetworkConnected())
            }

            override fun onLost(network: Network) {
                trySend(isNetworkConnected())
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                trySend(networkCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET))
            }
        }
        runCatching { cm.registerDefaultNetworkCallback(callback) }
        awaitClose {
            runCatching { cm.unregisterNetworkCallback(callback) }
        }
    }.distinctUntilChanged()

    fun getAllStatuses(): List<PermissionStatusItem> {
        val safCount = getGrantedSafFoldersCount()
        val assistantRoleAvailable = isAssistantRoleSupported()
        return listOf(
            PermissionStatusItem(
                id = PermissionId.DEFAULT_ASSISTANT,
                title = "Default Digital Assistant",
                description = "Allows Android's assistant gesture or button to invoke Personal AI and pass screen context via Assist APIs.",
                fallbackExplanation = "You can still open Personal AI directly from the launcher or floating button if another assistant is set as default.",
                isGranted = isDefaultAssistant(),
                isSupported = assistantRoleAvailable,
                statusDetail = if (isDefaultAssistant()) "Active default assistant" else if (!assistantRoleAvailable) "Role unavailable on this device; use Voice Input Settings" else "Not set as default"
            ),
            PermissionStatusItem(
                id = PermissionId.OVERLAY,
                title = "Display Over Other Apps",
                description = "Lets the calm floating AI pill and mini panel appear above other apps for quick assistance.",
                fallbackExplanation = "Without this permission, use the full-screen AI Chat inside Personal AI.",
                isGranted = canDrawOverlays(),
                statusDetail = if (canDrawOverlays()) "Floating overlay allowed" else "Overlay disabled"
            ),
            PermissionStatusItem(
                id = PermissionId.ACCESSIBILITY,
                title = "Accessibility Screen Reader",
                description = "Enables reading visible screen text, summarizing the active screen, and performing user-approved UI clicks.",
                fallbackExplanation = "Screen inspection will explain that Accessibility access is off; all chat, file, and app tools continue working.",
                isGranted = isAccessibilityEnabled(),
                statusDetail = if (isAccessibilityEnabled()) "Screen reader connected" else "Service inactive"
            ),
            PermissionStatusItem(
                id = PermissionId.FILE_ACCESS,
                title = "Accessible Folders (SAF)",
                description = "Grants read access only to folders you explicitly select via Android's Storage Access Framework for local indexing.",
                fallbackExplanation = "Without folder grants, file search only checks publicly readable downloads if permitted.",
                isGranted = safCount > 0,
                statusDetail = if (safCount > 0) "$safCount folder(s) authorized" else "No folders selected yet"
            ),
            PermissionStatusItem(
                id = PermissionId.MICROPHONE,
                title = "Microphone",
                description = "Enables hands-free speech-to-text queries inside AI Chat and the Floating Assistant panel.",
                fallbackExplanation = "Text input remains fully available when microphone access is denied.",
                isGranted = hasMicrophonePermission(),
                statusDetail = if (hasMicrophonePermission()) "Voice input ready" else "Text input only"
            ),
            PermissionStatusItem(
                id = PermissionId.NOTIFICATIONS,
                title = "Notifications",
                description = "Displays the persistent status indicator required by Android while the floating overlay or file scanner is active.",
                fallbackExplanation = "Foreground services still operate on Android, though system status notifications may be hidden.",
                isGranted = hasNotificationsPermission(),
                statusDetail = if (hasNotificationsPermission()) "Notifications enabled" else "Notifications blocked"
            )
        )
    }

    fun createAssistantRoleRequestIntent(): Intent? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(RoleManager::class.java)
            if (roleManager != null && roleManager.isRoleAvailable(RoleManager.ROLE_ASSISTANT)) {
                return roleManager.createRequestRoleIntent(RoleManager.ROLE_ASSISTANT)
            }
        }
        return null
    }

    fun createVoiceInputSettingsIntent(): Intent =
        Intent(Settings.ACTION_VOICE_INPUT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun createOverlaySettingsIntent(): Intent =
        Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun createAccessibilitySettingsIntent(): Intent =
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun createAppNotificationSettingsIntent(): Intent =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        } else {
            createAppDetailsIntent()
        }

    fun createAppDetailsIntent(): Intent =
        Intent(
            Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
            Uri.parse("package:${context.packageName}")
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
