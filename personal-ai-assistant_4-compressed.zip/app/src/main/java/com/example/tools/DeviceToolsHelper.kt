package com.example.tools

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import com.example.permissions.PermissionChecker
import com.example.screen.ScreenUnderstandingRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Safe device telemetry, settings navigation, clipboard, and URL helpers for ToolRegistry.
 */
object DeviceToolsHelper {

    fun collectDeviceStatus(
        context: Context,
        permissionChecker: PermissionChecker,
        screenRepo: ScreenUnderstandingRepository
    ): JSONObject {
        val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) (level * 100) / scale else -1
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val stat = runCatching { StatFs(Environment.getDataDirectory().path) }.getOrNull()
        val freeBytes = stat?.availableBytes ?: 0L
        val totalBytes = stat?.totalBytes ?: 0L

        val activeApp = screenRepo.latestSnapshot.value?.packageName ?: "unknown"
        val isOnline = permissionChecker.isNetworkConnected()

        return JSONObject()
            .put("battery_percent", pct)
            .put("is_charging", isCharging)
            .put("is_online", isOnline)
            .put("free_storage_gb", String.format("%.2f", freeBytes / (1024.0 * 1024.0 * 1024.0)))
            .put("total_storage_gb", String.format("%.2f", totalBytes / (1024.0 * 1024.0 * 1024.0)))
            .put("android_sdk", Build.VERSION.SDK_INT)
            .put("device_model", "${Build.MANUFACTURER} ${Build.MODEL}")
            .put("active_screen_package", activeApp)
            .put("accessibility_enabled", permissionChecker.isAccessibilityEnabled())
    }

    suspend fun handleClipboard(
        context: Context,
        mode: String,
        text: String
    ): ToolExecutionOutcome = withContext(Dispatchers.Main) {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
            ?: return@withContext ToolExecutionOutcome.Executed(
                false,
                JSONObject().put("error", "Clipboard service unavailable.").toString(),
                "Clipboard unavailable."
            )
        if (mode == "write" || mode == "set" || mode == "copy") {
            cm.setPrimaryClip(ClipData.newPlainText("Personal AI", text))
            ToolExecutionOutcome.Executed(
                true,
                JSONObject().put("copied_length", text.length).toString(),
                "Copied text to clipboard."
            )
        } else {
            val clipText = cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
            ToolExecutionOutcome.Executed(
                true,
                JSONObject().put("clipboard_text", clipText.take(2000)).toString(),
                if (clipText.isBlank()) "Clipboard is empty." else "Read ${clipText.length} chars from clipboard."
            )
        }
    }

    fun openSafeUrl(context: Context, rawUrl: String): ToolExecutionOutcome {
        val trimmed = rawUrl.trim()
        if (!trimmed.startsWith("https://", ignoreCase = true) &&
            !trimmed.startsWith("http://", ignoreCase = true)
        ) {
            return ToolExecutionOutcome.Executed(
                false,
                JSONObject().put("error", "Only http:// or https:// URLs are allowed.").toString(),
                "Blocked non-HTTP URL."
            )
        }
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(trimmed)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            ToolExecutionOutcome.Executed(
                true,
                JSONObject().put("opened_url", trimmed).toString(),
                "Opened URL in browser."
            )
        } catch (_: Exception) {
            ToolExecutionOutcome.Executed(
                false,
                JSONObject().put("error", "No browser app could open that URL.").toString(),
                "Could not open URL."
            )
        }
    }

    fun resolveSettingsIntent(section: String, permissionChecker: PermissionChecker): Intent =
        when (section.lowercase().trim()) {
            "wifi", "wi-fi" -> Intent(Settings.ACTION_WIFI_SETTINGS)
            "bluetooth" -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
            "display" -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
            "sound" -> Intent(Settings.ACTION_SOUND_SETTINGS)
            "storage" -> Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS)
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            "voice_input", "assistant" -> Intent(Settings.ACTION_VOICE_INPUT_SETTINGS)
            "overlay" -> permissionChecker.createOverlaySettingsIntent()
            "apps" -> Intent(Settings.ACTION_APPLICATION_SETTINGS)
            "battery" -> Intent(Intent.ACTION_POWER_USAGE_SUMMARY)
            "security" -> Intent(Settings.ACTION_SECURITY_SETTINGS)
            "location" -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
            "language" -> Intent(Settings.ACTION_LOCALE_SETTINGS)
            else -> Intent(Settings.ACTION_SETTINGS)
        }.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
}
