package com.example.tools

import com.example.ai.AiToolDefinition
import com.example.permissions.PermissionId

data class AskUserOption(
    val id: String,
    val label: String,
    val subtitle: String = "",
    val replyValue: String = label
)

data class PendingConfirmation(
    val toolName: String,
    val argumentsJson: String,
    val humanReadableSummary: String
)

data class ToolDescriptor(
    val definition: AiToolDefinition,
    val requiredPermission: PermissionId? = null,
    val isSensitive: Boolean = false
)

sealed interface ToolExecutionOutcome {
    data class Executed(
        val success: Boolean,
        val resultJson: String,
        val summaryForUser: String,
        val askUserQuestion: String? = null,
        val askUserOptions: List<AskUserOption> = emptyList()
    ) : ToolExecutionOutcome

    data class NeedsConfirmation(
        val confirmation: PendingConfirmation
    ) : ToolExecutionOutcome
}
