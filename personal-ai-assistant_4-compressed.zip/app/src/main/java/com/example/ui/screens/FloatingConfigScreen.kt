package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.settings.ThemeMode
import com.example.floating.FloatingBubbleView
import com.example.permissions.PermissionId
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.UtilityCard
import com.example.ui.viewmodel.PersonalAiViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun FloatingConfigScreen(
    viewModel: PersonalAiViewModel,
    onBack: () -> Unit
) {
    val floatingSettings by viewModel.floatingSettings.collectAsStateWithLifecycle()
    val assistantSettings by viewModel.assistantSettings.collectAsStateWithLifecycle()
    val isRunning by viewModel.isFloatingRunning.collectAsStateWithLifecycle()
    val permissions by viewModel.permissions.collectAsStateWithLifecycle()

    val overlayGranted = permissions.firstOrNull { it.id == PermissionId.OVERLAY }?.isGranted == true

    val overlayLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { viewModel.refreshSystemState() }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Floating Assistant", fontWeight = FontWeight.SemiBold) }
            )
        }
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 680.dp)
            ) {
                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Display Over Other Apps", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                StatusPill(granted = overlayGranted)
                            }
                            Text(
                                text = "When enabled, a calm movable [ AI ] pill floats above other applications. Tap to expand into a compact assistant panel with voice, text, and screen awareness.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (!overlayGranted) {
                                Button(
                                    onClick = { overlayLauncher.launch(viewModel.getOverlaySettingsIntent()) },
                                    modifier = Modifier.testTag("floating_grant_overlay_button")
                                ) {
                                    Icon(Icons.Filled.Layers, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Grant Overlay Permission")
                                }
                            } else {
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Button(
                                        onClick = { viewModel.setFloatingOverlayRunning(!isRunning) },
                                        modifier = Modifier.testTag("floating_toggle_service_button")
                                    ) {
                                        Text(if (isRunning) "Stop Floating Assistant" else "Launch Floating Assistant")
                                    }
                                    OutlinedButton(
                                        onClick = { overlayLauncher.launch(viewModel.getOverlaySettingsIntent()) }
                                    ) {
                                        Text("System Setting")
                                    }
                                }
                            }
                        }
                    }
                }

                item { SectionHeader("Bubble Preview & Theme") }

                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = assistantSettings.themeMode.label,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Floating bubble & logo adapt live to your theme",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                FloatingBubbleView(
                                    settings = floatingSettings,
                                    isProcessing = false,
                                    onTapExpand = {},
                                    onDragDelta = { _, _ -> }
                                )
                            }
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                ThemeMode.entries.forEach { mode ->
                                    FilterChip(
                                        selected = assistantSettings.themeMode == mode,
                                        onClick = { viewModel.setThemeMode(mode) },
                                        label = { Text(mode.label) },
                                        modifier = Modifier.testTag("floating_theme_chip_${mode.id}")
                                    )
                                }
                            }
                        }
                    }
                }

                item { SectionHeader("Overlay Behavior") }

                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            SettingToggleRow(
                                title = "Start docked on right edge",
                                subtitle = "Position the floating bubble along the right edge when launched.",
                                checked = floatingSettings.startOnRightEdge,
                                onCheckedChange = { checked ->
                                    viewModel.updateFloatingSettings { it.copy(startOnRightEdge = checked) }
                                }
                            )
                            SettingToggleRow(
                                title = "Compact bubble label",
                                subtitle = "Display a minimal 'AI' pill instead of a wider label.",
                                checked = floatingSettings.compactBubbleLabel,
                                onCheckedChange = { checked ->
                                    viewModel.updateFloatingSettings { it.copy(compactBubbleLabel = checked) }
                                }
                            )
                            SettingToggleRow(
                                title = "Auto-minimize after action",
                                subtitle = "Collapse back to the floating bubble once a message finishes.",
                                checked = floatingSettings.autoMinimizeAfterAction,
                                onCheckedChange = { checked ->
                                    viewModel.updateFloatingSettings { it.copy(autoMinimizeAfterAction = checked) }
                                }
                            )
                            Column {
                                Text(
                                    text = "Bubble Opacity: ${(floatingSettings.bubbleOpacity * 100).toInt()}%",
                                    style = MaterialTheme.typography.labelMedium
                                )
                                Slider(
                                    value = floatingSettings.bubbleOpacity,
                                    onValueChange = { value ->
                                        viewModel.updateFloatingSettings { it.copy(bubbleOpacity = value) }
                                    },
                                    valueRange = 0.65f..1f
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
