package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.settings.ThemeMode
import com.example.ui.theme.DarkPrimary
import com.example.ui.theme.DarkTertiary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LightPrimary
import com.example.ui.theme.LightTertiary
import com.example.ui.theme.LocalThemeMode
import com.example.ui.theme.NeonBackground
import com.example.ui.theme.NeonPrimary
import com.example.ui.theme.NeonSecondary
import com.example.ui.theme.NeonSurface
import com.example.ui.theme.NeonTertiary
import com.example.ui.theme.PersianPrimary
import com.example.ui.theme.PersianSecondary
import com.example.ui.theme.PersianTertiary
import com.example.ui.theme.previewSwatchColors
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Dynamic theme-responsive brand emblem used across headers, onboarding,
 * AssistActivity, and the floating assistant bubble/panel.
 */
@Composable
fun PersonalAiLogo(
    themeMode: ThemeMode = LocalThemeMode.current,
    size: Dp = 36.dp,
    modifier: Modifier = Modifier
) {
    val systemDark = isSystemInDarkTheme()
    val effectiveDark = when (themeMode) {
        ThemeMode.DARK, ThemeMode.NEON -> true
        ThemeMode.LIGHT, ThemeMode.PERSIAN -> false
        ThemeMode.SYSTEM -> systemDark
    }

    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val cx = w / 2f
        val cy = h / 2f
        val radius = minOf(w, h) / 2f

        when (themeMode) {
            ThemeMode.PERSIAN -> {
                // Royal lapis-to-turquoise medallion with illuminated saffron gold Shamseh star
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(PersianPrimary, PersianSecondary),
                        center = Offset(cx * 0.85f, cy * 0.85f),
                        radius = radius * 1.15f
                    ),
                    radius = radius * 0.94f,
                    center = Offset(cx, cy)
                )
                drawCircle(
                    color = PersianTertiary,
                    radius = radius * 0.94f,
                    center = Offset(cx, cy),
                    style = Stroke(width = radius * 0.11f)
                )
                drawShamsehStar(
                    center = Offset(cx, cy),
                    outerRadius = radius * 0.62f,
                    innerRadius = radius * 0.30f,
                    fillColor = Color(0xFFFEF0C7),
                    strokeColor = PersianTertiary,
                    strokeWidth = radius * 0.06f
                )
                drawCircle(
                    color = PersianPrimary,
                    radius = radius * 0.14f,
                    center = Offset(cx, cy)
                )
            }

            ThemeMode.NEON -> {
                // Cyber void hexagon with glowing electric cyan halo & laser magenta core
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(NeonPrimary.copy(alpha = 0.42f), Color.Transparent),
                        center = Offset(cx, cy),
                        radius = radius
                    ),
                    radius = radius,
                    center = Offset(cx, cy)
                )
                val hexPath = polygonPath(cx, cy, radius * 0.86f, sides = 6, rotationRad = -PI / 6.0)
                drawPath(path = hexPath, color = NeonBackground)
                drawPath(
                    path = hexPath,
                    brush = Brush.linearGradient(
                        colors = listOf(NeonPrimary, NeonSecondary, NeonTertiary)
                    ),
                    style = Stroke(width = radius * 0.12f, join = StrokeJoin.Round)
                )
                // Inner glowing spark / circuit lines
                drawLine(
                    color = NeonSecondary,
                    start = Offset(cx - radius * 0.38f, cy),
                    end = Offset(cx + radius * 0.38f, cy),
                    strokeWidth = radius * 0.09f,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = NeonPrimary,
                    start = Offset(cx, cy - radius * 0.42f),
                    end = Offset(cx, cy + radius * 0.42f),
                    strokeWidth = radius * 0.09f,
                    cap = StrokeCap.Round
                )
                drawCircle(
                    color = NeonPrimary,
                    radius = radius * 0.18f,
                    center = Offset(cx, cy)
                )
                drawCircle(
                    color = Color.White,
                    radius = radius * 0.07f,
                    center = Offset(cx, cy)
                )
            }

            ThemeMode.SYSTEM, ThemeMode.LIGHT, ThemeMode.DARK -> {
                val p = if (effectiveDark) DarkPrimary else LightPrimary
                val t = if (effectiveDark) DarkTertiary else LightTertiary
                drawCircle(
                    brush = Brush.linearGradient(
                        colors = listOf(p, t),
                        start = Offset(0f, 0f),
                        end = Offset(w, h)
                    ),
                    radius = radius * 0.92f,
                    center = Offset(cx, cy)
                )
                drawFourPointSpark(
                    center = Offset(cx, cy),
                    outerRadius = radius * 0.56f,
                    innerRadius = radius * 0.18f,
                    color = Color.White
                )
                drawCircle(
                    color = Color.White.copy(alpha = 0.85f),
                    radius = radius * 0.09f,
                    center = Offset(cx + radius * 0.42f, cy - radius * 0.40f)
                )
            }
        }
    }
}

/**
 * Theme-adaptive hero banner replacing static bitmap artwork on Home, Setup, and About screens.
 */
@Composable
fun PersonalAiHeroBanner(
    themeMode: ThemeMode = LocalThemeMode.current,
    subtitle: String? = null,
    modifier: Modifier = Modifier
) {
    val systemDark = isSystemInDarkTheme()
    val effectiveDark = when (themeMode) {
        ThemeMode.DARK, ThemeMode.NEON -> true
        ThemeMode.LIGHT, ThemeMode.PERSIAN -> false
        ThemeMode.SYSTEM -> systemDark
    }

    val bannerShape = when (themeMode) {
        ThemeMode.NEON -> RoundedCornerShape(14.dp)
        ThemeMode.PERSIAN -> RoundedCornerShape(18.dp)
        else -> RoundedCornerShape(16.dp)
    }

    val borderStroke = when (themeMode) {
        ThemeMode.PERSIAN -> BorderStroke(1.5.dp, PersianTertiary.copy(alpha = 0.7f))
        ThemeMode.NEON -> BorderStroke(1.5.dp, NeonPrimary.copy(alpha = 0.85f))
        else -> BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    }

    Surface(
        shape = bannerShape,
        border = borderStroke,
        modifier = modifier
            .fillMaxWidth()
            .height(132.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                when (themeMode) {
                    ThemeMode.PERSIAN -> {
                        drawRect(
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF0A2E5C),
                                    PersianPrimary,
                                    Color(0xFF005C5A)
                                ),
                                start = Offset(0f, 0f),
                                end = Offset(w, h)
                            )
                        )
                        // Architectural Isfahan tilework geometric rings & gold stars
                        val starCenter = Offset(w * 0.84f, h * 0.50f)
                        drawCircle(
                            color = PersianTertiary.copy(alpha = 0.22f),
                            radius = h * 0.68f,
                            center = starCenter,
                            style = Stroke(width = 2.dp.toPx())
                        )
                        drawCircle(
                            color = Color(0xFFFEF0C7).copy(alpha = 0.20f),
                            radius = h * 0.52f,
                            center = starCenter,
                            style = Stroke(width = 1.2.dp.toPx())
                        )
                        drawShamsehStar(
                            center = starCenter,
                            outerRadius = h * 0.42f,
                            innerRadius = h * 0.21f,
                            fillColor = PersianTertiary.copy(alpha = 0.24f),
                            strokeColor = Color(0xFFFEF0C7).copy(alpha = 0.55f),
                            strokeWidth = 1.4.dp.toPx()
                        )
                        drawLine(
                            color = PersianTertiary.copy(alpha = 0.45f),
                            start = Offset(0f, h - 4.dp.toPx()),
                            end = Offset(w, h - 4.dp.toPx()),
                            strokeWidth = 2.dp.toPx()
                        )
                    }

                    ThemeMode.NEON -> {
                        drawRect(
                            brush = Brush.linearGradient(
                                colors = listOf(NeonBackground, NeonSurface, Color(0xFF1A0836)),
                                start = Offset(0f, 0f),
                                end = Offset(w, h)
                            )
                        )
                        // Subtle cyber grid
                        val step = 22.dp.toPx()
                        var x = 0f
                        while (x < w) {
                            drawLine(
                                color = NeonPrimary.copy(alpha = 0.12f),
                                start = Offset(x, 0f),
                                end = Offset(x, h),
                                strokeWidth = 1f
                            )
                            x += step
                        }
                        var y = 0f
                        while (y < h) {
                            drawLine(
                                color = NeonTertiary.copy(alpha = 0.12f),
                                start = Offset(0f, y),
                                end = Offset(w, y),
                                strokeWidth = 1f
                            )
                            y += step
                        }
                        // Glowing neon energy arcs
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(NeonSecondary.copy(alpha = 0.32f), Color.Transparent),
                                center = Offset(w * 0.85f, h * 0.45f),
                                radius = h * 0.85f
                            ),
                            radius = h * 0.85f,
                            center = Offset(w * 0.85f, h * 0.45f)
                        )
                        drawLine(
                            brush = Brush.horizontalGradient(listOf(NeonPrimary, NeonSecondary)),
                            start = Offset(0f, h - 2.dp.toPx()),
                            end = Offset(w, h - 2.dp.toPx()),
                            strokeWidth = 2.5.dp.toPx()
                        )
                    }

                    else -> {
                        val gradStart = if (effectiveDark) Color(0xFF0F2547) else Color(0xFF1E3A8A)
                        val gradEnd = if (effectiveDark) Color(0xFF0F4C4A) else Color(0xFF0F766E)
                        drawRect(
                            brush = Brush.linearGradient(
                                colors = listOf(gradStart, gradEnd),
                                start = Offset(0f, 0f),
                                end = Offset(w, h)
                            )
                        )
                        drawCircle(
                            color = Color.White.copy(alpha = 0.12f),
                            radius = h * 0.72f,
                            center = Offset(w * 0.88f, h * 0.32f),
                            style = Stroke(width = 1.5.dp.toPx())
                        )
                        drawCircle(
                            color = Color.White.copy(alpha = 0.08f),
                            radius = h * 0.46f,
                            center = Offset(w * 0.88f, h * 0.32f)
                        )
                    }
                }
            }

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 18.dp, vertical = 14.dp)
            ) {
                PersonalAiLogo(themeMode = themeMode, size = 56.dp)
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    val badgeLabel = when (themeMode) {
                        ThemeMode.PERSIAN -> "PERSIAN EDITION • فیروزه‌ای"
                        ThemeMode.NEON -> "NEON CYBER • OVERDRIVE"
                        else -> "ANDROID PERSONAL ASSISTANT"
                    }
                    Text(
                        text = badgeLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = JetBrainsMonoFontFamily,
                        color = when (themeMode) {
                            ThemeMode.PERSIAN -> Color(0xFFFEF0C7)
                            ThemeMode.NEON -> NeonPrimary
                            else -> Color(0xFFBFDBFE)
                        }
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Personal AI",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = subtitle ?: when (themeMode) {
                            ThemeMode.PERSIAN -> "هوش مصنوعی شخصی • Screen, Files & Tools"
                            ThemeMode.NEON -> "High-contrast cyber assistant, voice & floating HUD"
                            else -> "Provider-independent assistant, files, apps & screen AI"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.86f)
                    )
                }
            }
        }
    }
}

/**
 * Visual Theme Selector list/cards displaying live swatches + logo preview per theme.
 */
@Composable
fun ThemeSelectorList(
    selectedTheme: ThemeMode,
    onSelectTheme: (ThemeMode) -> Unit,
    modifier: Modifier = Modifier
) {
    val systemDark = isSystemInDarkTheme()
    Column(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = modifier
    ) {
        ThemeMode.entries.forEach { mode ->
            val selected = selectedTheme == mode
            val swatches = mode.previewSwatchColors(systemDark)
            val border = if (selected) {
                BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
            } else {
                BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            }

            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(
                    containerColor = if (selected) {
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                    } else {
                        MaterialTheme.colorScheme.surface
                    }
                ),
                border = border,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(MaterialTheme.shapes.medium)
                    .clickable { onSelectTheme(mode) }
                    .testTag("theme_option_${mode.id}")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    PersonalAiLogo(themeMode = mode, size = 38.dp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = mode.label,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = mode.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        swatches.forEach { swatch ->
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(swatch)
                            )
                        }
                    }
                    if (selected) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = "Selected theme",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ThemePickerDialog(
    selectedTheme: ThemeMode,
    onSelectTheme: (ThemeMode) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text("Select App Theme", fontWeight = FontWeight.SemiBold)
                Text(
                    text = "Updates the entire app, floating bubble, panel & logo",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        text = {
            ThemeSelectorList(
                selectedTheme = selectedTheme,
                onSelectTheme = { mode ->
                    onSelectTheme(mode)
                    onDismiss()
                }
            )
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

private fun DrawScope.drawShamsehStar(
    center: Offset,
    outerRadius: Float,
    innerRadius: Float,
    fillColor: Color,
    strokeColor: Color,
    strokeWidth: Float
) {
    val points = 16
    val path = Path()
    for (i in 0 until points) {
        val r = if (i % 2 == 0) outerRadius else innerRadius
        val angle = (i * PI / 8.0) - (PI / 2.0)
        val px = center.x + (r * cos(angle)).toFloat()
        val py = center.y + (r * sin(angle)).toFloat()
        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
    }
    path.close()
    drawPath(path = path, color = fillColor)
    drawPath(
        path = path,
        color = strokeColor,
        style = Stroke(width = strokeWidth, join = StrokeJoin.Round)
    )
}

private fun DrawScope.drawFourPointSpark(
    center: Offset,
    outerRadius: Float,
    innerRadius: Float,
    color: Color
) {
    val path = Path()
    val points = 8
    for (i in 0 until points) {
        val r = if (i % 2 == 0) outerRadius else innerRadius
        val angle = (i * PI / 4.0) - (PI / 2.0)
        val px = center.x + (r * cos(angle)).toFloat()
        val py = center.y + (r * sin(angle)).toFloat()
        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
    }
    path.close()
    drawPath(path = path, color = color)
}

private fun polygonPath(
    cx: Float,
    cy: Float,
    radius: Float,
    sides: Int,
    rotationRad: Double = 0.0
): Path {
    val path = Path()
    for (i in 0 until sides) {
        val angle = rotationRad + (2.0 * PI * i / sides)
        val px = cx + (radius * cos(angle)).toFloat()
        val py = cy + (radius * sin(angle)).toFloat()
        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
    }
    path.close()
    return path
}
