package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.SectionHeader
import com.example.ui.components.UtilityCard
import com.example.ui.components.formatFileSize
import com.example.ui.components.formatTimestamp
import com.example.ui.viewmodel.PersonalAiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileIndexScreen(
    viewModel: PersonalAiViewModel,
    onBack: () -> Unit,
    onOpenFileSearch: () -> Unit
) {
    val progress by viewModel.indexProgress.collectAsStateWithLifecycle()
    val totalIndexed by viewModel.totalIndexedFiles.collectAsStateWithLifecycle()
    val folders by viewModel.authorizedFolders.collectAsStateWithLifecycle()
    val recentFiles by viewModel.recentFiles.collectAsStateWithLifecycle()

    val folderLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> viewModel.onFolderAuthorized(uri) }

    val isScanning = progress?.status == "SCANNING"

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("File Index", fontWeight = FontWeight.SemiBold) },
                actions = {
                    IconButton(onClick = onOpenFileSearch) {
                        Icon(Icons.Filled.Search, contentDescription = "Search files")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 720.dp)
            ) {
                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = when (progress?.status) {
                                    "SCANNING" -> "Scanning files..."
                                    "PAUSED" -> "Scan paused"
                                    "CANCELLED" -> "Scan cancelled"
                                    "ERROR" -> "Scan encountered an issue"
                                    else -> "Local File Index"
                                },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold
                            )

                            if (isScanning) {
                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            }

                            Text(
                                text = "$totalIndexed files indexed",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )

                            val images = progress?.imagesCount ?: 0
                            val videos = progress?.videosCount ?: 0
                            val docs = progress?.documentsCount ?: 0
                            Text(
                                text = "$images images  •  $videos videos  •  $docs documents",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (!progress?.currentFolder.isNullOrBlank()) {
                                Text(
                                    text = progress!!.currentFolder,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (!progress?.errorMessage.isNullOrBlank()) {
                                Text(
                                    text = progress!!.errorMessage!!,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.error
                                )
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (isScanning) {
                                    OutlinedButton(
                                        onClick = { viewModel.pauseFileIndexing() },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Filled.Pause, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Pause")
                                    }
                                    OutlinedButton(
                                        onClick = { viewModel.cancelFileIndexing() },
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Filled.Cancel, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Cancel")
                                    }
                                } else {
                                    Button(
                                        onClick = { viewModel.startFileIndexing(incremental = true) },
                                        modifier = Modifier
                                            .weight(1f)
                                            .testTag("file_index_scan_button")
                                    ) {
                                        Icon(
                                            imageVector = if (progress?.status == "PAUSED") Icons.Filled.PlayArrow else Icons.Filled.Refresh,
                                            contentDescription = null
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(if (progress?.status == "PAUSED") "Resume Scan" else "Incremental Scan")
                                    }
                                    OutlinedButton(
                                        onClick = { viewModel.startFileIndexing(incremental = false) }
                                    ) {
                                        Text("Full Rescan")
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        SectionHeader(
                            title = "Authorized SAF Folders",
                            subtitle = "Indexed strictly on-device; never uploaded",
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { folderLauncher.launch(null) },
                            modifier = Modifier.testTag("file_index_add_folder_button")
                        ) {
                            Icon(Icons.Filled.FolderOpen, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Add Folder")
                        }
                    }
                }

                if (folders.isEmpty()) {
                    item {
                        EmptyStatePanel(
                            icon = Icons.Filled.FolderOpen,
                            title = "No folders selected",
                            message = "Grant access to Documents, Downloads, or project folders using Android's Storage Access Framework so Personal AI can search them locally.",
                            actionLabel = "Authorize Folder",
                            onAction = { folderLauncher.launch(null) }
                        )
                    }
                } else {
                    items(folders, key = { it.uri.toString() }) { folder ->
                        UtilityCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(14.dp)
                            ) {
                                Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(folder.displayName, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                    Text(
                                        text = "Authorized ${formatTimestamp(folder.grantedTime)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = { viewModel.removeAuthorizedFolder(folder.uri) }) {
                                    Icon(Icons.Filled.DeleteOutline, contentDescription = "Revoke folder access")
                                }
                            }
                        }
                    }
                }

                if (recentFiles.isNotEmpty()) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            SectionHeader("Recently Indexed (${recentFiles.size})", modifier = Modifier.weight(1f))
                            TextButton(onClick = { viewModel.clearFileIndex() }) {
                                Text("Clear Index", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                    items(recentFiles.take(25), key = { it.id }) { file ->
                        UtilityCard(
                            onClick = { viewModel.openFile(file) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(12.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(file.name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Medium)
                                    Text(
                                        text = "${file.displayPath} • ${formatFileSize(file.sizeBytes)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    text = file.category,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
