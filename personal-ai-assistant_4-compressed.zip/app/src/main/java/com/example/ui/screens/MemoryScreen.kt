package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.SectionHeader
import com.example.ui.components.UtilityCard
import com.example.ui.components.formatTimestamp
import com.example.ui.viewmodel.PersonalAiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemoryScreen(
    viewModel: PersonalAiViewModel,
    onBack: () -> Unit
) {
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val assistantSettings by viewModel.assistantSettings.collectAsStateWithLifecycle()
    var newMemoryInput by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Memory Management", fontWeight = FontWeight.SemiBold) },
                actions = {
                    if (memories.isNotEmpty()) {
                        IconButton(
                            onClick = { viewModel.clearAllMemories() },
                            modifier = Modifier.testTag("memory_clear_all_button")
                        ) {
                            Icon(Icons.Filled.DeleteSweep, contentDescription = "Clear all memories")
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 680.dp)
            ) {
                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            SettingToggleRow(
                                title = "Enable Personal Memory",
                                subtitle = "When disabled, saved memories are not created or sent to the AI.",
                                checked = assistantSettings.memoryEnabled,
                                onCheckedChange = viewModel::setMemoryEnabled
                            )
                        }
                    }
                }

                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text("Add Preference or Note", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = "Do not store passwords or API keys here. Secret-like strings are automatically blocked.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                OutlinedTextField(
                                    value = newMemoryInput,
                                    onValueChange = { newMemoryInput = it },
                                    placeholder = { Text("e.g. Prefer Firefox for web links") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("memory_add_input")
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        if (newMemoryInput.isNotBlank()) {
                                            viewModel.addMemory(newMemoryInput)
                                            newMemoryInput = ""
                                        }
                                    },
                                    enabled = assistantSettings.memoryEnabled && newMemoryInput.isNotBlank(),
                                    modifier = Modifier.testTag("memory_add_button")
                                ) {
                                    Icon(Icons.Filled.Add, contentDescription = "Save memory")
                                }
                            }
                        }
                    }
                }

                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        SectionHeader("Saved Memories (${memories.size})", modifier = Modifier.weight(1f))
                        if (memories.isNotEmpty()) {
                            TextButton(onClick = { viewModel.clearAllMemories() }) {
                                Text("Clear All", color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }

                if (memories.isEmpty()) {
                    item {
                        EmptyStatePanel(
                            icon = Icons.Filled.Psychology,
                            title = "No memories saved",
                            message = "Memories remain transparent and user-controlled. Add a preference above or ask the assistant to remember something."
                        )
                    }
                } else {
                    items(memories, key = { it.id }) { mem ->
                        UtilityCard(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(14.dp)
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(mem.fact, style = MaterialTheme.typography.bodyMedium)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "${mem.category} • ${formatTimestamp(mem.updatedAt)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.deleteMemory(mem.id) },
                                    modifier = Modifier.testTag("memory_delete_${mem.id}")
                                ) {
                                    Icon(Icons.Filled.Delete, contentDescription = "Delete memory")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
