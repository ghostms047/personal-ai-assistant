package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.data.settings.ThemeMode

private val DarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = DarkOnPrimary,
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = DarkOnPrimaryContainer,
    secondary = DarkSecondary,
    onSecondary = DarkOnSecondary,
    secondaryContainer = DarkSecondaryContainer,
    onSecondaryContainer = DarkOnSecondaryContainer,
    tertiary = DarkTertiary,
    onTertiary = DarkOnTertiary,
    tertiaryContainer = DarkTertiaryContainer,
    onTertiaryContainer = DarkOnTertiaryContainer,
    background = DarkBackground,
    onBackground = DarkOnBackground,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    surfaceContainerLow = DarkSurfaceContainerLow,
    surfaceContainer = DarkSurfaceContainer,
    surfaceContainerHigh = DarkSurfaceContainerHigh,
    outline = DarkOutline,
    outlineVariant = DarkOutlineVariant,
    error = DarkError,
    onError = DarkOnError,
    errorContainer = DarkErrorContainer,
    onErrorContainer = DarkOnErrorContainer
)

private val LightColorScheme = lightColorScheme(
    primary = LightPrimary,
    onPrimary = LightOnPrimary,
    primaryContainer = LightPrimaryContainer,
    onPrimaryContainer = LightOnPrimaryContainer,
    secondary = LightSecondary,
    onSecondary = LightOnSecondary,
    secondaryContainer = LightSecondaryContainer,
    onSecondaryContainer = LightOnSecondaryContainer,
    tertiary = LightTertiary,
    onTertiary = LightOnTertiary,
    tertiaryContainer = LightTertiaryContainer,
    onTertiaryContainer = LightOnTertiaryContainer,
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    surfaceContainerLow = LightSurfaceContainerLow,
    surfaceContainer = LightSurfaceContainer,
    surfaceContainerHigh = LightSurfaceContainerHigh,
    outline = LightOutline,
    outlineVariant = LightOutlineVariant,
    error = LightError,
    onError = LightOnError,
    errorContainer = LightErrorContainer,
    onErrorContainer = LightOnErrorContainer
)

private val PersianColorScheme = lightColorScheme(
    primary = PersianPrimary,
    onPrimary = PersianOnPrimary,
    primaryContainer = PersianPrimaryContainer,
    onPrimaryContainer = PersianOnPrimaryContainer,
    secondary = PersianSecondary,
    onSecondary = PersianOnSecondary,
    secondaryContainer = PersianSecondaryContainer,
    onSecondaryContainer = PersianOnSecondaryContainer,
    tertiary = PersianTertiary,
    onTertiary = PersianOnTertiary,
    tertiaryContainer = PersianTertiaryContainer,
    onTertiaryContainer = PersianOnTertiaryContainer,
    background = PersianBackground,
    onBackground = PersianOnBackground,
    surface = PersianSurface,
    onSurface = PersianOnSurface,
    surfaceVariant = PersianSurfaceVariant,
    onSurfaceVariant = PersianOnSurfaceVariant,
    surfaceContainerLow = PersianSurfaceContainerLow,
    surfaceContainer = PersianSurfaceContainer,
    surfaceContainerHigh = PersianSurfaceContainerHigh,
    outline = PersianOutline,
    outlineVariant = PersianOutlineVariant,
    error = PersianError,
    onError = PersianOnError,
    errorContainer = PersianErrorContainer,
    onErrorContainer = PersianOnErrorContainer
)

private val NeonColorScheme = darkColorScheme(
    primary = NeonPrimary,
    onPrimary = NeonOnPrimary,
    primaryContainer = NeonPrimaryContainer,
    onPrimaryContainer = NeonOnPrimaryContainer,
    secondary = NeonSecondary,
    onSecondary = NeonOnSecondary,
    secondaryContainer = NeonSecondaryContainer,
    onSecondaryContainer = NeonOnSecondaryContainer,
    tertiary = NeonTertiary,
    onTertiary = NeonOnTertiary,
    tertiaryContainer = NeonTertiaryContainer,
    onTertiaryContainer = NeonOnTertiaryContainer,
    background = NeonBackground,
    onBackground = NeonOnBackground,
    surface = NeonSurface,
    onSurface = NeonOnSurface,
    surfaceVariant = NeonSurfaceVariant,
    onSurfaceVariant = NeonOnSurfaceVariant,
    surfaceContainerLow = NeonSurfaceContainerLow,
    surfaceContainer = NeonSurfaceContainer,
    surfaceContainerHigh = NeonSurfaceContainerHigh,
    outline = NeonOutline,
    outlineVariant = NeonOutlineVariant,
    error = NeonError,
    onError = NeonOnError,
    errorContainer = NeonErrorContainer,
    onErrorContainer = NeonOnErrorContainer
)

val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

val PersianShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

val NeonShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(22.dp)
)

val LocalThemeMode = staticCompositionLocalOf { ThemeMode.SYSTEM }
val LocalIsDarkTheme = staticCompositionLocalOf { false }

fun ThemeMode.isDarkAppearance(systemIsDark: Boolean): Boolean =
    when (this) {
        ThemeMode.DARK, ThemeMode.NEON -> true
        ThemeMode.LIGHT, ThemeMode.PERSIAN -> false
        ThemeMode.SYSTEM -> systemIsDark
    }

fun ThemeMode.previewSwatchColors(systemIsDark: Boolean): List<Color> =
    when (this) {
        ThemeMode.PERSIAN -> listOf(PersianPrimary, PersianSecondary, PersianTertiary, PersianBackground)
        ThemeMode.NEON -> listOf(NeonPrimary, NeonSecondary, NeonTertiary, NeonBackground)
        ThemeMode.DARK -> listOf(DarkPrimary, DarkTertiary, DarkSurface, DarkBackground)
        ThemeMode.LIGHT -> listOf(LightPrimary, LightTertiary, LightSurface, LightBackground)
        ThemeMode.SYSTEM -> if (systemIsDark) {
            listOf(DarkPrimary, DarkTertiary, DarkSurface, DarkBackground)
        } else {
            listOf(LightPrimary, LightTertiary, LightSurface, LightBackground)
        }
    }

@Composable
fun PersonalAiTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val effectiveDark = themeMode.isDarkAppearance(darkTheme)
    val colorScheme = when (themeMode) {
        ThemeMode.PERSIAN -> PersianColorScheme
        ThemeMode.NEON -> NeonColorScheme
        ThemeMode.SYSTEM, ThemeMode.LIGHT, ThemeMode.DARK -> when {
            dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
                val context = LocalContext.current
                if (effectiveDark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
            }
            effectiveDark -> DarkColorScheme
            else -> LightColorScheme
        }
    }
    val shapes = when (themeMode) {
        ThemeMode.PERSIAN -> PersianShapes
        ThemeMode.NEON -> NeonShapes
        else -> AppShapes
    }

    CompositionLocalProvider(
        LocalThemeMode provides themeMode,
        LocalIsDarkTheme provides effectiveDark
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = shapes,
            content = content
        )
    }
}
