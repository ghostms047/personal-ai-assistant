package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.PersonalAiHeroBanner
import com.example.ui.components.SectionHeader
import com.example.ui.components.UtilityCard

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(
    onBack: () -> Unit,
    onOpenPermissions: () -> Unit,
    onOpenMemory: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("About Personal AI", fontWeight = FontWeight.SemiBold) }
            )
        }
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 680.dp)
            ) {
                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            PersonalAiHeroBanner()
                            Text(
                                text = "Personal AI",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Version 1.0 • Controlled Android Assistant Architecture",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "Personal AI separates your external AI provider from device capabilities through a deterministic Tool & Safety Layer. Local files and installed apps are indexed in on-device Room SQLite storage.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                item { SectionHeader("Security & Official API Guarantees") }

                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text("• Provider-independent AI engine (Gemini, OpenAI, Anthropic, Custom)", style = MaterialTheme.typography.bodyMedium)
                            Text("• API keys encrypted at rest via Android Keystore AES-256-GCM", style = MaterialTheme.typography.bodyMedium)
                            Text("• Official VoiceInteractionService & RoleManager assistant integration", style = MaterialTheme.typography.bodyMedium)
                            Text("• Official AccessibilityService & AssistStructure screen context", style = MaterialTheme.typography.bodyMedium)
                            Text("• Storage Access Framework (SAF) local indexing with WorkManager", style = MaterialTheme.typography.bodyMedium)
                            Text("• Zero arbitrary shell execution, silent installs, or permission bypasses", style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = onOpenPermissions,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Review Permissions")
                        }
                        OutlinedButton(
                            onClick = onOpenMemory,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Manage Saved Memories")
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                    }
                }
            }
        }
    }
}
