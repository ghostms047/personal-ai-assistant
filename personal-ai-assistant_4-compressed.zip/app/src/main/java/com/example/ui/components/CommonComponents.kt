package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.assistant.AssistantOrchestrator
import com.example.data.db.ChatMessageEntity
import com.example.data.settings.ThemeMode
import com.example.tools.AskUserOption
import com.example.tools.PendingConfirmation
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalIsDarkTheme
import com.example.ui.theme.LocalThemeMode
import com.example.ui.theme.NeonPrimary
import com.example.ui.theme.PersianTertiary
import com.example.ui.theme.StatusGrantedContainerDark
import com.example.ui.theme.StatusGrantedContainerLight
import com.example.ui.theme.StatusGrantedDark
import com.example.ui.theme.StatusGrantedLight
import com.example.ui.theme.StatusWarningContainerDark
import com.example.ui.theme.StatusWarningContainerLight
import com.example.ui.theme.StatusWarningDark
import com.example.ui.theme.StatusWarningLight
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date

@Composable
fun UtilityCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val themeMode = LocalThemeMode.current
    val border = when (themeMode) {
        ThemeMode.NEON -> BorderStroke(1.dp, NeonPrimary.copy(alpha = 0.42f))
        ThemeMode.PERSIAN -> BorderStroke(1.dp, PersianTertiary.copy(alpha = 0.40f))
        else -> BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    }
    val colors = CardDefaults.cardColors(
        containerColor = MaterialTheme.colorScheme.surface
    )
    if (onClick != null) {
        Card(
            onClick = onClick,
            shape = MaterialTheme.shapes.medium,
            colors = colors,
            border = border,
            modifier = modifier
        ) {
            content()
        }
    } else {
        Card(
            shape = MaterialTheme.shapes.medium,
            colors = colors,
            border = border,
            modifier = modifier
        ) {
            content()
        }
    }
}

@Composable
fun StatusPill(
    granted: Boolean,
    grantedLabel: String = "Granted",
    notGrantedLabel: String = "Not granted",
    modifier: Modifier = Modifier
) {
    val isDark = LocalIsDarkTheme.current
    val container = when {
        granted && isDark -> StatusGrantedContainerDark
        granted -> StatusGrantedContainerLight
        isDark -> StatusWarningContainerDark
        else -> StatusWarningContainerLight
    }
    val content = when {
        granted && isDark -> StatusGrantedDark
        granted -> StatusGrantedLight
        isDark -> StatusWarningDark
        else -> StatusWarningLight
    }

    Surface(
        shape = RoundedCornerShape(999.dp),
        color = container,
        contentColor = content,
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Icon(
                imageVector = if (granted) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                contentDescription = null,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = if (granted) grantedLabel else notGrantedLabel,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun SectionHeader(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        if (!subtitle.isNullOrBlank()) {
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun EmptyStatePanel(
    icon: ImageVector,
    title: String,
    message: String,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    UtilityCard(modifier = modifier.fillMaxWidth()) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.size(52.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(12.dp)
                )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (actionLabel != null && onAction != null) {
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = onAction) {
                    Text(actionLabel)
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ChatMessageCard(
    message: ChatMessageEntity,
    onSelectOption: (AskUserOption) -> Unit,
    onConfirmAction: (PendingConfirmation, Boolean) -> Unit,
    onSpeak: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val isUser = message.role == AssistantOrchestrator.ROLE_USER
    val isTool = message.role == AssistantOrchestrator.ROLE_TOOL
    val isSystem = message.role == AssistantOrchestrator.ROLE_SYSTEM

    val options = remember(message.optionsJson) { parseChatOptions(message.optionsJson) }
    val confirmation = remember(message.pendingConfirmationJson) {
        parseChatConfirmation(message.pendingConfirmationJson)
    }

    Column(
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
        modifier = modifier.fillMaxWidth()
    ) {
        when {
            isTool -> {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.widthIn(max = 520.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                    ) {
                        Icon(
                            imageVector = if (message.toolSuccess == false) {
                                Icons.Filled.WarningAmber
                            } else {
                                Icons.Filled.Build
                            },
                            contentDescription = null,
                            tint = if (message.toolSuccess == false) {
                                MaterialTheme.colorScheme.error
                            } else {
                                MaterialTheme.colorScheme.primary
                            },
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = message.toolName ?: "tool",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFontFamily,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = message.content,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
            isSystem -> {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    contentColor = MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.widthIn(max = 540.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ErrorOutline,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = message.content,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
            else -> {
                Surface(
                    shape = RoundedCornerShape(
                        topStart = 18.dp,
                        topEnd = 18.dp,
                        bottomStart = if (isUser) 18.dp else 4.dp,
                        bottomEnd = if (isUser) 4.dp else 18.dp
                    ),
                    color = if (isUser) {
                        MaterialTheme.colorScheme.primary
                    } else {
                        MaterialTheme.colorScheme.surface
                    },
                    contentColor = if (isUser) {
                        MaterialTheme.colorScheme.onPrimary
                    } else {
                        MaterialTheme.colorScheme.onSurface
                    },
                    border = if (isUser) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                    modifier = Modifier.widthIn(max = 540.dp)
                ) {
                    Text(
                        text = message.content,
                        style = MaterialTheme.typography.bodyLarge,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                    )
                }
                if (!isUser && onSpeak != null && message.content.isNotBlank()) {
                    TextButton(
                        onClick = onSpeak,
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Read aloud",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Speak", style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
        }

        if (options.isNotEmpty()) {
            Spacer(modifier = Modifier.height(6.dp))
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.widthIn(max = 540.dp)
            ) {
                options.forEach { opt ->
                    AssistChip(
                        onClick = { onSelectOption(opt) },
                        label = {
                            Column {
                                Text(opt.label, style = MaterialTheme.typography.labelLarge)
                                if (opt.subtitle.isNotBlank()) {
                                    Text(
                                        opt.subtitle,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    )
                }
            }
        }

        if (confirmation != null) {
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { onConfirmAction(confirmation, true) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Text("Approve Action")
                }
                OutlinedButton(
                    onClick = { onConfirmAction(confirmation, false) }
                ) {
                    Text("Cancel")
                }
            }
        }
    }
}

fun formatFileSize(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val kb = bytes / 1024.0
    if (kb < 1024.0) return String.format("%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024.0) return String.format("%.1f MB", mb)
    return String.format("%.2f GB", mb / 1024.0)
}

fun formatTimestamp(millis: Long): String {
    if (millis <= 0L) return "Unknown"
    return DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(millis))
}

private fun parseChatOptions(json: String?): List<AskUserOption> {
    if (json.isNullOrBlank()) return emptyList()
    return try {
        val arr = JSONArray(json)
        List(arr.length()) { idx ->
            val obj = arr.getJSONObject(idx)
            AskUserOption(
                id = obj.optString("id", "opt_$idx"),
                label = obj.optString("label"),
                subtitle = obj.optString("subtitle"),
                replyValue = obj.optString("replyValue", obj.optString("label"))
            )
        }
    } catch (_: Exception) {
        emptyList()
    }
}

private fun parseChatConfirmation(json: String?): PendingConfirmation? {
    if (json.isNullOrBlank()) return null
    return try {
        val obj = JSONObject(json)
        PendingConfirmation(
            toolName = obj.optString("toolName"),
            argumentsJson = obj.optString("argumentsJson"),
            humanReadableSummary = obj.optString("summary")
        )
    } catch (_: Exception) {
        null
    }
}
