package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Calm Precision Slate & Cobalt palette — Light Theme
val LightPrimary = Color(0xFF1D4ED8)
val LightOnPrimary = Color(0xFFFFFFFF)
val LightPrimaryContainer = Color(0xFFDBEAFE)
val LightOnPrimaryContainer = Color(0xFF1E3A8A)

val LightSecondary = Color(0xFF475569)
val LightOnSecondary = Color(0xFFFFFFFF)
val LightSecondaryContainer = Color(0xFFE2E8F0)
val LightOnSecondaryContainer = Color(0xFF1E293B)

val LightTertiary = Color(0xFF0F766E)
val LightOnTertiary = Color(0xFFFFFFFF)
val LightTertiaryContainer = Color(0xFFCCFBF1)
val LightOnTertiaryContainer = Color(0xFF115E59)

val LightBackground = Color(0xFFF8F9FB)
val LightOnBackground = Color(0xFF0F172A)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF0F172A)
val LightSurfaceVariant = Color(0xFFEEF2F6)
val LightOnSurfaceVariant = Color(0xFF475569)
val LightSurfaceContainerLow = Color(0xFFF3F5F9)
val LightSurfaceContainer = Color(0xFFEDF1F7)
val LightSurfaceContainerHigh = Color(0xFFE5EAF2)
val LightOutline = Color(0xFFCBD5E1)
val LightOutlineVariant = Color(0xFFE2E8F0)

val LightError = Color(0xFFDC2626)
val LightOnError = Color(0xFFFFFFFF)
val LightErrorContainer = Color(0xFFFEE2E2)
val LightOnErrorContainer = Color(0xFF991B1B)

// Calm Precision Obsidian & Sky-Cobalt palette — Dark Theme
val DarkPrimary = Color(0xFF60A5FA)
val DarkOnPrimary = Color(0xFF0A192F)
val DarkPrimaryContainer = Color(0xFF1E3A8A)
val DarkOnPrimaryContainer = Color(0xFFDBEAFE)

val DarkSecondary = Color(0xFF94A3B8)
val DarkOnSecondary = Color(0xFF0F172A)
val DarkSecondaryContainer = Color(0xFF1E293B)
val DarkOnSecondaryContainer = Color(0xFFE2E8F0)

val DarkTertiary = Color(0xFF2DD4BF)
val DarkOnTertiary = Color(0xFF042F2E)
val DarkTertiaryContainer = Color(0xFF134E4A)
val DarkOnTertiaryContainer = Color(0xFFCCFBF1)

val DarkBackground = Color(0xFF0D1117)
val DarkOnBackground = Color(0xFFF1F5F9)
val DarkSurface = Color(0xFF161B22)
val DarkOnSurface = Color(0xFFF1F5F9)
val DarkSurfaceVariant = Color(0xFF1F2733)
val DarkOnSurfaceVariant = Color(0xFF94A3B8)
val DarkSurfaceContainerLow = Color(0xFF131820)
val DarkSurfaceContainer = Color(0xFF1B212B)
val DarkSurfaceContainerHigh = Color(0xFF242B37)
val DarkOutline = Color(0xFF334155)
val DarkOutlineVariant = Color(0xFF262E3B)

val DarkError = Color(0xFFF87171)
val DarkOnError = Color(0xFF450A0A)
val DarkErrorContainer = Color(0xFF7F1D1D)
val DarkOnErrorContainer = Color(0xFFFEE2E2)

// Semantic status tokens
val StatusGrantedLight = Color(0xFF059669)
val StatusGrantedContainerLight = Color(0xFFD1FAE5)
val StatusGrantedDark = Color(0xFF34D399)
val StatusGrantedContainerDark = Color(0xFF064E3B)

val StatusWarningLight = Color(0xFFD97706)
val StatusWarningContainerLight = Color(0xFFFEF3C7)
val StatusWarningDark = Color(0xFFFBBF24)
val StatusWarningContainerDark = Color(0xFF78350F)

// Persian (Firoozeh, Lapis Lazuli & Illuminated Gold) palette
val PersianPrimary = Color(0xFF007A78)
val PersianOnPrimary = Color(0xFFFFFFFF)
val PersianPrimaryContainer = Color(0xFFC8F3EE)
val PersianOnPrimaryContainer = Color(0xFF003837)

val PersianSecondary = Color(0xFF1D3E8A)
val PersianOnSecondary = Color(0xFFFFFFFF)
val PersianSecondaryContainer = Color(0xFFDDE6FA)
val PersianOnSecondaryContainer = Color(0xFF0F2257)

val PersianTertiary = Color(0xFFB7791F)
val PersianOnTertiary = Color(0xFFFFFFFF)
val PersianTertiaryContainer = Color(0xFFFEF0C7)
val PersianOnTertiaryContainer = Color(0xFF5A3703)

val PersianBackground = Color(0xFFFAF6EE)
val PersianOnBackground = Color(0xFF192328)
val PersianSurface = Color(0xFFFFFDF8)
val PersianOnSurface = Color(0xFF192328)
val PersianSurfaceVariant = Color(0xFFF0E8D8)
val PersianOnSurfaceVariant = Color(0xFF544B3D)
val PersianSurfaceContainerLow = Color(0xFFF7F1E4)
val PersianSurfaceContainer = Color(0xFFEFE6D4)
val PersianSurfaceContainerHigh = Color(0xFFE5DAC2)
val PersianOutline = Color(0xFFC4B08B)
val PersianOutlineVariant = Color(0xFFE0D3B8)

val PersianError = Color(0xFFB91C1C)
val PersianOnError = Color(0xFFFFFFFF)
val PersianErrorContainer = Color(0xFFFEE2E2)
val PersianOnErrorContainer = Color(0xFF7F1D1D)

// Neon Cyber (Electric Cyan, Laser Magenta & Ultraviolet Void) palette
val NeonPrimary = Color(0xFF00F5D4)
val NeonOnPrimary = Color(0xFF001F1A)
val NeonPrimaryContainer = Color(0xFF003D37)
val NeonOnPrimaryContainer = Color(0xFF80FFED)

val NeonSecondary = Color(0xFFFF2E93)
val NeonOnSecondary = Color(0xFF2B0015)
val NeonSecondaryContainer = Color(0xFF4F0029)
val NeonOnSecondaryContainer = Color(0xFFFFA6D2)

val NeonTertiary = Color(0xFFB366FF)
val NeonOnTertiary = Color(0xFF1E0038)
val NeonTertiaryContainer = Color(0xFF390669)
val NeonOnTertiaryContainer = Color(0xFFEAD4FF)

val NeonBackground = Color(0xFF060712)
val NeonOnBackground = Color(0xFFEEF4FF)
val NeonSurface = Color(0xFF0D0F21)
val NeonOnSurface = Color(0xFFEEF4FF)
val NeonSurfaceVariant = Color(0xFF151936)
val NeonOnSurfaceVariant = Color(0xFF9EAAD8)
val NeonSurfaceContainerLow = Color(0xFF0A0C1A)
val NeonSurfaceContainer = Color(0xFF11142B)
val NeonSurfaceContainerHigh = Color(0xFF191E3D)
val NeonOutline = Color(0xFF00C9AE)
val NeonOutlineVariant = Color(0xFF273163)

val NeonError = Color(0xFFFF4D6D)
val NeonOnError = Color(0xFF33000B)
val NeonErrorContainer = Color(0xFF520319)
val NeonOnErrorContainer = Color(0xFFFFD9E0)
