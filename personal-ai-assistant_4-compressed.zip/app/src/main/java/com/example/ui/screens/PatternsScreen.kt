package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.db.UserPatternEntity
import com.example.patterns.PatternRepository
import com.example.patterns.PatternStep
import com.example.ui.components.SectionHeader
import com.example.ui.components.UtilityCard
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.viewmodel.PersonalAiViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun PatternsScreen(
    viewModel: PersonalAiViewModel,
    onBack: () -> Unit
) {
    val patterns by viewModel.userPatterns.collectAsStateWithLifecycle()
    val runResult by viewModel.patternRunResult.collectAsStateWithLifecycle()
    val isRunning by viewModel.isRunningPattern.collectAsStateWithLifecycle()

    var showCreateDialog by remember { mutableStateOf(false) }

    if (showCreateDialog) {
        TeachPatternDialog(
            onDismiss = { showCreateDialog = false },
            onSave = { name, trigger, desc, steps ->
                viewModel.saveUserPattern(name, trigger, desc, steps)
                showCreateDialog = false
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("patterns_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Learned Patterns & Routines", fontWeight = FontWeight.SemiBold) }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                modifier = Modifier.testTag("patterns_add_button")
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Teach new pattern")
            }
        }
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 720.dp)
            ) {
                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.AutoAwesome,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Multi-Step Phone Habits & Automation",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            Text(
                                text = "Teach Personal AI your repeatable workflows (app launches, screen taps, typing, scrolling, virus scans, or game launches). Tell the AI \"Learn my morning routine\" in chat or create one below—then run it anytime by asking.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                if (runResult != null) {
                    item {
                        val report = runResult!!
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (report.allSucceeded) {
                                MaterialTheme.colorScheme.primaryContainer
                            } else {
                                MaterialTheme.colorScheme.errorContainer
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(6.dp),
                                modifier = Modifier.padding(14.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "Ran \"${report.patternName}\" (${report.succeededSteps}/${report.totalSteps})",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    IconButton(
                                        onClick = { viewModel.clearPatternRunResult() },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Filled.Close, contentDescription = "Dismiss run log", modifier = Modifier.size(16.dp))
                                    }
                                }
                                report.logs.forEach { logLine ->
                                    Text(
                                        text = "• $logLine",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontFamily = JetBrainsMonoFontFamily
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    SectionHeader(
                        title = "Saved Patterns (${patterns.size})",
                        subtitle = "Stored locally on your phone in SQLite"
                    )
                }

                if (patterns.isEmpty()) {
                    item {
                        UtilityCard(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.padding(16.dp)
                            ) {
                                Text(
                                    text = "No patterns taught yet",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Tap + Teach Pattern or tell the AI in chat: \"Whenever I say 'work setup', open Slack and Gmail\".",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Button(
                                    onClick = { showCreateDialog = true },
                                    modifier = Modifier.testTag("patterns_empty_create_button")
                                ) {
                                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Teach Your First Pattern")
                                }
                            }
                        }
                    }
                } else {
                    items(patterns, key = { it.id }) { pattern ->
                        PatternCard(
                            pattern = pattern,
                            isRunning = isRunning,
                            onRun = { viewModel.runUserPattern(pattern) },
                            onDelete = { viewModel.deleteUserPattern(pattern.id) }
                        )
                    }
                }

                item { Spacer(modifier = Modifier.height(72.dp)) }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun PatternCard(
    pattern: UserPatternEntity,
    isRunning: Boolean,
    onRun: () -> Unit,
    onDelete: () -> Unit
) {
    val steps = remember(pattern.stepsJson) { PatternRepository.decodeSteps(pattern.stepsJson) }
    UtilityCard(modifier = Modifier.fillMaxWidth()) {
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = pattern.name,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "Trigger: \"${pattern.triggerPhrase}\" • Used ${pattern.useCount}x",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("pattern_delete_${pattern.id}")
                ) {
                    Icon(
                        Icons.Filled.DeleteOutline,
                        contentDescription = "Delete pattern",
                        tint = MaterialTheme.colorScheme.error
                    )
                }
            }

            if (pattern.description.isNotBlank()) {
                Text(
                    text = pattern.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                steps.forEachIndexed { idx, step ->
                    val targetPreview = listOf(step.target, step.value)
                        .filter { it.isNotBlank() }
                        .joinToString(" -> ")
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = "${idx + 1}. ${step.action}" + if (targetPreview.isNotBlank()) " ($targetPreview)" else "",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = JetBrainsMonoFontFamily,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Button(
                onClick = onRun,
                enabled = !isRunning,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pattern_run_${pattern.id}")
            ) {
                if (isRunning) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Running…")
                } else {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Run Pattern Now")
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TeachPatternDialog(
    onDismiss: () -> Unit,
    onSave: (name: String, trigger: String, desc: String, steps: List<PatternStep>) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var trigger by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    val steps = remember {
        mutableStateListOf(PatternStep(action = "open_app", target = "Chrome"))
    }
    var newAction by remember { mutableStateOf("open_app") }
    var newTarget by remember { mutableStateOf("") }
    var newValue by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Teach a New Pattern") },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 420.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Quick preset starters
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    SuggestionChip(
                        onClick = {
                            name = "Security Audit"
                            trigger = "check device safety"
                            description = "Scan installed apps and files for viruses then open Android battery check"
                            steps.clear()
                            steps += PatternStep(action = "scan_viruses")
                            steps += PatternStep(action = "open_settings", target = "security")
                        },
                        label = { Text("Preset: Virus Check", style = MaterialTheme.typography.labelSmall) }
                    )
                    SuggestionChip(
                        onClick = {
                            name = "Browser Search Setup"
                            trigger = "open chrome and search"
                            description = "Open Chrome browser and scroll down"
                            steps.clear()
                            steps += PatternStep(action = "open_app", target = "Chrome")
                            steps += PatternStep(action = "wait", value = "1200")
                            steps += PatternStep(action = "scroll", target = "down")
                        },
                        label = { Text("Preset: Chrome Flow", style = MaterialTheme.typography.labelSmall) }
                    )
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Pattern Name") },
                    placeholder = { Text("e.g. Morning Routine") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pattern_name_input")
                )
                OutlinedTextField(
                    value = trigger,
                    onValueChange = { trigger = it },
                    label = { Text("Trigger Phrase") },
                    placeholder = { Text("e.g. start my morning routine") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("pattern_trigger_input")
                )
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Steps (${steps.size})",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold
                )
                steps.forEachIndexed { idx, step ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${idx + 1}. ${step.action} ${step.target} ${step.value}".trim(),
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = JetBrainsMonoFontFamily,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { if (steps.size > 1) steps.removeAt(idx) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Filled.Close, contentDescription = "Remove step", modifier = Modifier.size(15.dp))
                            }
                        }
                    }
                }

                Text("Add Step", style = MaterialTheme.typography.labelMedium)
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    PatternRepository.supportedActions.forEach { act ->
                        FilterChip(
                            selected = newAction == act,
                            onClick = { newAction = act },
                            label = { Text(act, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
                OutlinedTextField(
                    value = newTarget,
                    onValueChange = { newTarget = it },
                    label = { Text("Target (app, element, x,y, dir, url)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = newValue,
                    onValueChange = { newValue = it },
                    label = { Text("Value / Text / Delay ms (optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = {
                        steps += PatternStep(action = newAction, target = newTarget.trim(), value = newValue.trim())
                        newTarget = ""
                        newValue = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Append Step")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && steps.isNotEmpty()) {
                        onSave(name, trigger.ifBlank { name }, description, steps.toList())
                    }
                },
                enabled = name.isNotBlank() && steps.isNotEmpty(),
                modifier = Modifier.testTag("pattern_save_dialog_button")
            ) {
                Text("Save Pattern")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
