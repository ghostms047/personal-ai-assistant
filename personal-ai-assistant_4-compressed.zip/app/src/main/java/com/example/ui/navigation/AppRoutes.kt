package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable data object SetupRoute
@Serializable data object HomeRoute
@Serializable data object ChatRoute
@Serializable data object AssistantSettingsRoute
@Serializable data object ApiKeySettingsRoute
@Serializable data object PermissionsRoute
@Serializable data object FileIndexRoute
@Serializable data object FileSearchRoute
@Serializable data object AppsRoute
@Serializable data object ScreenUnderstandingRoute
@Serializable data object FloatingConfigRoute
@Serializable data object ModelsAndSpeechRoute
@Serializable data object AboutRoute
@Serializable data object MemoryRoute
@Serializable data object SecurityScanRoute
@Serializable data object PatternsRoute

