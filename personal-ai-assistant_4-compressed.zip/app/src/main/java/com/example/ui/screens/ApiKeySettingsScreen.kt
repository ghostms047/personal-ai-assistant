package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ai.local.LocalRuntimeStatus
import com.example.data.settings.AiApiProtocol
import com.example.data.settings.AiProviderType
import com.example.data.settings.AiRoutingMode
import com.example.data.settings.AiSettings
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.UtilityCard
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.viewmodel.PersonalAiViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ApiKeySettingsScreen(
    viewModel: PersonalAiViewModel,
    onBack: () -> Unit,
    onOpenModelsAndSpeech: () -> Unit = {}
) {
    val aiSettings by viewModel.aiSettings.collectAsStateWithLifecycle()
    val configuredProviders by viewModel.configuredProviders.collectAsStateWithLifecycle()
    val testResult by viewModel.testConnectionState.collectAsStateWithLifecycle()
    val isTesting by viewModel.isTestingConnection.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
    val activeAiRoute by viewModel.activeAiRoute.collectAsStateWithLifecycle()
    val localRuntimeState by viewModel.localRuntimeState.collectAsStateWithLifecycle()

    var localEndpointDraft by remember(aiSettings.localEndpointUrl) {
        mutableStateOf(aiSettings.localEndpointUrl)
    }
    var localModelDraft by remember(aiSettings.localModelName) {
        mutableStateOf(aiSettings.localModelName)
    }

    var selectedProvider by remember { mutableStateOf(aiSettings.provider) }
    var loadedSettings by remember { mutableStateOf(aiSettings) }
    var protocolDraft by remember { mutableStateOf(aiSettings.protocol) }
    var customLabelDraft by remember { mutableStateOf(aiSettings.customProviderLabel) }
    var keyDraft by remember { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }
    var modelDraft by remember { mutableStateOf(aiSettings.model) }
    var baseUrlDraft by remember { mutableStateOf(aiSettings.customBaseUrl) }
    var authHeaderDraft by remember { mutableStateOf(aiSettings.authHeaderName) }
    var authPrefixDraft by remember { mutableStateOf(aiSettings.authHeaderPrefix) }
    var enableNativeTools by remember { mutableStateOf(aiSettings.enableNativeTools) }
    var allowEmptyKey by remember { mutableStateOf(aiSettings.allowEmptyKey) }
    var temperature by remember { mutableFloatStateOf(aiSettings.temperature) }
    var showAdvancedAuth by remember { mutableStateOf(selectedProvider == AiProviderType.CUSTOM || selectedProvider == AiProviderType.AZURE_OPENAI) }

    LaunchedEffect(selectedProvider) {
        val loaded: AiSettings = viewModel.loadProviderSettings(selectedProvider)
        loadedSettings = loaded
        protocolDraft = loaded.protocol
        customLabelDraft = loaded.customProviderLabel
        keyDraft = ""
        modelDraft = loaded.model
        baseUrlDraft = loaded.customBaseUrl
        authHeaderDraft = loaded.authHeaderName
        authPrefixDraft = loaded.authHeaderPrefix
        enableNativeTools = loaded.enableNativeTools
        allowEmptyKey = loaded.allowEmptyKey
        temperature = loaded.temperature
        if (selectedProvider == AiProviderType.CUSTOM || selectedProvider == AiProviderType.AZURE_OPENAI) {
            showAdvancedAuth = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("API Key & Provider Settings", fontWeight = FontWeight.SemiBold) }
            )
        }
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 700.dp)
            ) {
                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Offline / Online AI Routing",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Active route: ${activeAiRoute.routeBadge}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                StatusPill(
                                    granted = isOnline,
                                    grantedLabel = "Online",
                                    notGrantedLabel = "Offline"
                                )
                            }

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                AiRoutingMode.entries.forEach { mode ->
                                    FilterChip(
                                        selected = aiSettings.routingMode == mode,
                                        onClick = { viewModel.setAiRoutingMode(mode) },
                                        label = { Text(mode.shortLabel) },
                                        modifier = Modifier.testTag("routing_mode_${mode.id}")
                                    )
                                }
                            }

                            Text(
                                text = aiSettings.routingMode.subtitle,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            HorizontalDivider()

                            // Mode A: Built-in On-Device GGUF Runtime (no external server URL needed)
                            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "On-Device Local AI (Embedded llama.cpp)",
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (aiSettings.hasOnDeviceModelConfigured) {
                                        "Default GGUF: ${aiSettings.defaultDownloadedTextModelName}"
                                    } else {
                                        "No GGUF model selected yet. Download one (e.g. Gemma 3 4B) and tap 'Set as Default AI' to chat completely offline on this phone."
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                when (localRuntimeState.status) {
                                    LocalRuntimeStatus.LOADED -> Text(
                                        text = "Loaded in RAM: ${localRuntimeState.loadedModelName} (${localRuntimeState.architecture} ${localRuntimeState.quantization}, ctx ${localRuntimeState.contextLength})",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontFamily = JetBrainsMonoFontFamily,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    LocalRuntimeStatus.LOADING -> Text(
                                        text = "Loading ${localRuntimeState.loadedModelName} into RAM…",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    LocalRuntimeStatus.ERROR -> if (!localRuntimeState.errorMessage.isNullOrBlank()) {
                                        Text(
                                            text = localRuntimeState.errorMessage!!,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.error
                                        )
                                    }
                                    LocalRuntimeStatus.NOT_LOADED -> Unit
                                }
                                OutlinedButton(
                                    onClick = onOpenModelsAndSpeech,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("manage_on_device_models_button")
                                ) {
                                    Icon(Icons.Filled.RecordVoiceOver, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Manage On-Device Models")
                                }
                            }

                            HorizontalDivider()

                            // Mode B: Optional External Local Server (completely separate from On-Device GGUF)
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Optional External Local Server",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "Off by default. Enable only if connecting Local mode to an external Ollama, LM Studio, or llama-server.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = aiSettings.localUseExternalServer,
                                    onCheckedChange = { viewModel.setLocalUseExternalServer(it) },
                                    modifier = Modifier.testTag("local_external_server_switch")
                                )
                            }

                            AnimatedVisibility(visible = aiSettings.localUseExternalServer) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        OutlinedTextField(
                                            value = localEndpointDraft,
                                            onValueChange = { localEndpointDraft = it },
                                            label = { Text("External Server URL") },
                                            singleLine = true,
                                            modifier = Modifier
                                                .weight(1.3f)
                                                .testTag("local_endpoint_input")
                                        )
                                        OutlinedTextField(
                                            value = localModelDraft,
                                            onValueChange = { localModelDraft = it },
                                            label = { Text("Served Model") },
                                            singleLine = true,
                                            modifier = Modifier
                                                .weight(1f)
                                                .testTag("local_model_input")
                                        )
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            viewModel.saveLocalAiConfig(
                                                endpointUrl = localEndpointDraft,
                                                modelName = localModelDraft,
                                                useExternalServer = true
                                            )
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("local_save_button")
                                    ) {
                                        Text("Save External Local Server")
                                    }
                                }
                            }
                        }
                    }
                }

                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(14.dp)
                        ) {
                            Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Use any AI company or custom API endpoint. Every key format is accepted and encrypted on-device with Android Keystore AES-256-GCM.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                item {
                    SectionHeader(
                        title = "AI Company / Preset",
                        subtitle = "Choose a preset or select Custom / Any AI for any provider"
                    )
                }

                item {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        AiProviderType.entries.forEach { provider ->
                            val hasSavedKey = provider in configuredProviders
                            FilterChip(
                                selected = selectedProvider == provider,
                                onClick = {
                                    selectedProvider = provider
                                    viewModel.selectProvider(provider)
                                },
                                leadingIcon = if (hasSavedKey) {
                                    {
                                        Icon(
                                            imageVector = Icons.Filled.CheckCircle,
                                            contentDescription = "Key saved",
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                } else null,
                                label = { Text(provider.displayName) }
                            )
                        }
                    }
                }

                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = if (selectedProvider == AiProviderType.CUSTOM && customLabelDraft.isNotBlank()) {
                                        customLabelDraft
                                    } else {
                                        selectedProvider.displayName
                                    },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                StatusPill(
                                    granted = loadedSettings.hasApiKey,
                                    grantedLabel = if (loadedSettings.allowEmptyKey && loadedSettings.apiKey.isBlank()) "Keyless" else "Key Stored",
                                    notGrantedLabel = "No Key"
                                )
                            }

                            if (loadedSettings.apiKey.isNotBlank()) {
                                Text(
                                    text = "Stored key: ${loadedSettings.maskedApiKey}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = JetBrainsMonoFontFamily,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (selectedProvider == AiProviderType.CUSTOM) {
                                OutlinedTextField(
                                    value = customLabelDraft,
                                    onValueChange = { customLabelDraft = it },
                                    label = { Text("Provider Display Name (Optional)") },
                                    placeholder = { Text("e.g. Company AI Gateway, Ollama, Bedrock Proxy") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            OutlinedTextField(
                                value = keyDraft,
                                onValueChange = { keyDraft = it },
                                label = { Text("API Key / Token (Any Format)") },
                                placeholder = { Text(selectedProvider.keyHint) },
                                visualTransformation = if (showKey) VisualTransformation.None else PasswordVisualTransformation(),
                                trailingIcon = {
                                    IconButton(onClick = { showKey = !showKey }) {
                                        Icon(
                                            imageVector = if (showKey) Icons.Filled.VisibilityOff else Icons.Filled.Visibility,
                                            contentDescription = if (showKey) "Hide key" else "Show key"
                                        )
                                    }
                                },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("api_key_input")
                            )

                            OutlinedTextField(
                                value = modelDraft,
                                onValueChange = { modelDraft = it },
                                label = { Text("Model / Deployment ID") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("api_model_input")
                            )

                            if (selectedProvider.suggestedModels.isNotEmpty()) {
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    selectedProvider.suggestedModels.forEach { suggested ->
                                        SuggestionChip(
                                            onClick = { modelDraft = suggested },
                                            label = { Text(suggested, style = MaterialTheme.typography.labelSmall) }
                                        )
                                    }
                                }
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                TextButton(
                                    onClick = {
                                        val draft = AiSettings(
                                            provider = selectedProvider,
                                            protocol = protocolDraft,
                                            customProviderLabel = customLabelDraft,
                                            apiKey = keyDraft.ifBlank { loadedSettings.apiKey },
                                            model = modelDraft,
                                            customBaseUrl = baseUrlDraft,
                                            authHeaderName = authHeaderDraft,
                                            authHeaderPrefix = authPrefixDraft,
                                            enableNativeTools = enableNativeTools,
                                            allowEmptyKey = allowEmptyKey,
                                            temperature = temperature
                                        )
                                        viewModel.fetchProviderModels(draft)
                                        onOpenModelsAndSpeech()
                                    },
                                    modifier = Modifier.testTag("api_fetch_models_button")
                                ) {
                                    Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Fetch Models")
                                }
                                TextButton(
                                    onClick = onOpenModelsAndSpeech,
                                    modifier = Modifier.testTag("api_open_models_speech_button")
                                ) {
                                    Icon(Icons.Filled.RecordVoiceOver, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Downloadable Models")
                                }
                            }

                            OutlinedTextField(
                                value = baseUrlDraft,
                                onValueChange = { baseUrlDraft = it },
                                label = { Text("Base URL or Full Endpoint URL") },
                                supportingText = {
                                    Text(
                                        text = when (protocolDraft) {
                                            AiApiProtocol.OPENAI_COMPATIBLE -> "Appends /chat/completions unless already included in URL"
                                            AiApiProtocol.GEMINI -> "Appends /models/{model}:generateContent unless already included"
                                            AiApiProtocol.ANTHROPIC -> "Appends /messages unless already included in URL"
                                        }
                                    )
                                },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            TextButton(
                                onClick = { showAdvancedAuth = !showAdvancedAuth },
                                modifier = Modifier.testTag("api_advanced_toggle")
                            ) {
                                Text("Protocol, Auth Header & Tool Compatibility")
                                Spacer(modifier = Modifier.width(6.dp))
                                Icon(
                                    imageVector = if (showAdvancedAuth) Icons.Filled.ExpandLess else Icons.Filled.ExpandMore,
                                    contentDescription = null
                                )
                            }

                            AnimatedVisibility(visible = showAdvancedAuth) {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("API Protocol Dialect", style = MaterialTheme.typography.labelLarge)
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        AiApiProtocol.entries.forEach { proto ->
                                            FilterChip(
                                                selected = protocolDraft == proto,
                                                onClick = {
                                                    protocolDraft = proto
                                                    if (selectedProvider == AiProviderType.CUSTOM) {
                                                        authHeaderDraft = proto.defaultAuthHeader
                                                        authPrefixDraft = proto.defaultAuthPrefix
                                                    }
                                                },
                                                label = { Text(proto.displayName) }
                                            )
                                        }
                                    }

                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        OutlinedTextField(
                                            value = authHeaderDraft,
                                            onValueChange = { authHeaderDraft = it },
                                            label = { Text("Auth Header Name") },
                                            placeholder = { Text("Authorization / x-api-key / api-key") },
                                            singleLine = true,
                                            modifier = Modifier.weight(1f)
                                        )
                                        OutlinedTextField(
                                            value = authPrefixDraft,
                                            onValueChange = { authPrefixDraft = it },
                                            label = { Text("Value Prefix") },
                                            placeholder = { Text("Bearer  (or blank)") },
                                            singleLine = true,
                                            modifier = Modifier.weight(0.8f)
                                        )
                                    }

                                    SettingToggleRow(
                                        title = "Native function/tool calling",
                                        subtitle = "Disable if your provider rejects 'tools' payloads (automatically falls back to structured JSON tools).",
                                        checked = enableNativeTools,
                                        onCheckedChange = { enableNativeTools = it }
                                    )

                                    SettingToggleRow(
                                        title = "Allow empty API key",
                                        subtitle = "Useful for self-hosted local network endpoints (e.g. Ollama) that don't require an auth key.",
                                        checked = allowEmptyKey,
                                        onCheckedChange = { allowEmptyKey = it }
                                    )
                                }
                            }

                            Column {
                                Text(
                                    text = "Temperature: ${String.format("%.1f", temperature)}",
                                    style = MaterialTheme.typography.labelMedium
                                )
                                Slider(
                                    value = temperature,
                                    onValueChange = { temperature = it },
                                    valueRange = 0f..1f
                                )
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Button(
                                    onClick = {
                                        viewModel.saveProviderConfig(
                                            provider = selectedProvider,
                                            protocol = protocolDraft,
                                            customLabel = customLabelDraft,
                                            apiKeyInput = keyDraft.ifBlank { null },
                                            model = modelDraft,
                                            baseUrl = baseUrlDraft,
                                            authHeaderName = authHeaderDraft,
                                            authHeaderPrefix = authPrefixDraft,
                                            enableNativeTools = enableNativeTools,
                                            allowEmptyKey = allowEmptyKey,
                                            temperature = temperature
                                        )
                                        keyDraft = ""
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("api_save_button")
                                ) {
                                    Text("Save")
                                }
                                OutlinedButton(
                                    onClick = {
                                        viewModel.testAiConnection(
                                            provider = selectedProvider,
                                            protocol = protocolDraft,
                                            customLabel = customLabelDraft,
                                            apiKey = keyDraft,
                                            model = modelDraft,
                                            baseUrl = baseUrlDraft,
                                            authHeaderName = authHeaderDraft,
                                            authHeaderPrefix = authPrefixDraft,
                                            allowEmptyKey = allowEmptyKey
                                        )
                                    },
                                    enabled = !isTesting,
                                    modifier = Modifier.testTag("api_test_button")
                                ) {
                                    if (isTesting) {
                                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                        Spacer(modifier = Modifier.width(6.dp))
                                    }
                                    Text("Test")
                                }
                            }

                            if (loadedSettings.apiKey.isNotBlank()) {
                                TextButton(
                                    onClick = { viewModel.clearProviderKey(selectedProvider) },
                                    modifier = Modifier.testTag("api_clear_key_button")
                                ) {
                                    Text("Remove Stored Key", color = MaterialTheme.colorScheme.error)
                                }
                            }

                            if (!testResult.isNullOrBlank()) {
                                Surface(
                                    shape = MaterialTheme.shapes.small,
                                    color = if (testResult!!.startsWith("Success")) {
                                        MaterialTheme.colorScheme.primaryContainer
                                    } else {
                                        MaterialTheme.colorScheme.errorContainer
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = testResult!!,
                                        style = MaterialTheme.typography.bodySmall,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
