package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.EmptyStatePanel
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.UtilityCard
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.viewmodel.PersonalAiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScreenUnderstandingScreen(
    viewModel: PersonalAiViewModel,
    onBack: () -> Unit,
    onAskAboutScreen: (String) -> Unit
) {
    val snapshot by viewModel.latestScreenSnapshot.collectAsStateWithLifecycle()
    val connected by viewModel.accessibilityConnected.collectAsStateWithLifecycle()
    val visionEnabled by viewModel.visionEnabled.collectAsStateWithLifecycle()

    val settingsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { viewModel.refreshSystemState() }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Screen Understanding", fontWeight = FontWeight.SemiBold) },
                actions = {
                    IconButton(onClick = { viewModel.refreshScreenSnapshot(userTriggered = true) }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh screen snapshot")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 720.dp)
            ) {
                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                                    Text(
                                        text = "Screen Vision (Only When You Want)",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = if (visionEnabled) {
                                            "Vision ON — reads screen only when requested."
                                        } else {
                                            "Vision OFF — zero background screen capture or Assist reading."
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = visionEnabled,
                                    onCheckedChange = viewModel::setVisionEnabled,
                                    modifier = Modifier.testTag("screen_vision_master_toggle")
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Accessibility Screen Reader", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                StatusPill(
                                    granted = connected,
                                    grantedLabel = "Connected",
                                    notGrantedLabel = "Inactive"
                                )
                            }
                            Text(
                                text = "Uses Android's official AccessibilityNodeInfo and AssistStructure APIs on demand only. Never runs passively in the background.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { settingsLauncher.launch(viewModel.getAccessibilitySettingsIntent()) },
                                    modifier = Modifier.testTag("screen_open_accessibility_button")
                                ) {
                                    Text(if (connected) "Accessibility Settings" else "Enable Screen Reader")
                                }
                                OutlinedButton(
                                    onClick = { viewModel.refreshScreenSnapshot(userTriggered = true) }
                                ) {
                                    Text("Capture Now")
                                }
                            }
                        }
                    }
                }

                val snap = snapshot
                if (snap == null) {
                    item {
                        EmptyStatePanel(
                            icon = Icons.Filled.Visibility,
                            title = if (visionEnabled) "No external screen captured yet" else "Screen Vision is OFF",
                            message = if (visionEnabled) {
                                "Tap Capture Now or tap the Eye icon in Chat/Overlay while viewing another app."
                            } else {
                                "Turn on Screen Vision above or tap the Eye icon in Chat/Overlay whenever you want Personal AI to inspect your screen."
                            }
                        )
                    }
                } else {
                    item {
                        UtilityCard(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(16.dp)
                            ) {
                                Text("Latest Captured Screen", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = "Package: ${snap.packageName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    fontFamily = JetBrainsMonoFontFamily
                                )
                                if (snap.windowTitle.isNotBlank()) {
                                    Text("Window: ${snap.windowTitle}", style = MaterialTheme.typography.bodySmall)
                                }
                                Text(
                                    text = "Source: ${snap.source} • ${formatTimestamp(snap.capturedAt)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { onAskAboutScreen("Explain what is currently on my screen.") },
                                        modifier = Modifier.testTag("screen_explain_ai_button")
                                    ) {
                                        Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Explain in AI Chat")
                                    }
                                    OutlinedButton(
                                        onClick = { viewModel.clearCachedScreenSnapshot() },
                                        modifier = Modifier.testTag("screen_clear_snapshot_button")
                                    ) {
                                        Text("Clear Snapshot")
                                    }
                                }
                            }
                        }
                    }

                    item {
                        SectionHeader(
                            title = "Extracted Visible Text",
                            subtitle = "${snap.elements.size} UI nodes inspected"
                        )
                    }

                    item {
                        UtilityCard(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = snap.fullText.ifBlank { "No readable text nodes on this window." },
                                style = MaterialTheme.typography.bodyMedium,
                                modifier = Modifier.padding(14.dp)
                            )
                        }
                    }

                    if (snap.interactiveElements.isNotEmpty()) {
                        item {
                            SectionHeader("Interactive Elements (${snap.interactiveElements.size})")
                        }
                        items(snap.interactiveElements.take(30), key = { it.index }) { el ->
                            UtilityCard(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.padding(12.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(el.displayLabel, style = MaterialTheme.typography.titleSmall)
                                        if (el.viewId.isNotBlank()) {
                                            Text(
                                                text = el.viewId,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontFamily = JetBrainsMonoFontFamily,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Text(
                                        text = if (el.isEditable) "INPUT" else "CLICKABLE",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
