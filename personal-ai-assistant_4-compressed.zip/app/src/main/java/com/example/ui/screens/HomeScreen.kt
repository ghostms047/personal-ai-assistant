package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FolderCopy
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.ManageSearch
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SettingsSuggest
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.PersonalAiHeroBanner
import com.example.ui.components.PersonalAiLogo
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.ThemePickerDialog
import com.example.ui.components.UtilityCard
import com.example.ui.viewmodel.PersonalAiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: PersonalAiViewModel,
    onNavigateToChat: () -> Unit,
    onNavigateToAssistantSettings: () -> Unit,
    onNavigateToApiKeys: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onNavigateToFileIndex: () -> Unit,
    onNavigateToFileSearch: () -> Unit,
    onNavigateToApps: () -> Unit,
    onNavigateToScreenUnderstanding: () -> Unit,
    onNavigateToFloatingConfig: () -> Unit,
    onNavigateToModelsAndSpeech: () -> Unit,
    onNavigateToSecurityScan: () -> Unit = {},
    onNavigateToPatterns: () -> Unit = {},
    onNavigateToMemory: () -> Unit,
    onNavigateToAbout: () -> Unit
) {
    val context = LocalContext.current
    val aiSettings by viewModel.aiSettings.collectAsStateWithLifecycle()
    val assistantSettings by viewModel.assistantSettings.collectAsStateWithLifecycle()
    val permissions by viewModel.permissions.collectAsStateWithLifecycle()
    val totalIndexed by viewModel.totalIndexedFiles.collectAsStateWithLifecycle()
    val launchableAppsCount by viewModel.launchableAppsCount.collectAsStateWithLifecycle()
    val installedGames by viewModel.installedGames.collectAsStateWithLifecycle()
    val userPatterns by viewModel.userPatterns.collectAsStateWithLifecycle()
    val securityReport by viewModel.securityReport.collectAsStateWithLifecycle()
    val totalChatMessages by viewModel.totalStoredChatMessages.collectAsStateWithLifecycle()
    val isFloatingRunning by viewModel.isFloatingRunning.collectAsStateWithLifecycle()
    val wakeWordRunning by viewModel.wakeWordRunning.collectAsStateWithLifecycle()
    val accessibilityConnected by viewModel.accessibilityConnected.collectAsStateWithLifecycle()
    val isOnline by viewModel.isOnline.collectAsStateWithLifecycle()
    val activeAiRoute by viewModel.activeAiRoute.collectAsStateWithLifecycle()

    val chosenName = assistantSettings.assistantName.ifBlank { "Personal AI" }

    var showThemePicker by remember { mutableStateOf(false) }

    if (showThemePicker) {
        ThemePickerDialog(
            selectedTheme = assistantSettings.themeMode,
            onSelectTheme = { mode ->
                viewModel.setThemeMode(mode)
                viewModel.showNotice("Theme set to ${mode.label}")
            },
            onDismiss = { showThemePicker = false }
        )
    }

    val grantedCount = permissions.count { it.isGranted }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        PersonalAiLogo(
                            themeMode = assistantSettings.themeMode,
                            size = 34.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = chosenName,
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = activeAiRoute.routeBadge,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showThemePicker = true },
                        modifier = Modifier.testTag("home_theme_selector_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Palette,
                            contentDescription = "Select Theme (${assistantSettings.themeMode.label})",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 720.dp)
            ) {
                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            PersonalAiHeroBanner(
                                themeMode = assistantSettings.themeMode
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Assistant Readiness",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = "${activeAiRoute.routeBadge} • $totalChatMessages local msgs • $grantedCount/${permissions.size} permissions",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                StatusPill(
                                    granted = activeAiRoute.issue == null,
                                    grantedLabel = if (activeAiRoute.isUsingLocal) "Local Ready" else "Online Ready",
                                    notGrantedLabel = if (isOnline) "Setup Needed" else "Offline"
                                )
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Button(
                                    onClick = onNavigateToChat,
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("home_open_chat_button")
                                ) {
                                    Icon(Icons.AutoMirrored.Filled.Chat, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Open AI Chat")
                                }
                                FilledTonalButton(
                                    onClick = { viewModel.setFloatingOverlayRunning(!isFloatingRunning) },
                                    modifier = Modifier.testTag("home_toggle_floating_button")
                                ) {
                                    Icon(Icons.Filled.Layers, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(if (isFloatingRunning) "Stop Bubble" else "Start Bubble")
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(
                                onClick = { viewModel.launchBottomWakeAssistant(context) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("home_wake_overlay_button")
                            ) {
                                Icon(Icons.Filled.GraphicEq, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    if (wakeWordRunning) {
                                        "Wake \"$chosenName\" Bottom Sheet (Listening)"
                                    } else {
                                        "Summon Bottom Assistant Overlay"
                                    }
                                )
                            }
                        }
                    }
                }

                // Live local metrics row
                item {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        StatMetricCard(
                            title = "Indexed Files",
                            value = totalIndexed.toString(),
                            subtitle = "Local SQLite",
                            onClick = onNavigateToFileIndex,
                            modifier = Modifier.weight(1f)
                        )
                        StatMetricCard(
                            title = "Installed Apps",
                            value = launchableAppsCount.toString(),
                            subtitle = "Launchable",
                            onClick = onNavigateToApps,
                            modifier = Modifier.weight(1f)
                        )
                        StatMetricCard(
                            title = "Screen Reader",
                            value = if (accessibilityConnected) "Active" else "Off",
                            subtitle = "Accessibility",
                            onClick = onNavigateToScreenUnderstanding,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    SectionHeader(
                        title = "Workspace & Device Tools",
                        subtitle = "All tools operate offline except external AI queries"
                    )
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        HomeModuleRow(
                            icon = Icons.Filled.ManageSearch,
                            title = "File Search",
                            subtitle = "Natural-language search across indexed files",
                            tag = "home_nav_file_search",
                            onClick = onNavigateToFileSearch
                        )
                        HomeModuleRow(
                            icon = Icons.Filled.FolderCopy,
                            title = "File Index",
                            subtitle = "Authorize folders, view scan progress, incremental updates",
                            tag = "home_nav_file_index",
                            onClick = onNavigateToFileIndex
                        )
                        HomeModuleRow(
                            icon = Icons.Filled.Apps,
                            title = "Installed Apps & Games",
                            subtitle = "Search and launch $launchableAppsCount apps (${installedGames.size} games) + touch gestures",
                            tag = "home_nav_apps",
                            onClick = onNavigateToApps
                        )
                        HomeModuleRow(
                            icon = Icons.Filled.Radar,
                            title = "Virus & Malware Scanner",
                            subtitle = securityReport?.overallStatusLabel ?: "Scan installed apps, sideloaded APKs & local files",
                            tag = "home_nav_security_scan",
                            onClick = onNavigateToSecurityScan
                        )
                        HomeModuleRow(
                            icon = Icons.Filled.AutoAwesome,
                            title = "Learned Patterns & Routines",
                            subtitle = "${userPatterns.size} saved user workflow(s) ready to run",
                            tag = "home_nav_patterns",
                            onClick = onNavigateToPatterns
                        )
                        HomeModuleRow(
                            icon = Icons.Filled.Visibility,
                            title = "Screen Understanding",
                            subtitle = if (accessibilityConnected) "Connected — inspect text, type, scroll & tap elements" else "Enable Accessibility to inspect & control screens",
                            tag = "home_nav_screen",
                            onClick = onNavigateToScreenUnderstanding
                        )
                        HomeModuleRow(
                            icon = Icons.Filled.Layers,
                            title = "Floating Assistant",
                            subtitle = if (isFloatingRunning) "Overlay active above apps" else "Configure Display Over Other Apps bubble",
                            tag = "home_nav_floating",
                            onClick = onNavigateToFloatingConfig
                        )
                    }
                }

                item {
                    SectionHeader(
                        title = "Configuration & Governance",
                        subtitle = "Provider keys, permissions, memory, and system defaults"
                    )
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        HomeModuleRow(
                            icon = Icons.Filled.Key,
                            title = "API Key Settings",
                            subtitle = "${aiSettings.effectiveDisplayName} • ${aiSettings.maskedApiKey}",
                            tag = "home_nav_api_keys",
                            onClick = onNavigateToApiKeys
                        )
                        HomeModuleRow(
                            icon = Icons.Filled.RecordVoiceOver,
                            title = "AI Models & Downloads",
                            subtitle = "Browse text & speech models, download, and set your default AI",
                            tag = "home_nav_models_speech",
                            onClick = onNavigateToModelsAndSpeech
                        )
                        HomeModuleRow(
                            icon = Icons.Filled.Security,
                            title = "Permissions",
                            subtitle = "$grantedCount of ${permissions.size} permissions granted",
                            tag = "home_nav_permissions",
                            onClick = onNavigateToPermissions
                        )
                        HomeModuleRow(
                            icon = Icons.Filled.SettingsSuggest,
                            title = "AI Name, Wake Word & Theme",
                            subtitle = "Name: $chosenName (${if (wakeWordRunning) "Listening" else "Wake Off"}) • Theme: ${assistantSettings.themeMode.label}",
                            tag = "home_nav_assistant_settings",
                            onClick = onNavigateToAssistantSettings
                        )
                        HomeModuleRow(
                            icon = Icons.Filled.Psychology,
                            title = "Memory Management",
                            subtitle = "View, delete, or disable personal assistant memories",
                            tag = "home_nav_memory",
                            onClick = onNavigateToMemory
                        )
                        HomeModuleRow(
                            icon = Icons.Filled.Info,
                            title = "About Personal AI",
                            subtitle = "Architecture, security guarantees, and API disclosures",
                            tag = "home_nav_about",
                            onClick = onNavigateToAbout
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatMetricCard(
    title: String,
    value: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    UtilityCard(onClick = onClick, modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun HomeModuleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    tag: String,
    onClick: () -> Unit
) {
    UtilityCard(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .testTag(tag)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.size(42.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(9.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
