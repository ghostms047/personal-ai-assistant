package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.permissions.PermissionId
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.components.UtilityCard
import com.example.ui.viewmodel.PersonalAiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionsScreen(
    viewModel: PersonalAiViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val permissions by viewModel.permissions.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.refreshSystemState()
    }

    val activityLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { viewModel.refreshSystemState() }

    val folderLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri -> viewModel.onFolderAuthorized(uri) }

    val micLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { viewModel.refreshSystemState() }

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { viewModel.refreshSystemState() }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Permissions", fontWeight = FontWeight.SemiBold) },
                actions = {
                    IconButton(
                        onClick = { viewModel.refreshSystemState() },
                        modifier = Modifier.testTag("permissions_refresh_button")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Refresh status")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 680.dp)
            ) {
                item {
                    SectionHeader(
                        title = "System Capabilities & Privacy",
                        subtitle = "Personal AI works gracefully even when optional permissions are declined."
                    )
                }

                items(permissions, key = { it.id.name }) { item ->
                    UtilityCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("permission_card_${item.id.name.lowercase()}")
                    ) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.weight(1f)
                                )
                                StatusPill(granted = item.isGranted)
                            }

                            Text(
                                text = item.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )

                            if (item.statusDetail.isNotBlank()) {
                                Text(
                                    text = "Status: ${item.statusDetail}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            if (!item.isGranted) {
                                Text(
                                    text = "Fallback: ${item.fallbackExplanation}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            val onEnableClick: () -> Unit = {
                                when (item.id) {
                                    PermissionId.DEFAULT_ASSISTANT -> {
                                        val roleIntent = viewModel.getAssistantRoleIntent()
                                        if (roleIntent != null) {
                                            activityLauncher.launch(roleIntent)
                                        } else {
                                            context.startActivity(viewModel.getVoiceInputSettingsIntent())
                                        }
                                    }
                                    PermissionId.OVERLAY -> {
                                        activityLauncher.launch(viewModel.getOverlaySettingsIntent())
                                    }
                                    PermissionId.ACCESSIBILITY -> {
                                        activityLauncher.launch(viewModel.getAccessibilitySettingsIntent())
                                    }
                                    PermissionId.FILE_ACCESS -> {
                                        folderLauncher.launch(null)
                                    }
                                    PermissionId.MICROPHONE -> {
                                        micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                    PermissionId.NOTIFICATIONS -> {
                                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                        } else {
                                            activityLauncher.launch(viewModel.getNotificationSettingsIntent())
                                        }
                                    }
                                }
                            }

                            if (item.isGranted) {
                                OutlinedButton(
                                    onClick = onEnableClick,
                                    modifier = Modifier.testTag("permission_manage_${item.id.name.lowercase()}")
                                ) {
                                    Text(if (item.id == PermissionId.FILE_ACCESS) "Add Another Folder" else "Manage in Settings")
                                }
                            } else {
                                Button(
                                    onClick = onEnableClick,
                                    modifier = Modifier.testTag("permission_enable_${item.id.name.lowercase()}")
                                ) {
                                    Text(if (item.id == PermissionId.FILE_ACCESS) "Authorize Folder" else "Enable Permission")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
