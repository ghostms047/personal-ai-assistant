package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.settings.AiApiProtocol
import com.example.data.settings.AiProviderType
import com.example.data.settings.ThemeMode
import com.example.permissions.PermissionId
import com.example.ui.components.PersonalAiHeroBanner
import com.example.ui.components.StatusPill
import com.example.ui.components.UtilityCard
import com.example.ui.viewmodel.PersonalAiViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SetupScreen(
    viewModel: PersonalAiViewModel,
    onSetupFinished: () -> Unit
) {
    val context = LocalContext.current
    val aiSettings by viewModel.aiSettings.collectAsStateWithLifecycle()
    val assistantSettings by viewModel.assistantSettings.collectAsStateWithLifecycle()
    val permissions by viewModel.permissions.collectAsStateWithLifecycle()
    val indexProgress by viewModel.indexProgress.collectAsStateWithLifecycle()
    val authorizedFolders by viewModel.authorizedFolders.collectAsStateWithLifecycle()

    var step by remember { mutableIntStateOf(0) }
    val totalSteps = 6

    var selectedProvider by remember(aiSettings.provider) { mutableStateOf(aiSettings.provider) }
    var selectedProtocol by remember(aiSettings.protocol) { mutableStateOf(aiSettings.protocol) }
    var apiKeyInput by remember { mutableStateOf("") }
    var modelInput by remember(aiSettings.provider) { mutableStateOf(aiSettings.model) }
    var baseUrlInput by remember(aiSettings.provider) { mutableStateOf(aiSettings.customBaseUrl) }

    val roleLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { viewModel.refreshSystemState() }

    val settingsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { viewModel.refreshSystemState() }

    val folderPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        viewModel.onFolderAuthorized(uri)
    }

    val micLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { viewModel.refreshSystemState() }

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { viewModel.refreshSystemState() }

    Scaffold { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 620.dp)
                    .weight(1f)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Step ${step + 1} of $totalSteps",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    TextButton(
                        onClick = {
                            viewModel.completeOnboarding()
                            onSetupFinished()
                        },
                        modifier = Modifier.testTag("setup_skip_button")
                    ) {
                        Text("Skip for now")
                    }
                }

                LinearProgressIndicator(
                    progress = { (step + 1) / totalSteps.toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                AnimatedContent(
                    targetState = step,
                    label = "setup_step",
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) { currentStep ->
                    when (currentStep) {
                        0 -> {
                            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                                PersonalAiHeroBanner(
                                    themeMode = assistantSettings.themeMode
                                )
                                Text(
                                    text = "Welcome to Personal AI",
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "A calm, privacy-conscious Android assistant built around official system APIs. Personal AI indexes only the folders you authorize, inspects your screen only with your permission, and connects directly to your chosen AI provider.",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text(
                                        text = "Choose your theme & logo style",
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        ThemeMode.entries.forEach { mode ->
                                            FilterChip(
                                                selected = assistantSettings.themeMode == mode,
                                                onClick = { viewModel.setThemeMode(mode) },
                                                label = { Text(mode.label) }
                                            )
                                        }
                                    }
                                }
                                UtilityCard(modifier = Modifier.fillMaxWidth()) {
                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.padding(16.dp)
                                    ) {
                                        Text(
                                            text = "What we will configure",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text("• Choose your external AI provider & API key", style = MaterialTheme.typography.bodyMedium)
                                        Text("• Optionally register as Android's Default Assistant", style = MaterialTheme.typography.bodyMedium)
                                        Text("• Enable screen understanding, floating bubble, or voice", style = MaterialTheme.typography.bodyMedium)
                                        Text("• Select folders to build a private local file index", style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }

                        1 -> {
                            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Key, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "AI Provider & API Key",
                                        style = MaterialTheme.typography.headlineSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Text(
                                    text = "Personal AI works with any AI company or custom API key (OpenAI, Gemini, Anthropic, xAI, Groq, Mistral, DeepSeek, OpenRouter, Azure, or custom endpoints). Keys are encrypted locally via Android Keystore.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    AiProviderType.entries.forEach { provider ->
                                        FilterChip(
                                            selected = selectedProvider == provider,
                                            onClick = {
                                                selectedProvider = provider
                                                selectedProtocol = provider.defaultProtocol
                                                modelInput = provider.defaultModel
                                                baseUrlInput = provider.defaultBaseUrl
                                                viewModel.selectProvider(provider)
                                            },
                                            label = { Text(provider.displayName) }
                                        )
                                    }
                                }
                                if (selectedProvider == AiProviderType.CUSTOM) {
                                    FlowRow(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        AiApiProtocol.entries.forEach { proto ->
                                            FilterChip(
                                                selected = selectedProtocol == proto,
                                                onClick = { selectedProtocol = proto },
                                                label = { Text(proto.displayName) }
                                            )
                                        }
                                    }
                                }
                                OutlinedTextField(
                                    value = apiKeyInput,
                                    onValueChange = { apiKeyInput = it },
                                    label = { Text("${selectedProvider.displayName} API Key") },
                                    placeholder = { Text(if (aiSettings.hasApiKey) "Saved (${aiSettings.maskedApiKey})" else selectedProvider.keyHint) },
                                    visualTransformation = PasswordVisualTransformation(),
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("setup_api_key_input")
                                )
                                OutlinedTextField(
                                    value = modelInput,
                                    onValueChange = { modelInput = it },
                                    label = { Text("Model ID") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = baseUrlInput,
                                    onValueChange = { baseUrlInput = it },
                                    label = { Text("Base URL / Endpoint") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedButton(
                                    onClick = {
                                        viewModel.saveProviderConfig(
                                            provider = selectedProvider,
                                            protocol = selectedProtocol,
                                            apiKeyInput = apiKeyInput.ifBlank { null },
                                            model = modelInput,
                                            baseUrl = baseUrlInput
                                        )
                                    },
                                    modifier = Modifier.testTag("setup_save_key_button")
                                ) {
                                    Text("Save Provider Configuration")
                                }
                            }
                        }

                        2 -> {
                            val status = permissions.firstOrNull { it.id == PermissionId.DEFAULT_ASSISTANT }
                            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.RecordVoiceOver, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Default Digital Assistant",
                                        style = MaterialTheme.typography.headlineSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Text(
                                    text = "Registering Personal AI as your default assistant lets Android invoke it from the power/corner gesture and share active screen Assist context securely.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                UtilityCard(modifier = Modifier.fillMaxWidth()) {
                                    Column(
                                        verticalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.padding(16.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text("Current Status", style = MaterialTheme.typography.titleSmall)
                                            StatusPill(
                                                granted = status?.isGranted == true,
                                                grantedLabel = "Default Assistant",
                                                notGrantedLabel = "Not default"
                                            )
                                        }
                                        Text(
                                            text = status?.fallbackExplanation.orEmpty(),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        Button(
                                            onClick = {
                                                val roleIntent = viewModel.getAssistantRoleIntent()
                                                if (roleIntent != null) {
                                                    roleLauncher.launch(roleIntent)
                                                } else {
                                                    context.startActivity(viewModel.getVoiceInputSettingsIntent())
                                                }
                                            },
                                            modifier = Modifier.testTag("setup_default_assistant_button")
                                        ) {
                                            Text("Set as Default Assistant")
                                        }
                                    }
                                }
                            }
                        }

                        3 -> {
                            val overlay = permissions.firstOrNull { it.id == PermissionId.OVERLAY }
                            val accessibility = permissions.firstOrNull { it.id == PermissionId.ACCESSIBILITY }
                            val mic = permissions.firstOrNull { it.id == PermissionId.MICROPHONE }
                            val notif = permissions.firstOrNull { it.id == PermissionId.NOTIFICATIONS }
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = "Optional Capabilities",
                                    style = MaterialTheme.typography.headlineSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Grant only the permissions you want to use. Personal AI continues functioning cleanly even if you skip optional permissions.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                SetupPermissionCard(
                                    icon = Icons.Filled.Layers,
                                    title = "Display Over Other Apps",
                                    description = "Shows the movable floating AI button above other apps.",
                                    granted = overlay?.isGranted == true,
                                    onEnable = { settingsLauncher.launch(viewModel.getOverlaySettingsIntent()) }
                                )
                                SetupPermissionCard(
                                    icon = Icons.Filled.Visibility,
                                    title = "Accessibility Screen Reader",
                                    description = "Lets you ask 'What is on my screen?' or 'Find Settings'.",
                                    granted = accessibility?.isGranted == true,
                                    onEnable = { settingsLauncher.launch(viewModel.getAccessibilitySettingsIntent()) }
                                )
                                SetupPermissionCard(
                                    icon = Icons.Filled.Mic,
                                    title = "Microphone",
                                    description = "Enables voice queries inside chat and the floating panel.",
                                    granted = mic?.isGranted == true,
                                    onEnable = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
                                )
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    SetupPermissionCard(
                                        icon = Icons.Filled.Notifications,
                                        title = "Notifications",
                                        description = "Displays persistent status while floating or scanning.",
                                        granted = notif?.isGranted == true,
                                        onEnable = { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                                    )
                                }
                            }
                        }

                        4 -> {
                            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.FolderOpen, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Local File Access & Index",
                                        style = MaterialTheme.typography.headlineSmall,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Text(
                                    text = "Choose folders via Android's Storage Access Framework. Files are indexed strictly on-device in SQLite and never uploaded to build the index.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Button(
                                    onClick = { folderPickerLauncher.launch(null) },
                                    modifier = Modifier.testTag("setup_choose_folder_button")
                                ) {
                                    Icon(Icons.Filled.FolderOpen, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Choose Folder to Index")
                                }
                                if (authorizedFolders.isNotEmpty()) {
                                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                                        Column(
                                            verticalArrangement = Arrangement.spacedBy(6.dp),
                                            modifier = Modifier.padding(14.dp)
                                        ) {
                                            Text("Authorized Folders (${authorizedFolders.size})", style = MaterialTheme.typography.titleSmall)
                                            authorizedFolders.forEach { folder ->
                                                Text("• ${folder.displayName}", style = MaterialTheme.typography.bodyMedium)
                                            }
                                        }
                                    }
                                }
                                indexProgress?.let { prog ->
                                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                                        Column(
                                            verticalArrangement = Arrangement.spacedBy(4.dp),
                                            modifier = Modifier.padding(14.dp)
                                        ) {
                                            Text(
                                                text = if (prog.status == "SCANNING") "Scanning files..." else "Index status: ${prog.status}",
                                                style = MaterialTheme.typography.titleSmall
                                            )
                                            Text("${prog.totalIndexed} files indexed", style = MaterialTheme.typography.bodyMedium)
                                            Text(
                                                "${prog.imagesCount} images • ${prog.videosCount} videos • ${prog.documentsCount} documents",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        else -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 24.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(20.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    modifier = Modifier.size(64.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.CheckCircle,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(16.dp)
                                    )
                                }
                                Text(
                                    text = "Setup Complete",
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Personal AI is ready. You can adjust API keys, permissions, file folders, or floating overlay preferences anytime from Home.",
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (step > 0) {
                        OutlinedButton(
                            onClick = { step-- },
                            modifier = Modifier.testTag("setup_back_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Back")
                        }
                    } else {
                        Spacer(modifier = Modifier.width(1.dp))
                    }

                    if (step < totalSteps - 1) {
                        Button(
                            onClick = {
                                if (step == 1 && apiKeyInput.isNotBlank()) {
                                    viewModel.saveProviderConfig(
                                        provider = selectedProvider,
                                        protocol = selectedProtocol,
                                        apiKeyInput = apiKeyInput,
                                        model = modelInput,
                                        baseUrl = baseUrlInput
                                    )
                                }
                                step++
                            },
                            modifier = Modifier.testTag("setup_next_button")
                        ) {
                            Text("Continue")
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                        }
                    } else {
                        Button(
                            onClick = {
                                viewModel.completeOnboarding()
                                onSetupFinished()
                            },
                            modifier = Modifier.testTag("setup_finish_button")
                        ) {
                            Text("Enter Personal AI")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SetupPermissionCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    description: String,
    granted: Boolean,
    onEnable: () -> Unit
) {
    UtilityCard(modifier = Modifier.fillMaxWidth()) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(14.dp)
        ) {
            Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            if (granted) {
                StatusPill(granted = true)
            } else {
                OutlinedButton(onClick = onEnable) {
                    Text("Enable")
                }
            }
        }
    }
}
