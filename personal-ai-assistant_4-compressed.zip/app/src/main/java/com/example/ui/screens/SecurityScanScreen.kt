package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.security.FindingTargetType
import com.example.security.SecurityFinding
import com.example.security.SecuritySeverity
import com.example.ui.components.SectionHeader
import com.example.ui.components.UtilityCard
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.viewmodel.PersonalAiViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun SecurityScanScreen(
    viewModel: PersonalAiViewModel,
    onBack: () -> Unit
) {
    val report by viewModel.securityReport.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanningSecurity.collectAsStateWithLifecycle()
    val indexedFilesCount by viewModel.totalIndexedFiles.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        if (report == null) {
            viewModel.runVirusScan()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("security_back_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text("Virus & Malware Scanner", fontWeight = FontWeight.SemiBold) }
            )
        }
    ) { innerPadding ->
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 720.dp)
            ) {
                item {
                    UtilityCard(modifier = Modifier.fillMaxWidth()) {
                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = when {
                                        isScanning -> MaterialTheme.colorScheme.primaryContainer
                                        (report?.highRiskCount ?: 0) > 0 -> MaterialTheme.colorScheme.errorContainer
                                        (report?.mediumRiskCount ?: 0) > 0 -> MaterialTheme.colorScheme.tertiaryContainer
                                        else -> MaterialTheme.colorScheme.primaryContainer
                                    },
                                    modifier = Modifier.size(48.dp)
                                ) {
                                    Icon(
                                        imageVector = when {
                                            (report?.highRiskCount ?: 0) > 0 -> Icons.Filled.WarningAmber
                                            report != null && report?.findings?.isEmpty() == true -> Icons.Filled.CheckCircle
                                            else -> Icons.Filled.Shield
                                        },
                                        contentDescription = null,
                                        tint = when {
                                            (report?.highRiskCount ?: 0) > 0 -> MaterialTheme.colorScheme.error
                                            else -> MaterialTheme.colorScheme.primary
                                        },
                                        modifier = Modifier.padding(11.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = when {
                                            isScanning -> "Scanning apps & local files…"
                                            report != null -> report!!.overallStatusLabel
                                            else -> "Ready to scan device"
                                        },
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = if (report != null) {
                                            "Scanned ${report!!.scannedAppsCount} apps & ${report!!.scannedFilesCount} files • ${formatTimestamp(report!!.scannedAt)}"
                                        } else {
                                            "Audits installed apps, sideloaded sources, dangerous permissions, and $indexedFilesCount indexed files/APKs."
                                        },
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            if (report != null) {
                                FlowRow(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    SeverityStatChip("High Risk", report!!.highRiskCount, MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.onErrorContainer)
                                    SeverityStatChip("Suspicious", report!!.mediumRiskCount, MaterialTheme.colorScheme.tertiaryContainer, MaterialTheme.colorScheme.onTertiaryContainer)
                                    SeverityStatChip("Advisories", report!!.lowRiskCount, MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Button(
                                onClick = { viewModel.runVirusScan() },
                                enabled = !isScanning,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("security_run_scan_button")
                            ) {
                                if (isScanning) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(18.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Scanning Device…")
                                } else {
                                    Icon(Icons.Filled.Radar, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Run Full Virus & Risk Scan")
                                }
                            }
                        }
                    }
                }

                if (report != null && report!!.findings.isEmpty() && !isScanning) {
                    item {
                        UtilityCard(modifier = Modifier.fillMaxWidth()) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "No viruses or suspicious APKs found",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "All scanned launchable apps come from trusted sources or safe permissions, and no masquerading executables were found in indexed folders.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else if (report != null && report!!.findings.isNotEmpty()) {
                    item {
                        SectionHeader(
                            title = "Detected Findings (${report!!.findings.size})",
                            subtitle = "Review flags below and use Android system actions to inspect or remove threats"
                        )
                    }

                    items(report!!.findings, key = { it.id }) { finding ->
                        SecurityFindingCard(
                            finding = finding,
                            onUninstallApp = { pkg -> viewModel.uninstallFlaggedApp(pkg) },
                            onOpenAppDetails = { pkg -> viewModel.openFlaggedAppDetails(pkg) },
                            onDeleteFile = { uri -> viewModel.deleteRiskyFile(uri) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun SeverityStatChip(
    label: String,
    count: Int,
    containerColor: androidx.compose.ui.graphics.Color,
    contentColor: androidx.compose.ui.graphics.Color
) {
    Surface(
        shape = RoundedCornerShape(999.dp),
        color = containerColor
    ) {
        Text(
            text = "$label: $count",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Medium,
            color = contentColor,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
private fun SecurityFindingCard(
    finding: SecurityFinding,
    onUninstallApp: (String) -> Unit,
    onOpenAppDetails: (String) -> Unit,
    onDeleteFile: (String) -> Unit
) {
    val badgeBg = when (finding.severity) {
        SecuritySeverity.HIGH -> MaterialTheme.colorScheme.errorContainer
        SecuritySeverity.MEDIUM -> MaterialTheme.colorScheme.tertiaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val badgeFg = when (finding.severity) {
        SecuritySeverity.HIGH -> MaterialTheme.colorScheme.onErrorContainer
        SecuritySeverity.MEDIUM -> MaterialTheme.colorScheme.onTertiaryContainer
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    val borderColor = when (finding.severity) {
        SecuritySeverity.HIGH -> MaterialTheme.colorScheme.error.copy(alpha = 0.65f)
        SecuritySeverity.MEDIUM -> MaterialTheme.colorScheme.tertiary.copy(alpha = 0.5f)
        else -> MaterialTheme.colorScheme.outlineVariant
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, borderColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = finding.title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                Surface(shape = RoundedCornerShape(999.dp), color = badgeBg) {
                    Text(
                        text = finding.severity.label,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = badgeFg,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Text(
                text = finding.targetName,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = finding.detail,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (!finding.sha256.isNullOrBlank()) {
                Text(
                    text = "SHA-256: ${finding.sha256}",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = JetBrainsMonoFontFamily,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = "Advice: ${finding.recommendation}",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (finding.targetType == FindingTargetType.APP && !finding.packageName.isNullOrBlank()) {
                    OutlinedButton(
                        onClick = { onOpenAppDetails(finding.packageName) },
                        modifier = Modifier.testTag("security_app_info_${finding.packageName}")
                    ) {
                        Icon(Icons.Filled.Info, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("App Info")
                    }
                    Button(
                        onClick = { onUninstallApp(finding.packageName) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = MaterialTheme.colorScheme.onError
                        ),
                        modifier = Modifier.testTag("security_uninstall_${finding.packageName}")
                    ) {
                        Icon(Icons.Filled.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Uninstall")
                    }
                } else if (finding.targetType == FindingTargetType.FILE && !finding.fileUri.isNullOrBlank()) {
                    Button(
                        onClick = { onDeleteFile(finding.fileUri) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = MaterialTheme.colorScheme.onError
                        ),
                        modifier = Modifier.testTag("security_delete_file_button")
                    ) {
                        Icon(Icons.Filled.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Remove File")
                    }
                }
            }
        }
    }
}
