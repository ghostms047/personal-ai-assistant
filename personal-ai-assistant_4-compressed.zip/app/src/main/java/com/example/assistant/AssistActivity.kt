package com.example.assistant

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material3.AssistChip
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.MainActivity
import com.example.PersonalAiApp
import com.example.data.settings.AiRouteIssue
import com.example.data.settings.AiSettings
import com.example.data.settings.AssistantSettings
import com.example.data.settings.SpeechSettings
import com.example.data.settings.ThemeMode
import com.example.ui.components.ChatMessageCard
import com.example.ui.components.PersonalAiLogo
import com.example.ui.theme.NeonPrimary
import com.example.ui.theme.NeonSecondary
import com.example.ui.theme.NeonTertiary
import com.example.ui.theme.PersianPrimary
import com.example.ui.theme.PersianSecondary
import com.example.ui.theme.PersianTertiary
import com.example.ui.theme.PersonalAiTheme
import com.example.ui.theme.isDarkAppearance
import kotlinx.coroutines.launch

/**
 * Compact, sleek Gemini / Google Assistant-style bottom overlay invoked via system assistant triggers,
 * Quick Settings, notification, or WakeWordService ("Hey <AI Name>").
 */
class AssistActivity : ComponentActivity() {

    private var speechRecognizer: SpeechRecognizer? = null

    private var wakeTriggerSeq by mutableIntStateOf(0)
    private var wakeTriggered by mutableStateOf(false)
    private var pendingInitialCommand by mutableStateOf<String?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WakeWordService.isAssistantOverlayActive.value = true
        consumeWakeIntent(intent)

        val container = (applicationContext as PersonalAiApp).container

        setContent {
            val aiSettings by container.settingsRepository.aiSettingsFlow.collectAsState(initial = AiSettings())
            val assistantSettings by container.settingsRepository.assistantSettingsFlow.collectAsState(
                initial = AssistantSettings()
            )
            val speechSettings by container.settingsRepository.speechSettingsFlow.collectAsState(
                initial = SpeechSettings()
            )
            val isOnline by container.permissionChecker
                .observeNetworkConnectivity()
                .collectAsState(initial = container.permissionChecker.isNetworkConnected())
            val messages by container.orchestrator
                .observeMessages(AssistantOrchestrator.DEFAULT_SESSION_ID)
                .collectAsState(initial = emptyList())
            val isProcessing by container.orchestrator.isProcessing.collectAsState()
            val activeToolStatus by container.orchestrator.activeToolStatus.collectAsState()
            val latestSnapshot by container.screenUnderstandingRepository.latestSnapshot.collectAsState()
            val isSpeaking by container.speechAiManager.isSpeaking.collectAsState()
            val scope = rememberCoroutineScope()

            val activeRoute = remember(aiSettings, isOnline) {
                aiSettings.resolveEffectiveRoute(isOnline)
            }

            var input by remember { mutableStateOf("") }
            var attachScreen by remember { mutableStateOf(false) }
            var isListening by remember { mutableStateOf(false) }
            var partialTranscript by remember { mutableStateOf("") }
            var lastAutoSpokenId by remember { mutableLongStateOf(messages.lastOrNull()?.id ?: 0L) }

            val micPermissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) { granted ->
                if (granted) {
                    startListening(
                        onListeningChanged = { isListening = it },
                        onPartial = { partialTranscript = it },
                        onResult = { spoken ->
                            partialTranscript = ""
                            scope.launch {
                                container.orchestrator.submitUserMessage(
                                    userText = spoken,
                                    attachScreenSnapshot = attachScreen
                                )
                            }
                        }
                    )
                }
            }

            LaunchedEffect(wakeTriggerSeq) {
                val cmd = pendingInitialCommand
                if (!cmd.isNullOrBlank()) {
                    pendingInitialCommand = null
                    wakeTriggered = false
                    container.orchestrator.submitUserMessage(
                        userText = cmd,
                        attachScreenSnapshot = attachScreen
                    )
                } else if (wakeTriggered &&
                    assistantSettings.wakeAutoListenAfterTrigger &&
                    container.permissionChecker.hasMicrophonePermission()
                ) {
                    wakeTriggered = false
                    startListening(
                        onListeningChanged = { isListening = it },
                        onPartial = { partialTranscript = it },
                        onResult = { spoken ->
                            partialTranscript = ""
                            scope.launch {
                                container.orchestrator.submitUserMessage(
                                    userText = spoken,
                                    attachScreenSnapshot = attachScreen
                                )
                            }
                        }
                    )
                } else {
                    wakeTriggered = false
                }
            }

            LaunchedEffect(messages.size) {
                val latest = messages.lastOrNull() ?: return@LaunchedEffect
                if (speechSettings.autoSpeakResponses &&
                    latest.role == AssistantOrchestrator.ROLE_ASSISTANT &&
                    latest.id > lastAutoSpokenId &&
                    latest.content.isNotBlank()
                ) {
                    lastAutoSpokenId = latest.id
                    container.speechAiManager.speakText(
                        text = latest.content,
                        speechSettings = speechSettings,
                        aiSettings = aiSettings
                    )
                } else if (latest.id > lastAutoSpokenId) {
                    lastAutoSpokenId = latest.id
                }
            }

            val isDark = assistantSettings.themeMode.isDarkAppearance(isSystemInDarkTheme())
            val sheetBorder = when (assistantSettings.themeMode) {
                ThemeMode.NEON -> BorderStroke(1.5.dp, NeonPrimary.copy(alpha = 0.85f))
                ThemeMode.PERSIAN -> BorderStroke(1.5.dp, PersianTertiary.copy(alpha = 0.75f))
                else -> BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f))
            }
            val chosenName = assistantSettings.assistantName.ifBlank { "Personal AI" }

            PersonalAiTheme(
                themeMode = assistantSettings.themeMode,
                darkTheme = isDark,
                dynamicColor = assistantSettings.dynamicColor
            ) {
                Box(
                    contentAlignment = Alignment.BottomCenter,
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { finish() }
                ) {
                    Surface(
                        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.98f),
                        border = sheetBorder,
                        tonalElevation = 10.dp,
                        shadowElevation = 24.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .widthIn(max = 620.dp)
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) {}
                            .navigationBarsPadding()
                            .imePadding()
                    ) {
                        Column(modifier = Modifier.fillMaxWidth()) {
                            GeminiWakeGlowBar(
                                themeMode = assistantSettings.themeMode,
                                active = isListening || isProcessing || wakeTriggered
                            )

                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 8.dp)
                            ) {
                                // Slim drag handle
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.CenterHorizontally)
                                        .width(34.dp)
                                        .height(3.5.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f))
                                )

                                Spacer(modifier = Modifier.height(6.dp))

                                // Ultra-compact header
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    PersonalAiLogo(
                                        themeMode = assistantSettings.themeMode,
                                        size = 26.dp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = if (isListening) "$chosenName is listening…" else chosenName,
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = if (latestSnapshot != null && attachScreen) {
                                                "${activeRoute.routeBadge} • Screen ready"
                                            } else {
                                                activeRoute.routeBadge
                                            },
                                            style = MaterialTheme.typography.labelSmall,
                                            color = if (activeRoute.issue != null) {
                                                MaterialTheme.colorScheme.error
                                            } else {
                                                MaterialTheme.colorScheme.onSurfaceVariant
                                            },
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                    if (isSpeaking) {
                                        IconButton(
                                            onClick = { container.speechAiManager.stopSpeaking() },
                                            modifier = Modifier.size(36.dp)
                                        ) {
                                            Icon(
                                                Icons.Filled.Stop,
                                                contentDescription = "Stop speaking",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                    IconButton(
                                        onClick = {
                                            startActivity(
                                                Intent(this@AssistActivity, MainActivity::class.java).apply {
                                                    putExtra(
                                                        MainActivity.EXTRA_TARGET_ROUTE,
                                                        MainActivity.EXTRA_ROUTE_CHAT
                                                    )
                                                }
                                            )
                                            finish()
                                        },
                                        modifier = Modifier
                                            .size(36.dp)
                                            .testTag("assist_open_full_chat")
                                    ) {
                                        Icon(
                                            Icons.Filled.OpenInFull,
                                            contentDescription = "Open full chat view",
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { finish() },
                                        modifier = Modifier
                                            .size(36.dp)
                                            .testTag("assist_close_button")
                                    ) {
                                        Icon(
                                            Icons.Filled.Close,
                                            contentDescription = "Dismiss assistant",
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }

                                // Live voice transcript strip (shown only while speaking)
                                AnimatedVisibility(visible = isListening || partialTranscript.isNotBlank()) {
                                    Surface(
                                        shape = RoundedCornerShape(12.dp),
                                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 6.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.GraphicEq,
                                                contentDescription = null,
                                                tint = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.size(16.dp)
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = partialTranscript.ifBlank { "Speak now…" },
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                    }
                                }

                                // Route issue strip only when needed
                                val issue = activeRoute.issue
                                if (issue != null) {
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = MaterialTheme.colorScheme.errorContainer,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(top = 6.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text(
                                                text = when (issue) {
                                                    AiRouteIssue.MISSING_API_KEY -> "Add an AI API key or Local AI endpoint."
                                                    AiRouteIssue.OFFLINE_API_ONLY -> "Offline with 'API Key Only' mode active."
                                                    AiRouteIssue.MISSING_LOCAL_CONFIG -> "Configure Local AI endpoint for offline use."
                                                },
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onErrorContainer,
                                                modifier = Modifier.weight(1f)
                                            )
                                            TextButton(
                                                onClick = {
                                                    startActivity(
                                                        Intent(this@AssistActivity, MainActivity::class.java).apply {
                                                            putExtra(
                                                                MainActivity.EXTRA_TARGET_ROUTE,
                                                                MainActivity.EXTRA_ROUTE_API_KEYS
                                                            )
                                                        }
                                                    )
                                                    finish()
                                                }
                                            ) {
                                                Text("Setup", style = MaterialTheme.typography.labelSmall)
                                            }
                                        }
                                    }
                                }

                                // Compact conversation area only when messages exist; otherwise 1 compact horizontal pill row
                                if (messages.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    val listState = rememberLazyListState()
                                    LaunchedEffect(messages.size) {
                                        listState.animateScrollToItem(messages.lastIndex)
                                    }
                                    LazyColumn(
                                        state = listState,
                                        verticalArrangement = Arrangement.spacedBy(6.dp),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .heightIn(min = 56.dp, max = 185.dp)
                                    ) {
                                        items(messages.takeLast(6), key = { it.id }) { msg ->
                                            ChatMessageCard(
                                                message = msg,
                                                onSelectOption = { opt ->
                                                    scope.launch {
                                                        container.orchestrator.selectDisambiguationOption(msg.id, opt)
                                                    }
                                                },
                                                onConfirmAction = { conf, approved ->
                                                    scope.launch {
                                                        container.orchestrator.resolveConfirmation(
                                                            msg.id,
                                                            conf,
                                                            approved
                                                        )
                                                    }
                                                },
                                                onSpeak = if (msg.role == AssistantOrchestrator.ROLE_ASSISTANT) {
                                                    {
                                                        scope.launch {
                                                            container.speechAiManager.speakText(
                                                                text = msg.content,
                                                                speechSettings = speechSettings,
                                                                aiSettings = aiSettings
                                                            )
                                                        }
                                                    }
                                                } else null
                                            )
                                        }
                                    }
                                } else if (!isListening) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    LazyRow(
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        val quickPrompts = listOf(
                                            "Screen?" to "What's on my screen?",
                                            "Scan viruses" to "Scan my phone for viruses or risky apps",
                                            "Games" to "Show my installed games",
                                            "Patterns" to "List my learned patterns"
                                        )
                                        items(quickPrompts) { (chipLabel, promptText) ->
                                            AssistChip(
                                                onClick = {
                                                    scope.launch {
                                                        container.orchestrator.submitUserMessage(
                                                            userText = promptText,
                                                            attachScreenSnapshot = attachScreen
                                                        )
                                                    }
                                                },
                                                label = {
                                                    Text(
                                                        chipLabel,
                                                        style = MaterialTheme.typography.labelSmall
                                                    )
                                                }
                                            )
                                        }
                                    }
                                }

                                if (isProcessing || activeToolStatus != null) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(top = 4.dp)
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(13.dp),
                                            strokeWidth = 2.dp
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = activeToolStatus ?: "Working…",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                // Compact sleek pill composer with inline Screen toggle, Mic & Send
                                Surface(
                                    shape = RoundedCornerShape(24.dp),
                                    color = MaterialTheme.colorScheme.surfaceContainerHigh,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 4.dp, vertical = 3.dp)
                                    ) {
                                        IconButton(
                                            onClick = {
                                                if (isListening) {
                                                    speechRecognizer?.stopListening()
                                                    isListening = false
                                                } else if (container.permissionChecker.hasMicrophonePermission()) {
                                                    startListening(
                                                        onListeningChanged = { isListening = it },
                                                        onPartial = { partialTranscript = it },
                                                        onResult = { spoken ->
                                                            partialTranscript = ""
                                                            scope.launch {
                                                                container.orchestrator.submitUserMessage(
                                                                    userText = spoken,
                                                                    attachScreenSnapshot = attachScreen
                                                                )
                                                            }
                                                        }
                                                    )
                                                } else {
                                                    micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                                }
                                            },
                                            modifier = Modifier
                                                .size(40.dp)
                                                .testTag("assist_mic_button")
                                        ) {
                                            Icon(
                                                imageVector = if (isListening) Icons.Filled.Stop else Icons.Filled.Mic,
                                                contentDescription = if (isListening) "Stop voice input" else "Voice input",
                                                tint = if (isListening) {
                                                    MaterialTheme.colorScheme.error
                                                } else {
                                                    MaterialTheme.colorScheme.primary
                                                },
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }

                                        Box(
                                            contentAlignment = Alignment.CenterStart,
                                            modifier = Modifier
                                                .weight(1f)
                                                .padding(horizontal = 4.dp, vertical = 8.dp)
                                        ) {
                                            if (input.isEmpty()) {
                                                Text(
                                                    text = "Ask $chosenName…",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                            BasicTextField(
                                                value = input,
                                                onValueChange = { input = it },
                                                singleLine = true,
                                                textStyle = MaterialTheme.typography.bodyMedium.copy(
                                                    color = MaterialTheme.colorScheme.onSurface
                                                ),
                                                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .testTag("assist_input_field")
                                            )
                                        }

                                        IconButton(
                                            onClick = {
                                                val next = !attachScreen
                                                attachScreen = next
                                                if (next) {
                                                    container.screenUnderstandingRepository.refreshFromAccessibility(userTriggered = true)
                                                }
                                            },
                                            modifier = Modifier
                                                .size(38.dp)
                                                .testTag("assist_screen_toggle")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.Visibility,
                                                contentDescription = if (attachScreen) {
                                                    "Screen context attached"
                                                } else {
                                                    "Attach screen context"
                                                },
                                                tint = if (attachScreen) {
                                                    MaterialTheme.colorScheme.primary
                                                } else {
                                                    MaterialTheme.colorScheme.onSurfaceVariant
                                                },
                                                modifier = Modifier.size(19.dp)
                                            )
                                        }

                                        Spacer(modifier = Modifier.width(2.dp))

                                        Surface(
                                            shape = CircleShape,
                                            color = if (input.isNotBlank() && !isProcessing) {
                                                MaterialTheme.colorScheme.primary
                                            } else {
                                                MaterialTheme.colorScheme.surfaceVariant
                                            },
                                            contentColor = if (input.isNotBlank() && !isProcessing) {
                                                MaterialTheme.colorScheme.onPrimary
                                            } else {
                                                MaterialTheme.colorScheme.onSurfaceVariant
                                            }
                                        ) {
                                            IconButton(
                                                onClick = {
                                                    if (input.isNotBlank() && !isProcessing) {
                                                        val text = input
                                                        input = ""
                                                        scope.launch {
                                                            container.orchestrator.submitUserMessage(
                                                                userText = text,
                                                                attachScreenSnapshot = attachScreen
                                                            )
                                                        }
                                                    }
                                                },
                                                enabled = input.isNotBlank() && !isProcessing,
                                                modifier = Modifier
                                                    .size(38.dp)
                                                    .testTag("assist_send_button")
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.ArrowUpward,
                                                    contentDescription = "Send",
                                                    modifier = Modifier.size(19.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        consumeWakeIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        WakeWordService.isAssistantOverlayActive.value = true
    }

    override fun onPause() {
        WakeWordService.isAssistantOverlayActive.value = false
        super.onPause()
    }

    override fun onDestroy() {
        WakeWordService.isAssistantOverlayActive.value = false
        speechRecognizer?.destroy()
        speechRecognizer = null
        super.onDestroy()
    }

    private fun consumeWakeIntent(intent: Intent?) {
        if (intent == null) return
        val isWake = intent.getBooleanExtra(EXTRA_WAKE_TRIGGERED, false) ||
            intent.getBooleanExtra(EXTRA_FROM_VOICE_SESSION, false)
        val cmd = intent.getStringExtra(EXTRA_INITIAL_COMMAND)?.trim()
        if (isWake || !cmd.isNullOrBlank()) {
            wakeTriggered = isWake
            pendingInitialCommand = cmd
            wakeTriggerSeq++
        }
    }

    private fun startListening(
        onListeningChanged: (Boolean) -> Unit,
        onPartial: (String) -> Unit,
        onResult: (String) -> Unit
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        val recognizer = speechRecognizer ?: SpeechRecognizer.createSpeechRecognizer(this).also {
            speechRecognizer = it
        }
        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = onListeningChanged(true)
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() = onListeningChanged(false)
            override fun onError(error: Int) {
                onListeningChanged(false)
                onPartial("")
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?.trim()
                    .orEmpty()
                if (partial.isNotBlank()) onPartial(partial)
            }

            override fun onResults(results: Bundle?) {
                onListeningChanged(false)
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?.trim()
                    .orEmpty()
                if (text.isNotBlank()) onResult(text)
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer.startListening(intent)
    }

    companion object {
        const val EXTRA_FROM_VOICE_SESSION = "from_voice_session"
        const val EXTRA_WAKE_TRIGGERED = "extra_wake_triggered"
        const val EXTRA_INITIAL_COMMAND = "extra_initial_command"
    }
}

@Composable
private fun GeminiWakeGlowBar(
    themeMode: ThemeMode,
    active: Boolean
) {
    val palette = when (themeMode) {
        ThemeMode.NEON -> listOf(NeonPrimary, NeonSecondary, NeonTertiary, NeonPrimary)
        ThemeMode.PERSIAN -> listOf(PersianPrimary, PersianTertiary, PersianSecondary, PersianPrimary)
        else -> listOf(
            Color(0xFF4285F4),
            Color(0xFF00BFA5),
            Color(0xFF8E24AA),
            Color(0xFF34A853),
            Color(0xFF4285F4)
        )
    }
    val transition = rememberInfiniteTransition(label = "gemini_wake_glow")
    val shift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 900f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (active) 1600 else 3600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "glow_shift"
    )
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (active) 4.dp else 2.5.dp)
            .background(
                brush = Brush.linearGradient(
                    colors = palette,
                    start = Offset(shift - 450f, 0f),
                    end = Offset(shift + 450f, 0f)
                )
            )
    )
}
