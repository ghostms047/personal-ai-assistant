package com.example.assistant

import android.service.voice.VoiceInteractionService

class PersonalVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
    }
}
