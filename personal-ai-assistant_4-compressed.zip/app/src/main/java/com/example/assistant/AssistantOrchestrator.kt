package com.example.assistant

import com.example.ai.AiEngine
import com.example.ai.AiMessage
import com.example.ai.AiResult
import com.example.ai.AiRole
import com.example.data.db.ChatMessageDao
import com.example.data.db.ChatMessageEntity
import com.example.data.db.ChatSessionDao
import com.example.data.db.ChatSessionEntity
import com.example.data.settings.SettingsRepository
import com.example.memory.MemoryRepository
import com.example.patterns.PatternRepository
import com.example.permissions.PermissionChecker
import com.example.screen.ScreenUnderstandingRepository
import com.example.tools.AskUserOption
import com.example.tools.PendingConfirmation
import com.example.tools.ToolExecutionOutcome
import com.example.tools.ToolRegistry
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

data class ChatSessionSummary(
    val sessionId: String,
    val title: String,
    val lastPreview: String = "",
    val messageCount: Int = 0,
    val isPinned: Boolean = false,
    val lastTimestamp: Long = 0L
)

data class ChatHistorySearchHit(
    val sessionId: String,
    val sessionTitle: String,
    val snippet: String,
    val role: String,
    val timestamp: Long
)

class AssistantOrchestrator(
    private val aiEngine: AiEngine,
    private val toolRegistry: ToolRegistry,
    private val chatMessageDao: ChatMessageDao,
    private val chatSessionDao: ChatSessionDao,
    private val memoryRepository: MemoryRepository,
    private val patternRepository: PatternRepository,
    private val screenRepo: ScreenUnderstandingRepository,
    private val permissionChecker: PermissionChecker,
    private val settingsRepository: SettingsRepository
) {
    private val turnMutex = Mutex()

    @Volatile
    private var activeTurnJob: Job? = null

    @Volatile
    private var userCancelledTurn: Boolean = false

    private val _isProcessing = MutableStateFlow(false)
    val isProcessing: StateFlow<Boolean> = _isProcessing.asStateFlow()

    private val _activeToolStatus = MutableStateFlow<String?>(null)
    val activeToolStatus: StateFlow<String?> = _activeToolStatus.asStateFlow()

    val lastUsedRouteLabel: StateFlow<String?> = aiEngine.lastUsedRouteLabel

    fun cancelActiveGeneration() {
        userCancelledTurn = true
        aiEngine.cancelActiveLocalGeneration()
        activeTurnJob?.cancel()
    }

    fun observeMessages(sessionId: String = DEFAULT_SESSION_ID): Flow<List<ChatMessageEntity>> =
        chatMessageDao.observeMessages(sessionId)

    fun observeTotalChatMessageCount(): Flow<Int> =
        chatMessageDao.observeTotalChatMessagesCount()

    fun observeChatSessions(): Flow<List<ChatSessionSummary>> =
        combine(
            chatSessionDao.observeAllSessions(),
            chatMessageDao.observeAllUserChatMessages()
        ) { storedSessions, legacyUserMessages ->
            val storedMap = storedSessions.associateBy { it.sessionId }
            val result = storedSessions.map { s ->
                ChatSessionSummary(
                    sessionId = s.sessionId,
                    title = s.title,
                    lastPreview = s.lastMessagePreview,
                    messageCount = s.messageCount,
                    isPinned = s.isPinned,
                    lastTimestamp = s.updatedAt
                )
            }.toMutableList()

            // Backfill any sessions present in chat_messages that don't yet have a chat_sessions row
            legacyUserMessages.groupBy { it.sessionId }.forEach { (sid, msgs) ->
                if (!storedMap.containsKey(sid)) {
                    val first = msgs.firstOrNull()
                    val last = msgs.lastOrNull()
                    if (first != null && last != null) {
                        result += ChatSessionSummary(
                            sessionId = sid,
                            title = first.content.lineSequence().firstOrNull().orEmpty().trim().take(48).ifBlank { "Chat" },
                            lastPreview = last.content.take(80),
                            messageCount = msgs.size,
                            isPinned = false,
                            lastTimestamp = last.timestamp
                        )
                    }
                }
            }
            result.sortedWith(
                compareByDescending<ChatSessionSummary> { it.isPinned }
                    .thenByDescending { it.lastTimestamp }
            )
        }

    suspend fun searchLocalHistory(query: String): List<ChatHistorySearchHit> {
        val clean = query.trim()
        if (clean.isBlank()) return emptyList()
        val msgHits = chatMessageDao.searchMessages(clean, limit = 30)
        return msgHits.map { msg ->
            val session = chatSessionDao.getById(msg.sessionId)
            ChatHistorySearchHit(
                sessionId = msg.sessionId,
                sessionTitle = session?.title ?: "Saved Conversation",
                snippet = msg.content.take(120),
                role = msg.role,
                timestamp = msg.timestamp
            )
        }
    }

    suspend fun pinSession(sessionId: String, pinned: Boolean) {
        val existing = chatSessionDao.getById(sessionId)
        if (existing != null) {
            chatSessionDao.setPinned(sessionId, pinned)
        } else {
            syncSessionMetadata(sessionId, preview = "", overridePinned = pinned)
        }
    }

    suspend fun renameSession(sessionId: String, newTitle: String) {
        val clean = newTitle.trim().take(60)
        if (clean.isBlank()) return
        val existing = chatSessionDao.getById(sessionId)
        if (existing != null) {
            chatSessionDao.renameSession(sessionId, clean)
        } else {
            syncSessionMetadata(sessionId, preview = "", overrideTitle = clean)
        }
    }

    suspend fun exportSessionAsText(sessionId: String): String {
        val msgs = chatMessageDao.getMessagesForSessionOnce(sessionId)
        if (msgs.isEmpty()) return ""
        val session = chatSessionDao.getById(sessionId)
        return buildString {
            appendLine("# ${session?.title ?: "Personal AI Conversation"}")
            appendLine()
            msgs.forEach { m ->
                val who = when (m.role) {
                    ROLE_USER -> "You"
                    ROLE_TOOL -> "Tool (${m.toolName ?: "action"})"
                    ROLE_SYSTEM -> "System"
                    else -> "Assistant"
                }
                appendLine("[$who]")
                appendLine(m.content)
                appendLine()
            }
        }
    }

    suspend fun clearSession(sessionId: String = DEFAULT_SESSION_ID) {
        chatMessageDao.clearSession(sessionId)
        chatSessionDao.deleteById(sessionId)
    }

    suspend fun clearAllChatHistory() {
        chatMessageDao.clearAllChatMessages()
        chatSessionDao.clearAll()
    }

    private suspend fun syncSessionMetadata(
        sessionId: String,
        preview: String,
        overrideTitle: String? = null,
        overridePinned: Boolean? = null
    ) {
        if (sessionId == FLOATING_SESSION_ID) return
        val existing = chatSessionDao.getById(sessionId)
        val count = chatMessageDao.getSessionMessageCount(sessionId)
        val now = System.currentTimeMillis()
        val derivedTitle = overrideTitle
            ?: existing?.title?.takeIf { it.isNotBlank() && it != "New Chat" }
            ?: preview.lineSequence().firstOrNull().orEmpty().trim().take(48).ifBlank { "New Chat" }

        chatSessionDao.upsert(
            ChatSessionEntity(
                sessionId = sessionId,
                title = derivedTitle,
                lastMessagePreview = preview.ifBlank { existing?.lastMessagePreview.orEmpty() }.take(120),
                messageCount = count,
                isPinned = overridePinned ?: existing?.isPinned ?: false,
                createdAt = existing?.createdAt ?: now,
                updatedAt = now
            )
        )
    }

    suspend fun regenerateLastMessage(sessionId: String = DEFAULT_SESSION_ID) {
        if (_isProcessing.value || turnMutex.isLocked) return
        turnMutex.withLock {
            val allAsc = chatMessageDao.getMessagesForSessionOnce(sessionId)
            val lastUserIdx = allAsc.indexOfLast { it.role == ROLE_USER }
            if (lastUserIdx < 0) return

            userCancelledTurn = false
            activeTurnJob = currentCoroutineContext()[Job]
            _isProcessing.value = true
            _activeToolStatus.value = "Regenerating..."

            try {
                // Remove trailing assistant/tool/system replies for the last user turn without duplicating the user prompt.
                for (i in (lastUserIdx + 1) until allAsc.size) {
                    chatMessageDao.deleteById(allAsc[i].id)
                }
                runAssistantLoop(sessionId = sessionId, overrideLatestUserPrompt = null)
            } catch (ce: CancellationException) {
                if (!userCancelledTurn) throw ce
            } finally {
                userCancelledTurn = false
                activeTurnJob = null
                _isProcessing.value = false
                _activeToolStatus.value = null
            }
        }
    }

    suspend fun submitUserMessage(
        userText: String,
        sessionId: String = DEFAULT_SESSION_ID,
        attachScreenSnapshot: Boolean = false
    ) {
        val trimmed = userText.trim()
        if (trimmed.isBlank()) return

        turnMutex.withLock {
            userCancelledTurn = false
            activeTurnJob = currentCoroutineContext()[Job]
            _isProcessing.value = true
            _activeToolStatus.value = "Thinking..."

            try {
                val currentSettings = settingsRepository.assistantSettingsFlow.first()
                val autoScreen = currentSettings.visionEnabled && currentSettings.includeScreenContextAutomatically
                val effectivePrompt = if (attachScreenSnapshot || autoScreen) {
                    val snap = screenRepo.refreshFromAccessibility(userTriggered = attachScreenSnapshot)
                    if (snap != null) {
                        "$trimmed\n\n[Attached Screen Context]\n${snap.toPromptContext(2200)}"
                    } else {
                        trimmed
                    }
                } else {
                    trimmed
                }

                chatMessageDao.insert(
                    ChatMessageEntity(
                        sessionId = sessionId,
                        role = ROLE_USER,
                        content = trimmed
                    )
                )
                syncSessionMetadata(sessionId, preview = trimmed)

                runAssistantLoop(sessionId = sessionId, overrideLatestUserPrompt = effectivePrompt)
            } catch (ce: CancellationException) {
                if (!userCancelledTurn) throw ce
            } finally {
                userCancelledTurn = false
                activeTurnJob = null
                _isProcessing.value = false
                _activeToolStatus.value = null
            }
        }
    }

    suspend fun selectDisambiguationOption(
        messageId: Long,
        option: AskUserOption,
        sessionId: String = DEFAULT_SESSION_ID
    ) {
        chatMessageDao.clearOptions(messageId)
        submitUserMessage(option.replyValue, sessionId = sessionId)
    }

    suspend fun resolveConfirmation(
        messageId: Long,
        confirmation: PendingConfirmation,
        approved: Boolean,
        sessionId: String = DEFAULT_SESSION_ID
    ) {
        chatMessageDao.clearPendingConfirmation(messageId)
        turnMutex.withLock {
            userCancelledTurn = false
            activeTurnJob = currentCoroutineContext()[Job]
            _isProcessing.value = true
            try {
                if (!approved) {
                    chatMessageDao.insert(
                        ChatMessageEntity(
                            sessionId = sessionId,
                            role = ROLE_ASSISTANT,
                            content = "Understood — I cancelled that action."
                        )
                    )
                    return
                }

                _activeToolStatus.value = "Executing ${confirmation.toolName}..."
                val outcome = toolRegistry.execute(
                    toolName = confirmation.toolName,
                    argumentsJson = confirmation.argumentsJson,
                    bypassConfirmation = true
                )
                if (outcome is ToolExecutionOutcome.Executed) {
                    chatMessageDao.insert(
                        ChatMessageEntity(
                            sessionId = sessionId,
                            role = ROLE_TOOL,
                            content = outcome.summaryForUser,
                            toolName = confirmation.toolName,
                            toolArgsJson = confirmation.argumentsJson,
                            toolResultJson = outcome.resultJson,
                            toolSuccess = outcome.success
                        )
                    )
                    runAssistantLoop(sessionId = sessionId, overrideLatestUserPrompt = null)
                }
            } catch (ce: CancellationException) {
                if (!userCancelledTurn) throw ce
            } finally {
                userCancelledTurn = false
                activeTurnJob = null
                _isProcessing.value = false
                _activeToolStatus.value = null
            }
        }
    }

    private suspend fun runAssistantLoop(
        sessionId: String,
        overrideLatestUserPrompt: String?
    ) {
        val recentDesc = chatMessageDao.getRecentMessages(sessionId, limit = 18)
        val history = recentDesc.reversed().toMutableList()

        val aiConversation = mutableListOf<AiMessage>()
        for ((idx, msg) in history.withIndex()) {
            when (msg.role) {
                ROLE_USER -> {
                    val text = if (idx == history.lastIndex && overrideLatestUserPrompt != null) {
                        overrideLatestUserPrompt
                    } else {
                        msg.content
                    }
                    aiConversation.add(AiMessage(role = AiRole.USER, text = text))
                }
                ROLE_ASSISTANT -> {
                    aiConversation.add(AiMessage(role = AiRole.ASSISTANT, text = msg.content))
                }
                ROLE_TOOL -> {
                    val toolSummary = buildString {
                        append("Tool '${msg.toolName}' executed. Success=${msg.toolSuccess}. ")
                        append("Result: ${msg.toolResultJson ?: msg.content}")
                    }
                    aiConversation.add(AiMessage(role = AiRole.USER, text = toolSummary))
                }
            }
        }

        val systemPrompt = buildSystemPrompt()

        for (step in 0 until MAX_TOOL_STEPS) {
            if (userCancelledTurn) return
            _activeToolStatus.value = if (step == 0) "Consulting AI..." else "Processing tool results..."
            val result = aiEngine.complete(systemPrompt, aiConversation, toolRegistry.aiDefinitions)
            if (userCancelledTurn) return
            when (result) {
                is AiResult.MissingApiKey -> {
                    chatMessageDao.insert(
                        ChatMessageEntity(
                            sessionId = sessionId,
                            role = ROLE_SYSTEM,
                            content = "No API key is configured for ${result.provider.displayName}. Open API Key Settings to add your key."
                        )
                    )
                    return
                }
                is AiResult.Offline -> {
                    chatMessageDao.insert(
                        ChatMessageEntity(
                            sessionId = sessionId,
                            role = ROLE_SYSTEM,
                            content = "You are offline and routing is set to API Key Only. Switch to Auto (Offline → Local AI) or Local Only in settings to use an on-device model. File Search, Virus Scan, Apps, and Patterns work offline."
                        )
                    )
                    syncSessionMetadata(sessionId, preview = "Offline notice")
                    return
                }
                is AiResult.Error -> {
                    chatMessageDao.insert(
                        ChatMessageEntity(
                            sessionId = sessionId,
                            role = ROLE_SYSTEM,
                            content = result.userMessage
                        )
                    )
                    syncSessionMetadata(sessionId, preview = result.userMessage)
                    return
                }
                is AiResult.Success -> {
                    val completion = result.completion
                    if (completion.toolCalls.isEmpty()) {
                        val finalText = completion.text.ifBlank { "Done." }
                        chatMessageDao.insert(
                            ChatMessageEntity(
                                sessionId = sessionId,
                                role = ROLE_ASSISTANT,
                                content = finalText
                            )
                        )
                        syncSessionMetadata(sessionId, preview = finalText)
                        return
                    }

                    // Record assistant tool-call turn in transient conversation
                    aiConversation.add(
                        AiMessage(
                            role = AiRole.ASSISTANT,
                            text = completion.text,
                            toolCalls = completion.toolCalls
                        )
                    )

                    if (completion.text.isNotBlank()) {
                        chatMessageDao.insert(
                            ChatMessageEntity(
                                sessionId = sessionId,
                                role = ROLE_ASSISTANT,
                                content = completion.text
                            )
                        )
                    }

                    var shouldStopLoop = false
                    for (call in completion.toolCalls) {
                        _activeToolStatus.value = "Running ${call.name}..."
                        when (val outcome = toolRegistry.execute(call.name, call.argumentsJson)) {
                            is ToolExecutionOutcome.NeedsConfirmation -> {
                                val pendingJson = JSONObject()
                                    .put("toolName", outcome.confirmation.toolName)
                                    .put("argumentsJson", outcome.confirmation.argumentsJson)
                                    .put("summary", outcome.confirmation.humanReadableSummary)
                                    .toString()

                                chatMessageDao.insert(
                                    ChatMessageEntity(
                                        sessionId = sessionId,
                                        role = ROLE_ASSISTANT,
                                        content = outcome.confirmation.humanReadableSummary,
                                        pendingConfirmationJson = pendingJson
                                    )
                                )
                                shouldStopLoop = true
                            }
                            is ToolExecutionOutcome.Executed -> {
                                if (outcome.askUserQuestion != null) {
                                    val optsJson = JSONArray().apply {
                                        outcome.askUserOptions.forEach { opt ->
                                            put(
                                                JSONObject()
                                                    .put("id", opt.id)
                                                    .put("label", opt.label)
                                                    .put("subtitle", opt.subtitle)
                                                    .put("replyValue", opt.replyValue)
                                            )
                                        }
                                    }.toString()
                                    chatMessageDao.insert(
                                        ChatMessageEntity(
                                            sessionId = sessionId,
                                            role = ROLE_ASSISTANT,
                                            content = outcome.askUserQuestion,
                                            optionsJson = optsJson
                                        )
                                    )
                                    shouldStopLoop = true
                                } else {
                                    chatMessageDao.insert(
                                        ChatMessageEntity(
                                            sessionId = sessionId,
                                            role = ROLE_TOOL,
                                            content = outcome.summaryForUser,
                                            toolName = call.name,
                                            toolArgsJson = call.argumentsJson,
                                            toolResultJson = outcome.resultJson,
                                            toolSuccess = outcome.success
                                        )
                                    )
                                    aiConversation.add(
                                        AiMessage(
                                            role = AiRole.TOOL,
                                            text = outcome.resultJson,
                                            toolCallId = call.id,
                                            toolName = call.name
                                        )
                                    )
                                }
                            }
                        }
                        if (shouldStopLoop) break
                    }

                    if (shouldStopLoop) return
                }
            }
        }

        chatMessageDao.insert(
            ChatMessageEntity(
                sessionId = sessionId,
                role = ROLE_ASSISTANT,
                content = "I reached the maximum number of consecutive tool steps for this request."
            )
        )
    }

    private suspend fun buildSystemPrompt(): String {
        val assistantSettings = settingsRepository.assistantSettingsFlow.first()
        val chosenName = assistantSettings.assistantName.ifBlank { "Personal AI" }
        val memoryBlock = memoryRepository.getPromptContext()
        val patternBlock = patternRepository.getPromptContext()
        val permissionsSummary = buildString {
            append("Accessibility: ${if (permissionChecker.isAccessibilityEnabled()) "granted" else "not granted"}; ")
            append("File access: ${if (permissionChecker.hasFileAccess()) "granted" else "not granted"}; ")
            append("Default Assistant: ${if (permissionChecker.isDefaultAssistant()) "granted" else "not granted"}.")
        }
        return buildString {
            appendLine("You are $chosenName (Personal AI), a calm, capable, privacy-conscious Android system assistant.")
            appendLine("When the user greets you or asks your name, refer to yourself as $chosenName.")
            appendLine("You have expanded Android tool access: launch apps & games (open_app, find_games), inspect & read screens (inspect_screen), interact inside apps and games (click_screen_element, type_in_element, scroll_screen, tap_screen_coordinates, swipe_screen), scan the device for viruses/malware (scan_for_viruses), inspect device status/battery/storage (get_device_status), manage clipboard (clipboard_action), open URLs (open_url), search indexed files (search_files), and learn or run repeatable user patterns (save_user_pattern, list_user_patterns, run_user_pattern).")
            appendLine("Rules:")
            appendLine("1. Never claim to have executed a tool unless you actually called it and received a success result.")
            appendLine("2. If search_files or search_apps returns multiple plausible matches and intent is ambiguous, call ask_user with clear selectable options.")
            appendLine("3. When the user asks to learn/remember a routine or pattern (e.g. 'learn this pattern...'), use save_user_pattern with clear steps. When they ask to run a pattern or repeat a learned workflow, use run_user_pattern.")
            appendLine("4. When the user asks to play/control an app or game via UI coordinates, inspect_screen provides element center=x,y coordinates you can pass to tap_screen_coordinates or swipe_screen.")
            appendLine("5. If the user asks to check for viruses, malware, or suspicious APKs/apps, call scan_for_viruses.")
            appendLine("6. If a required permission is missing, explain which permission to enable in Personal AI -> Permissions.")
            appendLine("Current device permission status: $permissionsSummary")
            if (patternBlock.isNotBlank()) {
                appendLine("Learned user patterns (ready to run via run_user_pattern):")
                appendLine(patternBlock)
            }
            if (memoryBlock.isNotBlank()) {
                appendLine("User-approved memories:")
                appendLine(memoryBlock)
            }
        }
    }

    companion object {
        const val DEFAULT_SESSION_ID = "main_session"
        const val FLOATING_SESSION_ID = "floating_session"
        const val ROLE_USER = "USER"
        const val ROLE_ASSISTANT = "ASSISTANT"
        const val ROLE_TOOL = "TOOL"
        const val ROLE_SYSTEM = "SYSTEM"
        private const val MAX_TOOL_STEPS = 5
    }
}
