package com.example.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationChannelCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.PersonalAiApp
import com.example.R
import com.example.data.settings.ThemeMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Silent foreground wake listener using AudioRecord + on-device Goertzel/DTW spectral matching.
 * Never opens Google SpeechRecognizer in a loop, eliminating repeated STT chime/beep sounds and popups.
 */
class WakeWordService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var audioLoopJob: Job? = null
    private val session = SilentWakeDetector.StreamingSession()

    private var currentAssistantName: String = "Personal AI"
    private var currentThemeMode: ThemeMode = ThemeMode.SYSTEM
    private var hasEnrolledSample: Boolean = false
    private var isDestroyed = false
    private var lastWakeTimestampMs = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!hasMicPermission(this)) {
            stopSelf()
            return
        }
        isRunningFlow.value = true
        startForegroundNotification()

        val container = (applicationContext as PersonalAiApp).container
        serviceScope.launch {
            container.settingsRepository.assistantSettingsFlow.collect { settings ->
                currentAssistantName = settings.assistantName.ifBlank { "Personal AI" }
                currentThemeMode = settings.themeMode
                val decoded = SilentWakeDetector.decodeTemplate(settings.wakeTemplateJson)
                hasEnrolledSample = decoded != null
                session.setTemplate(decoded)

                if (!settings.wakeWordEnabled) {
                    stopSelf()
                    return@collect
                }
                updateNotification()
                if (!isAssistantOverlayActive.value && audioLoopJob == null) {
                    startSilentAudioLoop()
                }
            }
        }

        serviceScope.launch {
            isAssistantOverlayActive.collect { active ->
                if (active) {
                    stopAudioLoop()
                } else if (!isDestroyed) {
                    delay(450L)
                    if (!isDestroyed && !isAssistantOverlayActive.value) {
                        startSilentAudioLoop()
                    }
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        isDestroyed = true
        isRunningFlow.value = false
        isListeningFlow.value = false
        stopAudioLoop()
        serviceScope.cancel()
        super.onDestroy()
    }

    @SuppressLint("MissingPermission")
    private fun startSilentAudioLoop() {
        if (isDestroyed || isAssistantOverlayActive.value || audioLoopJob?.isActive == true) return
        if (!hasMicPermission(this)) {
            isListeningFlow.value = false
            return
        }

        audioLoopJob = serviceScope.launch(Dispatchers.Default) {
            val minBuf = AudioRecord.getMinBufferSize(
                SilentWakeDetector.SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(SilentWakeDetector.FRAME_SIZE * 4)

            val recorder = runCatching {
                AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    SilentWakeDetector.SAMPLE_RATE,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBuf * 2
                )
            }.getOrNull()

            if (recorder == null || recorder.state != AudioRecord.STATE_INITIALIZED) {
                runCatching { recorder?.release() }
                isListeningFlow.value = false
                lastHeardTextFlow.value = "Microphone hardware busy"
                return@launch
            }

            session.reset()
            val hopBuffer = ShortArray(SilentWakeDetector.HOP_SIZE)
            val rollingFrame = ShortArray(SilentWakeDetector.FRAME_SIZE)

            try {
                recorder.startRecording()
                isListeningFlow.value = true
                lastHeardTextFlow.value = if (hasEnrolledSample) {
                    "Silent voiceprint standby active"
                } else {
                    "Silent voice standby (enroll 2s sample in Settings for name match)"
                }

                // Prime first half-window
                var offset = 0
                while (offset < SilentWakeDetector.HOP_SIZE && isActive) {
                    val read = recorder.read(hopBuffer, offset, SilentWakeDetector.HOP_SIZE - offset)
                    if (read <= 0) {
                        delay(50L)
                    } else {
                        offset += read
                    }
                }
                hopBuffer.copyInto(rollingFrame, destinationOffset = 0)

                while (isActive && !isDestroyed && !isAssistantOverlayActive.value) {
                    var filled = 0
                    while (filled < SilentWakeDetector.HOP_SIZE && isActive) {
                        val read = recorder.read(hopBuffer, filled, SilentWakeDetector.HOP_SIZE - filled)
                        if (read <= 0) {
                            delay(25L)
                            break
                        }
                        filled += read
                    }
                    if (filled < SilentWakeDetector.HOP_SIZE) continue

                    // Shift previous second half into first half, append new hop
                    rollingFrame.copyInto(
                        destination = rollingFrame,
                        destinationOffset = 0,
                        startIndex = SilentWakeDetector.HOP_SIZE,
                        endIndex = SilentWakeDetector.FRAME_SIZE
                    )
                    hopBuffer.copyInto(
                        destination = rollingFrame,
                        destinationOffset = SilentWakeDetector.HOP_SIZE,
                        startIndex = 0,
                        endIndex = SilentWakeDetector.HOP_SIZE
                    )

                    val outcome = session.processFrame(rollingFrame, 0)
                    if (outcome == WakeDetectionOutcome.TEMPLATE_MATCH ||
                        outcome == WakeDetectionOutcome.GENERIC_BURST_MATCH
                    ) {
                        val now = System.currentTimeMillis()
                        val minGap = if (outcome == WakeDetectionOutcome.TEMPLATE_MATCH) WAKE_COOLDOWN_MS else 4000L
                        if (now - lastWakeTimestampMs >= minGap) {
                            lastWakeTimestampMs = now
                            lastHeardTextFlow.value = if (outcome == WakeDetectionOutcome.TEMPLATE_MATCH) {
                                "Matched voice sample for \"$currentAssistantName\""
                            } else {
                                "Detected wake phrase"
                            }
                            triggerWakeOverlay()
                            break
                        }
                    }
                }
            } catch (_: Exception) {
                // Gracefully release on audio interruptions
            } finally {
                isListeningFlow.value = false
                runCatching { recorder.stop() }
                runCatching { recorder.release() }
            }
        }
    }

    private fun stopAudioLoop() {
        audioLoopJob?.cancel()
        audioLoopJob = null
        isListeningFlow.value = false
    }

    private fun triggerWakeOverlay() {
        serviceScope.launch(Dispatchers.Main.immediate) {
            stopAudioLoop()
            val wakeIntent = Intent(this@WakeWordService, AssistActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP
                )
                putExtra(AssistActivity.EXTRA_WAKE_TRIGGERED, true)
            }
            runCatching { startActivity(wakeIntent) }
        }
    }

    private fun buildNotification(): Notification {
        val nm = NotificationManagerCompat.from(this)
        val channel = NotificationChannelCompat.Builder(
            CHANNEL_ID,
            NotificationManagerCompat.IMPORTANCE_LOW
        )
            .setName(getString(R.string.wake_notification_channel_name))
            .build()
        nm.createNotificationChannel(channel)

        val openIntent = PendingIntent.getActivity(
            this,
            10,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val wakeNowIntent = PendingIntent.getActivity(
            this,
            11,
            Intent(this, AssistActivity::class.java).putExtra(AssistActivity.EXTRA_WAKE_TRIGGERED, true),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            12,
            Intent(this, WakeWordService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val accentArgb = when (currentThemeMode) {
            ThemeMode.PERSIAN -> 0xFF007A78.toInt()
            ThemeMode.NEON -> 0xFF00F5D4.toInt()
            else -> 0xFF1D4ED8.toInt()
        }

        val detailText = if (hasEnrolledSample) {
            "Silent on-device standby • Say \"$currentAssistantName\""
        } else {
            "Silent standby active • Tap Settings to enroll 2s voice sample"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Silent Wake: \"$currentAssistantName\"")
            .setContentText(detailText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setColor(accentArgb)
            .setContentIntent(openIntent)
            .addAction(0, "Wake Now", wakeNowIntent)
            .addAction(0, "Stop", stopIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun startForegroundNotification() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification() {
        runCatching {
            NotificationManagerCompat.from(this).notify(NOTIFICATION_ID, buildNotification())
        }
    }

    companion object {
        private const val CHANNEL_ID = "personal_ai_wake_channel"
        private const val NOTIFICATION_ID = 4102
        private const val WAKE_COOLDOWN_MS = 2500L
        const val ACTION_STOP = "com.example.assistant.ACTION_STOP_WAKE"

        val isRunningFlow = MutableStateFlow(false)
        val isListeningFlow = MutableStateFlow(false)
        val isAssistantOverlayActive = MutableStateFlow(false)
        val lastHeardTextFlow = MutableStateFlow<String?>(null)

        fun hasMicPermission(context: Context): Boolean =
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.RECORD_AUDIO
            ) == PackageManager.PERMISSION_GRANTED

        fun start(context: Context) {
            if (!hasMicPermission(context)) return
            val intent = Intent(context, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, WakeWordService::class.java))
        }
    }
}
