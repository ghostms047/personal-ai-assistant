package com.example.assistant

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

data class WakeVoiceTemplate(
    val phrase: String,
    val frames: List<FloatArray>,
    val createdAt: Long = System.currentTimeMillis()
)

enum class WakeDetectionOutcome {
    NO_SPEECH,
    TEMPLATE_MATCH,
    GENERIC_BURST_MATCH,
    NON_MATCH
}

/**
 * 100% silent, on-device acoustic wake detector using Goertzel spectral band energies
 * and Dynamic Time Warping (DTW). Never opens Android SpeechRecognizer or plays chime sounds.
 */
object SilentWakeDetector {

    const val SAMPLE_RATE = 16000
    const val FRAME_SIZE = 512
    const val HOP_SIZE = 256
    private const val NUM_BANDS = 12
    private const val MIN_TEMPLATE_FRAMES = 10
    private const val MAX_TEMPLATE_FRAMES = 110
    private const val MIN_VOICE_RMS = 0.016f
    private const val GENERIC_BURST_RMS = 0.042f
    private const val TEMPLATE_MATCH_THRESHOLD = 0.42f

    // 12 speech-relevant frequencies spanning vowels & consonants (180Hz - 3850Hz)
    private val bandFrequenciesHz = floatArrayOf(
        180f, 270f, 380f, 520f, 700f, 940f,
        1220f, 1560f, 1980f, 2500f, 3120f, 3850f
    )

    private val hammingWindow = FloatArray(FRAME_SIZE) { n ->
        (0.54 - 0.46 * cos(2.0 * PI * n / (FRAME_SIZE - 1))).toFloat()
    }

    private val goertzelCoeffs = FloatArray(NUM_BANDS) { idx ->
        val k = (0.5 + (FRAME_SIZE * bandFrequenciesHz[idx]) / SAMPLE_RATE.toDouble()).toInt()
        val omega = (2.0 * PI * k) / FRAME_SIZE
        (2.0 * cos(omega)).toFloat()
    }

    fun computeFrameRms(pcm: ShortArray, offset: Int = 0, length: Int = min(FRAME_SIZE, pcm.size - offset)): Float {
        if (length <= 0) return 0f
        var sumSq = 0.0
        for (i in 0 until length) {
            val s = pcm[offset + i] / 32768.0
            sumSq += s * s
        }
        return sqrt(sumSq / length).toFloat()
    }

    fun extractSpectralFrame(pcm: ShortArray, offset: Int = 0): FloatArray {
        val windowed = FloatArray(FRAME_SIZE)
        for (i in 0 until FRAME_SIZE) {
            val sample = if (offset + i < pcm.size) pcm[offset + i] / 32768f else 0f
            windowed[i] = sample * hammingWindow[i]
        }

        val bands = FloatArray(NUM_BANDS)
        var mean = 0f
        for (b in 0 until NUM_BANDS) {
            val coeff = goertzelCoeffs[b]
            var q0 = 0f
            var q1 = 0f
            var q2 = 0f
            for (i in 0 until FRAME_SIZE) {
                q0 = coeff * q1 - q2 + windowed[i]
                q2 = q1
                q1 = q0
            }
            val power = max(1e-8f, q1 * q1 + q2 * q2 - q1 * q2 * coeff)
            val logEnergy = ln(1f + power)
            bands[b] = logEnergy
            mean += logEnergy
        }
        mean /= NUM_BANDS

        var normSq = 0f
        for (b in 0 until NUM_BANDS) {
            bands[b] -= mean
            normSq += bands[b] * bands[b]
        }
        val norm = sqrt(normSq)
        if (norm > 1e-5f) {
            for (b in 0 until NUM_BANDS) {
                bands[b] /= norm
            }
        }
        return bands
    }

    fun extractFramesFromPcm(pcm: ShortArray): List<FloatArray> {
        if (pcm.size < FRAME_SIZE) return emptyList()
        val out = ArrayList<FloatArray>((pcm.size - FRAME_SIZE) / HOP_SIZE + 1)
        var pos = 0
        while (pos + FRAME_SIZE <= pcm.size) {
            out += extractSpectralFrame(pcm, pos)
            pos += HOP_SIZE
        }
        return out
    }

    fun trimSpeechFrames(pcm: ShortArray): List<FloatArray> {
        if (pcm.size < FRAME_SIZE) return emptyList()
        val rmsList = mutableListOf<Float>()
        val frames = mutableListOf<FloatArray>()
        var pos = 0
        while (pos + FRAME_SIZE <= pcm.size) {
            val rms = computeFrameRms(pcm, pos, FRAME_SIZE)
            rmsList += rms
            frames += extractSpectralFrame(pcm, pos)
            pos += HOP_SIZE
        }
        if (rmsList.isEmpty()) return emptyList()
        val sortedRms = rmsList.sorted()
        val floor = sortedRms[sortedRms.size / 4]
        val peak = sortedRms.last()
        if (peak < MIN_VOICE_RMS) return emptyList()
        val gate = max(MIN_VOICE_RMS, floor + (peak - floor) * 0.22f)
        val firstSpeech = rmsList.indexOfFirst { it >= gate }.takeIf { it >= 0 } ?: return emptyList()
        val lastSpeech = rmsList.indexOfLast { it >= gate }.takeIf { it >= firstSpeech } ?: return emptyList()
        val start = max(0, firstSpeech - 2)
        val end = min(frames.lastIndex, lastSpeech + 2)
        return frames.subList(start, min(end + 1, start + MAX_TEMPLATE_FRAMES)).toList()
    }

    /**
     * Normalized Dynamic Time Warping distance using cosine distance on spectral vectors.
     * Lower = closer match (0.0 = identical).
     */
    fun dtwCosineDistance(seqA: List<FloatArray>, seqB: List<FloatArray>): Float {
        val n = seqA.size
        val m = seqB.size
        if (n == 0 || m == 0) return Float.POSITIVE_INFINITY
        // Reject wildly mismatched speaking durations (> 2.6x)
        val ratio = max(n, m).toFloat() / min(n, m).toFloat()
        if (ratio > 2.6f) return 1.0f

        val bandWidth = max(4, max(n, m) / 3)
        var prev = FloatArray(m + 1) { Float.POSITIVE_INFINITY }
        var curr = FloatArray(m + 1) { Float.POSITIVE_INFINITY }
        prev[0] = 0f

        for (i in 1..n) {
            curr.fill(Float.POSITIVE_INFINITY)
            val center = (i * m) / n
            val jStart = max(1, center - bandWidth)
            val jEnd = min(m, center + bandWidth)
            val vecA = seqA[i - 1]
            for (j in jStart..jEnd) {
                val dist = cosineDistance(vecA, seqB[j - 1])
                val bestPrev = min(prev[j], min(curr[j - 1], prev[j - 1]))
                if (bestPrev < Float.POSITIVE_INFINITY) {
                    curr[j] = dist + bestPrev
                }
            }
            val tmp = prev
            prev = curr
            curr = tmp
        }

        val total = prev[m]
        if (!total.isFinite()) return 1.0f
        return total / ((n + m) * 0.5f)
    }

    private fun cosineDistance(a: FloatArray, b: FloatArray): Float {
        val len = min(a.size, b.size)
        var dot = 0f
        for (i in 0 until len) {
            dot += a[i] * b[i]
        }
        return (1f - dot.coerceIn(-1f, 1f)) * 0.5f
    }

    fun matchesTemplate(utterance: List<FloatArray>, template: WakeVoiceTemplate, threshold: Float = TEMPLATE_MATCH_THRESHOLD): Boolean {
        if (utterance.size < MIN_TEMPLATE_FRAMES || template.frames.size < MIN_TEMPLATE_FRAMES) return false
        return dtwCosineDistance(utterance, template.frames) <= threshold
    }

    fun encodeTemplate(template: WakeVoiceTemplate): String {
        val safePhrase = template.phrase
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
        val sb = StringBuilder(256)
        sb.append("{\"phrase\":\"").append(safePhrase).append("\",")
        sb.append("\"createdAt\":").append(template.createdAt).append(',')
        sb.append("\"frames\":[")
        template.frames.forEachIndexed { idx, frame ->
            if (idx > 0) sb.append(',')
            sb.append('[')
            for (b in frame.indices) {
                if (b > 0) sb.append(',')
                val rounded = ((frame[b] * 1000f).toInt()) / 1000f
                sb.append(rounded)
            }
            sb.append(']')
        }
        sb.append("]}")
        return sb.toString()
    }

    fun decodeTemplate(raw: String): WakeVoiceTemplate? {
        if (raw.isBlank()) return null
        return runCatching {
            val phraseMatch = Regex("\"phrase\":\"((?:\\\\.|[^\"])*)\"").find(raw)
            val phrase = phraseMatch?.groupValues?.get(1)
                ?.replace("\\\"", "\"")
                ?.replace("\\\\", "\\")
                .orEmpty()
                .ifBlank { "Personal AI" }

            val createdAt = Regex("\"createdAt\":(\\d+)").find(raw)
                ?.groupValues?.get(1)?.toLongOrNull() ?: 0L

            val framesStart = raw.indexOf("\"frames\":[")
            if (framesStart < 0) return null
            val arrayBody = raw.substring(framesStart + "\"frames\":[".length)
            val frameRegex = Regex("\\[([0-9eE.+\\-,\\s]+)]")
            val parsedFrames = mutableListOf<FloatArray>()
            frameRegex.findAll(arrayBody).forEach { match ->
                val parts = match.groupValues[1].split(',')
                if (parts.size == NUM_BANDS) {
                    val vec = FloatArray(NUM_BANDS) { idx ->
                        parts[idx].trim().toFloatOrNull() ?: 0f
                    }
                    parsedFrames += vec
                }
            }
            if (parsedFrames.size < MIN_TEMPLATE_FRAMES) return null
            WakeVoiceTemplate(phrase = phrase, frames = parsedFrames, createdAt = createdAt)
        }.getOrNull()
    }

    /**
     * Stateful streaming frame processor with adaptive noise floor and hangover VAD.
     */
    class StreamingSession(
        private var template: WakeVoiceTemplate? = null
    ) {
        private var noiseFloorRms = 0.010f
        private var inSpeech = false
        private var silenceFrames = 0
        private var peakRms = 0f
        private val speechBuffer = ArrayList<FloatArray>(MAX_TEMPLATE_FRAMES)

        fun setTemplate(newTemplate: WakeVoiceTemplate?) {
            template = newTemplate
        }

        fun reset() {
            inSpeech = false
            silenceFrames = 0
            peakRms = 0f
            speechBuffer.clear()
        }

        fun processFrame(pcmFrame: ShortArray, offset: Int = 0): WakeDetectionOutcome {
            if (offset + FRAME_SIZE > pcmFrame.size) return WakeDetectionOutcome.NO_SPEECH
            val rms = computeFrameRms(pcmFrame, offset, FRAME_SIZE)
            val speechThreshold = max(MIN_VOICE_RMS, noiseFloorRms * 2.7f)

            if (!inSpeech) {
                // Smoothly adapt ambient noise floor while quiet
                noiseFloorRms = (noiseFloorRms * 0.94f + rms * 0.06f).coerceIn(0.004f, 0.08f)
                if (rms > speechThreshold) {
                    inSpeech = true
                    silenceFrames = 0
                    peakRms = rms
                    speechBuffer.clear()
                    speechBuffer += extractSpectralFrame(pcmFrame, offset)
                }
                return WakeDetectionOutcome.NO_SPEECH
            }

            if (rms > peakRms) peakRms = rms
            if (speechBuffer.size < MAX_TEMPLATE_FRAMES) {
                speechBuffer += extractSpectralFrame(pcmFrame, offset)
            }

            if (rms > speechThreshold * 0.78f) {
                silenceFrames = 0
            } else {
                silenceFrames++
            }

            val ended = silenceFrames >= 12 || speechBuffer.size >= MAX_TEMPLATE_FRAMES
            if (!ended) return WakeDetectionOutcome.NO_SPEECH

            val captured = speechBuffer.toList()
            val maxPeak = peakRms
            val currentFloor = noiseFloorRms
            reset()

            if (captured.size < MIN_TEMPLATE_FRAMES) {
                return WakeDetectionOutcome.NON_MATCH
            }

            val activeTemplate = template
            return if (activeTemplate != null) {
                if (matchesTemplate(captured, activeTemplate)) {
                    WakeDetectionOutcome.TEMPLATE_MATCH
                } else {
                    WakeDetectionOutcome.NON_MATCH
                }
            } else {
                // Without an enrolled sample, only trigger on a clear intentional near-field phrase burst (0.3s - 1.4s)
                if (captured.size in 18..88 && maxPeak >= max(GENERIC_BURST_RMS, currentFloor * 4.2f)) {
                    WakeDetectionOutcome.GENERIC_BURST_MATCH
                } else {
                    WakeDetectionOutcome.NON_MATCH
                }
            }
        }
    }

    /**
     * Silently records ~2.2 seconds of mono PCM via Android AudioRecord (no Google STT chime/popup)
     * and returns a serialized WakeVoiceTemplate JSON string if speech was captured.
     */
    @SuppressLint("MissingPermission")
    suspend fun recordWakeSample(
        phraseName: String,
        durationMs: Long = 2200L
    ): Result<String> = withContext(Dispatchers.IO) {
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(FRAME_SIZE * 4)

        val recorder = AudioRecord(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            minBuf * 2
        )
        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            runCatching { recorder.release() }
            return@withContext Result.failure(IllegalStateException("Could not initialize microphone hardware."))
        }

        val totalSamples = ((SAMPLE_RATE * durationMs) / 1000L).toInt()
        val captured = ShortArray(totalSamples)
        var written = 0
        try {
            recorder.startRecording()
            val chunk = ShortArray(HOP_SIZE * 2)
            while (written < totalSamples) {
                val n = recorder.read(chunk, 0, min(chunk.size, totalSamples - written))
                if (n <= 0) break
                chunk.copyInto(captured, destinationOffset = written, startIndex = 0, endIndex = n)
                written += n
            }
        } catch (e: Exception) {
            return@withContext Result.failure(e)
        } finally {
            runCatching { recorder.stop() }
            runCatching { recorder.release() }
        }

        val used = if (written < captured.size) captured.copyOf(written) else captured
        val trimmedFrames = trimSpeechFrames(used)
        if (trimmedFrames.size < MIN_TEMPLATE_FRAMES) {
            return@withContext Result.failure(
                IllegalStateException("No clear speech detected. Say \"${phraseName.ifBlank { "Hey Assistant" }}\" clearly near the microphone.")
            )
        }
        val encoded = encodeTemplate(
            WakeVoiceTemplate(
                phrase = phraseName.ifBlank { "Personal AI" },
                frames = trimmedFrames
            )
        )
        Result.success(encoded)
    }
}
