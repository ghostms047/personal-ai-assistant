package com.example.assistant

import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/**
 * Companion RecognitionService declared by [PersonalVoiceInteractionService] so Android
 * recognizes the app as a complete Digital Assistant candidate for Power-button and
 * Home-button long-press triggers.
 */
class PersonalRecognitionService : RecognitionService() {

    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        // AssistActivity manages interactive speech input cleanly via Microphone button.
        listener?.error(SpeechRecognizer.ERROR_CLIENT)
    }

    override fun onCancel(listener: Callback?) {
        // Nothing active to cancel
    }

    override fun onStopListening(listener: Callback?) {
        listener?.endOfSpeech()
    }
}
