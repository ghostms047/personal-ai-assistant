package com.example.assistant

data class WakeMatchResult(
    val assistantName: String,
    val remainingCommand: String
)

/**
 * Pure Kotlin wake-word matcher that detects when the user says their chosen AI name
 * (e.g. "Hey Nova", "Nova open Chrome", "سلام سارا ساعت چنده") and extracts any trailing command.
 */
object WakeWordMatcher {

    private val leadingSeparators = Regex("""^[\s,:;.!?؟،-]+""")

    fun matchWakePhrase(spokenText: String, assistantName: String): WakeMatchResult? {
        val rawSpoken = spokenText.trim()
        val cleanName = normalizeUnicode(assistantName).trim()
        if (rawSpoken.isBlank() || cleanName.length < 2) return null

        val normalizedSpoken = normalizeUnicode(rawSpoken)
        val escapedName = Regex.escape(cleanName)
        // Match the AI name at word/token boundaries (supports Latin, digits, and Persian/Arabic letters)
        val pattern = Regex(
            pattern = """(^|[^\p{L}\p{N}])($escapedName)($|[^\p{L}\p{N}])""",
            options = setOf(RegexOption.IGNORE_CASE)
        )
        val match = pattern.find(normalizedSpoken) ?: return null
        val nameEndIndex = match.groups[2]?.range?.last?.plus(1) ?: return null

        val trailingRaw = if (nameEndIndex <= rawSpoken.length) {
            rawSpoken.substring(nameEndIndex)
        } else {
            ""
        }
        val cleanTrailing = trailingRaw.replace(leadingSeparators, "").trim()

        return WakeMatchResult(
            assistantName = assistantName.trim(),
            remainingCommand = cleanTrailing
        )
    }

    internal fun normalizeUnicode(text: String): String =
        text
            .replace('\u064A', '\u06CC') // Arabic Yeh -> Persian Yeh
            .replace('\u0643', '\u06A9') // Arabic Kaf -> Persian Kaf
            .replace('\u200C', ' ')      // Zero-width non-joiner -> space
}
