#include <jni.h>
#include <android/log.h>

#include "llama.h"

#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <mutex>
#include <string>
#include <vector>

#define TAG "PersonalAiLlamaJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

std::once_flag g_backend_once;
std::mutex g_error_mutex;
std::string g_last_error;

void set_last_error(const std::string & msg) {
    std::lock_guard<std::mutex> lock(g_error_mutex);
    g_last_error = msg;
}

std::string get_last_error() {
    std::lock_guard<std::mutex> lock(g_error_mutex);
    return g_last_error;
}

void android_llama_log_cb(ggml_log_level level, const char * text, void * /*user_data*/) {
    if (!text) return;
    if (level == GGML_LOG_LEVEL_ERROR) {
        LOGE("%s", text);
        std::string msg(text);
        while (!msg.empty() && (msg.back() == '\n' || msg.back() == '\r')) {
            msg.pop_back();
        }
        if (!msg.empty()) {
            set_last_error(msg);
        }
    } else if (level == GGML_LOG_LEVEL_WARN) {
        LOGW("%s", text);
    } else if (level == GGML_LOG_LEVEL_INFO) {
        LOGI("%s", text);
    }
}

void ensure_backend_initialized() {
    std::call_once(g_backend_once, []() {
        llama_log_set(android_llama_log_cb, nullptr);
        llama_backend_init();
    });
}

// Converts arbitrary UTF-8 (replacing invalid sequences safely with U+FFFD) into UTF-16
// so NewString never aborts on ART's Modified UTF-8 validator when emitting Persian text or emojis.
jstring utf8_to_jstring(JNIEnv * env, const std::string & utf8) {
    std::vector<jchar> utf16;
    utf16.reserve(utf8.size());
    const size_t n = utf8.size();
    size_t i = 0;
    while (i < n) {
        uint8_t c = static_cast<uint8_t>(utf8[i]);
        uint32_t cp = 0xFFFD;
        if (c < 0x80) {
            cp = c;
            i += 1;
        } else if ((c & 0xE0) == 0xC0 && i + 1 < n) {
            uint8_t c1 = static_cast<uint8_t>(utf8[i + 1]);
            if ((c1 & 0xC0) == 0x80) {
                cp = ((c & 0x1F) << 6) | (c1 & 0x3F);
                i += 2;
            } else {
                i += 1;
            }
        } else if ((c & 0xF0) == 0xE0 && i + 2 < n) {
            uint8_t c1 = static_cast<uint8_t>(utf8[i + 1]);
            uint8_t c2 = static_cast<uint8_t>(utf8[i + 2]);
            if ((c1 & 0xC0) == 0x80 && (c2 & 0xC0) == 0x80) {
                cp = ((c & 0x0F) << 12) | ((c1 & 0x3F) << 6) | (c2 & 0x3F);
                i += 3;
            } else {
                i += 1;
            }
        } else if ((c & 0xF8) == 0xF0 && i + 3 < n) {
            uint8_t c1 = static_cast<uint8_t>(utf8[i + 1]);
            uint8_t c2 = static_cast<uint8_t>(utf8[i + 2]);
            uint8_t c3 = static_cast<uint8_t>(utf8[i + 3]);
            if ((c1 & 0xC0) == 0x80 && (c2 & 0xC0) == 0x80 && (c3 & 0xC0) == 0x80) {
                cp = ((c & 0x07) << 18) | ((c1 & 0x3F) << 12) | ((c2 & 0x3F) << 6) | (c3 & 0x3F);
                i += 4;
            } else {
                i += 1;
            }
        } else {
            i += 1;
        }

        if (cp <= 0xFFFF) {
            if (cp >= 0xD800 && cp <= 0xDFFF) {
                utf16.push_back(0xFFFD);
            } else {
                utf16.push_back(static_cast<jchar>(cp));
            }
        } else if (cp <= 0x10FFFF) {
            cp -= 0x10000;
            utf16.push_back(static_cast<jchar>(0xD800 + (cp >> 10)));
            utf16.push_back(static_cast<jchar>(0xDC00 + (cp & 0x3FF)));
        } else {
            utf16.push_back(0xFFFD);
        }
    }
    return env->NewString(utf16.data(), static_cast<jsize>(utf16.size()));
}

// Finds longest prefix that ends on a complete UTF-8 codepoint boundary.
size_t complete_utf8_prefix_len(const std::string & s) {
    if (s.empty()) return 0;
    size_t len = s.size();
    // Walk back at most 3 trailing continuation bytes / partial lead byte
    size_t scan = len;
    while (scan > 0 && (static_cast<uint8_t>(s[scan - 1]) & 0xC0) == 0x80) {
        --scan;
    }
    if (scan == 0) return len; // fallback
    uint8_t lead = static_cast<uint8_t>(s[scan - 1]);
    size_t expected = 1;
    if ((lead & 0x80) == 0) expected = 1;
    else if ((lead & 0xE0) == 0xC0) expected = 2;
    else if ((lead & 0xF0) == 0xE0) expected = 3;
    else if ((lead & 0xF8) == 0xF0) expected = 4;
    else return len;

    size_t have = len - (scan - 1);
    return (have < expected) ? (scan - 1) : len;
}

struct ModelHandle {
    llama_model * model = nullptr;
    llama_context * ctx = nullptr;
    const llama_vocab * vocab = nullptr;
    uint32_t n_ctx = 2048;
    uint32_t n_batch = 256;
    std::atomic<bool> stop_requested{false};
    std::mutex mutex;

    ~ModelHandle() {
        if (ctx) {
            llama_free(ctx);
            ctx = nullptr;
        }
        if (model) {
            llama_model_free(model);
            model = nullptr;
        }
    }
};

bool abort_decode_callback(void * user_data) {
    auto * handle = static_cast<ModelHandle *>(user_data);
    return handle != nullptr && handle->stop_requested.load();
}

} // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_example_ai_local_NativeLlamaBridge_nativeLoadModel(
        JNIEnv * env,
        jobject /*thiz*/,
        jstring modelPath,
        jint nCtx,
        jint nThreads,
        jint nBatch) {
    ensure_backend_initialized();
    set_last_error("");

    if (!modelPath) {
        set_last_error("Model path is null.");
        return 0L;
    }
    const char * pathChars = env->GetStringUTFChars(modelPath, nullptr);
    if (!pathChars) {
        set_last_error("Unable to read model path.");
        return 0L;
    }
    std::string path(pathChars);
    env->ReleaseStringUTFChars(modelPath, pathChars);

    try {
        llama_model_params mparams = llama_model_default_params();
        mparams.n_gpu_layers = 0; // CPU backend for universal Android arm64 compatibility
        mparams.check_tensors = false;

        llama_model * model = llama_model_load_from_file(path.c_str(), mparams);
        if (!model) {
            if (get_last_error().empty()) {
                set_last_error("llama_model_load_from_file failed for " + path);
            }
            return 0L;
        }

        auto * handle = new ModelHandle();
        handle->model = model;
        handle->vocab = llama_model_get_vocab(model);
        handle->n_ctx = static_cast<uint32_t>(std::max<jint>(512, nCtx));
        handle->n_batch = static_cast<uint32_t>(std::max<jint>(64, std::min<jint>(nBatch, static_cast<jint>(handle->n_ctx))));

        llama_context_params cparams = llama_context_default_params();
        cparams.n_ctx = handle->n_ctx;
        cparams.n_batch = handle->n_batch;
        cparams.n_ubatch = std::min<uint32_t>(handle->n_batch, 256);
        cparams.n_threads = std::max<int32_t>(1, nThreads);
        cparams.n_threads_batch = std::max<int32_t>(1, nThreads);
        cparams.no_perf = true;
        cparams.abort_callback = abort_decode_callback;
        cparams.abort_callback_data = handle;

        llama_context * ctx = llama_init_from_model(model, cparams);
        if (!ctx) {
            if (get_last_error().empty()) {
                set_last_error("Failed to allocate inference KV context (insufficient RAM).");
            }
            delete handle;
            return 0L;
        }

        handle->ctx = ctx;
        handle->n_ctx = llama_n_ctx(ctx);
        handle->n_batch = llama_n_batch(ctx);
        LOGI("Loaded GGUF model: n_ctx=%u, n_batch=%u, threads=%d", handle->n_ctx, handle->n_batch, cparams.n_threads);
        return reinterpret_cast<jlong>(handle);
    } catch (const std::exception & ex) {
        set_last_error(std::string("Native exception loading model: ") + ex.what());
        return 0L;
    } catch (...) {
        set_last_error("Unknown native error loading GGUF model.");
        return 0L;
    }
}

JNIEXPORT jstring JNICALL
Java_com_example_ai_local_NativeLlamaBridge_nativeApplyChatTemplate(
        JNIEnv * env,
        jobject /*thiz*/,
        jlong handlePtr,
        jobjectArray roles,
        jobjectArray contents,
        jboolean addAssistant) {
    if (handlePtr == 0L || !roles || !contents) return nullptr;
    auto * handle = reinterpret_cast<ModelHandle *>(handlePtr);
    std::lock_guard<std::mutex> lock(handle->mutex);
    if (!handle->model) return nullptr;

    const char * tmpl = llama_model_chat_template(handle->model, nullptr);
    if (!tmpl || std::strlen(tmpl) == 0) {
        return nullptr;
    }

    jsize n = env->GetArrayLength(roles);
    jsize n2 = env->GetArrayLength(contents);
    jsize count = std::min(n, n2);
    if (count <= 0) return nullptr;

    std::vector<std::string> roleStrings;
    std::vector<std::string> contentStrings;
    roleStrings.reserve(count);
    contentStrings.reserve(count);

    for (jsize i = 0; i < count; ++i) {
        auto rObj = static_cast<jstring>(env->GetObjectArrayElement(roles, i));
        auto cObj = static_cast<jstring>(env->GetObjectArrayElement(contents, i));
        const char * rCh = rObj ? env->GetStringUTFChars(rObj, nullptr) : nullptr;
        const char * cCh = cObj ? env->GetStringUTFChars(cObj, nullptr) : nullptr;
        roleStrings.emplace_back(rCh ? rCh : "user");
        contentStrings.emplace_back(cCh ? cCh : "");
        if (rCh) env->ReleaseStringUTFChars(rObj, rCh);
        if (cCh) env->ReleaseStringUTFChars(cObj, cCh);
        if (rObj) env->DeleteLocalRef(rObj);
        if (cObj) env->DeleteLocalRef(cObj);
    }

    std::vector<llama_chat_message> msgs(count);
    size_t totalChars = 0;
    for (jsize i = 0; i < count; ++i) {
        msgs[i].role = roleStrings[i].c_str();
        msgs[i].content = contentStrings[i].c_str();
        totalChars += roleStrings[i].size() + contentStrings[i].size();
    }

    std::vector<char> formatted(std::max<size_t>(2048, totalChars * 2 + 512));
    int32_t needed = llama_chat_apply_template(
            tmpl,
            msgs.data(),
            msgs.size(),
            addAssistant == JNI_TRUE,
            formatted.data(),
            static_cast<int32_t>(formatted.size()));

    if (needed < 0) {
        return nullptr;
    }
    if (static_cast<size_t>(needed) >= formatted.size()) {
        formatted.resize(static_cast<size_t>(needed) + 16);
        needed = llama_chat_apply_template(
                tmpl,
                msgs.data(),
                msgs.size(),
                addAssistant == JNI_TRUE,
                formatted.data(),
                static_cast<int32_t>(formatted.size()));
        if (needed < 0) return nullptr;
    }

    return utf8_to_jstring(env, std::string(formatted.data(), static_cast<size_t>(needed)));
}

JNIEXPORT jstring JNICALL
Java_com_example_ai_local_NativeLlamaBridge_nativeGenerate(
        JNIEnv * env,
        jobject /*thiz*/,
        jlong handlePtr,
        jstring prompt,
        jint maxTokens,
        jfloat temperature,
        jobject callback) {
    if (handlePtr == 0L || !prompt) {
        set_last_error("Invalid handle or empty prompt.");
        return utf8_to_jstring(env, "");
    }

    auto * handle = reinterpret_cast<ModelHandle *>(handlePtr);
    std::lock_guard<std::mutex> lock(handle->mutex);
    if (!handle->ctx || !handle->vocab) {
        set_last_error("Model context is not initialized.");
        return utf8_to_jstring(env, "");
    }

    set_last_error("");
    handle->stop_requested.store(false);

    const char * promptChars = env->GetStringUTFChars(prompt, nullptr);
    if (!promptChars) {
        set_last_error("Failed to decode prompt string.");
        return utf8_to_jstring(env, "");
    }
    std::string promptStr(promptChars);
    env->ReleaseStringUTFChars(prompt, promptChars);

    jmethodID onTokenMethod = nullptr;
    if (callback) {
        jclass cbClass = env->GetObjectClass(callback);
        if (cbClass) {
            onTokenMethod = env->GetMethodID(cbClass, "onToken", "(Ljava/lang/String;)V");
            env->DeleteLocalRef(cbClass);
        }
    }

    try {
        llama_memory_clear(llama_get_memory(handle->ctx), true);

        const bool hasBosPrefix =
                promptStr.rfind("<bos>", 0) == 0 ||
                promptStr.rfind("<|begin_of_text|>", 0) == 0 ||
                promptStr.rfind("<s>", 0) == 0;
        const bool addSpecial = !hasBosPrefix;

        int32_t n_prompt = -llama_tokenize(
                handle->vocab,
                promptStr.c_str(),
                static_cast<int32_t>(promptStr.size()),
                nullptr,
                0,
                addSpecial,
                true);
        if (n_prompt <= 0) {
            set_last_error("Prompt tokenization returned 0 tokens.");
            return utf8_to_jstring(env, "");
        }

        std::vector<llama_token> promptTokens(static_cast<size_t>(n_prompt));
        int32_t tokenized = llama_tokenize(
                handle->vocab,
                promptStr.c_str(),
                static_cast<int32_t>(promptStr.size()),
                promptTokens.data(),
                n_prompt,
                addSpecial,
                true);
        if (tokenized < 0) {
            set_last_error("Prompt tokenization buffer mismatch.");
            return utf8_to_jstring(env, "");
        }

        // Preserve room for generated tokens if prompt exceeds context window
        const uint32_t safetyMargin = 48;
        const uint32_t maxPromptTokens = (handle->n_ctx > safetyMargin) ? (handle->n_ctx - safetyMargin) : handle->n_ctx;
        if (promptTokens.size() > maxPromptTokens) {
            const size_t keepHead = std::min<size_t>(64, maxPromptTokens / 4);
            const size_t keepTail = maxPromptTokens - keepHead;
            std::vector<llama_token> trimmed;
            trimmed.reserve(maxPromptTokens);
            trimmed.insert(trimmed.end(), promptTokens.begin(), promptTokens.begin() + keepHead);
            trimmed.insert(trimmed.end(), promptTokens.end() - keepTail, promptTokens.end());
            promptTokens.swap(trimmed);
        }

        llama_batch_ext * batch = llama_batch_ext_init(handle->ctx);
        if (!batch) {
            set_last_error("Failed to allocate inference batch.");
            return utf8_to_jstring(env, "");
        }

        llama_pos cur_pos = 0;
        const size_t chunkMax = std::max<uint32_t>(1, handle->n_batch);
        for (size_t start = 0; start < promptTokens.size(); start += chunkMax) {
            if (handle->stop_requested.load()) {
                llama_batch_ext_free(batch);
                return utf8_to_jstring(env, "");
            }
            size_t end = std::min(promptTokens.size(), start + chunkMax);
            llama_batch_ext_clear(batch);
            for (size_t idx = start; idx < end; ++idx) {
                int32_t b_idx = llama_batch_ext_add_token(batch, 0, promptTokens[idx]);
                if (b_idx < 0) {
                    llama_batch_ext_free(batch);
                    set_last_error("Failed adding prompt token to batch.");
                    return utf8_to_jstring(env, "");
                }
                llama_pos p = cur_pos++;
                llama_batch_ext_set_pos(batch, b_idx, &p);
                llama_batch_ext_set_output_logits(batch, b_idx, idx == promptTokens.size() - 1);
            }
            int32_t rc = llama_process(handle->ctx, LLAMA_PROCESS_TYPE_DECODE, batch);
            if (rc == 2) { // Aborted by user
                llama_batch_ext_free(batch);
                return utf8_to_jstring(env, "");
            }
            if (rc != 0) {
                llama_batch_ext_free(batch);
                set_last_error("Prompt decode failed (code=" + std::to_string(rc) + ").");
                return utf8_to_jstring(env, "");
            }
        }

        auto sparams = llama_sampler_chain_default_params();
        sparams.no_perf = true;
        llama_sampler * smpl = llama_sampler_chain_init(sparams);
        llama_sampler_chain_add(smpl, llama_sampler_init_penalties(llama_vocab_n_tokens(handle->vocab), 64, 1.08f, 0.0f, 0.0f));
        if (temperature <= 0.05f) {
            llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
        } else {
            llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
            llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.92f, 1));
            llama_sampler_chain_add(smpl, llama_sampler_init_temp(temperature));
            llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
        }

        std::string output;
        std::string pendingUtf8;
        const int32_t budget = std::min<int32_t>(
                std::max<jint>(1, maxTokens),
                static_cast<int32_t>(handle->n_ctx) - static_cast<int32_t>(cur_pos) - 1);

        for (int32_t step = 0; step < budget; ++step) {
            if (handle->stop_requested.load()) break;

            llama_token tok = llama_sampler_sample(smpl, handle->ctx, -1);
            if (llama_vocab_is_eog(handle->vocab, tok)) {
                break;
            }

            char pieceBuf[512];
            int32_t nPiece = llama_token_to_piece(handle->vocab, tok, pieceBuf, sizeof(pieceBuf), 0, false);
            std::string piece;
            if (nPiece < 0) {
                std::vector<char> bigBuf(static_cast<size_t>(-nPiece) + 4);
                nPiece = llama_token_to_piece(handle->vocab, tok, bigBuf.data(), static_cast<int32_t>(bigBuf.size()), 0, false);
                if (nPiece > 0) piece.assign(bigBuf.data(), static_cast<size_t>(nPiece));
            } else if (nPiece > 0) {
                piece.assign(pieceBuf, static_cast<size_t>(nPiece));
            }

            if (!piece.empty()) {
                output.append(piece);
                pendingUtf8.append(piece);

                size_t validLen = complete_utf8_prefix_len(pendingUtf8);
                if (validLen > 0 && callback && onTokenMethod) {
                    std::string chunk = pendingUtf8.substr(0, validLen);
                    pendingUtf8.erase(0, validLen);
                    jstring jChunk = utf8_to_jstring(env, chunk);
                    if (jChunk) {
                        env->CallVoidMethod(callback, onTokenMethod, jChunk);
                        env->DeleteLocalRef(jChunk);
                        if (env->ExceptionCheck()) {
                            env->ExceptionClear();
                            handle->stop_requested.store(true);
                            break;
                        }
                    }
                }
            }

            llama_batch_ext_clear(batch);
            int32_t b_idx = llama_batch_ext_add_token(batch, 0, tok);
            if (b_idx < 0) break;
            llama_pos p = cur_pos++;
            llama_batch_ext_set_pos(batch, b_idx, &p);
            llama_batch_ext_set_output_logits(batch, b_idx, true);

            int32_t rc = llama_process(handle->ctx, LLAMA_PROCESS_TYPE_DECODE, batch);
            if (rc != 0) break;
        }

        if (!pendingUtf8.empty() && callback && onTokenMethod && !handle->stop_requested.load()) {
            jstring jChunk = utf8_to_jstring(env, pendingUtf8);
            if (jChunk) {
                env->CallVoidMethod(callback, onTokenMethod, jChunk);
                env->DeleteLocalRef(jChunk);
                if (env->ExceptionCheck()) env->ExceptionClear();
            }
        }

        llama_sampler_free(smpl);
        llama_batch_ext_free(batch);
        return utf8_to_jstring(env, output);
    } catch (const std::exception & ex) {
        set_last_error(std::string("Native generation error: ") + ex.what());
        return utf8_to_jstring(env, "");
    } catch (...) {
        set_last_error("Unknown native generation failure.");
        return utf8_to_jstring(env, "");
    }
}

JNIEXPORT void JNICALL
Java_com_example_ai_local_NativeLlamaBridge_nativeRequestStop(
        JNIEnv * /*env*/,
        jobject /*thiz*/,
        jlong handlePtr) {
    if (handlePtr == 0L) return;
    auto * handle = reinterpret_cast<ModelHandle *>(handlePtr);
    handle->stop_requested.store(true);
}

JNIEXPORT void JNICALL
Java_com_example_ai_local_NativeLlamaBridge_nativeUnloadModel(
        JNIEnv * /*env*/,
        jobject /*thiz*/,
        jlong handlePtr) {
    if (handlePtr == 0L) return;
    auto * handle = reinterpret_cast<ModelHandle *>(handlePtr);
    handle->stop_requested.store(true);
    {
        std::lock_guard<std::mutex> lock(handle->mutex);
    }
    delete handle;
}

JNIEXPORT jstring JNICALL
Java_com_example_ai_local_NativeLlamaBridge_nativeGetModelDescription(
        JNIEnv * env,
        jobject /*thiz*/,
        jlong handlePtr) {
    if (handlePtr == 0L) return utf8_to_jstring(env, "");
    auto * handle = reinterpret_cast<ModelHandle *>(handlePtr);
    std::lock_guard<std::mutex> lock(handle->mutex);
    if (!handle->model) return utf8_to_jstring(env, "");
    char buf[256] = {0};
    int32_t len = llama_model_desc(handle->model, buf, sizeof(buf));
    if (len <= 0) return utf8_to_jstring(env, "");
    return utf8_to_jstring(env, std::string(buf, static_cast<size_t>(std::min<int32_t>(len, static_cast<int32_t>(sizeof(buf) - 1)))));
}

JNIEXPORT jstring JNICALL
Java_com_example_ai_local_NativeLlamaBridge_nativeSystemInfo(
        JNIEnv * env,
        jobject /*thiz*/) {
    ensure_backend_initialized();
    const char * info = llama_print_system_info();
    return utf8_to_jstring(env, info ? info : "");
}

JNIEXPORT jstring JNICALL
Java_com_example_ai_local_NativeLlamaBridge_nativeGetLastError(
        JNIEnv * env,
        jobject /*thiz*/) {
    return utf8_to_jstring(env, get_last_error());
}

} // extern "C"
